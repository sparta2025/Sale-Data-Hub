# VERSION: 1.0.0
# Path: backend/app/main.py
# CHANGES v1.0.0:
#   - Этап 1: FastAPI app, CORS, lifespan (открытие/закрытие DuckDB),
#     include_router(api_router, prefix='/api')
"""
Точка входа FastAPI-приложения.

Запуск (локально, без Docker):
    cd backend
    uvicorn app.main:app --reload --port 8000

Запуск через Docker Compose — см. README.md в корне репозитория.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.router import api_router
from app.core.config import get_settings
from app.db.duckdb_conn import close_connection, get_raw_connection

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Открываем соединение с DuckDB при старте, чтобы файл БД был готов сразу.
    get_raw_connection()
    yield
    close_connection()


app = FastAPI(
    title=settings.app_name,
    debug=settings.debug,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")


@app.get("/")
async def root() -> dict:
    return {"service": settings.app_name, "docs": "/docs"}
