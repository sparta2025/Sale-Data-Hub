# VERSION: 1.6.0
# Path: backend/app/api/router.py
# CHANGES v1.0.0:
#   - Этап 1: api_router + GET /health (мягкая проверка Postgres)
# CHANGES v1.1.0:
#   - Этап 2: подключён data_import_router (prefix='/datasets', tags=['data-import'])
# CHANGES v1.2.0:
#   - Этап 5: подключён dashboard_router (prefix='/dashboards')
# CHANGES v1.3.0:
#   - Этап 6: подключён export_router (prefix='/export')
# CHANGES v1.4.0:
#   - Этап 12: подключён analytics_router (prefix='/analytics')
# CHANGES v1.5.0:
#   - Этап 14: подключён kpi_router (prefix='/kpi')
# CHANGES v1.6.0:
#   - Этап 15: подключён platform_router (prefix='/platform')
"""
Корневой роутер API. По мере появления модулей (Этап 2+) сюда добавляются
include_router(...) для каждого модуля — сам main.py не меняется.
"""
from fastapi import APIRouter

from app.db.postgres import check_postgres_connection
from app.modules.data_import.router import router as data_import_router
from app.modules.metadata.router import router as metadata_router
from app.modules.query_engine.router import router as query_router
from app.modules.dashboard_engine.router import router as dashboard_router
from app.modules.export.router import router as export_router
from app.modules.analytics.router import router as analytics_router
from app.modules.kpi.router import router as kpi_router
from app.modules.platform_registry.router import router as platform_router

api_router = APIRouter()


@api_router.get("/health", tags=["system"])
async def health_check() -> dict:
    postgres_ok = await check_postgres_connection()
    return {"status": "ok", "postgres": "connected" if postgres_ok else "unavailable"}


api_router.include_router(data_import_router, prefix="/datasets", tags=["data-import"])
api_router.include_router(metadata_router, prefix="/metadata", tags=["metadata"])
api_router.include_router(query_router, prefix="/query", tags=["query"])
api_router.include_router(dashboard_router, prefix="/dashboards", tags=["dashboards"])
api_router.include_router(export_router, prefix="/export", tags=["export"])
api_router.include_router(analytics_router, prefix="/analytics", tags=["analytics"])
api_router.include_router(kpi_router, prefix="/kpi", tags=["kpi"])
api_router.include_router(platform_router, prefix="/platform", tags=["platform"])
