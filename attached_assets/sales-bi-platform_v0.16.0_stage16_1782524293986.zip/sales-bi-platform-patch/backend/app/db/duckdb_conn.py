# VERSION: 1.1.0
# Path: backend/app/db/duckdb_conn.py
# CHANGES v1.0.0:
#   - Этап 1: постоянное соединение с DuckDB (get_raw_connection/duckdb_cursor/
#     close_connection), asyncio.Lock для сериализации доступа
# CHANGES v1.1.0:
#   - Этап 9 фикс: QUERY_LOCK экспортируется и используется в QueryService —
#     без явного захвата Lock при каждом _execute_query несколько одновременных
#     chart-запросов вызывали гонку за единственное DuckDB-соединение и крэш
#     (симптом: "Превышено время ожидания ответа сервера" при переключении
#     метрики на дашборде, когда все 7 чартов перезапрашиваются одновременно).
#     DuckDB не поддерживает конкурентный доступ к одному соединению из разных
#     потоков — Lock гарантирует, что в каждый момент времени только один поток
#     держит курсор.
"""
Подключение к DuckDB — здесь живут факт-данные (импортированные строки отчётов)
и выполняются все аналитические SQL-запросы (агрегации для KPI, графиков,
drill-down). Тяжёлые вычисления делаются здесь, а не в Pandas (см. ТЗ).

DuckDB не любит конкурентный доступ на запись из нескольких процессов к одному
файлу, поэтому в рамках одного процесса backend держим одно соединение и
сериализуем запросы через asyncio.Lock. Для FastAPI с одним воркером этого
достаточно; при горизонтальном масштабировании backend необходимо перейти на
DuckDB в режиме "один писатель / много читателей" или на отдельный сервис.
"""
import asyncio
from contextlib import contextmanager
from typing import Iterator

import duckdb

from app.core.config import get_settings

settings = get_settings()

_connection: duckdb.DuckDBPyConnection | None = None

# Глобальный Lock — ЕДИНСТВЕННЫЙ на весь процесс FastAPI.
# Экспортируется в QueryService для захвата перед каждым _execute_query:
#   async with QUERY_LOCK:
#       columns, rows = await asyncio.to_thread(self._execute_query, ...)
# Без этого Lock несколько одновременных asyncio.to_thread-вызовов конкурируют
# за одно duckdb.DuckDBPyConnection, которое не является thread-safe.
QUERY_LOCK = asyncio.Lock()


def get_raw_connection() -> duckdb.DuckDBPyConnection:
    """Создаёт (один раз) и возвращает постоянное соединение с файлом DuckDB."""
    global _connection
    if _connection is None:
        _connection = duckdb.connect(database=str(settings.duckdb_file), read_only=False)
    return _connection


@contextmanager
def duckdb_cursor() -> Iterator[duckdb.DuckDBPyConnection]:
    """
    Контекстный менеджер для синхронного использования (например, в модулях
    импорта данных, которые сами по себе синхронные/CPU-bound).
    НЕ захватывает QUERY_LOCK — это обязанность вызывающего async-кода.
    """
    conn = get_raw_connection()
    yield conn


async def get_duckdb_lock() -> asyncio.Lock:
    """Backward-compat: возвращает QUERY_LOCK. Используйте QUERY_LOCK напрямую."""
    return QUERY_LOCK


def close_connection() -> None:
    """Закрывает соединение — вызывается при остановке приложения."""
    global _connection
    if _connection is not None:
        _connection.close()
        _connection = None
