# VERSION: 1.0.0
# Path: backend/app/db/postgres.py
# CHANGES v1.0.0:
#   - Этап 1: async-движок SQLAlchemy, AsyncSessionLocal, Base, get_db()
#     dependency, check_postgres_connection() для /health
"""
Подключение к PostgreSQL (хранилище метаданных: датасеты, измерения/метрики,
конфигурации дашбордов, координаты филиалов и т.п.).

Используется async SQLAlchemy 2.0. Сами факт-данные (строки отчётов) сюда НЕ
попадают — для них есть DuckDB (см. duckdb_conn.py). Postgres — только метаданные.
"""
from collections.abc import AsyncGenerator

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.core.config import get_settings

settings = get_settings()

# pool_pre_ping — переподключение при разрыве соединения (важно для long-running контейнеров)
engine = create_async_engine(settings.database_url, echo=settings.debug, pool_pre_ping=True)

AsyncSessionLocal = async_sessionmaker(bind=engine, expire_on_commit=False, class_=AsyncSession)


class Base(DeclarativeBase):
    """Базовый класс для всех ORM-моделей метаданных (Этап 3 и далее)."""


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency: выдаёт сессию на запрос и гарантированно закрывает её."""
    async with AsyncSessionLocal() as session:
        yield session


async def check_postgres_connection() -> bool:
    """Используется в /health — не валит приложение, если БД временно недоступна."""
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return True
    except Exception:
        return False
