# VERSION: 1.1.0
# Path: backend/app/modules/query_engine/router.py
# CHANGES v1.0.0:
#   - Этап 4: API /api/query — aggregate, kpi, distinct_values
# CHANGES v1.1.0:
#   - Этап 8 фикс: GET /distinct/{column} принимает filters (JSON-encoded) —
#     каскадная фильтрация значений в FilterBar (Страна -> Филиал и т.п.)
"""API-эндпоинты Query Engine."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.postgres import get_db
from app.modules.query_engine.service import QueryService, QueryValidationError
from app.schemas.query import AggregatedValue, QueryRequest, QueryResult, parse_filters_json

router = APIRouter()

_FILTERS_QUERY_DESCRIPTION = (
    'JSON-encoded карта фильтров, например '
    '{"Страна":{"type":"in","values":["Германия"]}}'
)


@router.post("/{dataset_id}", response_model=QueryResult)
async def run_query(
    dataset_id: str,
    req: QueryRequest,
    db: AsyncSession = Depends(get_db),
) -> QueryResult:
    """
    Основной аналитический запрос: агрегация метрик по измерениям с фильтрами.

    Пример тела запроса:
    ```json
    {
      "dimensions": ["Страна", "Год"],
      "metrics": ["Выручка нетто (EUR)", "Маржа валовой прибыли (%)"],
      "filters": {
        "Год": {"type": "range", "min": 2015, "max": 2020},
        "Страна": {"type": "in", "values": ["Германия", "Франция"]}
      },
      "order_by": "Выручка нетто (EUR)",
      "order_desc": true,
      "limit": 100
    }
    ```
    """
    try:
        return await QueryService(db).execute_query(dataset_id, req)
    except QueryValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Ошибка выполнения запроса: {exc}") from exc


@router.get("/{dataset_id}/kpi", response_model=list[AggregatedValue])
async def get_kpi_totals(
    dataset_id: str,
    metrics: list[str] = Query(..., description="Список метрик через ?metrics=A&metrics=B"),
    db: AsyncSession = Depends(get_db),
) -> list[AggregatedValue]:
    """
    Итоговые агрегаты без группировки — для KPI-карточек на главной странице.
    Пример: GET /api/query/{id}/kpi?metrics=Выручка нетто (EUR)&metrics=Количество
    """
    try:
        return await QueryService(db).get_kpi_totals(dataset_id, metrics)
    except QueryValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/{dataset_id}/distinct/{column_name}", response_model=list)
async def get_distinct_values(
    dataset_id: str,
    column_name: str,
    limit: int = Query(200, ge=1, le=1000),
    filters: str | None = Query(None, description=_FILTERS_QUERY_DESCRIPTION),
    db: AsyncSession = Depends(get_db),
) -> list:
    """
    Уникальные значения измерения для наполнения выпадающих фильтров в UI.

    filters (опционально) — каскадное сужение по остальным активным фильтрам:
    GET /distinct/Филиал?filters={"Страна":{"type":"in","values":["Германия"]}}
    вернёт только филиалы Германии, а не все филиалы датасета.
    """
    try:
        parsed_filters = parse_filters_json(filters)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"Некорректный параметр filters: {exc}") from exc

    try:
        return await QueryService(db).get_distinct_values(dataset_id, column_name, limit, parsed_filters)
    except QueryValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
