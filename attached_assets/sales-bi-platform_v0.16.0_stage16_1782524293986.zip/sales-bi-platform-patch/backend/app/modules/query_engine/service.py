# VERSION: 1.1.0
# Path: backend/app/modules/query_engine/service.py
# CHANGES v1.0.0:
#   - Этап 4: QueryService — валидация, построение SQL, выполнение через DuckDB
# CHANGES v1.1.0:
#   - Этап 8 фикс: get_distinct_values принимает filters — каскадная
#     фильтрация значений в выпадающих списках FilterBar
"""
QueryService — аналитический движок поверх DuckDB.

Порядок работы:
  1. Загружает метаданные датасета из Postgres (dimensions + metrics).
  2. Валидирует запрос: все запрошенные колонки должны быть в метаданных.
  3. Строит SQL через sql_builder (безопасный построитель с параметрами).
  4. Выполняет SQL в DuckDB асинхронно (asyncio.to_thread).
  5. Возвращает QueryResult со строками, столбцами и временем выполнения.

Кэширование не реализовано на этом этапе — DuckDB крайне быстр на 500k строк
(обычно < 50 мс), поэтому кэш добавим только если профилирование покажет нужду.
"""
import asyncio
import time
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.duckdb_conn import duckdb_cursor, QUERY_LOCK
from app.models.dataset import Dataset
from app.models.metadata import Dimension, Metric
from app.modules.query_engine.sql_builder import (
    build_aggregation_query,
    build_distinct_values_query,
    build_kpi_query,
)
from app.schemas.query import AggregatedValue, FilterSpec, QueryRequest, QueryResult


class QueryValidationError(ValueError):
    pass


class QueryService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def _load_dataset(self, dataset_id: str) -> Dataset:
        ds = await self.db.get(Dataset, uuid.UUID(dataset_id))
        if ds is None:
            raise QueryValidationError(f"Датасет {dataset_id} не найден")
        return ds

    async def _load_metrics_map(self, dataset_id: str) -> dict[str, Metric]:
        uuid_id = uuid.UUID(dataset_id)
        result = await self.db.execute(
            select(Metric).where(Metric.dataset_id == uuid_id)
        )
        return {m.column_name: m for m in result.scalars().all()}

    async def _load_dimensions_map(self, dataset_id: str) -> dict[str, Dimension]:
        uuid_id = uuid.UUID(dataset_id)
        result = await self.db.execute(
            select(Dimension).where(Dimension.dataset_id == uuid_id)
        )
        return {d.column_name: d for d in result.scalars().all()}

    def _validate_columns(
        self,
        requested: list[str],
        available: dict,
        kind: str,
    ) -> None:
        unknown = [c for c in requested if c not in available]
        if unknown:
            raise QueryValidationError(
                f"Неизвестные {kind}: {unknown}. "
                f"Доступные: {sorted(available.keys())}"
            )

    def _execute_query(self, sql: str, params: list) -> tuple[list[str], list[dict]]:
        """Синхронная функция для запуска в asyncio.to_thread."""
        with duckdb_cursor() as conn:
            result = conn.execute(sql, params)
            columns = [desc[0] for desc in result.description]
            rows = [dict(zip(columns, row)) for row in result.fetchall()]
        return columns, rows

    async def execute_query(self, dataset_id: str, req: QueryRequest) -> QueryResult:
        ds = await self._load_dataset(dataset_id)
        dims_map = await self._load_dimensions_map(dataset_id)
        mets_map = await self._load_metrics_map(dataset_id)

        all_columns = {**dims_map, **mets_map}

        self._validate_columns(req.dimensions, dims_map, "измерения (dimensions)")
        self._validate_columns(req.metrics, mets_map, "метрики (metrics)")
        self._validate_columns(list(req.filters.keys()), all_columns, "колонки фильтров")

        if req.order_by and req.order_by not in all_columns:
            raise QueryValidationError(f"order_by: колонка {req.order_by!r} не найдена")

        metrics_with_agg = [
            (col, mets_map[col].aggregation) for col in req.metrics
        ]

        plan = build_aggregation_query(
            table_name=ds.duckdb_table,
            dimensions=req.dimensions,
            metrics=metrics_with_agg,
            filters=req.filters,
            order_by=req.order_by,
            order_desc=req.order_desc,
            limit=req.limit,
        )

        t0 = time.perf_counter()
        async with QUERY_LOCK:
            columns, rows = await asyncio.to_thread(self._execute_query, plan.sql, plan.params)
        elapsed_ms = (time.perf_counter() - t0) * 1000

        return QueryResult(
            dataset_id=dataset_id,
            columns=columns,
            rows=rows,
            total_rows=len(rows),
            sql=plan.sql,
            execution_ms=round(elapsed_ms, 2),
        )

    async def get_kpi_totals(
        self,
        dataset_id: str,
        metric_names: list[str],
        filters: dict[str, FilterSpec] | None = None,
    ) -> list[AggregatedValue]:
        """Итоговые значения метрик без группировки — для KPI-карточек."""
        ds = await self._load_dataset(dataset_id)
        mets_map = await self._load_metrics_map(dataset_id)
        self._validate_columns(metric_names, mets_map, "метрики")

        metrics_with_agg = [(col, mets_map[col].aggregation) for col in metric_names]
        plan = build_kpi_query(
            table_name=ds.duckdb_table,
            metrics=metrics_with_agg,
            filters=filters or {},
        )

        async with QUERY_LOCK:
            _columns, rows = await asyncio.to_thread(self._execute_query, plan.sql, plan.params)
        row = rows[0] if rows else {}

        return [
            AggregatedValue(
                metric=col,
                display_name=mets_map[col].display_name,
                value=row.get(col),
                aggregation=mets_map[col].aggregation,
                display_format=mets_map[col].display_format,
            )
            for col in metric_names
        ]

    async def get_distinct_values(
        self,
        dataset_id: str,
        column_name: str,
        limit: int = 200,
        filters: dict[str, FilterSpec] | None = None,
    ) -> list:
        """
        Уникальные значения измерения для наполнения фильтров в UI.

        filters (опционально) — каскадное сужение по остальным активным
        фильтрам: например при выборе Страна=Германия список значений
        Филиал должен показывать только филиалы Германии, а не все
        9 филиалов датасета (см. Этап 8 фикс).
        """
        ds = await self._load_dataset(dataset_id)
        dims_map = await self._load_dimensions_map(dataset_id)
        mets_map = await self._load_metrics_map(dataset_id)
        all_columns = {**dims_map, **mets_map}

        if column_name not in dims_map:
            raise QueryValidationError(f"Измерение {column_name!r} не найдено")
        self._validate_columns(list((filters or {}).keys()), all_columns, "колонки фильтров")

        plan = build_distinct_values_query(ds.duckdb_table, column_name, filters or {}, limit)
        async with QUERY_LOCK:
            _cols, rows = await asyncio.to_thread(self._execute_query, plan.sql, plan.params)
        return [r[column_name] for r in rows]
