# VERSION: 1.1.0
# Path: backend/app/modules/query_engine/sql_builder.py
# CHANGES v1.0.0:
#   - Этап 4: построитель SQL-запросов для DuckDB (GROUP BY + фильтры + агрегации)
# CHANGES v1.1.0:
#   - Этап 8 фикс: построение WHERE вынесено в _build_where() — переиспользуется
#     в build_aggregation_query и build_distinct_values_query (последний теперь
#     тоже принимает filters — нужно для каскадной фильтрации в FilterBar:
#     выбор "Страна=Германия" должен сужать список значений "Филиал")
"""
Безопасный построитель SQL для DuckDB.

Принципы безопасности:
  - Имена колонок передаются в белый список (только те, что есть в метаданных)
    и экранируются двойными кавычками — защита от SQL injection через имена.
  - Значения фильтров передаются как параметры (?, ?, ?) — защита от SQL injection
    через значения. DuckDB поддерживает позиционные параметры.
  - Лимит принудительно ограничен на уровне схемы (max 50 000).

Функции агрегации берутся из таблицы metrics в Postgres (service.py) и
не могут быть произвольно заданы клиентом — только sum/avg/count/min/max.
"""
from dataclasses import dataclass, field

from app.schemas.query import EqFilter, FilterSpec, InFilter, RangeFilter

_SAFE_AGG = {"sum", "avg", "count", "min", "max"}


def _q(name: str) -> str:
    """Экранирует имя колонки двойными кавычками для DuckDB."""
    return f'"{name.replace(chr(34), "")}"'


@dataclass
class QueryPlan:
    """Готовый SQL-запрос с параметрами."""
    sql: str
    params: list = field(default_factory=list)


def _build_where(filters: dict[str, FilterSpec]) -> tuple[str, list]:
    """
    Строит WHERE-clause и список параметров из карты фильтров.
    Общая логика для build_aggregation_query и build_distinct_values_query —
    одинаковое поведение фильтров везде, где они применяются.
    """
    params: list = []
    where_parts: list[str] = []

    for col_name, filt in filters.items():
        col_q = _q(col_name)

        if isinstance(filt, EqFilter):
            where_parts.append(f"{col_q} = ?")
            params.append(filt.value)

        elif isinstance(filt, InFilter):
            if not filt.values:
                continue
            placeholders = ", ".join("?" * len(filt.values))
            where_parts.append(f"{col_q} IN ({placeholders})")
            params.extend(filt.values)

        elif isinstance(filt, RangeFilter):
            if filt.min is not None and filt.max is not None:
                where_parts.append(f"{col_q} BETWEEN ? AND ?")
                params.extend([filt.min, filt.max])
            elif filt.min is not None:
                where_parts.append(f"{col_q} >= ?")
                params.append(filt.min)
            elif filt.max is not None:
                where_parts.append(f"{col_q} <= ?")
                params.append(filt.max)

    where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""
    return where_clause, params


def build_aggregation_query(
    table_name: str,
    dimensions: list[str],                    # имена колонок GROUP BY
    metrics: list[tuple[str, str]],           # [(column_name, aggregation), ...]
    filters: dict[str, FilterSpec],
    order_by: str | None = None,
    order_desc: bool = False,
    limit: int = 1000,
    allowed_columns: set[str] | None = None,  # белый список для валидации
) -> QueryPlan:
    """
    Строит SQL вида:
      SELECT dim1, dim2, SUM("metric1") AS "metric1", AVG("metric2") AS "metric2"
      FROM "dataset_<uuid>"
      WHERE dim1 IN (?, ?) AND dim2 BETWEEN ? AND ?
      GROUP BY dim1, dim2
      ORDER BY dim1
      LIMIT 1000
    """
    # ── SELECT ────────────────────────────────────────────────────────────────
    select_parts: list[str] = []
    for dim in dimensions:
        select_parts.append(_q(dim))

    for col_name, agg in metrics:
        agg_lower = agg.lower()
        if agg_lower not in _SAFE_AGG:
            raise ValueError(f"Недопустимая агрегация: {agg!r}")
        select_parts.append(f"{agg_lower.upper()}({_q(col_name)}) AS {_q(col_name)}")

    if not select_parts:
        raise ValueError("Запрос должен содержать хотя бы одно измерение или метрику")

    select_clause = ", ".join(select_parts)

    # ── WHERE ─────────────────────────────────────────────────────────────────
    where_clause, params = _build_where(filters)

    # ── GROUP BY ──────────────────────────────────────────────────────────────
    group_clause = ""
    if dimensions and metrics:
        group_clause = "GROUP BY " + ", ".join(_q(d) for d in dimensions)

    # ── ORDER BY ──────────────────────────────────────────────────────────────
    if order_by:
        direction = "DESC" if order_desc else "ASC"
        order_clause = f"ORDER BY {_q(order_by)} {direction}"
    elif dimensions:
        order_clause = f"ORDER BY {_q(dimensions[0])} ASC"
    else:
        order_clause = ""

    # ── LIMIT ─────────────────────────────────────────────────────────────────
    limit_clause = f"LIMIT {int(limit)}"

    parts = [
        f"SELECT {select_clause}",
        f'FROM "{table_name}"',
        where_clause,
        group_clause,
        order_clause,
        limit_clause,
    ]
    sql = "\n".join(p for p in parts if p)
    return QueryPlan(sql=sql, params=params)


def build_kpi_query(
    table_name: str,
    metrics: list[tuple[str, str]],  # [(column_name, aggregation), ...]
    filters: dict[str, FilterSpec],
) -> QueryPlan:
    """Запрос без GROUP BY — одна строка с итогами по всему датасету (для KPI-карточек)."""
    return build_aggregation_query(
        table_name=table_name,
        dimensions=[],
        metrics=metrics,
        filters=filters,
        limit=1,
    )


def build_distinct_values_query(
    table_name: str,
    column_name: str,
    filters: dict[str, FilterSpec] | None = None,
    limit: int = 200,
) -> QueryPlan:
    """
    Список уникальных значений измерения для фильтра в UI.

    filters (опционально) — каскадное сужение: например при выборе
    Страна=Германия список значений Филиал должен показывать только
    филиалы Германии. Вызывающая сторона обычно передаёт текущие активные
    фильтры БЕЗ фильтра по самой column_name (иначе результат тривиально
    схлопнется к уже выбранным значениям).
    """
    where_clause, params = _build_where(filters or {})
    parts = [
        f"SELECT DISTINCT {_q(column_name)}",
        f'FROM "{table_name}"',
        where_clause,
        f"ORDER BY {_q(column_name)}",
        f"LIMIT {int(limit)}",
    ]
    sql = "\n".join(p for p in parts if p)
    return QueryPlan(sql=sql, params=params)
