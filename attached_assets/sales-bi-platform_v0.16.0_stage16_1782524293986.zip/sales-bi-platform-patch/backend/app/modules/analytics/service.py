# VERSION: 1.0.0
# Path: backend/app/modules/analytics/service.py
# CHANGES v1.0.0:
#   - Этап 12: AnalyticsService.describe() — статистическая сводка по метрикам.
#     Для каждой видимой метрики выполняет один SQL-запрос к DuckDB с агрегатами:
#     count, null_count, min, max, avg, median, stddev, Q1, Q3.
#     Используется фильтрация через фильтры запроса (опционально).
import asyncio
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.duckdb_conn import QUERY_LOCK, duckdb_cursor
from app.models.dataset import Dataset
from app.models.metadata import Metric
from app.schemas.analytics import ColumnStats, DescribeResponse


class AnalyticsService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def _load_dataset(self, dataset_id: str) -> Dataset:
        ds = await self.db.get(Dataset, uuid.UUID(dataset_id))
        if ds is None:
            raise ValueError(f"Датасет {dataset_id} не найден")
        return ds

    async def _load_metrics(self, dataset_id: str) -> list[Metric]:
        result = await self.db.execute(
            select(Metric)
            .where(Metric.dataset_id == uuid.UUID(dataset_id))
            .where(Metric.is_visible == True)  # noqa: E712
        )
        return list(result.scalars().all())

    def _build_stats_sql(self, table: str, col: str) -> str:
        """Один SELECT: все агрегаты для одной колонки."""
        safe_col = f'"{col}"'
        safe_tbl = f'"{table}"'
        return f"""
        SELECT
            COUNT(*)                                                  AS total,
            COUNT(*) - COUNT({safe_col})                             AS null_count,
            MIN({safe_col})                                          AS min_val,
            MAX({safe_col})                                          AS max_val,
            AVG({safe_col})                                          AS mean_val,
            MEDIAN({safe_col})                                       AS median_val,
            STDDEV({safe_col})                                       AS std_val,
            PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY {safe_col}) AS q1_val,
            PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY {safe_col}) AS q3_val
        FROM {safe_tbl}
        """

    async def describe(self, dataset_id: str) -> DescribeResponse:
        ds      = await self._load_dataset(dataset_id)
        metrics = await self._load_metrics(dataset_id)

        if not metrics:
            return DescribeResponse(dataset_id=dataset_id, columns=[])

        table = ds.duckdb_table_name
        columns: list[ColumnStats] = []

        for metric in metrics:
            sql = self._build_stats_sql(table, metric.column_name)

            def _run(sql=sql):
                with duckdb_cursor() as cur:
                    cur.execute(sql)
                    return cur.fetchone()

            async with QUERY_LOCK:
                row = await asyncio.to_thread(_run)

            if row is None:
                continue

            total, nulls, mn, mx, mean, med, std, q1, q3 = row

            total  = int(total or 0)
            nulls  = int(nulls or 0)
            mn     = float(mn or 0)
            mx     = float(mx or 0)
            mean   = float(mean or 0)
            med    = float(med or 0)
            std    = float(std or 0)
            q1     = float(q1 or 0)
            q3     = float(q3 or 0)

            columns.append(ColumnStats(
                column_name=metric.column_name,
                display_name=metric.display_name,
                count=total,
                null_count=nulls,
                null_pct=round(nulls / total * 100, 2) if total > 0 else 0.0,
                min=mn,
                max=mx,
                mean=round(mean, 4),
                median=round(med, 4),
                std=round(std, 4),
                q1=round(q1, 4),
                q3=round(q3, 4),
                iqr=round(q3 - q1, 4),
                cv=round(std / mean * 100, 2) if mean != 0 else 0.0,
            ))

        return DescribeResponse(dataset_id=dataset_id, columns=columns)
