# VERSION: 1.0.0
# Path: backend/app/modules/analytics/router.py
# CHANGES v1.0.0:
#   - Этап 12: GET /analytics/{dataset_id}/describe
#     Возвращает статистическую сводку по всем видимым метрикам:
#     min, max, mean, median, Q1, Q3, std, IQR, CV, null%.
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.postgres import get_db
from app.modules.analytics.service import AnalyticsService
from app.schemas.analytics import DescribeResponse

router = APIRouter()


@router.get(
    "/{dataset_id}/describe",
    response_model=DescribeResponse,
    summary="Статистическая сводка по метрикам датасета",
)
async def describe_dataset(
    dataset_id: str,
    db: AsyncSession = Depends(get_db),
) -> DescribeResponse:
    """
    Возвращает min, max, mean, median, Q1, Q3, std, IQR, CV, null%
    для каждой видимой числовой метрики датасета.
    Вычисляется в DuckDB одним SQL-запросом на колонку.
    """
    svc = AnalyticsService(db)
    return await svc.describe(dataset_id)
