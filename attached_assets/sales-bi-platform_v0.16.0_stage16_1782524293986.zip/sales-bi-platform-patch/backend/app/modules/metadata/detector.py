# VERSION: 2.0.0
# Path: backend/app/modules/metadata/detector.py
# CHANGES v1.0.0:
#   - Этап 3: автоопределение иерархий (время/гео/товар), агрегаций и форматов;
#     строит Dimension/Metric-записи из column_profile датасета
# CHANGES v2.0.0:
#   - Этап 8: форматы отображения (FORMAT_CURRENCY/PERCENTAGE/INTEGER/FLOAT)
#     и ключевые слова иерархий (HIERARCHY_*_KEYWORDS) вынесены в .env/config.py.
#     _HIERARCHY_RULES и _FORMAT_MAP теперь строятся из Settings — можно
#     добавлять свои типы иерархий или менять символ валюты без правки кода.
"""
Автоматическое построение «словаря данных» из column_profile.

Иерархии строятся по ключевым словам в названии колонки:
  time      → Год → Месяц  (drill-down по времени)
  geography → Страна → Филиал  (drill-down по географии)
  product   → Товарная группа → Товар  (drill-down по товарам)

Агрегация по умолчанию:
  currency / integer → SUM   (суммируем выручку, количество)
  percentage         → AVG   (маржу усредняем, а не суммируем)
  float              → SUM

Формат отображения — читается из Settings (см. .env.example):
  currency    → FORMAT_CURRENCY   (по умолчанию "€ {:,.2f}")
  percentage  → FORMAT_PERCENTAGE (по умолчанию "{:.1%}")
  integer     → FORMAT_INTEGER    (по умолчанию "{:,.0f}")
  float       → FORMAT_FLOAT      (по умолчанию "{:,.2f}")
"""
from dataclasses import dataclass

from app.core.config import get_settings


def _build_hierarchy_rules() -> list[tuple[str, str, int, list[str]]]:
    """
    Строит список правил иерархий из Settings.
    Каждая запись: (group, label_ru, level, keywords).
    keywords разбиваются по символу | из строки окружения.
    """
    s = get_settings()
    return [
        ("time",      "Временна́я",     0, s.hierarchy_time_l0_keywords.split("|")),
        ("time",      "Временна́я",     1, s.hierarchy_time_l1_keywords.split("|")),
        ("geography", "Географическая", 0, s.hierarchy_geo_l0_keywords.split("|")),
        ("geography", "Географическая", 1, s.hierarchy_geo_l1_keywords.split("|")),
        ("product",   "Товарная",       0, s.hierarchy_product_l0_keywords.split("|")),
        ("product",   "Товарная",       1, s.hierarchy_product_l1_keywords.split("|")),
    ]


def _build_format_map() -> dict[str, str]:
    """Строит карту форматов отображения из Settings."""
    s = get_settings()
    return {
        "currency":   s.format_currency,
        "percentage": s.format_percentage,
        "integer":    s.format_integer,
        "float":      s.format_float,
    }


# Модульные константы — вычисляются один раз при первом импорте модуля.
# Если Settings изменились (например в тестах через monkeypatch), вызывайте
# _build_hierarchy_rules()/_build_format_map() заново.
_HIERARCHY_RULES = _build_hierarchy_rules()
_FORMAT_MAP = _build_format_map()
_HIERARCHY_LABELS: dict[str, str] = {
    "time":      "Временнáя иерархия",
    "geography": "Географическая иерархия",
    "product":   "Товарная иерархия",
}

# ── Агрегация ──────────────────────────────────────────────────────────────
_AGGREGATION_MAP: dict[str, str] = {
    "currency":   "sum",
    "integer":    "sum",
    "float":      "sum",
    "percentage": "avg",
}


@dataclass
class DimensionSpec:
    column_name: str
    display_name: str
    data_type: str
    hierarchy_group: str | None
    hierarchy_level: int
    sample_values: list
    distinct_count: int


@dataclass
class MetricSpec:
    column_name: str
    display_name: str
    data_type: str
    aggregation: str
    display_format: str


def _detect_hierarchy(name_lower: str) -> tuple[str | None, int]:
    """Возвращает (group, level) или (None, 0)."""
    for group, _label, level, keywords in _HIERARCHY_RULES:
        if any(kw in name_lower for kw in keywords):
            return group, level
    return None, 0


def build_specs(column_profile: list[dict]) -> tuple[list[DimensionSpec], list[MetricSpec]]:
    """
    Из column_profile (список словарей) строит готовые спецификации
    Dimension и Metric для записи в Postgres.
    """
    dimensions: list[DimensionSpec] = []
    metrics: list[MetricSpec] = []

    for col in column_profile:
        name = col["name"]
        role = col["role"]
        data_type = col["data_type"]
        name_lower = name.lower()

        if role == "dimension":
            h_group, h_level = _detect_hierarchy(name_lower)
            dimensions.append(DimensionSpec(
                column_name=name,
                display_name=name,
                data_type=data_type,
                hierarchy_group=h_group,
                hierarchy_level=h_level,
                sample_values=col.get("sample_values", []),
                distinct_count=col.get("distinct_count", 0),
            ))
        else:
            metrics.append(MetricSpec(
                column_name=name,
                display_name=name,
                data_type=data_type,
                aggregation=_AGGREGATION_MAP.get(data_type, "sum"),
                display_format=_FORMAT_MAP.get(data_type, "{:.2f}"),
            ))

    return dimensions, metrics


def get_hierarchy_label(group: str) -> str:
    return _HIERARCHY_LABELS.get(group, group.capitalize())
