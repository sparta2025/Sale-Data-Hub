# VERSION: 1.0.0
# Path: backend/app/modules/metadata/service.py
# CHANGES v1.0.0:
#   - Этап 3: MetadataService — build/refresh/query метаданных датасета
"""
MetadataService управляет «словарём данных» датасета:
  - build_metadata: первичное создание Dimension/Metric из column_profile
  - refresh_metadata: пересоздание (после повторного импорта или ручных правок)
  - get_overview: полная структура для API
  - patch_dimension / patch_metric: ручное редактирование пользователем

build_metadata вызывается автоматически из DataImportService после успешного
импорта. Это сделано намеренно «снаружи» сервиса импорта, чтобы каждый модуль
решал только свою задачу (Single Responsibility).
"""
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.dataset import Dataset
from app.models.metadata import Dimension, Metric
from app.modules.metadata.detector import build_specs, get_hierarchy_label
from app.schemas.metadata import (
    DimensionOut, DimensionPatch,
    HierarchyInfo, MetadataOverview,
    MetricOut, MetricPatch,
)


class MetadataNotFoundError(LookupError):
    pass


class MetadataService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def build_metadata(self, dataset: Dataset) -> None:
        """
        Строит Dimension/Metric из column_profile датасета.
        Вызывается один раз сразу после успешного импорта.
        Если метаданные уже существуют — ничего не делает (idempotent).
        """
        existing = await self.db.execute(
            select(Dimension).where(Dimension.dataset_id == dataset.id).limit(1)
        )
        if existing.scalars().first() is not None:
            return  # уже построены

        dim_specs, metric_specs = build_specs(dataset.column_profile)

        for spec in dim_specs:
            self.db.add(Dimension(
                dataset_id=dataset.id,
                column_name=spec.column_name,
                display_name=spec.display_name,
                data_type=spec.data_type,
                hierarchy_group=spec.hierarchy_group,
                hierarchy_level=spec.hierarchy_level,
                sample_values=spec.sample_values,
                distinct_count=spec.distinct_count,
            ))

        for spec in metric_specs:
            self.db.add(Metric(
                dataset_id=dataset.id,
                column_name=spec.column_name,
                display_name=spec.display_name,
                data_type=spec.data_type,
                aggregation=spec.aggregation,
                display_format=spec.display_format,
            ))

        await self.db.commit()

    async def refresh_metadata(self, dataset_id: str) -> None:
        """
        Удаляет и пересоздаёт метаданные датасета.
        Сбрасывает ручные правки пользователя — предупреждать в API.
        """
        did = uuid.UUID(dataset_id)
        dataset = await self.db.get(Dataset, did)
        if dataset is None:
            raise MetadataNotFoundError(f"Датасет {dataset_id} не найден")

        # CASCADE в FK удалит Dimension/Metric при удалении Dataset — но мы
        # хотим удалить только метаданные, оставив сам датасет. Делаем вручную.
        dims = await self.db.execute(select(Dimension).where(Dimension.dataset_id == did))
        for d in dims.scalars().all():
            await self.db.delete(d)

        mets = await self.db.execute(select(Metric).where(Metric.dataset_id == did))
        for m in mets.scalars().all():
            await self.db.delete(m)

        await self.db.flush()

        dim_specs, metric_specs = build_specs(dataset.column_profile)

        for spec in dim_specs:
            self.db.add(Dimension(
                dataset_id=dataset.id,
                column_name=spec.column_name,
                display_name=spec.display_name,
                data_type=spec.data_type,
                hierarchy_group=spec.hierarchy_group,
                hierarchy_level=spec.hierarchy_level,
                sample_values=spec.sample_values,
                distinct_count=spec.distinct_count,
            ))
        for spec in metric_specs:
            self.db.add(Metric(
                dataset_id=dataset.id,
                column_name=spec.column_name,
                display_name=spec.display_name,
                data_type=spec.data_type,
                aggregation=spec.aggregation,
                display_format=spec.display_format,
            ))

        await self.db.commit()

    async def get_overview(self, dataset_id: str) -> MetadataOverview:
        did = uuid.UUID(dataset_id)
        dims_result = await self.db.execute(
            select(Dimension).where(Dimension.dataset_id == did).order_by(Dimension.hierarchy_group, Dimension.hierarchy_level)
        )
        dims = dims_result.scalars().all()

        mets_result = await self.db.execute(
            select(Metric).where(Metric.dataset_id == did)
        )
        mets = mets_result.scalars().all()

        if not dims and not mets:
            raise MetadataNotFoundError(f"Метаданные для датасета {dataset_id} не найдены")

        # Собираем иерархии
        groups: dict[str, list[Dimension]] = {}
        for d in dims:
            if d.hierarchy_group:
                groups.setdefault(d.hierarchy_group, []).append(d)

        hierarchies = [
            HierarchyInfo(
                name=group,
                label=get_hierarchy_label(group),
                levels=sorted(
                    [DimensionOut.model_validate(d) for d in members],
                    key=lambda x: x.hierarchy_level,
                ),
            )
            for group, members in groups.items()
        ]

        return MetadataOverview(
            dataset_id=did,
            dimensions_count=len(dims),
            metrics_count=len(mets),
            hierarchies=hierarchies,
            dimensions=[DimensionOut.model_validate(d) for d in dims],
            metrics=[MetricOut.model_validate(m) for m in mets],
        )

    async def get_dimensions(self, dataset_id: str) -> list[Dimension]:
        did = uuid.UUID(dataset_id)
        result = await self.db.execute(
            select(Dimension).where(Dimension.dataset_id == did)
            .order_by(Dimension.hierarchy_group, Dimension.hierarchy_level)
        )
        return list(result.scalars().all())

    async def get_metrics(self, dataset_id: str) -> list[Metric]:
        did = uuid.UUID(dataset_id)
        result = await self.db.execute(
            select(Metric).where(Metric.dataset_id == did)
        )
        return list(result.scalars().all())

    async def patch_dimension(self, dimension_id: str, patch: DimensionPatch) -> Dimension:
        dim = await self.db.get(Dimension, uuid.UUID(dimension_id))
        if dim is None:
            raise MetadataNotFoundError(f"Измерение {dimension_id} не найдено")
        for field, value in patch.model_dump(exclude_none=True).items():
            setattr(dim, field, value)
        await self.db.commit()
        await self.db.refresh(dim)
        return dim

    async def patch_metric(self, metric_id: str, patch: MetricPatch) -> Metric:
        met = await self.db.get(Metric, uuid.UUID(metric_id))
        if met is None:
            raise MetadataNotFoundError(f"Метрика {metric_id} не найдена")
        for field, value in patch.model_dump(exclude_none=True).items():
            setattr(met, field, value)
        await self.db.commit()
        await self.db.refresh(met)
        return met
