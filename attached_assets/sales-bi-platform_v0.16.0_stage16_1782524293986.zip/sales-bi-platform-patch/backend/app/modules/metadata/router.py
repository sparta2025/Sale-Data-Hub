# VERSION: 1.0.0
# Path: backend/app/modules/metadata/router.py
# CHANGES v1.0.0:
#   - Этап 3: API /api/metadata — overview, dimensions, metrics, patch, refresh
"""API-эндпоинты Metadata Module."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.postgres import get_db
from app.modules.metadata.service import MetadataNotFoundError, MetadataService
from app.schemas.metadata import (
    DimensionOut, DimensionPatch,
    MetadataOverview,
    MetricOut, MetricPatch,
)

router = APIRouter()


@router.get("/{dataset_id}", response_model=MetadataOverview)
async def get_metadata_overview(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """Полная структура датасета: измерения, метрики, иерархии."""
    try:
        return await MetadataService(db).get_overview(dataset_id)
    except (MetadataNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{dataset_id}/dimensions", response_model=list[DimensionOut])
async def get_dimensions(dataset_id: str, db: AsyncSession = Depends(get_db)):
    dims = await MetadataService(db).get_dimensions(dataset_id)
    return [DimensionOut.model_validate(d) for d in dims]


@router.get("/{dataset_id}/metrics", response_model=list[MetricOut])
async def get_metrics(dataset_id: str, db: AsyncSession = Depends(get_db)):
    mets = await MetadataService(db).get_metrics(dataset_id)
    return [MetricOut.model_validate(m) for m in mets]


@router.post("/{dataset_id}/refresh", response_model=MetadataOverview)
async def refresh_metadata(dataset_id: str, db: AsyncSession = Depends(get_db)):
    """
    Пересоздаёт метаданные из column_profile датасета.
    ВНИМАНИЕ: сбрасывает ручные правки (display_name, aggregation и т.п.).
    """
    try:
        svc = MetadataService(db)
        await svc.refresh_metadata(dataset_id)
        return await svc.get_overview(dataset_id)
    except (MetadataNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.patch("/dimensions/{dimension_id}", response_model=DimensionOut)
async def patch_dimension(
    dimension_id: str, patch: DimensionPatch, db: AsyncSession = Depends(get_db)
):
    """Ручное редактирование измерения: display_name, иерархия, видимость."""
    try:
        dim = await MetadataService(db).patch_dimension(dimension_id, patch)
        return DimensionOut.model_validate(dim)
    except (MetadataNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.patch("/metrics/{metric_id}", response_model=MetricOut)
async def patch_metric(
    metric_id: str, patch: MetricPatch, db: AsyncSession = Depends(get_db)
):
    """Ручное редактирование метрики: display_name, aggregation, формат."""
    try:
        met = await MetadataService(db).patch_metric(metric_id, patch)
        return MetricOut.model_validate(met)
    except (MetadataNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
