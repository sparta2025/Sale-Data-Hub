# VERSION: 1.0.0
# Path: backend/app/modules/data_import/service.py
# CHANGES v1.0.0:
#   - Этап 2: DataImportService — реализация IDataProvider; объединяет file_reader/
#     structure_detector/cleaner/duckdb_writer + регистрация датасета в Postgres
"""
DataImportService — конкретная реализация IDataProvider (см. Этап 1,
app/interfaces/data_provider.py). Связывает воедино файл-ридер, детектор
структуры, очистку и запись в DuckDB, плюс регистрирует датасет в Postgres.

Это единственное место, которое знает обо ВСЕХ деталях импорта — Query Engine
и Dashboard Engine (Этапы 4-5) будут работать только с зарегистрированными
датасетами через эту запись в Postgres, не заботясь о том, как именно
происходила загрузка.
"""
import asyncio
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.interfaces import IDataProvider, ImportResult
from app.models.dataset import Dataset
from app.modules.data_import.cleaner import clean_dataframe
from app.modules.data_import.duckdb_writer import drop_dataset_table, fetch_preview, make_table_name, write_dataset_table
from app.modules.data_import.file_reader import read_table_file
from app.modules.data_import.structure_detector import detect_column_profiles
from app.schemas.dataset import ColumnProfile


class DatasetNotFoundError(LookupError):
    pass


class DataImportService(IDataProvider):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def validate_structure(self, source: Path) -> list[str]:
        """Быстрая проверка без полного импорта — например, для предпросмотра перед загрузкой."""
        problems: list[str] = []
        try:
            df, _info = await asyncio.to_thread(read_table_file, source, source.name)
        except Exception as exc:  # noqa: BLE001
            return [f"Не удалось прочитать файл: {exc}"]

        if df.empty:
            problems.append("Файл не содержит строк данных")
        if df.shape[1] < 2:
            problems.append("Файл должен содержать как минимум 2 столбца")
        if df.columns.duplicated().any():
            dupes = df.columns[df.columns.duplicated()].tolist()
            problems.append(f"Обнаружены повторяющиеся названия столбцов: {dupes}")
        return problems

    async def import_data(self, source: Path, dataset_name: str) -> ImportResult:
        """
        source — путь к уже сохранённому на диск файлу (см. router.py: файл
        сначала сохраняется в upload_dir, потом передаётся сюда по пути).
        """
        original_filename = source.name

        # pandas/openpyxl — синхронные и потенциально небыстрые на больших
        # файлах операции; не блокируем event loop FastAPI.
        df, read_info = await asyncio.to_thread(read_table_file, source, original_filename)

        structure_warnings = await self.validate_structure(source)
        profiles: list[ColumnProfile] = detect_column_profiles(df)
        cleaned_df, cleaning_warnings = clean_dataframe(df, profiles)

        dataset = Dataset(
            name=dataset_name,
            original_filename=original_filename,
            source_format=read_info["format"],
            duckdb_table="",  # заполним после получения id (см. ниже)
            row_count=len(cleaned_df),
            column_count=len(cleaned_df.columns),
            status="ready",
            warnings=structure_warnings + cleaning_warnings,
            column_profile=[p.model_dump() for p in profiles],
        )
        self.db.add(dataset)
        await self.db.flush()  # получаем dataset.id (генерируется default=uuid4 на стороне Python — id уже есть после add())

        table_name = make_table_name(str(dataset.id))
        dataset.duckdb_table = table_name

        try:
            await asyncio.to_thread(write_dataset_table, table_name, cleaned_df)
        except Exception:
            dataset.status = "failed"
            await self.db.commit()
            raise

        await self.db.commit()

        # Строим метаданные (Dimension/Metric) сразу после успешного импорта.
        # Импортируем здесь, а не на уровне модуля — избегаем циклического импорта
        # (metadata.service → models.dataset, data_import.service → models.dataset).
        from app.modules.metadata.service import MetadataService
        await MetadataService(self.db).build_metadata(dataset)

        return ImportResult(
            dataset_id=str(dataset.id),
            rows_imported=len(cleaned_df),
            rows_rejected=len(df) - len(cleaned_df),
            warnings=dataset.warnings,
        )

    async def get_preview(self, dataset_id: str, limit: int = 50) -> list[dict]:
        dataset = await self._get_dataset_or_raise(dataset_id)
        _columns, rows = await asyncio.to_thread(fetch_preview, dataset.duckdb_table, limit)
        return rows

    async def list_datasets(self) -> list[Dataset]:
        result = await self.db.execute(select(Dataset).order_by(Dataset.created_at.desc()))
        return list(result.scalars().all())

    async def get_dataset(self, dataset_id: str) -> Dataset:
        return await self._get_dataset_or_raise(dataset_id)

    async def delete_dataset(self, dataset_id: str) -> None:
        dataset = await self._get_dataset_or_raise(dataset_id)
        await asyncio.to_thread(drop_dataset_table, dataset.duckdb_table)
        await self.db.delete(dataset)
        await self.db.commit()

    async def _get_dataset_or_raise(self, dataset_id: str) -> Dataset:
        dataset = await self.db.get(Dataset, dataset_id)
        if dataset is None:
            raise DatasetNotFoundError(f"Датасет {dataset_id} не найден")
        return dataset
