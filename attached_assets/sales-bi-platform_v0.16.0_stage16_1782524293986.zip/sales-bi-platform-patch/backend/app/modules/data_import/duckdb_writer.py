# VERSION: 1.0.0
# Path: backend/app/modules/data_import/duckdb_writer.py
# CHANGES v1.0.0:
#   - Этап 2: запись DataFrame в DuckDB как физическую таблицу датасета
#     (register + CREATE TABLE AS SELECT, без поэлементных INSERT)
"""
Сохранение датасета в DuckDB. Используем явную регистрацию DataFrame
(conn.register) и SQL CREATE TABLE ... AS SELECT — это рекомендованный DuckDB
способ принять данные из Pandas с минимальными накладными расходами (без
поэлементных INSERT, важно для будущего теста на 500k строк, Этап 10).
"""
import re

import pandas as pd

from app.db.duckdb_conn import duckdb_cursor

_SAFE_NAME_RE = re.compile(r"[^a-zA-Z0-9_]")


def make_table_name(dataset_id: str) -> str:
    """dataset_<32 hex без дефисов> — безопасное и предсказуемое имя таблицы."""
    safe = _SAFE_NAME_RE.sub("", dataset_id.replace("-", ""))
    return f"dataset_{safe}"


def write_dataset_table(table_name: str, df: pd.DataFrame) -> None:
    with duckdb_cursor() as conn:
        conn.register("_import_view", df)
        try:
            conn.execute(f'CREATE OR REPLACE TABLE "{table_name}" AS SELECT * FROM _import_view')
        finally:
            conn.unregister("_import_view")


def drop_dataset_table(table_name: str) -> None:
    with duckdb_cursor() as conn:
        conn.execute(f'DROP TABLE IF EXISTS "{table_name}"')


def fetch_preview(table_name: str, limit: int = 50) -> tuple[list[str], list[dict]]:
    with duckdb_cursor() as conn:
        result = conn.execute(f'SELECT * FROM "{table_name}" LIMIT {int(limit)}')
        columns = [desc[0] for desc in result.description]
        rows = [dict(zip(columns, row)) for row in result.fetchall()]
    return columns, rows


def count_rows(table_name: str) -> int:
    with duckdb_cursor() as conn:
        return conn.execute(f'SELECT COUNT(*) FROM "{table_name}"').fetchone()[0]
