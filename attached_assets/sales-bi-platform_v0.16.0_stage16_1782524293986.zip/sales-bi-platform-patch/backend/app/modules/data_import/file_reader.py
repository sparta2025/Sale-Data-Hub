# VERSION: 1.0.0
# Path: backend/app/modules/data_import/file_reader.py
# CHANGES v1.0.0:
#   - Этап 2: чтение CSV (автоопределение кодировки/разделителя) и XLSX
#     (выбор листа с данными среди нескольких листов)
"""
Чтение входного файла в pandas.DataFrame. Поддерживаемые форматы — CSV и XLSX
(см. ТЗ). Дальше с DataFrame работает структурный детектор и очистка —
сам файл-ридер отвечает только за то, чтобы корректно "достать" таблицу.
"""
from pathlib import Path

import pandas as pd

SUPPORTED_EXTENSIONS = {".csv", ".tsv", ".xlsx", ".xlsm"}

# Если в XLSX несколько листов, эти слова в названии листа повышают приоритет
# выбора (типичные названия "лист с фактами" против "сводка"/"справочник").
_PREFERRED_SHEET_HINTS = ("данны", "data", "факт", "fact", "продаж", "sales")
_DEPRIORITIZED_SHEET_HINTS = ("сводк", "summary", "справочник", "formula", "формул", "pivot", "сводная")


class UnsupportedFileError(ValueError):
    pass


def _read_csv_smart(path: Path) -> pd.DataFrame:
    """
    Пытается угадать кодировку (utf-8 / cp1251 — частый случай для выгрузок
    из российских/восточноевропейских ERP) и разделитель (',' или ';').
    """
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "utf-8", "cp1251"):
        for sep in (",", ";", "\t"):
            try:
                df = pd.read_csv(path, encoding=encoding, sep=sep)
                # Если разделитель угадан неверно, обычно получаем 1 колонку —
                # это явный признак, что нужно пробовать следующий вариант.
                if df.shape[1] > 1:
                    return df
            except Exception as exc:  # noqa: BLE001 — перебор вариантов, ошибки ожидаемы
                last_error = exc
                continue
    if last_error:
        raise UnsupportedFileError(f"Не удалось разобрать CSV-файл: {last_error}")
    raise UnsupportedFileError("Не удалось разобрать CSV-файл: файл пуст или имеет один столбец")


def _pick_sheet(sheet_names: list[str]) -> str:
    if len(sheet_names) == 1:
        return sheet_names[0]

    def score(name: str) -> int:
        lower = name.lower()
        s = 0
        if any(hint in lower for hint in _PREFERRED_SHEET_HINTS):
            s += 10
        if any(hint in lower for hint in _DEPRIORITIZED_SHEET_HINTS):
            s -= 10
        return s

    return max(sheet_names, key=score)


def _read_xlsx_smart(path: Path) -> tuple[pd.DataFrame, str]:
    excel_file = pd.ExcelFile(path)
    sheet_name = _pick_sheet(excel_file.sheet_names)
    df = excel_file.parse(sheet_name=sheet_name)
    return df, sheet_name


def read_table_file(path: Path, original_filename: str) -> tuple[pd.DataFrame, dict[str, str]]:
    """
    Возвращает (DataFrame, info), где info содержит вспомогательные детали
    (например, какой лист был выбран в XLSX) — пригодится для warnings.
    """
    suffix = Path(original_filename).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise UnsupportedFileError(
            f"Формат '{suffix}' не поддерживается. Поддерживаются: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )

    if suffix in (".csv", ".tsv"):
        df = _read_csv_smart(path)
        return df, {"format": "csv"}

    df, sheet_name = _read_xlsx_smart(path)
    return df, {"format": "xlsx", "sheet_name": sheet_name}
