# VERSION: 1.0.0
# Path: backend/app/modules/data_import/router.py
# CHANGES v1.0.0:
#   - Этап 2: API-роутер /api/datasets — upload/list/get/columns/preview/delete
"""API-эндпоинты Data Import Module."""
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.db.postgres import get_db
from app.modules.data_import.file_reader import SUPPORTED_EXTENSIONS, UnsupportedFileError
from app.modules.data_import.service import DataImportService, DatasetNotFoundError
from app.schemas.dataset import ColumnProfile, DatasetOut, ImportResponse, PreviewResponse

router = APIRouter()
settings = get_settings()


@router.post("/upload", response_model=ImportResponse)
async def upload_dataset(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
) -> ImportResponse:
    if not file.filename:
        raise HTTPException(status_code=400, detail="Имя файла не указано")

    suffix = Path(file.filename).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Формат '{suffix}' не поддерживается. Поддерживаются: {', '.join(sorted(SUPPORTED_EXTENSIONS))}",
        )

    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > settings.max_upload_size_mb:
        raise HTTPException(status_code=413, detail=f"Файл слишком большой ({size_mb:.1f} МБ > {settings.max_upload_size_mb} МБ)")

    saved_path = settings.upload_path / f"{uuid.uuid4().hex}_{file.filename}"
    saved_path.write_bytes(contents)

    dataset_name = Path(file.filename).stem
    service = DataImportService(db)
    try:
        result = await service.import_data(saved_path, dataset_name)
    except UnsupportedFileError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    dataset = await service.get_dataset(result.dataset_id)
    columns = [ColumnProfile(**c) for c in dataset.column_profile]

    return ImportResponse(
        dataset=DatasetOut.model_validate(dataset),
        warnings=result.warnings,
        columns=columns,
    )


@router.get("", response_model=list[DatasetOut])
async def list_datasets(db: AsyncSession = Depends(get_db)) -> list[DatasetOut]:
    service = DataImportService(db)
    datasets = await service.list_datasets()
    return [DatasetOut.model_validate(d) for d in datasets]


@router.get("/{dataset_id}", response_model=DatasetOut)
async def get_dataset(dataset_id: str, db: AsyncSession = Depends(get_db)) -> DatasetOut:
    service = DataImportService(db)
    try:
        dataset = await service.get_dataset(dataset_id)
    except DatasetNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return DatasetOut.model_validate(dataset)


@router.get("/{dataset_id}/columns", response_model=list[ColumnProfile])
async def get_dataset_columns(dataset_id: str, db: AsyncSession = Depends(get_db)) -> list[ColumnProfile]:
    service = DataImportService(db)
    try:
        dataset = await service.get_dataset(dataset_id)
    except DatasetNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return [ColumnProfile(**c) for c in dataset.column_profile]


@router.get("/{dataset_id}/preview", response_model=PreviewResponse)
async def get_dataset_preview(dataset_id: str, limit: int = 50, db: AsyncSession = Depends(get_db)) -> PreviewResponse:
    service = DataImportService(db)
    try:
        dataset = await service.get_dataset(dataset_id)
        rows = await service.get_preview(dataset_id, limit)
    except DatasetNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return PreviewResponse(
        dataset_id=dataset.id,
        columns=[c["name"] for c in dataset.column_profile],
        rows=rows,
        total_rows=dataset.row_count,
    )


@router.delete("/{dataset_id}", status_code=204)
async def delete_dataset(dataset_id: str, db: AsyncSession = Depends(get_db)) -> None:
    service = DataImportService(db)
    try:
        await service.delete_dataset(dataset_id)
    except DatasetNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
