# VERSION: 1.1.0
# Path: backend/app/modules/data_import/structure_detector.py
# CHANGES v1.1.0:
#   - Этап 2: автоопределение роли/типа колонки (текст/число/%/валюта/год/месяц)
#     v1.1.0: добавлено «спасение» числовых колонок, ставших object из-за
#     пары «грязных» значений (иначе падали при сортировке смешанных типов в sample_values)
"""
Автоопределение структуры табличных данных (см. ТЗ: "Система должна автоматически
определять структуру загружаемых файлов").

Эвристика основана на (а) типе данных pandas и (б) названии колонки — этого
достаточно для отчётов о продажах из примера в ТЗ и для похожих отчётов. Если
эвристика ошибается на каком-то конкретном отчёте — пользователь должен иметь
возможность поправить роль/тип вручную в Metadata Module (Этап 3); здесь мы
закладываем только первое разумное предположение.
"""
import pandas as pd

from app.schemas.dataset import ColumnDataType, ColumnProfile, ColumnRole

# Ключевые слова в названии колонки, указывающие на конкретный смысл метрики.
_PERCENTAGE_HINTS = ("%", "процент", "маржа", "наценка", "rate", "доля")
_CURRENCY_HINTS = (
    "eur", "usd", "rub", "₽", "€", "$",
    "цена", "выручка", "прибыль", "себестоимост", "расход", "затрат",
    "налог", "акциз", "ндс", "платеж", "наклад", "доход", "стоимост",
)
_YEAR_HINTS = ("год", "year")
_MONTH_HINTS = ("месяц", "month")

MAX_SAMPLE_VALUES = 8
MAX_DISTINCT_FOR_SAMPLE = 500  # выше этого порога не считаем nunique() дорогую операцию по сэмплам


_NUMERIC_RESCUE_THRESHOLD = 0.8  # доля значений, которая должна быть числовой, чтобы спасти колонку


def _matches_any(name_lower: str, hints: tuple[str, ...]) -> bool:
    return any(hint in name_lower for hint in hints)


def _rescue_numeric(series: pd.Series) -> tuple[bool, bool]:
    """
    Для колонок с dtype=object (обычно из-за нескольких "грязных" значений
    среди в остальном числовых данных) проверяет, не является ли колонка на
    самом деле числовой. Возвращает (is_numeric, is_integer_like).

    Без этой проверки одна опечатка в числовой колонке ломает её тип на
    "object" и колонка ошибочно классифицируется как текстовое измерение —
    а реальные "похожие отчёты" из ТЗ почти гарантированно содержат такие
    опечатки/артефакты экспорта.
    """
    non_null = series.dropna()
    if non_null.empty:
        return False, False
    coerced = pd.to_numeric(non_null, errors="coerce")
    valid_ratio = coerced.notna().mean()
    if valid_ratio < _NUMERIC_RESCUE_THRESHOLD:
        return False, False
    valid_values = coerced.dropna()
    is_integer_like = bool((valid_values == valid_values.round()).all())
    return True, is_integer_like


def _classify_column(name: str, series: pd.Series) -> tuple[ColumnRole, ColumnDataType]:
    name_lower = name.lower()
    dtype = series.dtype

    if pd.api.types.is_bool_dtype(dtype):
        return "dimension", "text"

    is_integer_like = pd.api.types.is_integer_dtype(dtype)
    is_numeric = is_integer_like or pd.api.types.is_float_dtype(dtype)

    if not is_numeric:
        is_numeric, is_integer_like = _rescue_numeric(series)

    if not is_numeric:
        return "dimension", "text"

    # Семантические подсказки по имени проверяем ДО is_integer_like.
    # Без этого "Выручка нетто (EUR)" с целыми значениями (49000, 51000...)
    # ошибочно получает тип "integer" вместо "currency".
    if _matches_any(name_lower, _PERCENTAGE_HINTS):
        return "metric", "percentage"
    if _matches_any(name_lower, _CURRENCY_HINTS):
        return "metric", "currency"
    if _matches_any(name_lower, _YEAR_HINTS):
        return "dimension", "year"
    if _matches_any(name_lower, _MONTH_HINTS):
        return "dimension", "month"

    if is_integer_like:
        return "metric", "integer"
    return "metric", "float"


def detect_column_profiles(df: pd.DataFrame) -> list[ColumnProfile]:
    """Строит профиль каждой колонки DataFrame: роль, тип, nullable, примеры значений."""
    profiles: list[ColumnProfile] = []
    for column in df.columns:
        series = df[column]
        role, data_type = _classify_column(str(column), series)
        nullable = bool(series.isna().any())
        distinct_count = int(series.nunique(dropna=True))

        sample_values: list = []
        if role == "dimension" and distinct_count <= MAX_DISTINCT_FOR_SAMPLE:
            unique_values = series.dropna().unique().tolist()
            try:
                sample_values = sorted(unique_values)[:MAX_SAMPLE_VALUES]
            except TypeError:
                # Смешанные типы в одной колонке (редкая аномалия "грязных"
                # данных) — сортируем по строковому представлению, лишь бы
                # не падать; это только превью для UI, не критично.
                sample_values = sorted(unique_values, key=str)[:MAX_SAMPLE_VALUES]

        profiles.append(
            ColumnProfile(
                name=str(column),
                role=role,
                data_type=data_type,
                nullable=nullable,
                distinct_count=distinct_count,
                sample_values=sample_values,
            )
        )
    return profiles
