# VERSION: 1.0.0
# Path: backend/app/modules/data_import/cleaner.py
# CHANGES v1.0.0:
#   - Этап 2: очистка данных и обработка пропусков (текст -> плейсхолдер,
#     числа -> NULL, а не 0, чтобы не искажать агрегаты)
"""
Очистка данных и обработка пропусков (см. ТЗ: Data Import Module).

Принципы:
  - Полностью пустые строки отбрасываются.
  - Пропуски в текстовых измерениях заменяются явным плейсхолдером — это
    лучше для UI фильтров/группировок, чем NULL "в никуда".
  - Пропуски в метриках НЕ заполняются нулём: SUM/AVG в DuckDB корректно
    игнорируют NULL, а замена на 0 искажала бы агрегаты (0 — это "продано
    на 0 евро", а не "нет данных").
  - Год/месяц — отдельный случай: без них строка не встанет в drill-down
    по времени, поэтому пропуски здесь — повод предупредить пользователя
    отдельно, а не молча подставить значение.
"""
import pandas as pd

from app.schemas.dataset import ColumnProfile

MISSING_TEXT_PLACEHOLDER = "(не указано)"


def clean_dataframe(df: pd.DataFrame, profiles: list[ColumnProfile]) -> tuple[pd.DataFrame, list[str]]:
    warnings: list[str] = []
    df = df.copy()

    rows_before = len(df)
    df = df.dropna(how="all")
    dropped_empty = rows_before - len(df)
    if dropped_empty:
        warnings.append(f"Удалено {dropped_empty} полностью пустых строк")

    profile_by_name = {p.name: p for p in profiles}

    for column in df.columns:
        profile = profile_by_name.get(str(column))
        if profile is None:
            continue

        if profile.data_type == "text":
            missing = df[column].isna().sum()
            # Подчищаем пробелы по краям у строковых значений — частый источник
            # "невидимых" дублей категорий ("Берлин " != "Берлин").
            df[column] = df[column].apply(lambda v: v.strip() if isinstance(v, str) else v)
            df[column] = df[column].fillna(MISSING_TEXT_PLACEHOLDER)
            empty_after_strip = (df[column] == "").sum()
            if empty_after_strip:
                df.loc[df[column] == "", column] = MISSING_TEXT_PLACEHOLDER
            if missing:
                warnings.append(f"Колонка '{column}': {missing} пропусков заменено на '{MISSING_TEXT_PLACEHOLDER}'")

        elif profile.data_type in ("integer", "float", "percentage", "currency"):
            coerced = pd.to_numeric(df[column], errors="coerce")
            newly_invalid = coerced.isna().sum() - df[column].isna().sum()
            if newly_invalid > 0:
                warnings.append(f"Колонка '{column}': {newly_invalid} нечисловых значений заменено на пропуск (NULL)")
            df[column] = coerced

        elif profile.data_type in ("year", "month"):
            coerced = pd.to_numeric(df[column], errors="coerce")
            missing = coerced.isna().sum()
            if missing:
                warnings.append(
                    f"Колонка '{column}': {missing} строк без значения — "
                    "эти строки не попадут в drill-down по времени"
                )
            df[column] = coerced

    return df, warnings
