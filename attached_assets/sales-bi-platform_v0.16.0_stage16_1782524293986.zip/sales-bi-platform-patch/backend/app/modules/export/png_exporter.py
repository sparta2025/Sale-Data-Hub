# VERSION: 1.1.0
# Path: backend/app/modules/export/png_exporter.py
# CHANGES v1.0.0:
#   - Этап 6: PNG-экспортёр — серверный рендеринг chart-данных через matplotlib
#     (без headless-браузера — лёгкий вариант для Docker, работает с готовыми
#     структурами из chart_formatters.py: CategoryData/PieData/TimeseriesData)
# CHANGES v1.1.0:
#   - Этап 8: размеры/DPI по умолчанию берутся из Settings (EXPORT_PNG_*)
"""
PNG-экспортёр.

В отличие от интерактивных чартов на фронтенде (ECharts), здесь — статический
рендеринг через matplotlib с Agg-бэкендом (без дисплея, безопасно для сервера).
Подходит для: вставки в презентации, отправки по email, печати.

Шрифт DejaVu Sans подключается явно — стандартный шрифт matplotlib (DejaVu Sans)
уже поддерживает кириллицу "из коробки" в большинстве сборок, но на всякий
случай конфигурируем его явно, чтобы не зависеть от системных настроек локали.
"""
import io

import matplotlib
matplotlib.use("Agg")  # без дисплея — обязательно для серверного рендеринга
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

from app.core.config import get_settings

_DEJAVU_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans.ttf",
]

_FONT_CONFIGURED = False


def _configure_font() -> None:
    global _FONT_CONFIGURED
    if _FONT_CONFIGURED:
        return
    _FONT_CONFIGURED = True
    for path in _DEJAVU_PATHS:
        try:
            fm.fontManager.addfont(path)
            plt.rcParams["font.family"] = fm.FontProperties(fname=path).get_name()
            break
        except Exception:
            continue
    else:
        # DejaVu Sans — дефолтный шрифт matplotlib, обычно уже поддерживает кириллицу
        plt.rcParams["font.family"] = "DejaVu Sans"


_PALETTE = [
    "#1F3864", "#2E75B6", "#9DC3E6", "#5B9BD5", "#A9D18E",
    "#FFC000", "#ED7D31", "#C00000", "#7030A0", "#808080",
]


def export_category_png(
    title: str,
    categories: list[str],
    metric_name: str,
    values: list[float | int | None],
    width: int | None = None,
    height: int | None = None,
) -> bytes:
    """Горизонтальный бар-чарт по категориям (соответствует CategoryData с одной метрикой)."""
    s = get_settings()
    w = width or s.export_png_bar_width
    h = height or s.export_png_bar_height
    dpi = s.export_png_dpi
    _configure_font()
    fig, ax = plt.subplots(figsize=(w / dpi, h / dpi), dpi=dpi)

    clean_values = [v if v is not None else 0 for v in values]
    y_pos = range(len(categories))
    ax.barh(y_pos, clean_values, color=_PALETTE[0])
    ax.set_yticks(list(y_pos))
    ax.set_yticklabels(categories)
    ax.invert_yaxis()  # наибольшее значение сверху
    ax.set_xlabel(metric_name)
    ax.set_title(title, fontsize=13, fontweight="bold", color="#1F3864")
    ax.grid(axis="x", linestyle="--", alpha=0.4)
    fig.tight_layout()

    return _fig_to_png(fig)


def export_pie_png(
    title: str,
    labels: list[str],
    values: list[float | int | None],
    width: int | None = None,
    height: int | None = None,
) -> bytes:
    """Круговая диаграмма (соответствует PieData)."""
    s = get_settings()
    w = width or s.export_png_pie_width
    h = height or s.export_png_pie_height
    dpi = s.export_png_dpi
    _configure_font()
    fig, ax = plt.subplots(figsize=(w / dpi, h / dpi), dpi=dpi)

    clean_values = [v if v is not None and v > 0 else 0 for v in values]
    colors = [_PALETTE[i % len(_PALETTE)] for i in range(len(labels))]

    ax.pie(
        clean_values,
        labels=labels,
        autopct="%1.1f%%",
        colors=colors,
        startangle=90,
        textprops={"fontsize": 9},
    )
    ax.set_title(title, fontsize=13, fontweight="bold", color="#1F3864")
    ax.axis("equal")
    fig.tight_layout()

    return _fig_to_png(fig)


def export_timeseries_png(
    title: str,
    periods: list[str],
    series: dict[str, list[float | int | None]],  # {series_name: [values aligned to periods]}
    width: int | None = None,
    height: int | None = None,
) -> bytes:
    """Линейный график временного ряда (соответствует TimeseriesData)."""
    s = get_settings()
    w = width or s.export_png_line_width
    h = height or s.export_png_line_height
    dpi = s.export_png_dpi
    _configure_font()
    fig, ax = plt.subplots(figsize=(w / dpi, h / dpi), dpi=dpi)

    for i, (series_name, values) in enumerate(series.items()):
        clean_values = [v if v is not None else None for v in values]
        ax.plot(
            periods, clean_values,
            marker="o", markersize=4, linewidth=2,
            color=_PALETTE[i % len(_PALETTE)],
            label=series_name,
        )

    ax.set_title(title, fontsize=13, fontweight="bold", color="#1F3864")
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    if len(series) > 1:
        ax.legend(loc="best", fontsize=9)
    plt.xticks(rotation=45, ha="right")
    fig.tight_layout()

    return _fig_to_png(fig)


def _fig_to_png(fig) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor="white", bbox_inches="tight")
    plt.close(fig)
    return buf.getvalue()
