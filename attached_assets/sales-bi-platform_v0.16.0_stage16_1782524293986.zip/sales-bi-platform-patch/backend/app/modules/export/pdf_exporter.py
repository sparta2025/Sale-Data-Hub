# VERSION: 1.1.0
# Path: backend/app/modules/export/pdf_exporter.py
# CHANGES v1.0.0:
#   - Этап 6: PDF-экспортёр — reportlab, таблица + заголовок + дата формирования + итоги
# CHANGES v1.1.0:
#   - Этап 8: max_rows по умолчанию берётся из Settings (EXPORT_PDF_MAX_ROWS)
"""
PDF-экспортёр.

reportlab не имеет встроенной поддержки кириллицы в стандартных шрифтах
(Helvetica и т.п. не содержат кириллических глифов) — поэтому подключаем
DejaVuSans, который покрывает кириллицу и доступен как системный TTF-шрифт
в большинстве Linux-дистрибутивов (включая базовый образ python:3.12-slim
после установки fonts-dejavu-core, см. Dockerfile).
"""
import io
import os

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (

    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

from app.core.config import get_settings

_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans.ttf",
]
_FONT_BOLD_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
]

_FONT_NAME = "Helvetica"        # запасной вариант — нет кириллицы
_FONT_BOLD = "Helvetica-Bold"
_FONTS_REGISTERED = False


def _register_fonts() -> None:
    """
    Регистрирует DejaVuSans, если шрифт найден в системе. Если файл шрифта
    отсутствует (например при локальном запуске без установки fonts-dejavu-core),
    откатываемся на Helvetica — кириллица не отобразится, но PDF не упадёт.
    """
    global _FONT_NAME, _FONT_BOLD, _FONTS_REGISTERED
    if _FONTS_REGISTERED:
        return
    _FONTS_REGISTERED = True

    regular = next((p for p in _FONT_CANDIDATES if os.path.exists(p)), None)
    bold = next((p for p in _FONT_BOLD_CANDIDATES if os.path.exists(p)), None)

    if regular:
        pdfmetrics.registerFont(TTFont("DejaVuSans", regular))
        _FONT_NAME = "DejaVuSans"
    if bold:
        pdfmetrics.registerFont(TTFont("DejaVuSans-Bold", bold))
        _FONT_BOLD = "DejaVuSans-Bold"
    elif regular:
        _FONT_BOLD = "DejaVuSans"  # нет жирного — используем обычный


def export_pdf(
    columns: list[str],
    rows: list[dict],
    title: str = "Отчёт",
    generated_at: str = "",
    summary_row: dict | None = None,
    max_rows: int | None = None,
) -> bytes:
    """
    Формирует PDF-отчёт: заголовок + дата формирования + таблица данных
    (с переносом на несколько страниц при необходимости) + итоговая строка.

    max_rows ограничивает размер таблицы — PDF не предназначен для вывода
    десятков тысяч строк (для этого есть CSV/XLSX); при превышении лимита
    в отчёт попадают первые max_rows строк с пометкой об усечении.
    """
    _register_fonts()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=landscape(A4),
        topMargin=15 * mm,
        bottomMargin=15 * mm,
        leftMargin=12 * mm,
        rightMargin=12 * mm,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TitleRu", parent=styles["Title"],
        fontName=_FONT_BOLD, fontSize=18, textColor=colors.HexColor("#1F3864"),
    )
    meta_style = ParagraphStyle(
        "MetaRu", parent=styles["Normal"],
        fontName=_FONT_NAME, fontSize=9, textColor=colors.grey,
    )

    elements = [
        Paragraph(title, title_style),
        Spacer(1, 4),
    ]
    if generated_at:
        elements.append(Paragraph(f"Сформировано: {generated_at}", meta_style))
    elements.append(Paragraph(f"Строк в отчёте: {len(rows)}", meta_style))
    elements.append(Spacer(1, 10))

    if max_rows is None:
        max_rows = get_settings().export_pdf_max_rows

    truncated = len(rows) > max_rows
    display_rows = rows[:max_rows]

    table_data = [columns]
    for row in display_rows:
        table_data.append([_fmt(row.get(c)) for c in columns])

    if summary_row:
        summary_line = [
            "ИТОГО" if i == 0 else _fmt(summary_row.get(c, ""))
            for i, c in enumerate(columns)
        ]
        table_data.append(summary_line)

    n_cols = max(len(columns), 1)
    avail_width = landscape(A4)[0] - 24 * mm
    col_width = avail_width / n_cols

    table = Table(table_data, colWidths=[col_width] * n_cols, repeatRows=1)

    style_commands = [
        ("FONTNAME", (0, 0), (-1, -1), _FONT_NAME),
        ("FONTNAME", (0, 0), (-1, 0), _FONT_BOLD),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3864")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#BFBFBF")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1 if not summary_row else -2),
         [colors.white, colors.HexColor("#EEF3FA")]),
    ]
    if summary_row:
        style_commands += [
            ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#D6E4F0")),
            ("FONTNAME", (0, -1), (-1, -1), _FONT_BOLD),
        ]
    table.setStyle(TableStyle(style_commands))
    elements.append(table)

    if truncated:
        elements.append(Spacer(1, 8))
        elements.append(Paragraph(
            f"Показаны первые {max_rows} из {len(rows)} строк. "
            f"Для полного набора данных используйте экспорт в CSV или XLSX.",
            meta_style,
        ))

    doc.build(elements)
    return buf.getvalue()


def _fmt(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:,.2f}".replace(",", " ")
    return str(value)
