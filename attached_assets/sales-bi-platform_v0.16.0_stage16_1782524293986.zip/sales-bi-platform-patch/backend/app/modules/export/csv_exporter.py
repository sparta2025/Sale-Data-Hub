# VERSION: 1.0.0
# Path: backend/app/modules/export/csv_exporter.py
# CHANGES v1.0.0:
#   - Этап 6: CSV-экспортёр — потоковая генерация через StringIO + итоговая строка
"""CSV-экспортёр."""
import csv
import io
from datetime import datetime


def export_csv(
    columns: list[str],
    rows: list[dict],
    summary_row: dict | None = None,
    encoding: str = "utf-8-sig",  # utf-8-sig: BOM для корректного открытия в Excel
) -> bytes:
    """
    Формирует CSV в памяти и возвращает bytes.

    utf-8-sig добавляет BOM — это стандартная практика для CSV с кириллицей,
    позволяет Excel автоматически определить кодировку при двойном клике.

    summary_row (опционально) — итоговая строка с SUM/AVG метрик,
    добавляется в конец с пометкой «ИТОГО».
    """
    buf = io.StringIO()
    writer = csv.DictWriter(
        buf,
        fieldnames=columns,
        extrasaction="ignore",
        lineterminator="\r\n",
    )
    writer.writeheader()
    writer.writerows(rows)

    if summary_row:
        # Первая колонка — метка, остальные — значения
        summary = {c: "" for c in columns}
        if columns:
            summary[columns[0]] = "ИТОГО"
        summary.update(summary_row)
        writer.writerow(summary)

    return buf.getvalue().encode(encoding)
