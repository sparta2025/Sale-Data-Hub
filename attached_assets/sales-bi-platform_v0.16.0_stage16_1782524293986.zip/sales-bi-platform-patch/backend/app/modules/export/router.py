# VERSION: 1.0.0
# Path: backend/app/modules/export/router.py
# CHANGES v1.0.0:
#   - Этап 6: API /api/export — табличный экспорт (CSV/XLSX/PDF) и PNG-чарты
"""API-эндпоинты Export Module."""
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.postgres import get_db
from app.modules.export.service import ExportError, ExportService
from app.schemas.export import ExportRequest

router = APIRouter()


@router.post("/{dataset_id}/table")
async def export_table(
    dataset_id: str,
    req: ExportRequest,
    db: AsyncSession = Depends(get_db),
) -> Response:
    """
    Экспорт агрегированной таблицы в CSV / XLSX / PDF.

    Тело запроса — как у QueryRequest, плюс:
      - format: "csv" | "xlsx" | "pdf"
      - title: заголовок отчёта (для XLSX/PDF)
      - include_summary: добавить итоговую строку (SUM/AVG метрик)

    Ответ — бинарный файл с правильным Content-Type и Content-Disposition
    (браузер предложит сохранить файл с корректным именем).
    """
    try:
        content, filename, media_type = await ExportService(db).export_table(dataset_id, req)
    except ExportError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Ошибка экспорта: {exc}") from exc

    return Response(
        content=content,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{dataset_id}/chart/category.png")
async def export_category_chart_png(
    dataset_id: str,
    dimension: str = Query(...),
    metric: str = Query(...),
    title: str = Query(""),
    limit: int = Query(20),
    db: AsyncSession = Depends(get_db),
) -> Response:
    """PNG бар-чарта по категории — для вставки в презентации/документы."""
    try:
        content = await ExportService(db).export_chart_png(
            dataset_id, "category", title or dimension,
            dimension=dimension, metric=metric, limit=limit,
        )
    except ExportError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return Response(
        content=content, media_type="image/png",
        headers={"Content-Disposition": 'inline; filename="chart.png"'},
    )


@router.get("/{dataset_id}/chart/pie.png")
async def export_pie_chart_png(
    dataset_id: str,
    dimension: str = Query(...),
    metric: str = Query(...),
    title: str = Query(""),
    limit: int = Query(20),
    db: AsyncSession = Depends(get_db),
) -> Response:
    """PNG круговой диаграммы."""
    try:
        content = await ExportService(db).export_chart_png(
            dataset_id, "pie", title or metric,
            dimension=dimension, metric=metric, limit=limit,
        )
    except ExportError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return Response(
        content=content, media_type="image/png",
        headers={"Content-Disposition": 'inline; filename="chart.png"'},
    )


@router.get("/{dataset_id}/chart/timeseries.png")
async def export_timeseries_chart_png(
    dataset_id: str,
    dimensions: list[str] = Query(...),
    metrics: list[str] = Query(...),
    group_by: str | None = Query(None),
    title: str = Query(""),
    limit: int = Query(500),
    db: AsyncSession = Depends(get_db),
) -> Response:
    """PNG линейного графика временного ряда."""
    try:
        content = await ExportService(db).export_chart_png(
            dataset_id, "timeseries", title or "Динамика",
            dimensions=dimensions, metrics=metrics, group_by=group_by, limit=limit,
        )
    except ExportError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return Response(
        content=content, media_type="image/png",
        headers={"Content-Disposition": 'inline; filename="chart.png"'},
    )
