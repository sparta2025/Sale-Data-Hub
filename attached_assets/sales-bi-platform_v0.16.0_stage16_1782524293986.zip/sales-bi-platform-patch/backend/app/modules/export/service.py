# VERSION: 1.0.0
# Path: backend/app/modules/export/service.py
# CHANGES v1.0.0:
#   - Этап 6: ExportService — выполняет запрос через QueryService, считает
#     итоговую строку (summary), вызывает нужный экспортёр, возвращает bytes+имя файла
"""
ExportService — мост между Query/Dashboard Engine и форматами вывода.

Для CSV/XLSX/PDF: выполняет обычный агрегационный запрос (как QueryService),
затем считает summary_row (сумма для sum-метрик, среднее для avg-метрик)
и передаёт результат соответствующему экспортёру.

Для PNG: переиспользует DashboardService для получения готовых структур
(CategoryData/PieData/TimeseriesData) и передаёт их в png_exporter.
"""
import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dataset import Dataset
from app.models.metadata import Metric
from app.modules.dashboard_engine.service import DashboardService
from app.modules.export.csv_exporter import export_csv
from app.modules.export.pdf_exporter import export_pdf
from app.modules.export.png_exporter import export_category_png, export_pie_png, export_timeseries_png
from app.modules.export.xlsx_exporter import export_xlsx
from app.modules.query_engine.service import QueryService, QueryValidationError
from app.schemas.export import ExportRequest
from app.schemas.query import QueryRequest


class ExportError(ValueError):
    pass


def _safe_filename(name: str, ext: str) -> str:
    safe = "".join(c if c.isalnum() or c in " _-" else "_" for c in name).strip()
    safe = safe.replace(" ", "_") or "export"
    return f"{safe}.{ext}"


class ExportService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def _load_dataset_name(self, dataset_id: str) -> str:
        ds = await self.db.get(Dataset, uuid.UUID(dataset_id))
        return ds.name if ds else "export"

    async def _load_metrics_map(self, dataset_id: str) -> dict[str, Metric]:
        result = await self.db.execute(
            select(Metric).where(Metric.dataset_id == uuid.UUID(dataset_id))
        )
        return {m.column_name: m for m in result.scalars().all()}

    def _compute_summary(
        self, rows: list[dict], metrics: list[str], metrics_map: dict[str, Metric]
    ) -> dict | None:
        """
        Итоговая строка: для sum-метрик — сумма по всем строкам результата,
        для avg-метрик — среднее. Так пользователь видит и детальные строки,
        и общий итог в одном файле, без повторного запроса к БД.
        """
        if not rows or not metrics:
            return None
        summary: dict = {}
        for m in metrics:
            values = [r.get(m) for r in rows if r.get(m) is not None]
            if not values:
                summary[m] = None
                continue
            agg = metrics_map.get(m)
            aggregation = agg.aggregation if agg else "sum"
            if aggregation == "avg":
                summary[m] = sum(values) / len(values)
            elif aggregation == "count":
                summary[m] = len(values)
            elif aggregation == "min":
                summary[m] = min(values)
            elif aggregation == "max":
                summary[m] = max(values)
            else:
                summary[m] = sum(values)
        return summary

    async def export_table(self, dataset_id: str, req: ExportRequest) -> tuple[bytes, str, str]:
        """
        Универсальный табличный экспорт: CSV / XLSX / PDF.
        Возвращает (содержимое_файла, имя_файла, media_type).
        """
        query_svc = QueryService(self.db)
        query_req = QueryRequest(
            dimensions=req.dimensions,
            metrics=req.metrics,
            filters=req.filters,
            order_by=req.order_by,
            order_desc=req.order_desc,
            limit=req.limit,
        )
        try:
            result = await query_svc.execute_query(dataset_id, query_req)
        except QueryValidationError as exc:
            raise ExportError(str(exc)) from exc

        metrics_map = await self._load_metrics_map(dataset_id)
        summary = (
            self._compute_summary(result.rows, req.metrics, metrics_map)
            if req.include_summary else None
        )

        dataset_name = await self._load_dataset_name(dataset_id)
        generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

        if req.format == "csv":
            content = export_csv(result.columns, result.rows, summary)
            return content, _safe_filename(dataset_name, "csv"), "text/csv"

        if req.format == "xlsx":
            column_types = {
                col: (metrics_map[col].data_type if col in metrics_map else "text")
                for col in result.columns
            }
            content = export_xlsx(
                result.columns, result.rows, title=req.title,
                summary_row=summary, column_types=column_types,
            )
            return (
                content,
                _safe_filename(dataset_name, "xlsx"),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

        if req.format == "pdf":
            content = export_pdf(
                result.columns, result.rows, title=req.title,
                generated_at=generated_at, summary_row=summary,
            )
            return content, _safe_filename(dataset_name, "pdf"), "application/pdf"

        raise ExportError(f"Неподдерживаемый формат: {req.format}")

    async def export_chart_png(
        self,
        dataset_id: str,
        chart_type: str,           # "category" | "pie" | "timeseries"
        title: str,
        dimension: str | None = None,
        dimensions: list[str] | None = None,
        metric: str | None = None,
        metrics: list[str] | None = None,
        group_by: str | None = None,
        limit: int = 20,
    ) -> bytes:
        """Рендерит готовый чарт в PNG, переиспользуя DashboardService."""
        dash_svc = DashboardService(self.db)

        try:
            if chart_type == "category":
                if not dimension or not metric:
                    raise ExportError("Для category нужны dimension и metric")
                data = await dash_svc.get_category(dataset_id, "png", title, dimension, [metric], limit=limit)
                values = [p.values.get(metric) for p in data.points]
                return export_category_png(title, data.categories, metric, values)

            if chart_type == "pie":
                if not dimension or not metric:
                    raise ExportError("Для pie нужны dimension и metric")
                data = await dash_svc.get_pie(dataset_id, "png", title, dimension, metric, limit=limit)
                labels = [s.name for s in data.slices]
                values = [s.value for s in data.slices]
                return export_pie_png(title, labels, values)

            if chart_type == "timeseries":
                if not dimensions or not metrics:
                    raise ExportError("Для timeseries нужны dimensions и metrics")
                data = await dash_svc.get_timeseries(
                    dataset_id, "png", title, dimensions, metrics, group_by, limit=limit
                )
                periods_ordered = sorted(set(p.period for p in data.points))
                series_data: dict[str, list] = {name: [] for name in data.series_names}
                for series_name in data.series_names:
                    value_by_period = {
                        p.period: p.value for p in data.points
                        if (p.series == series_name)
                    }
                    series_data[series_name] = [value_by_period.get(per) for per in periods_ordered]
                return export_timeseries_png(title, periods_ordered, series_data)
        except QueryValidationError as exc:
            # Единообразная обработка ошибок валидации: ExportError ловится
            # в роутере и превращается в HTTP 422. Без этого QueryValidationError,
            # вылетевшая из глубины DashboardService -> QueryService, дошла бы
            # до роутера необработанной и превратилась бы в 500.
            raise ExportError(str(exc)) from exc

        raise ExportError(f"Неподдерживаемый тип чарта для PNG: {chart_type}")
