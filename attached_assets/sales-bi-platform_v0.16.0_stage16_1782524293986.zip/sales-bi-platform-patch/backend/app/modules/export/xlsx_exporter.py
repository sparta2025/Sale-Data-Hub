# VERSION: 1.0.0
# Path: backend/app/modules/export/xlsx_exporter.py
# CHANGES v1.0.0:
#   - Этап 6: XLSX-экспортёр — openpyxl с форматированием: шапка, ширина колонок,
#     чередование строк, итоговая строка, числовые форматы
"""XLSX-экспортёр."""
import io
from datetime import datetime

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

# ── Цветовая схема (корпоративный синий) ──────────────────────────────────
_HEADER_FILL  = PatternFill("solid", fgColor="1F3864")   # тёмно-синий
_SUMMARY_FILL = PatternFill("solid", fgColor="D6E4F0")   # светло-голубой
_ALT_ROW_FILL = PatternFill("solid", fgColor="EEF3FA")   # чуть синеватый белый
_HEADER_FONT  = Font(bold=True, color="FFFFFF", size=11)
_SUMMARY_FONT = Font(bold=True, size=11)
_THIN_BORDER  = Border(
    left=Side(style="thin", color="BFBFBF"),
    right=Side(style="thin", color="BFBFBF"),
    top=Side(style="thin", color="BFBFBF"),
    bottom=Side(style="thin", color="BFBFBF"),
)

# Числовые форматы для openpyxl
_FORMAT_MAP = {
    "currency":   '#,##0.00 "€"',
    "percentage": '0.00%',
    "integer":    '#,##0',
    "float":      '#,##0.00',
}


def _col_width(column: str, rows: list[dict], max_width: int = 40) -> float:
    """Авторазмер колонки по максимальной длине значения."""
    header_len = len(str(column))
    max_val_len = max(
        (len(str(r.get(column, "") or "")) for r in rows[:200]),
        default=0,
    )
    return min(max(header_len, max_val_len) + 2, max_width)


def export_xlsx(
    columns: list[str],
    rows: list[dict],
    title: str = "Отчёт",
    summary_row: dict | None = None,
    column_types: dict[str, str] | None = None,  # {col_name: data_type}
) -> bytes:
    """
    Формирует XLSX в памяти:
      - Строка 1: заголовок (title) на всю ширину
      - Строка 2: шапка таблицы (жирный белый текст, тёмно-синий фон)
      - Строки 3…N: данные с чередованием заливки
      - Последняя строка (если include_summary): итоговая строка (полужирная)
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Данные"

    n_cols = len(columns)

    # ── Заголовок листа ───────────────────────────────────────────────────
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(n_cols, 1))
    title_cell = ws.cell(row=1, column=1, value=title)
    title_cell.font = Font(bold=True, size=14, color="1F3864")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    # ── Шапка таблицы ────────────────────────────────────────────────────
    for col_idx, col_name in enumerate(columns, start=1):
        cell = ws.cell(row=2, column=col_idx, value=col_name)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _THIN_BORDER
    ws.row_dimensions[2].height = 20

    # ── Данные ────────────────────────────────────────────────────────────
    col_types = column_types or {}
    for row_idx, row in enumerate(rows, start=3):
        fill = _ALT_ROW_FILL if row_idx % 2 == 1 else None
        for col_idx, col_name in enumerate(columns, start=1):
            val = row.get(col_name)
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.border = _THIN_BORDER
            if fill:
                cell.fill = fill
            dtype = col_types.get(col_name, "")
            if dtype and dtype in _FORMAT_MAP:
                cell.number_format = _FORMAT_MAP[dtype]
            if isinstance(val, (int, float)):
                cell.alignment = Alignment(horizontal="right")

    # ── Итоговая строка ───────────────────────────────────────────────────
    if summary_row:
        sum_row_idx = len(rows) + 3
        for col_idx, col_name in enumerate(columns, start=1):
            label = "ИТОГО" if col_idx == 1 else summary_row.get(col_name, "")
            cell = ws.cell(row=sum_row_idx, column=col_idx, value=label)
            cell.fill = _SUMMARY_FILL
            cell.font = _SUMMARY_FONT
            cell.border = _THIN_BORDER
            dtype = col_types.get(col_name, "")
            if dtype and dtype in _FORMAT_MAP and col_idx > 1:
                cell.number_format = _FORMAT_MAP[dtype]
            if isinstance(label, (int, float)):
                cell.alignment = Alignment(horizontal="right")
        ws.row_dimensions[sum_row_idx].height = 18

    # ── Ширина колонок ────────────────────────────────────────────────────
    for col_idx, col_name in enumerate(columns, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = _col_width(col_name, rows)

    # ── Заморозка шапки ──────────────────────────────────────────────────
    ws.freeze_panes = "A3"

    # ── Авто-фильтр ──────────────────────────────────────────────────────
    if n_cols > 0 and len(rows) > 0:
        ws.auto_filter.ref = (
            f"A2:{get_column_letter(n_cols)}{len(rows) + 2}"
        )

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
