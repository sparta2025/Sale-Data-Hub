# VERSION: 1.0.0
# Path: backend/app/modules/dashboard_engine/chart_formatters.py
# CHANGES v1.0.0:
#   - Этап 5: форматировщики QueryResult → TimeseriesData/CategoryData/PieData/TreemapData/TableData
"""
Преобразование сырых строк QueryResult в структуры данных, готовые к рендерингу
на фронтенде (ECharts, Recharts и т.п.).

Каждый форматировщик принимает:
  - chart_id, title: идентификация чарта
  - rows: список dict (строки из DuckDB)
  - columns: имена колонок
  - dims/metrics: запрошенные измерения и метрики
  - execution_ms: время выполнения запроса
"""
from app.schemas.dashboard import (
    CategoryData, CategoryPoint,
    PieData, PieSlice,
    TableData,
    TimeseriesData, TimeseriesPoint,
    TreemapData, TreemapNode,
)


def format_timeseries(
    chart_id: str,
    title: str,
    rows: list[dict],
    time_dimensions: list[str],   # например ["Год"] или ["Год", "Месяц"]
    metrics: list[str],
    group_by: str | None,          # например "Страна" → несколько серий
    execution_ms: float,
) -> TimeseriesData:
    """
    Формирует точки временного ряда.
    period строится как конкатенация time_dimensions: "2015" или "2015-01".
    При наличии group_by — несколько серий на одном графике.
    """
    series_names: list[str] = []
    points: list[TimeseriesPoint] = []

    for row in rows:
        period_parts = [str(int(row[d])) if row[d] is not None else "?" for d in time_dimensions]
        period = "-".join(period_parts)

        series = str(row[group_by]) if group_by and group_by in row else None
        if series and series not in series_names:
            series_names.append(series)

        for metric in metrics:
            points.append(TimeseriesPoint(
                period=period,
                value=row.get(metric),
                series=series or metric,
            ))

    if not series_names:
        series_names = metrics

    return TimeseriesData(
        chart_id=chart_id,
        title=title,
        series_names=series_names,
        points=points,
        execution_ms=execution_ms,
    )


def format_category(
    chart_id: str,
    title: str,
    rows: list[dict],
    dimension: str,
    metrics: list[str],
    execution_ms: float,
) -> CategoryData:
    """
    Формирует данные для горизонтального/вертикального бар-чарта.
    Каждая строка — одна категория с набором значений метрик.
    """
    categories: list[str] = []
    points: list[CategoryPoint] = []

    for row in rows:
        cat = str(row.get(dimension, ""))
        categories.append(cat)
        points.append(CategoryPoint(
            category=cat,
            values={m: row.get(m) for m in metrics},
        ))

    return CategoryData(
        chart_id=chart_id,
        title=title,
        categories=categories,
        metrics=metrics,
        points=points,
        execution_ms=execution_ms,
    )


def format_pie(
    chart_id: str,
    title: str,
    rows: list[dict],
    dimension: str,
    metric: str,
    execution_ms: float,
) -> PieData:
    """
    Формирует срезы круговой диаграммы.
    Вычисляет процентное соотношение каждого среза к общему итогу.
    """
    slices: list[PieSlice] = []
    total = 0.0

    for row in rows:
        v = row.get(metric)
        if v is not None:
            total += float(v)

    for row in rows:
        v = row.get(metric)
        pct = (float(v) / total * 100) if (v is not None and total > 0) else None
        slices.append(PieSlice(
            name=str(row.get(dimension, "")),
            value=v,
            percentage=round(pct, 2) if pct is not None else None,
        ))

    # Сортируем по убыванию значения
    slices.sort(key=lambda s: (s.value or 0), reverse=True)

    return PieData(
        chart_id=chart_id,
        title=title,
        metric=metric,
        total=round(total, 4),
        slices=slices,
        execution_ms=execution_ms,
    )


def format_treemap(
    chart_id: str,
    title: str,
    rows: list[dict],
    dimensions: list[str],   # иерархические уровни: [Товарная группа, Товар]
    metric: str,
    execution_ms: float,
) -> TreemapData:
    """
    Строит вложенную структуру для треemap.
    dimensions[0] — верхний уровень, dimensions[1] — вложенный.
    При одном измерении — плоский список.
    """
    if len(dimensions) == 1:
        root = TreemapNode(
            name="root",
            value=None,
            children=[
                TreemapNode(name=str(r.get(dimensions[0], "")), value=r.get(metric))
                for r in rows
            ],
        )
    else:
        # Группируем по первому измерению
        groups: dict[str, list] = {}
        for row in rows:
            parent = str(row.get(dimensions[0], ""))
            groups.setdefault(parent, []).append(row)

        children: list[TreemapNode] = []
        for parent, group_rows in groups.items():
            sub = [
                TreemapNode(name=str(r.get(dimensions[1], "")), value=r.get(metric))
                for r in group_rows
            ]
            parent_val = sum(float(n.value or 0) for n in sub) or None
            children.append(TreemapNode(name=parent, value=parent_val, children=sub))

        root = TreemapNode(name="root", value=None, children=children)

    return TreemapData(
        chart_id=chart_id,
        title=title,
        metric=metric,
        root=root,
        execution_ms=execution_ms,
    )


def format_table(
    chart_id: str,
    title: str,
    columns: list[str],
    rows: list[dict],
    execution_ms: float,
) -> TableData:
    return TableData(
        chart_id=chart_id,
        title=title,
        columns=columns,
        rows=rows,
        total_rows=len(rows),
        execution_ms=execution_ms,
    )
