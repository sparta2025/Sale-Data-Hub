# VERSION: 1.1.0
# Path: backend/app/modules/dashboard_engine/service.py
# CHANGES v1.0.0:
#   - Этап 5: DashboardService — CRUD дашбордов, данные KPI/чартов/drill-down
# CHANGES v1.1.0:
#   - Этап 8: лимиты чартов (category/pie/timeseries/table/drilldown) берутся
#     из Settings (CHART_*_LIMIT) вместо захардкоженных значений
"""
DashboardService: управление дашбордами и получение данных для рендеринга.

Использует QueryService (Этап 4) как движок выборки данных и chart_formatters
для преобразования в структуры, готовые к рендерингу на фронтенде.
"""
import asyncio
import time
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.dashboard import Dashboard
from app.models.dataset import Dataset
from app.models.metadata import Dimension, Metric
from app.modules.dashboard_engine.chart_formatters import (
    format_category, format_pie, format_table, format_timeseries, format_treemap,
)
from app.modules.query_engine.service import QueryService, QueryValidationError
from app.schemas.dashboard import (
    CategoryData, DrilldownData, DrilldownRequest, KpiCard,
    DashboardConfig, DashboardCreate, DashboardUpdate,
    PieData, TableData, TimeseriesData, TreemapData,
)
from app.schemas.query import QueryRequest, RangeFilter, InFilter, EqFilter


class DashboardNotFoundError(LookupError):
    pass


class DashboardService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ── CRUD ──────────────────────────────────────────────────────────────────

    async def create(self, dataset_id: str, data: DashboardCreate) -> Dashboard:
        ds = await self.db.get(Dataset, uuid.UUID(dataset_id))
        if ds is None:
            raise DashboardNotFoundError(f"Датасет {dataset_id} не найден")
        dash = Dashboard(
            dataset_id=uuid.UUID(dataset_id),
            name=data.name,
            description=data.description,
            config=data.config.model_dump(),
        )
        self.db.add(dash)
        await self.db.commit()
        await self.db.refresh(dash)
        return dash

    async def list_by_dataset(self, dataset_id: str) -> list[Dashboard]:
        result = await self.db.execute(
            select(Dashboard)
            .where(Dashboard.dataset_id == uuid.UUID(dataset_id))
            .order_by(Dashboard.created_at.desc())
        )
        return list(result.scalars().all())

    async def get(self, dashboard_id: str) -> Dashboard:
        dash = await self.db.get(Dashboard, uuid.UUID(dashboard_id))
        if dash is None:
            raise DashboardNotFoundError(f"Дашборд {dashboard_id} не найден")
        return dash

    async def update(self, dashboard_id: str, data: DashboardUpdate) -> Dashboard:
        dash = await self.get(dashboard_id)
        if data.name is not None:
            dash.name = data.name
        if data.description is not None:
            dash.description = data.description
        if data.config is not None:
            dash.config = data.config.model_dump()
        await self.db.commit()
        await self.db.refresh(dash)
        return dash

    async def delete(self, dashboard_id: str) -> None:
        dash = await self.get(dashboard_id)
        await self.db.delete(dash)
        await self.db.commit()

    # ── Данные для чартов ────────────────────────────────────────────────────

    async def get_kpi(
        self,
        dataset_id: str,
        metric_names: list[str],
        filters: dict | None = None,
    ) -> list[KpiCard]:
        """KPI-карточки: одно итоговое значение на каждую метрику."""
        aggregated = await QueryService(self.db).get_kpi_totals(
            dataset_id, metric_names, filters
        )
        return [
            KpiCard(
                metric=a.metric,
                display_name=a.display_name,
                value=a.value,
                aggregation=a.aggregation,
                display_format=a.display_format,
            )
            for a in aggregated
        ]

    async def get_timeseries(
        self,
        dataset_id: str,
        chart_id: str,
        title: str,
        time_dimensions: list[str],
        metrics: list[str],
        group_by: str | None = None,
        filters: dict | None = None,
        limit: int | None = None,
    ) -> TimeseriesData:
        limit = limit or get_settings().chart_timeseries_limit
        dimensions = time_dimensions + ([group_by] if group_by else [])
        req = QueryRequest(
            dimensions=dimensions,
            metrics=metrics,
            filters=filters or {},
            order_by=time_dimensions[0] if time_dimensions else None,
            limit=limit,
        )
        result = await QueryService(self.db).execute_query(dataset_id, req)
        return format_timeseries(
            chart_id=chart_id,
            title=title,
            rows=result.rows,
            time_dimensions=time_dimensions,
            metrics=metrics,
            group_by=group_by,
            execution_ms=result.execution_ms,
        )

    async def get_category(
        self,
        dataset_id: str,
        chart_id: str,
        title: str,
        dimension: str,
        metrics: list[str],
        filters: dict | None = None,
        limit: int | None = None,
    ) -> CategoryData:
        limit = limit or get_settings().chart_category_limit
        req = QueryRequest(
            dimensions=[dimension],
            metrics=metrics,
            filters=filters or {},
            order_by=metrics[0] if metrics else None,
            order_desc=True,
            limit=limit,
        )
        result = await QueryService(self.db).execute_query(dataset_id, req)
        return format_category(
            chart_id=chart_id,
            title=title,
            rows=result.rows,
            dimension=dimension,
            metrics=metrics,
            execution_ms=result.execution_ms,
        )

    async def get_pie(
        self,
        dataset_id: str,
        chart_id: str,
        title: str,
        dimension: str,
        metric: str,
        filters: dict | None = None,
        limit: int | None = None,
    ) -> PieData:
        limit = limit or get_settings().chart_pie_limit
        req = QueryRequest(
            dimensions=[dimension],
            metrics=[metric],
            filters=filters or {},
            order_by=metric,
            order_desc=True,
            limit=limit,
        )
        result = await QueryService(self.db).execute_query(dataset_id, req)
        return format_pie(
            chart_id=chart_id,
            title=title,
            rows=result.rows,
            dimension=dimension,
            metric=metric,
            execution_ms=result.execution_ms,
        )

    async def get_treemap(
        self,
        dataset_id: str,
        chart_id: str,
        title: str,
        dimensions: list[str],
        metric: str,
        filters: dict | None = None,
        limit: int | None = None,
    ) -> TreemapData:
        limit = limit or get_settings().chart_timeseries_limit
        req = QueryRequest(
            dimensions=dimensions,
            metrics=[metric],
            filters=filters or {},
            order_by=metric,
            order_desc=True,
            limit=limit,
        )
        result = await QueryService(self.db).execute_query(dataset_id, req)
        return format_treemap(
            chart_id=chart_id,
            title=title,
            rows=result.rows,
            dimensions=dimensions,
            metric=metric,
            execution_ms=result.execution_ms,
        )

    async def get_table(
        self,
        dataset_id: str,
        chart_id: str,
        title: str,
        dimensions: list[str],
        metrics: list[str],
        filters: dict | None = None,
        order_by: str | None = None,
        order_desc: bool = False,
        limit: int | None = None,
    ) -> TableData:
        limit = limit or get_settings().chart_table_limit
        req = QueryRequest(
            dimensions=dimensions,
            metrics=metrics,
            filters=filters or {},
            order_by=order_by,
            order_desc=order_desc,
            limit=limit,
        )
        result = await QueryService(self.db).execute_query(dataset_id, req)
        return format_table(
            chart_id=chart_id,
            title=title,
            columns=result.columns,
            rows=result.rows,
            execution_ms=result.execution_ms,
        )

    async def get_drilldown(
        self,
        dataset_id: str,
        req: DrilldownRequest,
    ) -> DrilldownData:
        """
        Следующий уровень иерархии drill-down.

        Например: пользователь кликнул на "Германия" в pie-чарте по странам →
        запрашивает drilldown(hierarchy_group="geography", current_level=0,
        parent_value="Германия") → получает данные по Филиалам Германии.
        """
        # Загружаем все измерения датасета отсортированные по иерархии
        result = await self.db.execute(
            select(Dimension)
            .where(Dimension.dataset_id == uuid.UUID(dataset_id))
            .where(Dimension.hierarchy_group == req.hierarchy_group)
            .order_by(Dimension.hierarchy_level)
        )
        hier_dims = list(result.scalars().all())

        if not hier_dims:
            raise QueryValidationError(
                f"Иерархия '{req.hierarchy_group}' не найдена в датасете"
            )

        next_level = req.current_level + 1
        if next_level >= len(hier_dims):
            raise QueryValidationError(
                f"Уровень {next_level} не существует в иерархии '{req.hierarchy_group}'"
            )

        next_dim = hier_dims[next_level]
        parent_dim = hier_dims[req.current_level]

        filters = dict(req.extra_filters)
        if req.parent_value is not None:
            filters[parent_dim.column_name] = {"type": "eq", "value": req.parent_value}

        t0 = time.perf_counter()
        req_q = QueryRequest(
            dimensions=[next_dim.column_name],
            metrics=req.metrics,
            filters=filters,
            order_by=req.metrics[0] if req.metrics else None,
            order_desc=True,
            limit=get_settings().chart_drilldown_limit,
        )
        result_q = await QueryService(self.db).execute_query(dataset_id, req_q)
        elapsed = (time.perf_counter() - t0) * 1000

        cat_data = format_category(
            chart_id=f"drilldown_{req.hierarchy_group}_{next_level}",
            title=f"{next_dim.display_name} → {req.parent_value or 'все'}",
            rows=result_q.rows,
            dimension=next_dim.column_name,
            metrics=req.metrics,
            execution_ms=round(elapsed, 2),
        )

        return DrilldownData(
            next_dimension=next_dim.column_name,
            parent_value=req.parent_value,
            points=cat_data.points,
            execution_ms=round(elapsed, 2),
        )
