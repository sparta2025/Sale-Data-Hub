# VERSION: 1.2.0
# Path: backend/app/modules/dashboard_engine/router.py
# CHANGES v1.0.0:
#   - Этап 5: API /api/dashboards — CRUD + данные KPI/чартов/drill-down
# CHANGES v1.1.0:
#   - Этап 8 фикс: эндпоинты chart/kpi не пробрасывали filters в сервисный слой,
#     хотя DashboardService их полностью поддерживал — FilterBar (Этап 7) не мог
#     влиять на данные. Добавлен query-параметр filters (JSON-encoded FilterMap)
#     во все эндпоинты: kpi, timeseries, category, pie, treemap, table.
# CHANGES v1.2.0:
#   - Этап 8 фикс 2: локальный _parse_filters/_FilterMapAdapter заменён на общий
#     parse_filters_json из app.schemas.query — та же логика теперь переиспользуется
#     в query_engine/router.py (distinct values), без дублирования кода.
"""API-эндпоинты Dashboard Engine."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.postgres import get_db
from app.modules.dashboard_engine.service import DashboardNotFoundError, DashboardService
from app.modules.query_engine.service import QueryValidationError
from app.schemas.dashboard import (
    CategoryData, DashboardCreate, DashboardOut, DashboardUpdate,
    DrilldownData, DrilldownRequest,
    KpiCard, PieData, TableData, TimeseriesData, TreemapData,
)
from app.schemas.query import parse_filters_json

router = APIRouter()

_FILTERS_QUERY_DESCRIPTION = (
    'JSON-encoded карта фильтров, например '
    '{"Год":{"type":"range","min":2015,"max":2020},'
    '"Страна":{"type":"in","values":["Германия","Франция"]}}'
)


def _parse_filters(filters_json: str | None) -> dict:
    """Тонкая обёртка над parse_filters_json: ValueError -> HTTPException(422)."""
    try:
        return parse_filters_json(filters_json)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"Некорректный параметр filters: {exc}") from exc


def _svc(db: AsyncSession = Depends(get_db)) -> DashboardService:
    return DashboardService(db)


def _handle(exc: Exception) -> HTTPException:
    if isinstance(exc, HTTPException):
        # Уже готовый HTTPException (например 422 из _parse_filters) — пробрасываем
        # как есть, не заворачиваем в 500. Без этой проверки validation-ошибки
        # в query-параметре filters долетали до клиента как "500 Internal Server
        # Error" вместо honest "422 Unprocessable Entity".
        return exc
    if isinstance(exc, DashboardNotFoundError):
        return HTTPException(status_code=404, detail=str(exc))
    if isinstance(exc, QueryValidationError):
        return HTTPException(status_code=422, detail=str(exc))
    return HTTPException(status_code=500, detail=str(exc))


# ── CRUD ──────────────────────────────────────────────────────────────────────

@router.post("/{dataset_id}", response_model=DashboardOut, status_code=201)
async def create_dashboard(
    dataset_id: str, data: DashboardCreate, svc: DashboardService = Depends(_svc)
):
    try:
        return DashboardOut.model_validate(await svc.create(dataset_id, data))
    except Exception as exc:
        raise _handle(exc)


@router.get("/{dataset_id}", response_model=list[DashboardOut])
async def list_dashboards(dataset_id: str, svc: DashboardService = Depends(_svc)):
    return [DashboardOut.model_validate(d) for d in await svc.list_by_dataset(dataset_id)]


@router.get("/item/{dashboard_id}", response_model=DashboardOut)
async def get_dashboard(dashboard_id: str, svc: DashboardService = Depends(_svc)):
    try:
        return DashboardOut.model_validate(await svc.get(dashboard_id))
    except DashboardNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.put("/item/{dashboard_id}", response_model=DashboardOut)
async def update_dashboard(
    dashboard_id: str, data: DashboardUpdate, svc: DashboardService = Depends(_svc)
):
    try:
        return DashboardOut.model_validate(await svc.update(dashboard_id, data))
    except DashboardNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/item/{dashboard_id}", status_code=204)
async def delete_dashboard(dashboard_id: str, svc: DashboardService = Depends(_svc)):
    try:
        await svc.delete(dashboard_id)
    except DashboardNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ── Данные для чартов ─────────────────────────────────────────────────────────

@router.get("/{dataset_id}/kpi", response_model=list[KpiCard])
async def get_kpi(
    dataset_id: str,
    metrics: list[str] = Query(...),
    filters: str | None = Query(None, description=_FILTERS_QUERY_DESCRIPTION),
    svc: DashboardService = Depends(_svc),
):
    """KPI-карточки: итоговые агрегаты по всему датасету (с учётом фильтров)."""
    try:
        return await svc.get_kpi(dataset_id, metrics, _parse_filters(filters))
    except Exception as exc:
        raise _handle(exc)


@router.post("/{dataset_id}/chart/timeseries", response_model=TimeseriesData)
async def get_timeseries(
    dataset_id: str,
    time_dimensions: list[str] = Query(...),
    metrics: list[str] = Query(...),
    chart_id: str = Query("timeseries"),
    title: str = Query(""),
    group_by: str | None = Query(None),
    filters: str | None = Query(None, description=_FILTERS_QUERY_DESCRIPTION),
    limit: int = Query(500),
    svc: DashboardService = Depends(_svc),
):
    """Данные для линейного/барного чарта по времени."""
    try:
        return await svc.get_timeseries(
            dataset_id, chart_id, title, time_dimensions, metrics, group_by,
            filters=_parse_filters(filters), limit=limit,
        )
    except Exception as exc:
        raise _handle(exc)


@router.get("/{dataset_id}/chart/category", response_model=CategoryData)
async def get_category(
    dataset_id: str,
    dimension: str = Query(...),
    metrics: list[str] = Query(...),
    chart_id: str = Query("category"),
    title: str = Query(""),
    filters: str | None = Query(None, description=_FILTERS_QUERY_DESCRIPTION),
    limit: int = Query(50),
    svc: DashboardService = Depends(_svc),
):
    """Данные для бар-чарта по категории."""
    try:
        return await svc.get_category(
            dataset_id, chart_id, title, dimension, metrics,
            filters=_parse_filters(filters), limit=limit,
        )
    except Exception as exc:
        raise _handle(exc)


@router.get("/{dataset_id}/chart/pie", response_model=PieData)
async def get_pie(
    dataset_id: str,
    dimension: str = Query(...),
    metric: str = Query(...),
    chart_id: str = Query("pie"),
    title: str = Query(""),
    filters: str | None = Query(None, description=_FILTERS_QUERY_DESCRIPTION),
    limit: int = Query(20),
    svc: DashboardService = Depends(_svc),
):
    """Данные для круговой диаграммы."""
    try:
        return await svc.get_pie(
            dataset_id, chart_id, title, dimension, metric,
            filters=_parse_filters(filters), limit=limit,
        )
    except Exception as exc:
        raise _handle(exc)


@router.get("/{dataset_id}/chart/treemap", response_model=TreemapData)
async def get_treemap(
    dataset_id: str,
    dimensions: list[str] = Query(...),
    metric: str = Query(...),
    chart_id: str = Query("treemap"),
    title: str = Query(""),
    filters: str | None = Query(None, description=_FILTERS_QUERY_DESCRIPTION),
    svc: DashboardService = Depends(_svc),
):
    """Данные для иерархической треemap."""
    try:
        return await svc.get_treemap(
            dataset_id, chart_id, title, dimensions, metric,
            filters=_parse_filters(filters),
        )
    except Exception as exc:
        raise _handle(exc)


@router.post("/{dataset_id}/chart/table", response_model=TableData)
async def get_table(
    dataset_id: str,
    dimensions: list[str] = Query(...),
    metrics: list[str] = Query(...),
    chart_id: str = Query("table"),
    title: str = Query(""),
    order_by: str | None = Query(None),
    order_desc: bool = Query(False),
    filters: str | None = Query(None, description=_FILTERS_QUERY_DESCRIPTION),
    limit: int = Query(200),
    svc: DashboardService = Depends(_svc),
):
    """Данные для агрегированной таблицы."""
    try:
        return await svc.get_table(
            dataset_id, chart_id, title, dimensions, metrics,
            filters=_parse_filters(filters), order_by=order_by, order_desc=order_desc, limit=limit,
        )
    except Exception as exc:
        raise _handle(exc)


@router.post("/{dataset_id}/drilldown", response_model=DrilldownData)
async def get_drilldown(
    dataset_id: str,
    req: DrilldownRequest,
    svc: DashboardService = Depends(_svc),
):
    """Drill-down: данные следующего уровня иерархии при клике на элемент чарта."""
    try:
        return await svc.get_drilldown(dataset_id, req)
    except Exception as exc:
        raise _handle(exc)
