# VERSION: 1.0.0
# Path: backend/app/modules/kpi/service.py
# CHANGES v1.0.0:
#   - Этап 14: KpiService — scorecard() и compare().
#     scorecard(): для каждой видимой метрики выполняет один SQL SELECT с
#     двумя условными агрегатами (FILTER WHERE period_col = A/B) — один проход.
#     compare(): один SELECT с GROUP BY dimension + FILTER для двух периодов.
#     Все запросы через asyncio.to_thread + QUERY_LOCK.
import asyncio
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.duckdb_conn import QUERY_LOCK, duckdb_cursor
from app.models.dataset import Dataset
from app.models.metadata import Dimension, Metric
from app.schemas.kpi import (
    KpiCompareItem, KpiCompareResponse,
    KpiMetricPeriod, KpiScorecardResponse,
)


class KpiService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------
    async def _get_dataset(self, dataset_id: str) -> Dataset:
        ds = await self.db.get(Dataset, uuid.UUID(dataset_id))
        if ds is None:
            raise ValueError(f"Dataset {dataset_id} not found")
        return ds

    async def _get_metrics(self, dataset_id: str) -> list[Metric]:
        res = await self.db.execute(
            select(Metric)
            .where(Metric.dataset_id == uuid.UUID(dataset_id))
            .where(Metric.is_visible.is_(True))
        )
        return list(res.scalars().all())

    async def _get_dimension(self, dataset_id: str, col: str) -> Dimension | None:
        res = await self.db.execute(
            select(Dimension)
            .where(Dimension.dataset_id == uuid.UUID(dataset_id))
            .where(Dimension.column_name == col)
        )
        return res.scalar_one_or_none()

    # ------------------------------------------------------------------
    async def scorecard(
        self,
        dataset_id: str,
        period_col: str,
        period_a: str,
        period_b: str,
    ) -> KpiScorecardResponse:
        """KPI Скоркарта: все метрики, период A vs период B за один проход."""
        ds      = await self._get_dataset(dataset_id)
        metrics = await self._get_metrics(dataset_id)
        if not metrics:
            return KpiScorecardResponse(
                dataset_id=dataset_id, period_col=period_col,
                period_a=period_a, period_b=period_b, metrics=[],
            )

        tbl  = f'"{ds.duckdb_table_name}"'
        pcol = f'"{period_col}"'

        # Один SELECT: для каждой метрики — два условных SUM
        agg_parts = []
        for m in metrics:
            mc = f'"{m.column_name}"'
            agg_parts.append(
                f'SUM({mc}) FILTER (WHERE CAST({pcol} AS VARCHAR) = \'{period_a}\') AS val_a_{len(agg_parts)},'
                f'SUM({mc}) FILTER (WHERE CAST({pcol} AS VARCHAR) = \'{period_b}\') AS val_b_{len(agg_parts)}'
            )
        sql = f"SELECT {', '.join(agg_parts)} FROM {tbl}"

        def _run(sql=sql):
            with duckdb_cursor() as cur:
                cur.execute(sql)
                return cur.fetchone()

        async with QUERY_LOCK:
            row = await asyncio.to_thread(_run)

        result_metrics: list[KpiMetricPeriod] = []
        for i, m in enumerate(metrics):
            va = float(row[i * 2]     or 0) if row else 0.0
            vb = float(row[i * 2 + 1] or 0) if row else 0.0
            delta_abs = va - vb
            delta_pct = (delta_abs / abs(vb) * 100) if vb != 0 else 0.0
            result_metrics.append(KpiMetricPeriod(
                column_name=m.column_name,
                display_name=m.display_name,
                display_format=m.display_format,
                value_a=round(va, 4),
                value_b=round(vb, 4),
                delta_abs=round(delta_abs, 4),
                delta_pct=round(delta_pct, 2),
            ))

        return KpiScorecardResponse(
            dataset_id=dataset_id, period_col=period_col,
            period_a=period_a, period_b=period_b, metrics=result_metrics,
        )

    # ------------------------------------------------------------------
    async def compare(
        self,
        dataset_id: str,
        dimension: str,
        metric: str,
        period_col: str,
        period_a: str,
        period_b: str,
        limit: int = 20,
    ) -> KpiCompareResponse:
        """Сравнение двух периодов по метрике в разрезе dimension."""
        ds         = await self._get_dataset(dataset_id)
        metric_obj = next(
            (m for m in await self._get_metrics(dataset_id) if m.column_name == metric), None
        )

        tbl  = f'"{ds.duckdb_table_name}"'
        dim  = f'"{dimension}"'
        met  = f'"{metric}"'
        pcol = f'"{period_col}"'

        sql = f"""
        SELECT
            {dim} AS label,
            SUM({met}) FILTER (WHERE CAST({pcol} AS VARCHAR) = '{period_a}') AS va,
            SUM({met}) FILTER (WHERE CAST({pcol} AS VARCHAR) = '{period_b}') AS vb
        FROM {tbl}
        GROUP BY {dim}
        ORDER BY va DESC NULLS LAST
        LIMIT {limit}
        """

        def _run(sql=sql):
            with duckdb_cursor() as cur:
                cur.execute(sql)
                return cur.fetchall()

        async with QUERY_LOCK:
            rows = await asyncio.to_thread(_run)

        items: list[KpiCompareItem] = []
        for label, va, vb in (rows or []):
            va = float(va or 0)
            vb = float(vb or 0)
            delta_pct = ((va - vb) / abs(vb) * 100) if vb != 0 else 0.0
            items.append(KpiCompareItem(
                label=str(label),
                value_a=round(va, 4),
                value_b=round(vb, 4),
                delta_pct=round(delta_pct, 2),
            ))

        return KpiCompareResponse(
            dataset_id=dataset_id,
            dimension=dimension,
            metric=metric,
            metric_display=metric_obj.display_name if metric_obj else metric,
            period_a=period_a,
            period_b=period_b,
            items=items,
        )
