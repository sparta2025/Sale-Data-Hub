# VERSION: 1.0.0
# Path: backend/app/modules/kpi/router.py
# CHANGES v1.0.0:
#   - Этап 14: GET /kpi/{dataset_id}/scorecard и /compare
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.postgres import get_db
from app.modules.kpi.service import KpiService
from app.schemas.kpi import KpiScorecardResponse, KpiCompareResponse

router = APIRouter()


@router.get(
    "/{dataset_id}/scorecard",
    response_model=KpiScorecardResponse,
    summary="KPI Скоркарта: все метрики с period-vs-period",
)
async def kpi_scorecard(
    dataset_id: str,
    period_col: str = Query(..., description="Колонка периода (напр. 'Год')"),
    period_a:   str = Query(..., description="Текущий период (напр. '2025')"),
    period_b:   str = Query(..., description="Базовый период (напр. '2024')"),
    db: AsyncSession = Depends(get_db),
) -> KpiScorecardResponse:
    """
    Возвращает все видимые метрики с суммой за period_a и period_b —
    один SQL-проход с условными агрегатами FILTER WHERE.
    """
    return await KpiService(db).scorecard(dataset_id, period_col, period_a, period_b)


@router.get(
    "/{dataset_id}/compare",
    response_model=KpiCompareResponse,
    summary="Сравнение двух периодов по одной метрике в разрезе dimension",
)
async def kpi_compare(
    dataset_id: str,
    dimension:  str = Query(..., description="Колонка группировки"),
    metric:     str = Query(..., description="Метрика для сравнения"),
    period_col: str = Query(..., description="Колонка периода"),
    period_a:   str = Query(..., description="Период A"),
    period_b:   str = Query(..., description="Период B"),
    limit:      int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
) -> KpiCompareResponse:
    """
    Возвращает top-N категорий с суммой метрики за оба периода
    и % изменением для side-by-side bar chart.
    """
    return await KpiService(db).compare(
        dataset_id, dimension, metric, period_col, period_a, period_b, limit,
    )
