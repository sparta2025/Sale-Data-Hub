# VERSION: 1.0.0
# Path: backend/app/modules/platform_registry/router.py
# CHANGES v1.0.0:
#   - Этап 15: GET /api/platform/info — информация о платформе и активных модулях.
#     GET /api/platform/modules — список модулей для фронтенда.
#     ENABLED_MODULES env var → список разрешённых модулей.
#     Используется фронтендом при старте для синхронизации с сервером.
import os
from datetime import datetime, timezone
from fastapi import APIRouter
from app.schemas.platform import ModuleInfo, PlatformInfo

router = APIRouter()

PLATFORM_VERSION = "0.15.0"
API_VERSION      = "v1"
STARTED_AT       = datetime.now(timezone.utc).isoformat()

# Все известные модули на backend
ALL_BACKEND_MODULES: list[ModuleInfo] = [
    ModuleInfo(id="dashboards", name="Dashboards",   version="0.15.0", tier="free",       enabled=True,  routes=["/api/datasets", "/api/metadata", "/api/query", "/api/export"]),
    ModuleInfo(id="kpi",        name="KPI Analysis", version="1.0.0",  tier="pro",        enabled=False, routes=["/api/kpi"]),
    ModuleInfo(id="analytics",  name="Analytics",    version="1.0.0",  tier="free",       enabled=True,  routes=["/api/analytics"]),
    ModuleInfo(id="agents",     name="AI Agents",    version="0.0.1",  tier="enterprise", enabled=False, routes=[]),
]


def _get_enabled_modules() -> list[ModuleInfo]:
    """
    Читает ENABLED_MODULES из env.
    Пустая строка / не задана → все модули разрешены.
    """
    raw = os.getenv("ENABLED_MODULES", "").strip()
    if not raw:
        return [m.model_copy(update={"enabled": True}) for m in ALL_BACKEND_MODULES]
    allowed = {s.strip() for s in raw.split(",")}
    return [m.model_copy(update={"enabled": m.id in allowed}) for m in ALL_BACKEND_MODULES]


@router.get("/info", response_model=PlatformInfo, summary="Информация о платформе")
async def platform_info() -> PlatformInfo:
    """Версия платформы, активные модули, режим развёртывания."""
    modules = _get_enabled_modules()
    return PlatformInfo(
        platform_name="Sales BI Platform",
        platform_version=PLATFORM_VERSION,
        api_version=API_VERSION,
        started_at=STARTED_AT,
        enabled_modules=modules,
        standalone_mode=os.getenv("STANDALONE_MODE", "false").lower() == "true",
    )


@router.get("/modules", response_model=list[ModuleInfo], summary="Список модулей")
async def list_modules() -> list[ModuleInfo]:
    """Упрощённый список модулей для фронтенда."""
    return _get_enabled_modules()
