# VERSION: 1.0.0
# Path: backend/app/interfaces/data_exporter.py
# CHANGES v1.0.0:
#   - Этап 1: контракт IDataExporter (реализация — Этап 6)
"""
IDataExporter — контракт экспорта данных (Этап 6: CSV/XLSX/PDF/PNG).
Каждый формат экспорта — отдельная реализация этого интерфейса, регистрируемая
в одном месте (фабрика экспортёров), что позволяет добавлять новые форматы без
изменения остального кода.
"""
from abc import ABC, abstractmethod
from typing import Any


class IDataExporter(ABC):
    @abstractmethod
    async def export(self, data: Any, options: dict[str, Any] | None = None) -> bytes:
        """Сериализует данные в байты целевого формата (CSV/XLSX/PDF/PNG)."""
        raise NotImplementedError

    @property
    @abstractmethod
    def content_type(self) -> str:
        """MIME-тип результата — используется для HTTP-ответа."""
        raise NotImplementedError

    @property
    @abstractmethod
    def file_extension(self) -> str:
        """Расширение файла без точки (например, 'csv')."""
        raise NotImplementedError
