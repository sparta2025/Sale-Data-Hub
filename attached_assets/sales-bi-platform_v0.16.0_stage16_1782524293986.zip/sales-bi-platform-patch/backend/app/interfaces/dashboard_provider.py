# VERSION: 1.0.0
# Path: backend/app/interfaces/dashboard_provider.py
# CHANGES v1.0.0:
#   - Этап 1: контракт IDashboardProvider (реализация — Этап 5)
"""
IDashboardProvider — контракт хранения/получения конфигураций дашбордов.

Реализация появится в Этапе 5 (Dashboard Engine). Дашборд описывается JSON-
конфигурацией (источник данных, тип графика, измерения, метрики, фильтры — см. ТЗ).
Интерфейс отделяет "как дашборды хранятся" от "как они рендерятся" — в перспективе
сюда можно подключить версионирование, шаринг между пользователями, AI-генерацию
конфигов и т.п. без переписывания фронтенда.
"""
from abc import ABC, abstractmethod
from typing import Any


class IDashboardProvider(ABC):
    @abstractmethod
    async def get_dashboard(self, dashboard_id: str) -> dict[str, Any]:
        """Возвращает JSON-конфигурацию дашборда по id."""
        raise NotImplementedError

    @abstractmethod
    async def list_dashboards(self) -> list[dict[str, Any]]:
        """Возвращает список доступных дашбордов (id + название + краткое описание)."""
        raise NotImplementedError

    @abstractmethod
    async def save_dashboard(self, dashboard_id: str, config: dict[str, Any]) -> None:
        """Создаёт или обновляет конфигурацию дашборда."""
        raise NotImplementedError
