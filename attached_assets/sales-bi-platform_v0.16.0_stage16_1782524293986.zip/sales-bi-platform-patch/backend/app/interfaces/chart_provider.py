# VERSION: 1.0.0
# Path: backend/app/interfaces/chart_provider.py
# CHANGES v1.0.0:
#   - Этап 1: контракт IChartProvider (реализация — Этап 5/8)
"""
IChartProvider — контракт получения данных для конкретного типа визуализации
(линейный график, столбчатая диаграмма, pie, treemap, heatmap, waterfall — Этап 5/8).

Каждый тип графика реализует этот интерфейс и сам решает, какой SQL-запрос к
DuckDB (через Query Engine) ему нужен для своей формы данных. Dashboard Engine
работает только с этим контрактом и не знает деталей конкретных графиков —
это позволяет добавлять новые типы графиков, не трогая остальную систему.
"""
from abc import ABC, abstractmethod
from typing import Any


class IChartProvider(ABC):
    @abstractmethod
    async def get_chart_data(
        self,
        dataset_id: str,
        dimensions: list[str],
        metrics: list[str],
        filters: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Возвращает данные в формате, готовом для рендеринга конкретным типом
        графика (например, для ECharts) — конкретная форма ответа зависит от
        реализации (line/bar/pie/treemap/heatmap/waterfall).
        """
        raise NotImplementedError
