# VERSION: 1.0.0
# Path: backend/app/interfaces/__init__.py
# CHANGES v1.0.0:
#   - Этап 1: единая точка импорта всех интерфейсов расширяемости
from app.interfaces.chart_provider import IChartProvider
from app.interfaces.dashboard_provider import IDashboardProvider
from app.interfaces.data_exporter import IDataExporter
from app.interfaces.data_provider import IDataProvider, ImportResult
from app.interfaces.metric_provider import IMetricProvider

__all__ = [
    "IChartProvider",
    "IDashboardProvider",
    "IDataExporter",
    "IDataProvider",
    "ImportResult",
    "IMetricProvider",
]
