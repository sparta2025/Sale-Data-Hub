# VERSION: 1.0.0
# Path: backend/app/interfaces/data_provider.py
# CHANGES v1.0.0:
#   - Этап 1: контракт IDataProvider + ImportResult (реализация — Этап 2)
"""
IDataProvider — контракт источника данных.

Сейчас единственная реализация — локальные CSV/XLSX файлы (Этап 2,
app/modules/data_import). Интерфейс заведён уже сейчас, чтобы в будущем можно
было подключить новые источники (БД клиента, API, потоковые источники, выгрузки
из ERP и т.п.) без переписывания Query Engine / Dashboard Engine — им достаточно
получить данные, реализующие этот контракт.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class ImportResult:
    dataset_id: str
    rows_imported: int
    rows_rejected: int
    warnings: list[str]


class IDataProvider(ABC):
    """Базовый контракт для любого поставщика табличных данных в систему."""

    @abstractmethod
    async def import_data(self, source: Any, dataset_name: str) -> ImportResult:
        """Загружает данные из источника и сохраняет их в аналитическое хранилище."""
        raise NotImplementedError

    @abstractmethod
    async def validate_structure(self, source: Any) -> list[str]:
        """Возвращает список проблем структуры (пустой список — всё ок)."""
        raise NotImplementedError

    @abstractmethod
    async def get_preview(self, dataset_id: str, limit: int = 50) -> list[dict[str, Any]]:
        """Возвращает несколько строк датасета для предпросмотра."""
        raise NotImplementedError
