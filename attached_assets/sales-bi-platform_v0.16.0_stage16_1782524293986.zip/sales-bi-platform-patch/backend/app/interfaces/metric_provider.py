# VERSION: 1.0.0
# Path: backend/app/interfaces/metric_provider.py
# CHANGES v1.0.0:
#   - Этап 1: контракт IMetricProvider (реализация — Этап 5)
"""
IMetricProvider — контракт вычисления метрик/KPI (Этап 5: главная страница,
KPI-карточки). Позволяет в будущем подключать вычисляемые/производные метрики
(в т.ч. через AI-агентов или RAG, см. ТЗ) без изменения Query Engine.
"""
from abc import ABC, abstractmethod
from typing import Any


class IMetricProvider(ABC):
    @abstractmethod
    async def compute_metric(self, dataset_id: str, metric_name: str, filters: dict[str, Any]) -> float:
        """Вычисляет одну метрику с учётом текущих фильтров/уровня drill-down."""
        raise NotImplementedError

    @abstractmethod
    async def list_available_metrics(self, dataset_id: str) -> list[str]:
        """Список метрик, доступных для датасета (определяется Metadata Module)."""
        raise NotImplementedError
