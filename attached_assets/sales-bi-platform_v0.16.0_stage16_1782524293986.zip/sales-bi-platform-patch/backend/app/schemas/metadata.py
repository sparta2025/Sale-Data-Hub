# VERSION: 1.0.0
# Path: backend/app/schemas/metadata.py
# CHANGES v1.0.0:
#   - Этап 3: схемы DimensionOut, MetricOut, MetadataOverview, патч-схемы
"""Pydantic-схемы ответов API Metadata Module."""
import uuid
from typing import Literal

from pydantic import BaseModel, ConfigDict

AggregationMethod = Literal["sum", "avg", "count", "min", "max"]


class DimensionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    dataset_id: uuid.UUID
    column_name: str
    display_name: str
    data_type: str
    hierarchy_group: str | None
    hierarchy_level: int
    sample_values: list
    distinct_count: int
    is_visible: bool


class DimensionPatch(BaseModel):
    """Что пользователь может поправить вручную."""
    display_name: str | None = None
    hierarchy_group: str | None = None
    hierarchy_level: int | None = None
    is_visible: bool | None = None


class MetricOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    dataset_id: uuid.UUID
    column_name: str
    display_name: str
    data_type: str
    aggregation: AggregationMethod
    display_format: str
    is_visible: bool


class MetricPatch(BaseModel):
    display_name: str | None = None
    aggregation: AggregationMethod | None = None
    display_format: str | None = None
    is_visible: bool | None = None


class HierarchyInfo(BaseModel):
    """Описание одной иерархии (для Этапов 5/9 — drill-down)."""
    name: str          # "time" | "geography" | "product"
    label: str         # "Временна́я иерархия" (для UI)
    levels: list[DimensionOut]   # отсортировано по hierarchy_level


class MetadataOverview(BaseModel):
    dataset_id: uuid.UUID
    dimensions_count: int
    metrics_count: int
    hierarchies: list[HierarchyInfo]
    dimensions: list[DimensionOut]
    metrics: list[MetricOut]
