# VERSION: 1.0.0
# Path: backend/app/schemas/analytics.py
# CHANGES v1.0.0:
#   - Этап 12: схемы для аналитического describe — статистическая сводка
#     по числовым колонкам датасета (min, max, mean, median, Q1, Q3, std, nulls%).
from pydantic import BaseModel


class ColumnStats(BaseModel):
    """Статистика по одной числовой колонке (метрике)."""
    column_name: str
    display_name: str
    count: int
    null_count: int
    null_pct: float
    min: float
    max: float
    mean: float
    median: float
    std: float
    q1: float
    q3: float
    iqr: float          # Q3 - Q1
    cv: float           # коэффициент вариации = std / mean * 100 (%)


class DescribeResponse(BaseModel):
    """Результат describe по всем видимым метрикам датасета."""
    dataset_id: str
    columns: list[ColumnStats]
