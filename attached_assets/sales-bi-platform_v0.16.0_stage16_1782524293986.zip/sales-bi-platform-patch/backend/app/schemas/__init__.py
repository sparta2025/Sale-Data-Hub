# VERSION: 1.5.0
# Path: backend/app/schemas/__init__.py
# CHANGES v1.0.0:
#   - Этап 2: точка импорта схем датасета (файл переписан целиком, см. models/__init__.py)
# CHANGES v1.2.0:
#   - Этап 5: добавлены схемы Dashboard / chart data
# CHANGES v1.3.0:
#   - Этап 6: добавлены ExportRequest / ExportFormat
from app.schemas.dataset import ColumnProfile, DatasetOut, ImportResponse, PreviewResponse
from app.schemas.metadata import (
    DimensionOut, DimensionPatch, MetricOut, MetricPatch, HierarchyInfo, MetadataOverview,
)
from app.schemas.query import (
    QueryRequest, QueryResult, AggregatedValue, RangeFilter, InFilter, EqFilter, FilterSpec,
)
from app.schemas.dashboard import (
    ChartConfig, DashboardConfig, DashboardCreate, DashboardUpdate, DashboardOut,
    KpiCard, TimeseriesData, CategoryData, PieData, TreemapData, TableData,
    DrilldownRequest, DrilldownData,
)

from app.schemas.export import ExportRequest, ExportFormat
from app.schemas.analytics import ColumnStats, DescribeResponse
from app.schemas.kpi import KpiMetricPeriod, KpiScorecardResponse, KpiCompareItem, KpiCompareResponse

__all__ = [
    "ColumnProfile", "DatasetOut", "ImportResponse", "PreviewResponse",
    "DimensionOut", "DimensionPatch", "MetricOut", "MetricPatch", "HierarchyInfo", "MetadataOverview",
    "QueryRequest", "QueryResult", "AggregatedValue", "RangeFilter", "InFilter", "EqFilter", "FilterSpec",
    "ChartConfig", "DashboardConfig", "DashboardCreate", "DashboardUpdate", "DashboardOut",
    "KpiCard", "TimeseriesData", "CategoryData", "PieData", "TreemapData", "TableData",
    "DrilldownRequest", "DrilldownData",
    "ExportRequest", "ExportFormat",
    "ColumnStats", "DescribeResponse",
]
