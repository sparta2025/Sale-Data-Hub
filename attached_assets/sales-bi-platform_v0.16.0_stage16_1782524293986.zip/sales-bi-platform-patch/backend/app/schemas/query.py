# VERSION: 1.1.0
# Path: backend/app/schemas/query.py
# CHANGES v1.0.0:
#   - Этап 4: схемы QueryRequest/QueryResult/FilterSpec для Query Engine
# CHANGES v1.1.0:
#   - Этап 8 фикс: добавлен parse_filters_json() — общий хелпер разбора
#     JSON-encoded FilterMap из query-параметра, переиспользуется в
#     dashboard_engine/router.py и query_engine/router.py (вместо дублирования
#     одинакового TypeAdapter-кода в двух местах)
"""
Схемы аналитических запросов к DuckDB.

QueryRequest описывает, ЧТО хочет получить клиент:
  - dimensions: список колонок для GROUP BY
  - metrics: список колонок для агрегации
  - filters: фильтры по значениям (=, IN, BETWEEN)
  - limit: максимум строк результата

QueryResult — что возвращается: строки агрегата + мета-информация (время выполнения).
"""
from typing import Any, Literal
from pydantic import BaseModel, Field, TypeAdapter, ValidationError


class RangeFilter(BaseModel):
    """Фильтр диапазона: column BETWEEN min AND max."""
    type: Literal["range"] = "range"
    min: float | int | None = None
    max: float | int | None = None


class InFilter(BaseModel):
    """Фильтр по множеству значений: column IN (...)."""
    type: Literal["in"] = "in"
    values: list[Any]


class EqFilter(BaseModel):
    """Точное совпадение: column = value."""
    type: Literal["eq"] = "eq"
    value: Any


FilterSpec = RangeFilter | InFilter | EqFilter

_FilterMapAdapter = TypeAdapter(dict[str, FilterSpec])


def parse_filters_json(filters_json: str | None) -> dict[str, FilterSpec]:
    """
    Разбирает JSON-encoded карту фильтров из query-параметра, например:
      {"Год":{"type":"range","min":2015,"max":2020},
       "Страна":{"type":"in","values":["Германия","Франция"]}}

    Пустая строка/None -> {} (без фильтров). Невалидный JSON или несоответствие
    схеме FilterSpec -> ValueError (вызывающая сторона в роутере конвертирует
    его в HTTPException 422).
    """
    if not filters_json:
        return {}
    try:
        return _FilterMapAdapter.validate_json(filters_json)
    except ValidationError as exc:
        raise ValueError(str(exc)) from exc


class QueryRequest(BaseModel):
    """Запрос к Query Engine."""
    dimensions: list[str] = Field(default_factory=list, description="Колонки для GROUP BY")
    metrics: list[str] = Field(default_factory=list, description="Колонки для агрегации")
    filters: dict[str, FilterSpec] = Field(
        default_factory=dict,
        description="Фильтры: {column_name: FilterSpec}"
    )
    order_by: str | None = Field(None, description="Имя колонки для сортировки")
    order_desc: bool = False
    limit: int = Field(1000, ge=1, le=50000)


class QueryResult(BaseModel):
    """Результат аналитического запроса."""
    dataset_id: str
    columns: list[str]
    rows: list[dict[str, Any]]
    total_rows: int
    sql: str  # сгенерированный SQL для отладки
    execution_ms: float


class AggregatedValue(BaseModel):
    """Одно агрегированное значение для KPI-карточки."""
    metric: str
    display_name: str
    value: float | int | None
    aggregation: str
    display_format: str
