# VERSION: 1.0.0
# Path: backend/app/schemas/dashboard.py
# CHANGES v1.0.0:
#   - Этап 5: схемы Dashboard CRUD и форматов данных чартов
"""Схемы Dashboard Module."""
import uuid
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

# ── Конфигурация чарта внутри дашборда ────────────────────────────────────

ChartType = Literal["timeseries", "bar", "pie", "treemap", "heatmap", "table"]


class ChartConfig(BaseModel):
    id: str
    type: ChartType
    title: str = ""
    dimensions: list[str] = Field(default_factory=list)
    metrics: list[str] = Field(default_factory=list)
    group_by: str | None = None   # доп. измерение для серий (например Страна в линейном)
    limit: int = 500


class DashboardConfig(BaseModel):
    kpi_metrics: list[str] = Field(default_factory=list)
    default_filters: dict[str, Any] = Field(default_factory=dict)
    charts: list[ChartConfig] = Field(default_factory=list)


# ── CRUD схемы дашборда ────────────────────────────────────────────────────

class DashboardCreate(BaseModel):
    name: str
    description: str | None = None
    config: DashboardConfig = Field(default_factory=DashboardConfig)


class DashboardUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    config: DashboardConfig | None = None


class DashboardOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    dataset_id: uuid.UUID
    name: str
    description: str | None
    config: dict
    created_at: datetime
    updated_at: datetime


# ── Форматы данных для чартов (отдаются фронтенду) ────────────────────────

class KpiCard(BaseModel):
    """KPI-карточка: одна метрика с итоговым значением."""
    metric: str
    display_name: str
    value: float | int | None
    aggregation: str
    display_format: str


class TimeseriesPoint(BaseModel):
    """Одна точка временного ряда."""
    period: str              # "2015-01", "2015", "Q1 2015"
    value: float | int | None
    series: str | None = None  # имя серии (например страна) при group_by


class TimeseriesData(BaseModel):
    chart_id: str
    title: str
    series_names: list[str]
    points: list[TimeseriesPoint]
    execution_ms: float


class CategoryPoint(BaseModel):
    """Одно значение категориального чарта."""
    category: str
    values: dict[str, float | int | None]  # {metric_name: value}


class CategoryData(BaseModel):
    chart_id: str
    title: str
    categories: list[str]
    metrics: list[str]
    points: list[CategoryPoint]
    execution_ms: float


class PieSlice(BaseModel):
    name: str
    value: float | int | None
    percentage: float | None = None


class PieData(BaseModel):
    chart_id: str
    title: str
    metric: str
    total: float | int | None
    slices: list[PieSlice]
    execution_ms: float


class TreemapNode(BaseModel):
    name: str
    value: float | int | None
    children: list["TreemapNode"] = Field(default_factory=list)


class TreemapData(BaseModel):
    chart_id: str
    title: str
    metric: str
    root: TreemapNode
    execution_ms: float


class TableData(BaseModel):
    chart_id: str
    title: str
    columns: list[str]
    rows: list[dict[str, Any]]
    total_rows: int
    execution_ms: float


class DrilldownRequest(BaseModel):
    """Запрос данных следующего уровня иерархии."""
    hierarchy_group: str              # "time" | "geography" | "product"
    current_level: int                # текущий уровень (0 = верхний)
    parent_value: str | None = None   # значение текущего уровня (фильтр)
    metrics: list[str]
    extra_filters: dict[str, Any] = Field(default_factory=dict)


class DrilldownData(BaseModel):
    next_dimension: str
    parent_value: str | None
    points: list[CategoryPoint]
    execution_ms: float
