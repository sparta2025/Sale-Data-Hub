# VERSION: 1.0.0
# Path: backend/app/schemas/export.py
# CHANGES v1.0.0:
#   - Этап 6: схемы ExportRequest, ExportFormat для Export Module
"""Схемы Export Module."""
from typing import Any, Literal
from pydantic import BaseModel, Field

ExportFormat = Literal["csv", "xlsx", "pdf"]


class ExportRequest(BaseModel):
    """
    Параметры экспорта. Повторяет логику QueryRequest, но добавляет:
      - format: целевой формат файла
      - title: заголовок отчёта (для PDF/XLSX)
      - include_summary: включить сводную строку итогов (SUM/AVG по метрикам)
    """
    dimensions: list[str] = Field(default_factory=list)
    metrics: list[str] = Field(default_factory=list)
    filters: dict[str, Any] = Field(default_factory=dict)
    order_by: str | None = None
    order_desc: bool = False
    limit: int = Field(50_000, ge=1, le=100_000)

    format: ExportFormat = "csv"
    title: str = "Отчёт о продажах"
    include_summary: bool = True
