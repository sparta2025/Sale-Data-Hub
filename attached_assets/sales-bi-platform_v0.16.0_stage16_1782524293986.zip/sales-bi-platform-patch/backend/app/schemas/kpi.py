# VERSION: 1.0.0
# Path: backend/app/schemas/kpi.py
# CHANGES v1.0.0:
#   - Этап 14: схемы KPI Analysis модуля.
#     KpiScorecardResponse — сводка всех метрик: текущий период vs предыдущий.
#     KpiCompareResponse — два ряда значений по категории для side-by-side чарта.
from pydantic import BaseModel


class KpiMetricPeriod(BaseModel):
    """Значение одной метрики за один период."""
    column_name: str
    display_name: str
    display_format: str
    value_a: float       # текущий период
    value_b: float       # предыдущий период
    delta_abs: float     # value_a - value_b
    delta_pct: float     # % изменение


class KpiScorecardResponse(BaseModel):
    """KPI Скоркарта: все видимые метрики с периодным сравнением."""
    dataset_id: str
    period_col: str
    period_a: str
    period_b: str
    metrics: list[KpiMetricPeriod]


class KpiCompareItem(BaseModel):
    """Одна категория с двумя значениями для side-by-side."""
    label: str
    value_a: float
    value_b: float
    delta_pct: float


class KpiCompareResponse(BaseModel):
    """Сравнение двух периодов по одной метрике в разрезе категории."""
    dataset_id: str
    dimension: str
    metric: str
    metric_display: str
    period_a: str
    period_b: str
    items: list[KpiCompareItem]
