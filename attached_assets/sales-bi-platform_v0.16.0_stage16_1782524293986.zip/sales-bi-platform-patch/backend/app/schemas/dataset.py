# VERSION: 1.0.0
# Path: backend/app/schemas/dataset.py
# CHANGES v1.0.0:
#   - Этап 2: Pydantic-схемы ColumnProfile/DatasetOut/ImportResponse/PreviewResponse
"""Схемы ответов API модуля импорта данных."""
import uuid
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

ColumnRole = Literal["dimension", "metric"]
ColumnDataType = Literal[
    "text", "integer", "float", "percentage", "currency", "year", "month",
]


class ColumnProfile(BaseModel):
    name: str
    role: ColumnRole
    data_type: ColumnDataType
    nullable: bool
    distinct_count: int
    sample_values: list[Any] = []


class DatasetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    original_filename: str
    source_format: str
    row_count: int
    column_count: int
    status: str
    created_at: datetime


class ImportResponse(BaseModel):
    dataset: DatasetOut
    warnings: list[str]
    columns: list[ColumnProfile]


class PreviewResponse(BaseModel):
    dataset_id: uuid.UUID
    columns: list[str]
    rows: list[dict[str, Any]]
    total_rows: int
