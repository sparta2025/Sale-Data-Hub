# VERSION: 1.0.0
# Path: backend/app/schemas/platform.py
# CHANGES v1.0.0:
#   - Этап 15: схемы Platform Registry — список активных модулей платформы,
#     версия платформы, конфигурация сервера.
from pydantic import BaseModel
from datetime import datetime


class ModuleInfo(BaseModel):
    id: str
    name: str
    version: str
    tier: str          # free | pro | enterprise
    enabled: bool
    routes: list[str]  # API-роуты, которые регистрирует модуль


class PlatformInfo(BaseModel):
    platform_name: str
    platform_version: str
    api_version: str
    started_at: str
    enabled_modules: list[ModuleInfo]
    standalone_mode: bool
