# VERSION: 1.0.0
# Path: backend/app/core/__init__.py
# CHANGES v1.0.0:
#   - Этап 1: маркер пакета app.core
