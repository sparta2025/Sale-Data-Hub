# VERSION: 2.0.0
# Path: backend/app/core/config.py
# CHANGES v1.0.0:
#   - Этап 1: класс Settings (pydantic-settings) — Postgres/DuckDB/upload_dir/
#     CORS/лимиты производительности; get_settings() с lru_cache
# CHANGES v2.0.0:
#   - Этап 8: расширен после аудита .env — добавлены все параметры, которые
#     ранее были захардкожены в модулях: лимиты чартов, пагинация, экспорт,
#     обнаружение иерархий, форматы отображения, CORS как строка из env.
"""
Центральная конфигурация приложения.

Все настраиваемые параметры читаются из переменных окружения (см. .env.example
в корне репозитория). Ничего не хардкодим — это важно, так как приложение должно
одинаково работать локально, в Docker Compose и в проде.
"""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # ── Общее ─────────────────────────────────────────────────────────────────
    app_name: str = "Sales BI Platform"
    environment: str = "development"  # development | production
    debug: bool = True

    # ── PostgreSQL ─────────────────────────────────────────────────────────────
    postgres_user: str = "bi_user"
    postgres_password: str = "bi_password"
    postgres_db: str = "bi_metadata"
    postgres_host: str = "localhost"
    postgres_port: int = 5432

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+asyncpg://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    @property
    def database_url_sync(self) -> str:
        return (
            f"postgresql+psycopg2://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    # ── DuckDB ────────────────────────────────────────────────────────────────
    duckdb_path: str = "../data/duckdb/analytics.duckdb"

    @property
    def duckdb_file(self) -> Path:
        path = Path(self.duckdb_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    # ── Файловое хранилище ────────────────────────────────────────────────────
    upload_dir: str = "../data/uploads"

    @property
    def upload_path(self) -> Path:
        path = Path(self.upload_dir)
        path.mkdir(parents=True, exist_ok=True)
        return path

    # Максимальный размер загружаемого файла в мегабайтах
    max_upload_size_mb: int = 200

    # ── CORS ──────────────────────────────────────────────────────────────────
    # Строка URL через запятую: "http://localhost:5173,http://localhost:3000"
    # pydantic-settings автоматически превратит "a,b" в ["a", "b"] для list[str]
    cors_origins: list[str] = ["http://localhost:5173", "http://localhost:3000"]

    # ── Лимиты Query Engine ───────────────────────────────────────────────────
    # Лимит строк по умолчанию для POST /api/query/{id}
    query_default_limit: int = 1000
    # Абсолютный потолок лимита (клиент не может запросить больше)
    query_max_limit: int = 50000
    # Максимум уникальных значений для дропдаунов FilterBar
    distinct_values_limit: int = 200
    # TTL кэша Query Engine в секундах (0 = кэш отключён, зарезервировано)
    query_cache_ttl_seconds: int = 0

    # ── Лимиты чартов (Dashboard Engine) ─────────────────────────────────────
    chart_category_limit: int = 10      # топ-N категорий в bar-chart
    chart_pie_limit: int = 10           # количество секторов в pie
    chart_waterfall_limit: int = 8      # столбцов в waterfall (без "Итого")
    chart_timeseries_limit: int = 500   # точек в timeseries
    chart_table_limit: int = 200        # строк в таблице
    chart_drilldown_limit: int = 100    # строк drill-down следующего уровня
    chart_heatmap_query_limit: int = 5000  # строк heatmap через Query Engine

    # ── Экспорт ───────────────────────────────────────────────────────────────
    export_pdf_max_rows: int = 1000   # строк в PDF-таблице до обрезания
    export_png_dpi: int = 100         # разрешение PNG
    export_png_bar_width: int = 900
    export_png_bar_height: int = 500
    export_png_pie_width: int = 700
    export_png_pie_height: int = 700
    export_png_line_width: int = 1000
    export_png_line_height: int = 500

    # ── Форматы отображения метрик (Metadata Detector) ───────────────────────
    # Python format-string, используется в formatValue.ts и PDF/XLSX-экспорте
    format_currency: str = "€ {:,.2f}"
    format_percentage: str = "{:.1%}"
    format_integer: str = "{:,.0f}"
    format_float: str = "{:,.2f}"

    # ── Ключевые слова иерархий (Metadata Detector) ──────────────────────────
    # Разделитель — символ | (pipe). Регистронезависимое частичное совпадение.
    hierarchy_time_l0_keywords: str = "год|year"
    hierarchy_time_l1_keywords: str = "месяц|month|квартал|quarter"
    hierarchy_geo_l0_keywords: str = "страна|country|регион|region"
    hierarchy_geo_l1_keywords: str = "филиал|город|city|branch|офис"
    hierarchy_product_l0_keywords: str = "товарная группа|product group|категория|category"
    hierarchy_product_l1_keywords: str = "товар|product|артикул|sku|номенклатура"


@lru_cache
def get_settings() -> Settings:
    """Settings — синглтон на процесс (через lru_cache), чтобы не парсить env каждый раз."""
    return Settings()
