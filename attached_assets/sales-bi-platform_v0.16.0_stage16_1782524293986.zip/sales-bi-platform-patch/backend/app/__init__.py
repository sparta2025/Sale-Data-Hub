# VERSION: 1.0.0
# Path: backend/app/__init__.py
# CHANGES v1.0.0:
#   - Этап 1: маркер пакета app
