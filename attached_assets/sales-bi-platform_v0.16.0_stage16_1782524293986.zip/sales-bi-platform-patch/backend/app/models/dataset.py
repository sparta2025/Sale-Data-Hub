# VERSION: 1.0.0
# Path: backend/app/models/dataset.py
# CHANGES v1.0.0:
#   - Этап 2: ORM-модель Dataset — реестр загруженных датасетов в Postgres
# CHANGES v1.1.0:
#   - Этап 5: добавлен relationship dashboards
"""
Dataset — запись о загруженном отчёте: где лежат его данные (имя таблицы в
DuckDB), сколько строк/столбцов, в каком статусе импорт, какие предупреждения
возникли при очистке. Сами данные (строки отчёта) здесь не хранятся — только
метаданные о них (см. ТЗ: "PostgreSQL для метаданных, DuckDB для аналитики").

column_profile хранит результат автоопределения структуры (роль/тип каждой
колонки, см. structure_detector.py) как JSON — это рабочий кэш, который
Metadata Module (Этап 3) переосмыслит в полноценные таблицы dimensions/metrics.
"""
import uuid
from datetime import datetime

from sqlalchemy import JSON, DateTime, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.postgres import Base


class Dataset(Base):
    __tablename__ = "datasets"

    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(512), nullable=False)
    source_format: Mapped[str] = mapped_column(String(16), nullable=False)  # 'csv' | 'xlsx'
    duckdb_table: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)

    row_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    column_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    status: Mapped[str] = mapped_column(String(32), nullable=False, default="ready")  # 'ready' | 'failed'
    warnings: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    column_profile: Mapped[list] = mapped_column(JSON, nullable=False, default=list)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    dimensions = relationship("Dimension", back_populates="dataset", cascade="all, delete-orphan")
    metrics = relationship("Metric", back_populates="dataset", cascade="all, delete-orphan")
    dashboards = relationship("Dashboard", back_populates="dataset", cascade="all, delete-orphan")
