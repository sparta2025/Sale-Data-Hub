# VERSION: 1.0.0
# Path: backend/app/models/metadata.py
# CHANGES v1.0.0:
#   - Этап 3: ORM-модели Dimension и Metric — структурированные метаданные
#     каждого датасета; используются Query Engine (Этап 4) и Dashboard (Этап 5)
"""
Dimension — одно измерение датасета (текстовая/временнáя категория для
группировки/фильтрации): Страна, Год, Месяц, Товарная группа и т.п.

Metric — одна метрика датасета (числовой показатель для агрегации):
Выручка нетто, Валовая прибыль, Маржа % и т.п.

Почему отдельные таблицы, а не JSON в Dataset.column_profile?
column_profile — черновой снимок «что нашли при импорте» (только для
структурного детектора). Здесь же — полноценный «словарь данных» с
иерархиями, агрегациями и форматами отображения, который пользователь
может редактировать вручную (Этапы 7-9).
"""
import uuid
from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.postgres import Base


class Dimension(Base):
    __tablename__ = "dimensions"

    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dataset_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True
    )

    # Имя колонки в DuckDB-таблице (machine name)
    column_name: Mapped[str] = mapped_column(String(255), nullable=False)
    # Человекочитаемое имя для UI (по умолчанию = column_name, редактируется пользователем)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)

    # text | year | month — из structure_detector
    data_type: Mapped[str] = mapped_column(String(32), nullable=False)

    # Иерархия drill-down:
    #   hierarchy_group = "time" | "geography" | "product" | None
    #   hierarchy_level = 0 (верхний) … N (нижний)
    # Пример: Страна(geo,0) → Филиал(geo,1); Год(time,0) → Месяц(time,1)
    hierarchy_group: Mapped[str | None] = mapped_column(String(64), nullable=True)
    hierarchy_level: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Примеры значений для фильтров в UI
    sample_values: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    distinct_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Пользователь может скрыть измерение из UI, не удаляя его
    is_visible: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    dataset = relationship("Dataset", back_populates="dimensions")


class Metric(Base):
    __tablename__ = "metrics"

    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dataset_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True
    )

    column_name: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)

    # integer | float | percentage | currency — из structure_detector
    data_type: Mapped[str] = mapped_column(String(32), nullable=False)

    # Метод агрегации по умолчанию: sum | avg | count | min | max
    # currency/integer → sum; percentage → avg
    aggregation: Mapped[str] = mapped_column(String(16), nullable=False, default="sum")

    # Строка формата для UI: "€ {:.2f}" | "{:.1%}" | "{:,.0f}"
    display_format: Mapped[str] = mapped_column(String(64), nullable=False, default="{:.2f}")

    is_visible: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    dataset = relationship("Dataset", back_populates="metrics")
