# VERSION: 1.0.0
# Path: backend/app/models/dashboard.py
# CHANGES v1.0.0:
#   - Этап 5: ORM-модель Dashboard — сохранённая конфигурация дашборда
"""
Dashboard — сохранённая конфигурация дашборда пользователя.

Хранит:
  - привязку к датасету
  - глобальные фильтры по умолчанию (период, страны и т.п.)
  - список KPI-метрик для карточек
  - список чартов с их настройками (тип, измерения, метрики)

Архитектурное решение: вся конфигурация чартов хранится в едином
JSON-поле config (а не в отдельных таблицах chart/widget). Это позволяет
легко сериализовать/десериализовать весь дашборд за один SELECT,
упрощает первые этапы разработки и достаточно гибко для ТЗ.
"""
import uuid
from datetime import datetime

from sqlalchemy import JSON, DateTime, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.postgres import Base


class Dashboard(Base):
    __tablename__ = "dashboards"

    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dataset_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("datasets.id", ondelete="CASCADE"),
        nullable=False, index=True
    )

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(String(1024), nullable=True)

    # Полная конфигурация дашборда. Структура:
    # {
    #   "kpi_metrics": ["Выручка нетто (EUR)", "Количество"],
    #   "default_filters": {"Год": {"type": "range", "min": 2015, "max": 2026}},
    #   "charts": [
    #     {
    #       "id": "chart_1",
    #       "type": "timeseries",   -- timeseries|bar|pie|treemap|heatmap|table
    #       "title": "Выручка по месяцам",
    #       "dimensions": ["Год", "Месяц"],
    #       "metrics": ["Выручка нетто (EUR)"],
    #       "group_by": "Страна",  -- опциональная серия
    #       "limit": 100
    #     }
    #   ]
    # }
    config: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    dataset = relationship("Dataset", back_populates="dashboards")
