# VERSION: 1.2.0
# Path: backend/app/models/__init__.py
# CHANGES v1.0.0:
#   - Этап 2: Dataset
# CHANGES v1.1.0:
#   - Этап 3: Dimension, Metric
# CHANGES v1.2.0:
#   - Этап 5: Dashboard
# CHANGES v1.2.0:
#   - Этап 5: добавлен импорт Dashboardfrom app.models.dataset import Dataset
from app.models.metadata import Dimension, Metric
from app.models.dashboard import Dashboard

__all__ = ["Dataset", "Dimension", "Metric", "Dashboard"]
