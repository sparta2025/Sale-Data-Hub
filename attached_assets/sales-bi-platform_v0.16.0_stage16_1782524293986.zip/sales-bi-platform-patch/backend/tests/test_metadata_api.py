# VERSION: 1.0.0
# Path: backend/tests/test_metadata_api.py
# CHANGES v1.0.0:
#   - Этап 3: интеграционные тесты /api/metadata против реального Postgres+DuckDB
"""Интеграционные тесты Metadata Module."""
import io
import csv as csv_module

import pytest
from fastapi.testclient import TestClient

from app.main import app

_ROWS = [
    {"Страна": "Германия", "Филиал": "Берлин", "Год": "2015", "Месяц": "1",
     "Товарная группа": "Группа А", "Товар": "Товар-01",
     "Количество": "10", "Выручка нетто (EUR)": "49013.9",
     "Маржа валовой прибыли (%)": "0.32"},
    {"Страна": "Франция",  "Филиал": "Париж",  "Год": "2015", "Месяц": "2",
     "Товарная группа": "Группа Б", "Товар": "Товар-02",
     "Количество": "5",  "Выручка нетто (EUR)": "31200.5",
     "Маржа валовой прибыли (%)": "0.28"},
]


def _csv() -> bytes:
    buf = io.StringIO()
    w = csv_module.DictWriter(buf, fieldnames=_ROWS[0].keys())
    w.writeheader(); w.writerows(_ROWS)
    return buf.getvalue().encode("utf-8")



@pytest.fixture()
def uploaded_dataset_id(client):
    """Загружаем датасет свежо для каждого теста.
    DB чиста к этому моменту благодаря autouse _clean_datasets_table."""
    resp = client.post(
        "/api/datasets/upload",
        files={"file": ("meta_test.csv", io.BytesIO(_csv()), "text/csv")},
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["dataset"]["id"]


# ── GET /api/metadata/{dataset_id} ──────────────────────────────────────────

def test_overview_is_created_automatically_on_upload(client, uploaded_dataset_id):
    """Метаданные должны строиться автоматически при upload, без ручного вызова."""
    resp = client.get(f"/api/metadata/{uploaded_dataset_id}")
    assert resp.status_code == 200


def test_overview_correct_counts(client, uploaded_dataset_id):
    body = client.get(f"/api/metadata/{uploaded_dataset_id}").json()
    assert body["dimensions_count"] == 6
    assert body["metrics_count"] == 3


def test_overview_has_time_hierarchy(client, uploaded_dataset_id):
    body = client.get(f"/api/metadata/{uploaded_dataset_id}").json()
    h_names = [h["name"] for h in body["hierarchies"]]
    assert "time" in h_names


def test_overview_time_hierarchy_order(client, uploaded_dataset_id):
    body = client.get(f"/api/metadata/{uploaded_dataset_id}").json()
    time_h = next(h for h in body["hierarchies"] if h["name"] == "time")
    assert time_h["levels"][0]["column_name"] == "Год"
    assert time_h["levels"][1]["column_name"] == "Месяц"


def test_overview_has_geography_hierarchy(client, uploaded_dataset_id):
    body = client.get(f"/api/metadata/{uploaded_dataset_id}").json()
    h_names = [h["name"] for h in body["hierarchies"]]
    assert "geography" in h_names


def test_overview_geography_hierarchy_order(client, uploaded_dataset_id):
    body = client.get(f"/api/metadata/{uploaded_dataset_id}").json()
    geo = next(h for h in body["hierarchies"] if h["name"] == "geography")
    cols = [l["column_name"] for l in geo["levels"]]
    assert cols.index("Страна") < cols.index("Филиал")


def test_overview_404_for_unknown_dataset(client):
    resp = client.get("/api/metadata/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404


# ── GET /api/metadata/{dataset_id}/dimensions ────────────────────────────────

def test_get_dimensions_returns_all(client, uploaded_dataset_id):
    resp = client.get(f"/api/metadata/{uploaded_dataset_id}/dimensions")
    assert resp.status_code == 200
    assert len(resp.json()) == 6


def test_dimensions_have_required_fields(client, uploaded_dataset_id):
    dims = client.get(f"/api/metadata/{uploaded_dataset_id}/dimensions").json()
    for d in dims:
        assert "id" in d
        assert "column_name" in d
        assert "data_type" in d
        assert "is_visible" in d


# ── GET /api/metadata/{dataset_id}/metrics ───────────────────────────────────

def test_get_metrics_returns_all(client, uploaded_dataset_id):
    resp = client.get(f"/api/metadata/{uploaded_dataset_id}/metrics")
    assert resp.status_code == 200
    assert len(resp.json()) == 3


def test_percentage_metric_aggregation_is_avg(client, uploaded_dataset_id):
    mets = client.get(f"/api/metadata/{uploaded_dataset_id}/metrics").json()
    маржа = next(m for m in mets if "Маржа" in m["column_name"])
    assert маржа["aggregation"] == "avg"


def test_currency_metric_aggregation_is_sum(client, uploaded_dataset_id):
    mets = client.get(f"/api/metadata/{uploaded_dataset_id}/metrics").json()
    выручка = next(m for m in mets if "Выручка" in m["column_name"])
    assert выручка["aggregation"] == "sum"
    assert "€" in выручка["display_format"]


# ── PATCH /api/metadata/dimensions/{id} ─────────────────────────────────────

def test_patch_dimension_display_name(client, uploaded_dataset_id):
    dims = client.get(f"/api/metadata/{uploaded_dataset_id}/dimensions").json()
    страна = next(d for d in dims if d["column_name"] == "Страна")
    resp = client.patch(
        f"/api/metadata/dimensions/{страна['id']}",
        json={"display_name": "Государство"},
    )
    assert resp.status_code == 200
    assert resp.json()["display_name"] == "Государство"


def test_patch_dimension_visibility(client, uploaded_dataset_id):
    dims = client.get(f"/api/metadata/{uploaded_dataset_id}/dimensions").json()
    товар = next(d for d in dims if d["column_name"] == "Товар")
    resp = client.patch(
        f"/api/metadata/dimensions/{товар['id']}",
        json={"is_visible": False},
    )
    assert resp.status_code == 200
    assert resp.json()["is_visible"] is False


# ── PATCH /api/metadata/metrics/{id} ────────────────────────────────────────

def test_patch_metric_aggregation(client, uploaded_dataset_id):
    mets = client.get(f"/api/metadata/{uploaded_dataset_id}/metrics").json()
    кол = next(m for m in mets if m["column_name"] == "Количество")
    resp = client.patch(
        f"/api/metadata/metrics/{кол['id']}",
        json={"aggregation": "avg", "display_name": "Среднее количество"},
    )
    assert resp.status_code == 200
    assert resp.json()["aggregation"] == "avg"
    assert resp.json()["display_name"] == "Среднее количество"


# ── POST /api/metadata/{dataset_id}/refresh ──────────────────────────────────

def test_refresh_metadata_restores_defaults(client, uploaded_dataset_id):
    """Refresh сбрасывает ручные правки обратно к авто-детектированным значениям."""
    resp = client.post(f"/api/metadata/{uploaded_dataset_id}/refresh")
    assert resp.status_code == 200
    body = resp.json()
    # После refresh количество dim/metric должно совпадать
    assert body["dimensions_count"] == 6
    assert body["metrics_count"] == 3
    # Агрегация Количество должна вернуться к sum
    кол = next(m for m in body["metrics"] if m["column_name"] == "Количество")
    assert кол["aggregation"] == "sum"
