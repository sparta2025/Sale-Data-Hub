# VERSION: 1.0.0
# Path: backend/tests/test_duckdb_conn.py
# CHANGES v1.0.0:
#   - Этап 1: тест реального запроса/записи в DuckDB через get_raw_connection()
"""Тесты app.db.duckdb_conn — реальное соединение с DuckDB (тестовый файл)."""
from app.db.duckdb_conn import duckdb_cursor, get_raw_connection


def test_get_raw_connection_returns_working_connection():
    conn = get_raw_connection()
    result = conn.execute("SELECT 1 + 1 AS value").fetchone()
    assert result == (2,)


def test_get_raw_connection_is_singleton():
    assert get_raw_connection() is get_raw_connection()


def test_duckdb_cursor_context_manager_executes_query():
    with duckdb_cursor() as conn:
        result = conn.execute("SELECT 'hello' AS greeting").fetchone()
    assert result == ("hello",)


def test_can_create_and_query_table():
    """Дымовой тест на запись/чтение — то, на чём будет строиться Этап 2 (импорт)."""
    with duckdb_cursor() as conn:
        conn.execute("CREATE OR REPLACE TABLE _smoke_test (id INTEGER, name VARCHAR)")
        conn.execute("INSERT INTO _smoke_test VALUES (1, 'Берлин'), (2, 'Париж')")
        rows = conn.execute("SELECT * FROM _smoke_test ORDER BY id").fetchall()
    assert rows == [(1, "Берлин"), (2, "Париж")]


# ── QUERY_LOCK (Этап 9) ───────────────────────────────────────────────────────

def test_query_lock_exported():
    """QUERY_LOCK должен быть доступен из duckdb_conn — используется в QueryService."""
    from app.db.duckdb_conn import QUERY_LOCK
    import asyncio
    assert isinstance(QUERY_LOCK, asyncio.Lock), "QUERY_LOCK должен быть asyncio.Lock"


def test_query_lock_is_singleton():
    """Один и тот же объект Lock при каждом импорте — иначе сериализация не работает."""
    from app.db.duckdb_conn import QUERY_LOCK
    from app.db import duckdb_conn
    assert QUERY_LOCK is duckdb_conn.QUERY_LOCK, "Lock должен быть единственным экземпляром"
