# VERSION: 1.0.0
# Path: backend/tests/test_cleaner.py
# CHANGES v1.0.0:
#   - Этап 2: тесты модуля очистки данных (замена пропусков, NULL vs 0, предупреждения)
"""Тесты app.modules.data_import.cleaner."""
import pandas as pd

from app.modules.data_import.cleaner import MISSING_TEXT_PLACEHOLDER, clean_dataframe
from app.modules.data_import.structure_detector import detect_column_profiles


def _df(*cols: tuple) -> pd.DataFrame:
    """Хелпер: создаёт DataFrame из (name, values) — гарантирует >1 столбца,
    чтобы dropna(how='all') не удалял строки с NaN только в тестируемом столбце."""
    return pd.DataFrame({name: vals for name, vals in cols})


def test_fully_empty_rows_are_dropped():
    # Строка [None, None] — ВСЕ столбцы пусты => должна удалиться
    df = pd.DataFrame({"A": [1, None, 3], "B": ["x", None, "z"]})
    profiles = detect_column_profiles(df)
    cleaned, warnings = clean_dataframe(df, profiles)
    assert len(cleaned) == 2
    assert any("пустых строк" in w for w in warnings)


def test_missing_text_replaced_with_placeholder():
    # Строка с None только в «Страна», но «Год» заполнен → строка остаётся
    df = _df(("Страна", ["Германия", None, "Польша"]),
             ("Год",    [2015,      2015, 2026]))
    profiles = detect_column_profiles(df)
    cleaned, warnings = clean_dataframe(df, profiles)
    assert cleaned["Страна"].tolist() == ["Германия", MISSING_TEXT_PLACEHOLDER, "Польша"]
    assert any("заменено на" in w for w in warnings)


def test_text_values_are_stripped_of_whitespace():
    df = _df(("Страна", [" Германия ", "Польша"]),
             ("Год",    [2015,          2026]))
    profiles = detect_column_profiles(df)
    cleaned, _ = clean_dataframe(df, profiles)
    assert cleaned["Страна"].tolist() == ["Германия", "Польша"]


def test_missing_numeric_stays_null_not_zero():
    """Пропуски в метриках не должны заполняться нулём — это искажает SUM/AVG."""
    # Вторая колонка нужна, чтобы dropna(how='all') не удалила строку с NaN
    df = _df(("Выручка нетто (EUR)", [100.0, None, 300.0]),
             ("Год",                  [2015,  2015, 2026]))
    profiles = detect_column_profiles(df)
    cleaned, _ = clean_dataframe(df, profiles)
    assert cleaned["Выручка нетто (EUR)"].isna().sum() == 1
    assert (cleaned["Выручка нетто (EUR)"] == 0).sum() == 0


def test_invalid_numeric_value_becomes_null_with_warning():
    """Одна опечатка среди 5 нормальных значений (83% > 80%) → столбец спасается
    как числовой, «не число» → NULL с предупреждением."""
    df = _df(("Выручка нетто (EUR)", [100.0, 200.0, 300.0, 400.0, 500.0, "не число"]),
             ("Год",                  [2015,  2015,  2015,  2016,  2016,  2016]))
    profiles = detect_column_profiles(df)
    cleaned, warnings = clean_dataframe(df, profiles)
    assert cleaned["Выручка нетто (EUR)"].isna().sum() == 1
    assert any("нечисловых значений" in w for w in warnings)


def test_missing_year_generates_drill_down_warning():
    # None только в «Год» — строка НЕ удаляется (другие столбцы заполнены)
    df = _df(("Год",    [2015, None, 2026]),
             ("Страна", ["Германия", "Франция", "Польша"]))
    profiles = detect_column_profiles(df)
    _cleaned, warnings = clean_dataframe(df, profiles)
    assert any("drill-down" in w for w in warnings)


def test_clean_dataframe_on_data_without_issues_produces_no_warnings():
    df = _df(("Страна", ["Германия", "Польша"]),
             ("Год",    [2015, 2026]))
    profiles = detect_column_profiles(df)
    _cleaned, warnings = clean_dataframe(df, profiles)
    assert warnings == []
