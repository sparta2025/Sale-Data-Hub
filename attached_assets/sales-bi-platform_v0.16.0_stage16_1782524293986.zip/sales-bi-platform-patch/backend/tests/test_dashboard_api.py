# VERSION: 1.0.0
# Path: backend/tests/test_dashboard_api.py
# CHANGES v1.0.0:
#   - Этап 5: интеграционные тесты /api/dashboards — CRUD + данные чартов
"""Интеграционные тесты Dashboard Engine."""
import io, csv as csv_module
import pytest
from fastapi.testclient import TestClient
from app.main import app

_ROWS = [
    {"Страна": "Германия", "Филиал": "Берлин",  "Год": "2015", "Месяц": "1",
     "Товарная группа": "Группа А", "Товар": "Товар-01",
     "Выручка нетто (EUR)": "49000", "Количество": "10", "Маржа валовой прибыли (%)": "0.32"},
    {"Страна": "Германия", "Филиал": "Мюнхен",  "Год": "2015", "Месяц": "2",
     "Товарная группа": "Группа А", "Товар": "Товар-02",
     "Выручка нетто (EUR)": "51000", "Количество": "12", "Маржа валовой прибыли (%)": "0.30"},
    {"Страна": "Франция",  "Филиал": "Париж",   "Год": "2015", "Месяц": "1",
     "Товарная группа": "Группа Б", "Товар": "Товар-03",
     "Выручка нетто (EUR)": "31000", "Количество": "8",  "Маржа валовой прибыли (%)": "0.28"},
    {"Страна": "Польша",   "Филиал": "Варшава", "Год": "2026", "Месяц": "1",
     "Товарная группа": "Группа А", "Товар": "Товар-04",
     "Выручка нетто (EUR)": "22000", "Количество": "5",  "Маржа валовой прибыли (%)": "0.25"},
]


def _csv():
    buf = io.StringIO()
    w = csv_module.DictWriter(buf, fieldnames=_ROWS[0].keys())
    w.writeheader(); w.writerows(_ROWS)
    return buf.getvalue().encode("utf-8")


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture()
def ds_id(client):
    r = client.post("/api/datasets/upload",
                    files={"file": ("dash_test.csv", io.BytesIO(_csv()), "text/csv")})
    assert r.status_code == 200
    return r.json()["dataset"]["id"]


# ── CRUD ──────────────────────────────────────────────────────────────────────

def test_create_dashboard(client, ds_id):
    r = client.post(f"/api/dashboards/{ds_id}", json={
        "name": "Тестовый дашборд",
        "config": {"kpi_metrics": ["Выручка нетто (EUR)"], "charts": []}
    })
    assert r.status_code == 201
    body = r.json()
    assert body["name"] == "Тестовый дашборд"
    assert body["dataset_id"] == ds_id


def test_list_dashboards(client, ds_id):
    client.post(f"/api/dashboards/{ds_id}", json={"name": "Д1"})
    client.post(f"/api/dashboards/{ds_id}", json={"name": "Д2"})
    r = client.get(f"/api/dashboards/{ds_id}")
    assert r.status_code == 200
    assert len(r.json()) >= 2


def test_get_dashboard_by_id(client, ds_id):
    dash_id = client.post(f"/api/dashboards/{ds_id}", json={"name": "Д"}).json()["id"]
    r = client.get(f"/api/dashboards/item/{dash_id}")
    assert r.status_code == 200
    assert r.json()["id"] == dash_id


def test_update_dashboard(client, ds_id):
    dash_id = client.post(f"/api/dashboards/{ds_id}", json={"name": "Старое"}).json()["id"]
    r = client.put(f"/api/dashboards/item/{dash_id}", json={"name": "Новое"})
    assert r.status_code == 200
    assert r.json()["name"] == "Новое"


def test_delete_dashboard(client, ds_id):
    dash_id = client.post(f"/api/dashboards/{ds_id}", json={"name": "Удалить"}).json()["id"]
    assert client.delete(f"/api/dashboards/item/{dash_id}").status_code == 204
    assert client.get(f"/api/dashboards/item/{dash_id}").status_code == 404


# ── KPI ───────────────────────────────────────────────────────────────────────

def test_kpi_returns_correct_total(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/kpi",
                   params={"metrics": ["Выручка нетто (EUR)", "Количество"]})
    assert r.status_code == 200
    kpis = {k["metric"]: k for k in r.json()}
    assert kpis["Выручка нетто (EUR)"]["value"] == pytest.approx(153000, rel=0.01)
    assert kpis["Выручка нетто (EUR)"]["aggregation"] == "sum"
    assert "€" in kpis["Выручка нетто (EUR)"]["display_format"]


def test_kpi_percentage_uses_avg(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/kpi",
                   params={"metrics": ["Маржа валовой прибыли (%)"]})
    kpi = r.json()[0]
    assert kpi["aggregation"] == "avg"


# ── Timeseries ────────────────────────────────────────────────────────────────

def test_timeseries_by_year(client, ds_id):
    r = client.post(f"/api/dashboards/{ds_id}/chart/timeseries",
                    params={"time_dimensions": ["Год"],
                            "metrics": ["Выручка нетто (EUR)"],
                            "chart_id": "ts1", "title": "По годам"})
    assert r.status_code == 200
    body = r.json()
    periods = [p["period"] for p in body["points"]]
    assert "2015" in periods or "2026" in periods


def test_timeseries_with_group_by_country(client, ds_id):
    r = client.post(f"/api/dashboards/{ds_id}/chart/timeseries",
                    params={"time_dimensions": ["Год"],
                            "metrics": ["Выручка нетто (EUR)"],
                            "group_by": "Страна", "chart_id": "ts2"})
    assert r.status_code == 200
    series = {p["series"] for p in r.json()["points"]}
    assert "Германия" in series


# ── Category ─────────────────────────────────────────────────────────────────

def test_category_by_country(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/chart/category",
                   params={"dimension": "Страна",
                           "metrics": ["Выручка нетто (EUR)"],
                           "chart_id": "cat1"})
    assert r.status_code == 200
    cats = r.json()["categories"]
    assert "Германия" in cats
    assert "Франция" in cats


def test_category_sorted_desc(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/chart/category",
                   params={"dimension": "Страна", "metrics": ["Выручка нетто (EUR)"]})
    values = [p["values"]["Выручка нетто (EUR)"] for p in r.json()["points"]]
    assert values == sorted(values, reverse=True)


# ── Pie ───────────────────────────────────────────────────────────────────────

def test_pie_data(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/chart/pie",
                   params={"dimension": "Страна", "metric": "Выручка нетто (EUR)"})
    assert r.status_code == 200
    body = r.json()
    assert body["total"] == pytest.approx(153000, rel=0.01)
    slices = {s["name"]: s["percentage"] for s in body["slices"]}
    assert "Германия" in slices
    assert sum(slices.values()) == pytest.approx(100.0, rel=0.01)


# ── Treemap ───────────────────────────────────────────────────────────────────

def test_treemap_flat(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/chart/treemap",
                   params={"dimensions": ["Страна"], "metric": "Выручка нетто (EUR)"})
    assert r.status_code == 200
    children = r.json()["root"]["children"]
    names = [c["name"] for c in children]
    assert "Германия" in names


def test_treemap_nested(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/chart/treemap",
                   params={"dimensions": ["Товарная группа", "Товар"],
                           "metric": "Выручка нетто (EUR)"})
    assert r.status_code == 200
    top = r.json()["root"]["children"]
    assert any(len(n["children"]) > 0 for n in top)


# ── Table ─────────────────────────────────────────────────────────────────────

def test_table_data(client, ds_id):
    r = client.post(f"/api/dashboards/{ds_id}/chart/table",
                    params={"dimensions": ["Страна"],
                            "metrics": ["Выручка нетто (EUR)", "Количество"]})
    assert r.status_code == 200
    body = r.json()
    assert "Страна" in body["columns"]
    assert body["total_rows"] == 3


# ── Drilldown ─────────────────────────────────────────────────────────────────

def test_drilldown_geography(client, ds_id):
    r = client.post(f"/api/dashboards/{ds_id}/drilldown", json={
        "hierarchy_group": "geography",
        "current_level": 0,
        "parent_value": "Германия",
        "metrics": ["Выручка нетто (EUR)"]
    })
    assert r.status_code == 200
    body = r.json()
    assert body["next_dimension"] == "Филиал"
    filials = [p["category"] for p in body["points"]]
    assert "Берлин" in filials or "Мюнхен" in filials


def test_drilldown_invalid_hierarchy(client, ds_id):
    r = client.post(f"/api/dashboards/{ds_id}/drilldown", json={
        "hierarchy_group": "НесуществующаяИерархия",
        "current_level": 0,
        "metrics": ["Выручка нетто (EUR)"]
    })
    assert r.status_code in (404, 422, 500)


# ── Filters (Этап 8 фикс) ───────────────────────────────────────────────────
# Проверяем, что параметр filters (JSON-encoded) реально влияет на результат
# во всех chart-эндпоинтах, а не просто принимается и игнорируется.

def test_kpi_respects_filters(client, ds_id):
    import json as _json
    r_all = client.get(f"/api/dashboards/{ds_id}/kpi",
                       params={"metrics": ["Выручка нетто (EUR)"]})
    total_all = r_all.json()[0]["value"]

    filters = _json.dumps({"Страна": {"type": "eq", "value": "Германия"}})
    r_filtered = client.get(f"/api/dashboards/{ds_id}/kpi",
                            params={"metrics": ["Выручка нетто (EUR)"], "filters": filters})
    total_filtered = r_filtered.json()[0]["value"]

    assert total_filtered < total_all
    assert total_filtered == pytest.approx(100000, rel=0.01)  # 49000+51000


def test_category_respects_filters(client, ds_id):
    import json as _json
    filters = _json.dumps({"Год": {"type": "eq", "value": 2015}})
    r = client.get(f"/api/dashboards/{ds_id}/chart/category", params={
        "dimension": "Страна", "metrics": ["Выручка нетто (EUR)"], "filters": filters,
    })
    assert r.status_code == 200
    cats = r.json()["categories"]
    assert "Польша" not in cats  # Польша только в 2026 году


def test_pie_respects_filters(client, ds_id):
    import json as _json
    filters = _json.dumps({"Страна": {"type": "in", "values": ["Германия", "Франция"]}})
    r = client.get(f"/api/dashboards/{ds_id}/chart/pie", params={
        "dimension": "Страна", "metric": "Выручка нетто (EUR)", "filters": filters,
    })
    assert r.status_code == 200
    names = [s["name"] for s in r.json()["slices"]]
    assert "Польша" not in names


def test_timeseries_respects_filters(client, ds_id):
    import json as _json
    filters = _json.dumps({"Страна": {"type": "eq", "value": "Франция"}})
    r = client.post(f"/api/dashboards/{ds_id}/chart/timeseries", params={
        "time_dimensions": ["Год"], "metrics": ["Выручка нетто (EUR)"], "filters": filters,
    })
    assert r.status_code == 200
    # У Франции только 2015 год в тестовых данных
    periods = {p["period"] for p in r.json()["points"]}
    assert periods == {"2015"}


def test_treemap_respects_filters(client, ds_id):
    import json as _json
    filters = _json.dumps({"Страна": {"type": "eq", "value": "Германия"}})
    r = client.get(f"/api/dashboards/{ds_id}/chart/treemap", params={
        "dimensions": ["Страна"], "metric": "Выручка нетто (EUR)", "filters": filters,
    })
    assert r.status_code == 200
    names = [c["name"] for c in r.json()["root"]["children"]]
    assert names == ["Германия"]


def test_table_respects_filters(client, ds_id):
    import json as _json
    filters = _json.dumps({"Год": {"type": "eq", "value": 2026}})
    r = client.post(f"/api/dashboards/{ds_id}/chart/table", params={
        "dimensions": ["Страна"], "metrics": ["Количество"], "filters": filters,
    })
    assert r.status_code == 200
    assert r.json()["total_rows"] == 1  # только Польша в 2026


def test_invalid_filters_json_returns_422(client, ds_id):
    r = client.get(f"/api/dashboards/{ds_id}/kpi", params={
        "metrics": ["Выручка нетто (EUR)"], "filters": "{не валидный json",
    })
    assert r.status_code == 422


def test_empty_filters_param_means_no_filter(client, ds_id):
    """Пустая строка filters эквивалентна отсутствию параметра."""
    r1 = client.get(f"/api/dashboards/{ds_id}/kpi",
                    params={"metrics": ["Количество"]})
    r2 = client.get(f"/api/dashboards/{ds_id}/kpi",
                    params={"metrics": ["Количество"], "filters": ""})
    assert r1.json()[0]["value"] == r2.json()[0]["value"]
