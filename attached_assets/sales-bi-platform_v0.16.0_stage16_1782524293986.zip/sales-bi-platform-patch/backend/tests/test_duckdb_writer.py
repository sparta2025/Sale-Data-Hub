# VERSION: 1.0.0
# Path: backend/tests/test_duckdb_writer.py
# CHANGES v1.0.0:
#   - Этап 2: тесты write/fetch/count/drop таблиц датасетов в DuckDB
"""Тесты app.modules.data_import.duckdb_writer."""
import pandas as pd
import pytest

from app.modules.data_import.duckdb_writer import (
    count_rows,
    drop_dataset_table,
    fetch_preview,
    make_table_name,
    write_dataset_table,
)

_TABLE = "test_writer_table_etap2"


@pytest.fixture(autouse=True)
def _cleanup_duckdb_table():
    drop_dataset_table(_TABLE)
    yield
    drop_dataset_table(_TABLE)


def test_make_table_name_format():
    name = make_table_name("2dafbf00-ede3-431f-a3fb-9fc7fac9eb07")
    assert name.startswith("dataset_")
    assert "-" not in name
    assert len(name) > 10


def test_write_and_count_rows():
    df = pd.DataFrame({"Страна": ["Германия", "Польша"], "Год": [2015, 2026]})
    write_dataset_table(_TABLE, df)
    assert count_rows(_TABLE) == 2


def test_write_is_create_or_replace():
    """Повторная запись в ту же таблицу должна заменять данные, а не добавлять."""
    df1 = pd.DataFrame({"Страна": ["Германия", "Польша"]})
    df2 = pd.DataFrame({"Страна": ["Франция"]})
    write_dataset_table(_TABLE, df1)
    write_dataset_table(_TABLE, df2)
    assert count_rows(_TABLE) == 1


def test_fetch_preview_returns_correct_columns_and_rows():
    df = pd.DataFrame({"Страна": ["Германия", "Польша", "Франция"], "Год": [2015, 2026, 2015]})
    write_dataset_table(_TABLE, df)
    columns, rows = fetch_preview(_TABLE, limit=2)
    assert columns == ["Страна", "Год"]
    assert len(rows) == 2
    assert isinstance(rows[0], dict)
    assert "Страна" in rows[0]


def test_fetch_preview_respects_limit():
    df = pd.DataFrame({"Страна": [f"Страна-{i}" for i in range(20)]})
    write_dataset_table(_TABLE, df)
    _, rows = fetch_preview(_TABLE, limit=5)
    assert len(rows) == 5


def test_drop_table_makes_it_disappear():
    df = pd.DataFrame({"X": [1, 2, 3]})
    write_dataset_table(_TABLE, df)
    drop_dataset_table(_TABLE)
    # После удаления count_rows должен упасть с ошибкой
    with pytest.raises(Exception):
        count_rows(_TABLE)


def test_drop_nonexistent_table_is_safe():
    """DROP TABLE IF EXISTS — не должен бросать исключение."""
    drop_dataset_table("definitely_does_not_exist_xyz")


def test_write_large_dataframe_performance():
    """Базовая проверка масштабируемости: 5000 строк должны записываться < 3 секунд."""
    import time
    df = pd.DataFrame({
        "Страна": ["Германия"] * 5000,
        "Выручка (EUR)": [float(i) * 1.5 for i in range(5000)],
    })
    start = time.time()
    write_dataset_table(_TABLE, df)
    elapsed = time.time() - start
    assert count_rows(_TABLE) == 5000
    assert elapsed < 3.0, f"Запись 5000 строк заняла {elapsed:.2f}с — слишком медленно"
