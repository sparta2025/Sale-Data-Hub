# VERSION: 1.0.0
# Path: backend/tests/test_health.py
# CHANGES v1.0.0:
#   - Этап 1: тесты GET / и GET /api/health (включая отсутствие Postgres)
"""Тесты эндпоинтов / и /api/health."""
from fastapi.testclient import TestClient

from app.main import app


def test_root_returns_service_info():
    with TestClient(app) as client:
        response = client.get("/")
    assert response.status_code == 200
    body = response.json()
    assert body["service"] == "Sales BI Platform"
    assert body["docs"] == "/docs"


def test_health_check_responds_ok_even_without_postgres():
    """
    /api/health не должен возвращать ошибку, даже если PostgreSQL недоступен —
    это "мягкая" проверка (см. app/db/postgres.check_postgres_connection).
    """
    with TestClient(app) as client:
        response = client.get("/api/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["postgres"] in {"connected", "unavailable"}
