# VERSION: 1.0.0
# Path: backend/tests/test_query_api.py
# CHANGES v1.0.0:
#   - Этап 4: интеграционные тесты /api/query против реального DuckDB
"""Интеграционные тесты Query Engine."""
import io
import csv as csv_module

import pytest
from fastapi.testclient import TestClient

from app.main import app

# Датасет с несколькими странами, годами и числовыми метриками
_ROWS = [
    {"Страна": "Германия", "Год": "2015", "Месяц": "1", "Выручка нетто (EUR)": "49000", "Количество": "10", "Маржа валовой прибыли (%)": "0.32"},
    {"Страна": "Германия", "Год": "2015", "Месяц": "2", "Выручка нетто (EUR)": "51000", "Количество": "12", "Маржа валовой прибыли (%)": "0.30"},
    {"Страна": "Германия", "Год": "2026", "Месяц": "1", "Выручка нетто (EUR)": "60000", "Количество": "15", "Маржа валовой прибыли (%)": "0.35"},
    {"Страна": "Франция",  "Год": "2015", "Месяц": "1", "Выручка нетто (EUR)": "31000", "Количество": "8",  "Маржа валовой прибыли (%)": "0.28"},
    {"Страна": "Франция",  "Год": "2015", "Месяц": "2", "Выручка нетто (EUR)": "33000", "Количество": "9",  "Маржа валовой прибыли (%)": "0.29"},
    {"Страна": "Польша",   "Год": "2015", "Месяц": "1", "Выручка нетто (EUR)": "22000", "Количество": "5",  "Маржа валовой прибыли (%)": "0.25"},
]


def _csv() -> bytes:
    buf = io.StringIO()
    w = csv_module.DictWriter(buf, fieldnames=_ROWS[0].keys())
    w.writeheader(); w.writerows(_ROWS)
    return buf.getvalue().encode("utf-8")



@pytest.fixture()
def ds_id(client):
    resp = client.post(
        "/api/datasets/upload",
        files={"file": ("query_test.csv", io.BytesIO(_csv()), "text/csv")},
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["dataset"]["id"]


# ── POST /api/query/{dataset_id} ─────────────────────────────────────────────

def test_basic_group_by_query(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["Выручка нетто (EUR)"],
    })
    assert resp.status_code == 200
    body = resp.json()
    assert "Страна" in body["columns"]
    assert "Выручка нетто (EUR)" in body["columns"]
    assert body["total_rows"] == 3  # 3 страны


def test_group_by_multiple_dimensions(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна", "Год"],
        "metrics": ["Выручка нетто (EUR)", "Количество"],
    })
    assert resp.status_code == 200
    assert resp.json()["total_rows"] == 4  # Германия×2, Франция×1, Польша×1


def test_sum_aggregation_correct(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["Выручка нетто (EUR)"],
        "filters": {"Страна": {"type": "eq", "value": "Германия"}},
    })
    rows = resp.json()["rows"]
    assert len(rows) == 1
    # 49000 + 51000 + 60000 = 160000
    assert rows[0]["Выручка нетто (EUR)"] == pytest.approx(160000, rel=0.01)


def test_avg_aggregation_for_percentage(client, ds_id):
    """Маржа должна агрегироваться через AVG, а не SUM."""
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["Маржа валовой прибыли (%)"],
        "filters": {"Страна": {"type": "eq", "value": "Германия"}},
    })
    rows = resp.json()["rows"]
    # AVG(0.32, 0.30, 0.35) ≈ 0.3233
    assert rows[0]["Маржа валовой прибыли (%)"] == pytest.approx(0.3233, rel=0.01)


def test_in_filter(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["Количество"],
        "filters": {"Страна": {"type": "in", "values": ["Германия", "Франция"]}},
    })
    rows = resp.json()["rows"]
    countries = {r["Страна"] for r in rows}
    assert countries == {"Германия", "Франция"}
    assert "Польша" not in countries


def test_range_filter(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Год"],
        "metrics": ["Количество"],
        "filters": {"Год": {"type": "range", "min": 2015, "max": 2015}},
    })
    rows = resp.json()["rows"]
    assert all(r["Год"] == 2015 for r in rows)


def test_order_by_desc(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["Выручка нетто (EUR)"],
        "order_by": "Выручка нетто (EUR)",
        "order_desc": True,
    })
    values = [r["Выручка нетто (EUR)"] for r in resp.json()["rows"]]
    assert values == sorted(values, reverse=True)


def test_limit_respected(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["Количество"],
        "limit": 2,
    })
    assert resp.json()["total_rows"] == 2


def test_response_contains_sql_and_timing(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["Количество"],
    })
    body = resp.json()
    assert "sql" in body
    assert "execution_ms" in body
    assert body["execution_ms"] >= 0


def test_unknown_metric_returns_422(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["Страна"],
        "metrics": ["НесуществующаяМетрика"],
    })
    assert resp.status_code == 422


def test_unknown_dimension_returns_422(client, ds_id):
    resp = client.post(f"/api/query/{ds_id}", json={
        "dimensions": ["НесуществующееИзмерение"],
        "metrics": ["Количество"],
    })
    assert resp.status_code == 422


# ── GET /api/query/{dataset_id}/kpi ──────────────────────────────────────────

def test_kpi_totals(client, ds_id):
    resp = client.get(
        f"/api/query/{ds_id}/kpi",
        params={"metrics": ["Выручка нетто (EUR)", "Количество"]},
    )
    assert resp.status_code == 200
    kpis = resp.json()
    assert len(kpis) == 2
    выручка = next(k for k in kpis if k["metric"] == "Выручка нетто (EUR)")
    # 49000+51000+60000+31000+33000+22000 = 246000
    assert выручка["value"] == pytest.approx(246000, rel=0.01)
    assert выручка["aggregation"] == "sum"
    assert "€" in выручка["display_format"]


def test_kpi_unknown_metric_returns_422(client, ds_id):
    resp = client.get(f"/api/query/{ds_id}/kpi", params={"metrics": ["НетТакой"]})
    assert resp.status_code == 422


# ── GET /api/query/{dataset_id}/distinct/{column} ────────────────────────────

def test_distinct_values_for_dimension(client, ds_id):
    resp = client.get(f"/api/query/{ds_id}/distinct/Страна")
    assert resp.status_code == 200
    values = resp.json()
    assert set(values) == {"Германия", "Франция", "Польша"}


def test_distinct_values_sorted(client, ds_id):
    resp = client.get(f"/api/query/{ds_id}/distinct/Страна")
    values = resp.json()
    assert values == sorted(values)


def test_distinct_values_unknown_column_422(client, ds_id):
    resp = client.get(f"/api/query/{ds_id}/distinct/НесуществующаяКолонка")
    assert resp.status_code == 422


# ── distinct values с фильтрами (Этап 8 фикс: каскадная фильтрация) ─────────

def test_distinct_without_filters_returns_all(client, ds_id):
    """Без фильтра — все уникальные значения Страна."""
    r = client.get(f"/api/query/{ds_id}/distinct/Страна")
    assert r.status_code == 200
    assert set(r.json()) == {"Германия", "Польша", "Франция"}


def test_distinct_with_eq_filter_narrows_values(client, ds_id):
    """Фильтр по Год=2026 → Страна показывает только страны с данными в 2026."""
    import json as _json
    filters = _json.dumps({"Год": {"type": "eq", "value": 2026}})
    r = client.get(f"/api/query/{ds_id}/distinct/Страна", params={"filters": filters})
    assert r.status_code == 200
    countries = set(r.json())
    # В тестовых данных 2026 есть только Германия
    assert countries == {"Германия"}
    assert "Польша" not in countries
    assert "Франция" not in countries


def test_distinct_with_filter_cascades_month_by_country(client, ds_id):
    """Фильтр по Страна=Польша → Год показывает только годы где есть Польша."""
    import json as _json
    filters = _json.dumps({"Страна": {"type": "eq", "value": "Польша"}})
    r = client.get(f"/api/query/{ds_id}/distinct/Год", params={"filters": filters})
    assert r.status_code == 200
    # В тестовых данных Польша есть только в 2015
    assert set(r.json()) == {2015}


def test_distinct_invalid_filters_returns_422(client, ds_id):
    """Невалидный JSON → 422."""
    r = client.get(f"/api/query/{ds_id}/distinct/Страна",
                   params={"filters": "{не валидный json"})
    assert r.status_code == 422


def test_distinct_empty_filters_equals_no_filter(client, ds_id):
    """Пустая строка filters эквивалентна отсутствию параметра."""
    r1 = client.get(f"/api/query/{ds_id}/distinct/Страна")
    r2 = client.get(f"/api/query/{ds_id}/distinct/Страна", params={"filters": ""})
    assert r1.json() == r2.json()
