# VERSION: 1.0.0
# Path: backend/tests/test_config.py
# CHANGES v1.0.0:
#   - Этап 1: тесты Settings — database_url(_sync), создание директорий
"""Тесты app.core.config.Settings."""
from app.core.config import get_settings


def test_settings_loads_with_defaults():
    settings = get_settings()
    assert settings.app_name == "Sales BI Platform"
    assert settings.postgres_port == 5432


def test_database_url_format():
    settings = get_settings()
    url = settings.database_url
    assert url.startswith("postgresql+asyncpg://")
    assert settings.postgres_db in url

    sync_url = settings.database_url_sync
    assert sync_url.startswith("postgresql+psycopg2://")


def test_duckdb_file_creates_parent_directory():
    settings = get_settings()
    duckdb_file = settings.duckdb_file
    assert duckdb_file.parent.exists()


def test_upload_path_creates_directory():
    settings = get_settings()
    upload_path = settings.upload_path
    assert upload_path.exists()
    assert upload_path.is_dir()


def test_get_settings_is_cached_singleton():
    assert get_settings() is get_settings()
