# VERSION: 1.0.0
# Path: backend/tests/test_platform_api.py
# CHANGES v1.0.0:
#   - Этап 16: тесты Platform Registry (/api/platform/info и /modules).
"""Tests for Platform Registry API."""
import pytest
from httpx import AsyncClient


class TestPlatformInfo:
    """GET /api/platform/info"""

    async def test_info_returns_200(self, client: AsyncClient):
        resp = await client.get("/api/platform/info")
        assert resp.status_code == 200

    async def test_info_schema(self, client: AsyncClient):
        data = (await client.get("/api/platform/info")).json()
        assert "platform_name"    in data
        assert "platform_version" in data
        assert "api_version"      in data
        assert "started_at"       in data
        assert "enabled_modules"  in data
        assert "standalone_mode"  in data

    async def test_info_platform_name(self, client: AsyncClient):
        data = (await client.get("/api/platform/info")).json()
        assert data["platform_name"] == "Sales BI Platform"

    async def test_info_modules_list(self, client: AsyncClient):
        data = (await client.get("/api/platform/info")).json()
        mods = data["enabled_modules"]
        assert isinstance(mods, list)
        assert len(mods) > 0
        ids = {m["id"] for m in mods}
        assert "dashboards" in ids

    async def test_info_module_schema(self, client: AsyncClient):
        data = (await client.get("/api/platform/info")).json()
        for m in data["enabled_modules"]:
            assert "id"      in m
            assert "name"    in m
            assert "version" in m
            assert "tier"    in m
            assert "enabled" in m
            assert "routes"  in m

    async def test_info_started_at_iso(self, client: AsyncClient):
        from datetime import datetime
        data = (await client.get("/api/platform/info")).json()
        # started_at должно парситься как ISO datetime
        dt = datetime.fromisoformat(data["started_at"].replace("Z", "+00:00"))
        assert dt is not None


class TestPlatformModules:
    """GET /api/platform/modules"""

    async def test_modules_returns_200(self, client: AsyncClient):
        resp = await client.get("/api/platform/modules")
        assert resp.status_code == 200

    async def test_modules_is_list(self, client: AsyncClient):
        data = (await client.get("/api/platform/modules")).json()
        assert isinstance(data, list)

    async def test_modules_has_dashboards(self, client: AsyncClient):
        data = (await client.get("/api/platform/modules")).json()
        ids = {m["id"] for m in data}
        assert "dashboards" in ids

    async def test_modules_tier_values(self, client: AsyncClient):
        data = (await client.get("/api/platform/modules")).json()
        valid_tiers = {"free", "pro", "enterprise"}
        for m in data:
            assert m["tier"] in valid_tiers

    async def test_modules_routes_is_list(self, client: AsyncClient):
        data = (await client.get("/api/platform/modules")).json()
        for m in data:
            assert isinstance(m["routes"], list)

    async def test_all_modules_enabled_without_env(self, client: AsyncClient, monkeypatch):
        """Без ENABLED_MODULES все модули должны быть enabled=True."""
        import os
        monkeypatch.delenv("ENABLED_MODULES", raising=False)
        data = (await client.get("/api/platform/modules")).json()
        for m in data:
            assert m["enabled"] is True

    async def test_filter_by_env(self, client: AsyncClient, monkeypatch):
        """ENABLED_MODULES=dashboards → только dashboards enabled."""
        import os
        monkeypatch.setenv("ENABLED_MODULES", "dashboards")
        from app.modules.platform_registry import router as reg_router
        import importlib
        importlib.reload(reg_router)
        data = (await client.get("/api/platform/modules")).json()
        for m in data:
            if m["id"] == "dashboards":
                assert m["enabled"] is True
            else:
                assert m["enabled"] is False
