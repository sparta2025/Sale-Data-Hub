# VERSION: 1.1.0
# Path: backend/tests/conftest.py
# CHANGES v1.0.0:
#   - Этап 1: изоляция тестов — временные DUCKDB_PATH/UPLOAD_DIR до импорта app.*
# CHANGES v1.1.0:
#   - Этап 2: добавлена изолированная тестовая БД PostgreSQL (bi_metadata_test) —
#     создаётся автоматически, схема накатывается через Base.metadata.create_all(),
#     таблица datasets очищается перед каждым тестом
"""
Общая подготовка тестового окружения.

КРИТИЧНО: переменные окружения для DUCKDB_PATH/UPLOAD_DIR/POSTGRES_DB
устанавливаются на уровне МОДУЛЯ (а не внутри фикстуры), потому что
app.db.duckdb_conn и app.db.postgres читают settings = get_settings() при
импорте модуля — то есть ещё до того, как успела бы выполниться обычная
pytest-фикстура. conftest.py импортируется pytest раньше тестовых файлов,
поэтому это надёжно работает.

Это гарантирует, что тесты:
  - не используют реальный data/duckdb/analytics.duckdb проекта;
  - не используют рабочую БД bi_metadata — у тестов своя bi_metadata_test;
  - не оставляют мусор после себя (временная директория уровня сессии,
    очистка таблицы datasets перед каждым тестом);
  - могут запускаться параллельно с реальным запуском приложения.

Креды для создания тестовой БД (bi_user/bi_password) совпадают с дефолтами
.env.example — это локальная sandbox-настройка для разработки; в CI/прод
тестовая БД должна быть создана заранее тем же способом, что и рабочая
(см. scripts/setup_postgres.sh — он создаёт обе: bi_metadata и bi_metadata_test).
"""
import os
import shutil
import tempfile

import psycopg2
import pytest
from sqlalchemy import create_engine, text

_TEST_DATA_DIR = tempfile.mkdtemp(prefix="bi_backend_tests_")
os.environ["DUCKDB_PATH"] = os.path.join(_TEST_DATA_DIR, "test_analytics.duckdb")
os.environ["UPLOAD_DIR"] = os.path.join(_TEST_DATA_DIR, "uploads")
os.environ["POSTGRES_DB"] = "bi_metadata_test"

_PG_USER = os.environ.get("POSTGRES_USER", "bi_user")
_PG_PASSWORD = os.environ.get("POSTGRES_PASSWORD", "bi_password")
_PG_HOST = os.environ.get("POSTGRES_HOST", "localhost")
_PG_PORT = os.environ.get("POSTGRES_PORT", "5432")
_TEST_DB_NAME = "bi_metadata_test"


def _ensure_test_database_exists() -> None:
    conn = psycopg2.connect(dbname="postgres", user=_PG_USER, password=_PG_PASSWORD, host=_PG_HOST, port=_PG_PORT)
    conn.autocommit = True
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (_TEST_DB_NAME,))
            if cur.fetchone() is None:
                cur.execute(f'CREATE DATABASE "{_TEST_DB_NAME}" OWNER {_PG_USER}')
    finally:
        conn.close()


_ensure_test_database_exists()

# Импортируем ПОСЛЕ установки POSTGRES_DB, чтобы get_settings() подхватил
# тестовую БД, и ПОСЛЕ создания БД, чтобы к ней было что подключать.
from app.core.config import get_settings  # noqa: E402
from app.db.postgres import Base  # noqa: E402
import app.models  # noqa: E402,F401 — регистрирует Dataset на Base.metadata

_sync_engine = create_engine(get_settings().database_url_sync)
Base.metadata.create_all(_sync_engine)


@pytest.fixture(scope="session", autouse=True)
def _cleanup_test_data_dir():
    yield
    shutil.rmtree(_TEST_DATA_DIR, ignore_errors=True)
    _sync_engine.dispose()


@pytest.fixture(autouse=True)
def _clean_datasets_table():
    """Перед каждым тестом таблица datasets пуста — тесты не зависят друг от друга.
    CASCADE удаляет также связанные dimensions и metrics (FK с ondelete=CASCADE)."""
    with _sync_engine.connect() as conn:
        conn.execute(text("TRUNCATE TABLE datasets CASCADE"))
        conn.commit()
    yield


# Session-scope TestClient — один на все тест-модули.
# Устраняет "RuntimeError: Task attached to a different event loop",
# которая возникает при последовательном создании нескольких module-scope
# клиентов (каждый создаёт новый event loop, а asyncpg держит ссылки на предыдущий).
# Тест-модули, которым нужен клиент, могут использовать эту фикстуру
# или объявить свою локальную module-scope с той же реализацией
# (pytest подхватит session-scope как более широкий).
from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c
