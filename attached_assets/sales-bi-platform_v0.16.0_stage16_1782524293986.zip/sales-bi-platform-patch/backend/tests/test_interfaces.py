# VERSION: 1.0.0
# Path: backend/tests/test_interfaces.py
# CHANGES v1.0.0:
#   - Этап 1: тест, что все 5 интерфейсов — настоящие ABC (нельзя инстанцировать)
"""
Тесты контрактов расширяемости. Главное, что должно быть гарантировано на
этом этапе: все пять интерфейсов — настоящие ABC, их нельзя инстанцировать
без реализации абстрактных методов. Это защищает архитектуру от случайного
создания "пустой" реализации, которая тихо ничего не делает.
"""
import pytest

from app.interfaces import (
    IChartProvider,
    IDashboardProvider,
    IDataExporter,
    IDataProvider,
    IMetricProvider,
)

ALL_INTERFACES = [
    IDataProvider,
    IDashboardProvider,
    IChartProvider,
    IMetricProvider,
    IDataExporter,
]


@pytest.mark.parametrize("interface_cls", ALL_INTERFACES)
def test_interface_cannot_be_instantiated_directly(interface_cls):
    with pytest.raises(TypeError):
        interface_cls()


def test_concrete_implementation_must_implement_all_methods():
    """Частичная реализация контракта тоже должна оставаться абстрактной."""

    class PartialDataProvider(IDataProvider):
        async def import_data(self, source, dataset_name):  # noqa: D401
            return None

        # validate_structure и get_preview не реализованы — класс должен
        # оставаться абстрактным.

    with pytest.raises(TypeError):
        PartialDataProvider()
