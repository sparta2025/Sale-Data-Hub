# VERSION: 1.0.0
# Path: backend/tests/test_data_import_api.py
# CHANGES v1.0.0:
#   - Этап 2: интеграционные тесты /api/datasets — upload/list/preview/columns/delete
#     против реального PostgreSQL (bi_metadata_test) и DuckDB
"""
Интеграционные тесты модуля импорта данных.

Используют реальный PostgreSQL (bi_metadata_test, изолированная тестовая БД)
и реальный DuckDB (временный файл в tmpdir, см. conftest.py). Таблица datasets
очищается перед каждым тестом фикстурой _clean_datasets_table (см. conftest.py).

Для тестов используется синтетический CSV-файл из 3 строк — чтобы не зависеть
от пути к реальному загруженному xlsx и не тащить 1.5 МБ в тест-фикстуры.
"""
import io
import csv as csv_module

import pytest
from fastapi.testclient import TestClient

from app.main import app



def _make_csv(rows: list[dict]) -> bytes:
    """Создаёт минимальный CSV-файл в памяти."""
    buf = io.StringIO()
    writer = csv_module.DictWriter(buf, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
    return buf.getvalue().encode("utf-8")


_SAMPLE_ROWS = [
    {"Страна": "Германия", "Год": "2015", "Месяц": "1", "Выручка нетто (EUR)": "49013.9"},
    {"Страна": "Франция",  "Год": "2015", "Месяц": "2", "Выручка нетто (EUR)": "31200.5"},
    {"Страна": "Польша",   "Год": "2026", "Месяц": "1", "Выручка нетто (EUR)": "22100.0"},
]
_CSV_BYTES = _make_csv(_SAMPLE_ROWS)


def _upload(client, content: bytes = _CSV_BYTES, filename: str = "test_sales.csv") -> dict:
    resp = client.post(
        "/api/datasets/upload",
        files={"file": (filename, io.BytesIO(content), "text/csv")},
    )
    assert resp.status_code == 200, f"upload failed: {resp.text}"
    return resp.json()


# ── POST /api/datasets/upload ────────────────────────────────────────────────

def test_upload_returns_correct_shape(client):
    body = _upload(client)
    assert body["dataset"]["row_count"] == 3
    assert body["dataset"]["column_count"] == 4
    assert body["dataset"]["status"] == "ready"
    assert body["dataset"]["source_format"] == "csv"
    assert body["warnings"] == []


def test_upload_detects_column_roles(client):
    body = _upload(client)
    by_name = {c["name"]: c for c in body["columns"]}
    assert by_name["Страна"]["role"] == "dimension"
    assert by_name["Год"]["role"] == "dimension"
    assert by_name["Выручка нетто (EUR)"]["role"] == "metric"
    assert by_name["Выручка нетто (EUR)"]["data_type"] == "currency"


def test_upload_unsupported_extension_returns_400(client):
    resp = client.post(
        "/api/datasets/upload",
        files={"file": ("data.json", b'{"x":1}', "application/json")},
    )
    assert resp.status_code == 400
    assert ".json" in resp.json()["detail"] or "не поддерживается" in resp.json()["detail"]


def test_upload_empty_file_does_not_crash(client):
    """Пустой CSV — не должен роняться с 500, должен вернуть 4xx или пустой датасет."""
    empty = "Страна,Год\n".encode("utf-8")  # только заголовок, данных нет
    resp = client.post(
        "/api/datasets/upload",
        files={"file": ("empty.csv", io.BytesIO(empty), "text/csv")},
    )
    # Приемлемо и 200 с row_count=0, и 4xx с сообщением — главное не 500
    assert resp.status_code != 500


# ── GET /api/datasets ────────────────────────────────────────────────────────

def test_list_datasets_empty_initially(client):
    resp = client.get("/api/datasets")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_datasets_after_upload(client):
    _upload(client)
    resp = client.get("/api/datasets")
    assert resp.status_code == 200
    assert len(resp.json()) == 1


def test_list_datasets_returns_multiple(client):
    _upload(client, filename="a.csv")
    _upload(client, filename="b.csv")
    resp = client.get("/api/datasets")
    assert len(resp.json()) == 2


# ── GET /api/datasets/{id} ───────────────────────────────────────────────────

def test_get_dataset_by_id(client):
    ds_id = _upload(client)["dataset"]["id"]
    resp = client.get(f"/api/datasets/{ds_id}")
    assert resp.status_code == 200
    assert resp.json()["id"] == ds_id


def test_get_dataset_not_found(client):
    resp = client.get("/api/datasets/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404


# ── GET /api/datasets/{id}/columns ──────────────────────────────────────────

def test_get_columns_returns_all_columns(client):
    ds_id = _upload(client)["dataset"]["id"]
    resp = client.get(f"/api/datasets/{ds_id}/columns")
    assert resp.status_code == 200
    names = [c["name"] for c in resp.json()]
    assert "Страна" in names
    assert "Выручка нетто (EUR)" in names
    assert len(names) == 4


# ── GET /api/datasets/{id}/preview ──────────────────────────────────────────

def test_get_preview_default_limit(client):
    ds_id = _upload(client)["dataset"]["id"]
    resp = client.get(f"/api/datasets/{ds_id}/preview")
    assert resp.status_code == 200
    body = resp.json()
    assert body["total_rows"] == 3
    assert len(body["rows"]) == 3
    assert "Страна" in body["columns"]


def test_get_preview_custom_limit(client):
    ds_id = _upload(client)["dataset"]["id"]
    resp = client.get(f"/api/datasets/{ds_id}/preview?limit=2")
    assert len(resp.json()["rows"]) == 2


def test_get_preview_row_values_match_uploaded_data(client):
    ds_id = _upload(client)["dataset"]["id"]
    rows = client.get(f"/api/datasets/{ds_id}/preview").json()["rows"]
    countries = {r["Страна"] for r in rows}
    assert countries == {"Германия", "Франция", "Польша"}


# ── DELETE /api/datasets/{id} ────────────────────────────────────────────────

def test_delete_dataset_returns_204(client):
    ds_id = _upload(client)["dataset"]["id"]
    resp = client.delete(f"/api/datasets/{ds_id}")
    assert resp.status_code == 204


def test_delete_removes_from_list(client):
    ds_id = _upload(client)["dataset"]["id"]
    client.delete(f"/api/datasets/{ds_id}")
    remaining = client.get("/api/datasets").json()
    ids = [d["id"] for d in remaining]
    assert ds_id not in ids


def test_delete_makes_dataset_not_found(client):
    ds_id = _upload(client)["dataset"]["id"]
    client.delete(f"/api/datasets/{ds_id}")
    resp = client.get(f"/api/datasets/{ds_id}")
    assert resp.status_code == 404


def test_delete_nonexistent_returns_404(client):
    resp = client.delete("/api/datasets/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404
