# VERSION: 1.0.0
# Path: backend/tests/test_chart_formatters.py
# CHANGES v1.0.0:
#   - Этап 5: тесты chart_formatters (timeseries/category/pie/treemap/table)
"""Тесты app.modules.dashboard_engine.chart_formatters."""
from app.modules.dashboard_engine.chart_formatters import (
    format_category, format_pie, format_table, format_timeseries, format_treemap,
)

_ROWS = [
    {"Страна": "Германия", "Год": 2015, "Месяц": 1, "Выручка нетто (EUR)": 49000.0},
    {"Страна": "Германия", "Год": 2015, "Месяц": 2, "Выручка нетто (EUR)": 51000.0},
    {"Страна": "Франция",  "Год": 2015, "Месяц": 1, "Выручка нетто (EUR)": 31000.0},
    {"Страна": "Польша",   "Год": 2015, "Месяц": 1, "Выручка нетто (EUR)": 22000.0},
]


# ── Timeseries ────────────────────────────────────────────────────────────────

def test_timeseries_period_from_year_month():
    data = format_timeseries("c1", "Тест", _ROWS, ["Год", "Месяц"], ["Выручка нетто (EUR)"], None, 1.0)
    periods = [p.period for p in data.points]
    assert "2015-1" in periods


def test_timeseries_with_group_by():
    data = format_timeseries("c1", "Тест", _ROWS, ["Год"], ["Выручка нетто (EUR)"], "Страна", 1.0)
    series = {p.series for p in data.points}
    assert "Германия" in series
    assert "Франция" in series


def test_timeseries_series_names_without_group():
    data = format_timeseries("c1", "", _ROWS, ["Год"], ["Выручка нетто (EUR)"], None, 1.0)
    assert "Выручка нетто (EUR)" in data.series_names


# ── Category ─────────────────────────────────────────────────────────────────

def test_category_correct_categories():
    rows = [
        {"Страна": "Германия", "Выручка нетто (EUR)": 160000.0},
        {"Страна": "Франция",  "Выручка нетто (EUR)": 31000.0},
    ]
    data = format_category("c1", "Тест", rows, "Страна", ["Выручка нетто (EUR)"], 1.0)
    assert data.categories == ["Германия", "Франция"]
    assert data.points[0].values["Выручка нетто (EUR)"] == 160000.0


def test_category_multiple_metrics():
    rows = [{"Страна": "Германия", "Выручка нетто (EUR)": 100.0, "Количество": 10}]
    data = format_category("c1", "", rows, "Страна", ["Выручка нетто (EUR)", "Количество"], 1.0)
    assert "Количество" in data.points[0].values


# ── Pie ───────────────────────────────────────────────────────────────────────

def test_pie_total_is_sum():
    rows = [
        {"Страна": "Германия", "Выручка нетто (EUR)": 100.0},
        {"Страна": "Франция",  "Выручка нетто (EUR)": 50.0},
    ]
    data = format_pie("c1", "", rows, "Страна", "Выручка нетто (EUR)", 1.0)
    assert data.total == 150.0


def test_pie_percentages_sum_to_100():
    rows = [
        {"Страна": "Германия", "Выручка нетто (EUR)": 75.0},
        {"Страна": "Франция",  "Выручка нетто (EUR)": 25.0},
    ]
    data = format_pie("c1", "", rows, "Страна", "Выручка нетто (EUR)", 1.0)
    total_pct = sum(s.percentage or 0 for s in data.slices)
    assert abs(total_pct - 100.0) < 0.1


def test_pie_sorted_descending():
    rows = [
        {"Страна": "Маленькая", "Выручка нетто (EUR)": 10.0},
        {"Страна": "Большая",   "Выручка нетто (EUR)": 90.0},
    ]
    data = format_pie("c1", "", rows, "Страна", "Выручка нетто (EUR)", 1.0)
    assert data.slices[0].name == "Большая"


# ── Treemap ───────────────────────────────────────────────────────────────────

def test_treemap_flat_one_dimension():
    rows = [
        {"Страна": "Германия", "Выручка нетто (EUR)": 160000.0},
        {"Страна": "Франция",  "Выручка нетто (EUR)": 31000.0},
    ]
    data = format_treemap("c1", "", rows, ["Страна"], "Выручка нетто (EUR)", 1.0)
    assert data.root.name == "root"
    names = [c.name for c in data.root.children]
    assert "Германия" in names


def test_treemap_nested_two_dimensions():
    rows = [
        {"Товарная группа": "Группа А", "Товар": "Товар 1", "Выручка нетто (EUR)": 50.0},
        {"Товарная группа": "Группа А", "Товар": "Товар 2", "Выручка нетто (EUR)": 30.0},
        {"Товарная группа": "Группа Б", "Товар": "Товар 3", "Выручка нетто (EUR)": 20.0},
    ]
    data = format_treemap("c1", "", rows, ["Товарная группа", "Товар"], "Выручка нетто (EUR)", 1.0)
    assert len(data.root.children) == 2
    group_a = next(c for c in data.root.children if c.name == "Группа А")
    assert len(group_a.children) == 2


# ── Table ─────────────────────────────────────────────────────────────────────

def test_table_columns_and_rows():
    cols = ["Страна", "Выручка нетто (EUR)"]
    rows = [{"Страна": "Германия", "Выручка нетто (EUR)": 160000.0}]
    data = format_table("c1", "Тест", cols, rows, 1.0)
    assert data.columns == cols
    assert data.total_rows == 1
    assert data.rows[0]["Страна"] == "Германия"
