# VERSION: 1.0.0
# Path: backend/tests/test_metadata_detector.py
# CHANGES v1.0.0:
#   - Этап 3: тесты автоопределения иерархий (время/гео/товар) и агрегаций
"""Тесты app.modules.metadata.detector."""
from app.modules.metadata.detector import build_specs

# column_profile в том же формате, что и dataset.column_profile (JSON из БД)
_REAL_PROFILE = [
    {"name": "Страна",           "role": "dimension", "data_type": "text",       "nullable": False, "distinct_count": 3,   "sample_values": ["Германия", "Польша", "Франция"]},
    {"name": "Филиал",           "role": "dimension", "data_type": "text",       "nullable": False, "distinct_count": 9,   "sample_values": []},
    {"name": "Год",              "role": "dimension", "data_type": "year",       "nullable": False, "distinct_count": 2,   "sample_values": [2015, 2026]},
    {"name": "Месяц",            "role": "dimension", "data_type": "month",      "nullable": False, "distinct_count": 12,  "sample_values": []},
    {"name": "Товарная группа",  "role": "dimension", "data_type": "text",       "nullable": False, "distinct_count": 10,  "sample_values": []},
    {"name": "Товар",            "role": "dimension", "data_type": "text",       "nullable": False, "distinct_count": 100, "sample_values": []},
    {"name": "Количество",       "role": "metric",    "data_type": "integer",    "nullable": False, "distinct_count": 200, "sample_values": []},
    {"name": "Выручка нетто (EUR)", "role": "metric", "data_type": "currency",   "nullable": False, "distinct_count": 500, "sample_values": []},
    {"name": "Маржа валовой прибыли (%)", "role": "metric", "data_type": "percentage", "nullable": False, "distinct_count": 500, "sample_values": []},
    {"name": "Операц. маржа %",  "role": "metric",    "data_type": "percentage", "nullable": False, "distinct_count": 500, "sample_values": []},
]


def _dims(profile):
    dims, _ = build_specs(profile)
    return dims


def _mets(profile):
    _, mets = build_specs(profile)
    return mets


def _by_col(items, col_name):
    return next(x for x in items if x.column_name == col_name)


# ── Иерархии ────────────────────────────────────────────────────────────────

def test_temporal_hierarchy_detected():
    dims = _dims(_REAL_PROFILE)
    год = _by_col(dims, "Год")
    месяц = _by_col(dims, "Месяц")
    assert год.hierarchy_group == "time"
    assert год.hierarchy_level == 0
    assert месяц.hierarchy_group == "time"
    assert месяц.hierarchy_level == 1


def test_geographic_hierarchy_detected():
    dims = _dims(_REAL_PROFILE)
    страна = _by_col(dims, "Страна")
    филиал = _by_col(dims, "Филиал")
    assert страна.hierarchy_group == "geography"
    assert страна.hierarchy_level == 0
    assert филиал.hierarchy_group == "geography"
    assert филиал.hierarchy_level == 1


def test_product_hierarchy_detected():
    dims = _dims(_REAL_PROFILE)
    tg = _by_col(dims, "Товарная группа")
    t = _by_col(dims, "Товар")
    assert tg.hierarchy_group == "product"
    assert tg.hierarchy_level == 0
    assert t.hierarchy_group == "product"
    assert t.hierarchy_level == 1


def test_dimension_without_hierarchy_has_none_group():
    profile = [{"name": "Менеджер", "role": "dimension", "data_type": "text",
                "nullable": False, "distinct_count": 5, "sample_values": []}]
    dims = _dims(profile)
    assert dims[0].hierarchy_group is None
    assert dims[0].hierarchy_level == 0


# ── Агрегации ────────────────────────────────────────────────────────────────

def test_currency_metric_aggregation_is_sum():
    mets = _mets(_REAL_PROFILE)
    выручка = _by_col(mets, "Выручка нетто (EUR)")
    assert выручка.aggregation == "sum"


def test_percentage_metric_aggregation_is_avg():
    mets = _mets(_REAL_PROFILE)
    маржа = _by_col(mets, "Маржа валовой прибыли (%)")
    assert маржа.aggregation == "avg"
    операц = _by_col(mets, "Операц. маржа %")
    assert операц.aggregation == "avg"


def test_integer_metric_aggregation_is_sum():
    mets = _mets(_REAL_PROFILE)
    кол = _by_col(mets, "Количество")
    assert кол.aggregation == "sum"


# ── Форматы ──────────────────────────────────────────────────────────────────

def test_currency_format():
    mets = _mets(_REAL_PROFILE)
    assert "€" in _by_col(mets, "Выручка нетто (EUR)").display_format


def test_percentage_format():
    mets = _mets(_REAL_PROFILE)
    fmt = _by_col(mets, "Маржа валовой прибыли (%)").display_format
    assert "%" in fmt


def test_integer_format_has_no_decimals():
    mets = _mets(_REAL_PROFILE)
    fmt = _by_col(mets, "Количество").display_format
    assert ".0f" in fmt or ",.0f" in fmt


# ── Counts ───────────────────────────────────────────────────────────────────

def test_correct_number_of_dimensions_and_metrics():
    dims, mets = build_specs(_REAL_PROFILE)
    assert len(dims) == 6
    assert len(mets) == 4
