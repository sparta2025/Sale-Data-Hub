# VERSION: 1.0.0
# Path: backend/tests/test_export_api.py
# CHANGES v1.0.0:
#   - Этап 6: интеграционные тесты /api/export — table (csv/xlsx/pdf) + chart PNG
"""Интеграционные тесты Export Module."""
import io, csv as csv_module
import openpyxl
import pytest

_ROWS = [
    {"Страна": "Германия", "Год": "2015", "Выручка нетто (EUR)": "49000", "Количество": "10"},
    {"Страна": "Германия", "Год": "2026", "Выручка нетто (EUR)": "60000", "Количество": "15"},
    {"Страна": "Франция",  "Год": "2015", "Выручка нетто (EUR)": "31000", "Количество": "8"},
    {"Страна": "Польша",   "Год": "2015", "Выручка нетто (EUR)": "22000", "Количество": "5"},
]


def _csv():
    buf = io.StringIO()
    w = csv_module.DictWriter(buf, fieldnames=_ROWS[0].keys())
    w.writeheader(); w.writerows(_ROWS)
    return buf.getvalue().encode("utf-8")


@pytest.fixture()
def ds_id(client):
    r = client.post("/api/datasets/upload",
                    files={"file": ("export_test.csv", io.BytesIO(_csv()), "text/csv")})
    assert r.status_code == 200, r.text
    return r.json()["dataset"]["id"]


# ── POST /api/export/{dataset_id}/table — CSV ────────────────────────────────

def test_export_csv_returns_correct_content_type(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"], "format": "csv",
    })
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("text/csv")
    assert "attachment" in r.headers["content-disposition"]


def test_export_csv_content_has_data(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"], "format": "csv",
    })
    text = r.content.decode("utf-8-sig")
    assert "Германия" in text
    assert "ИТОГО" in text  # include_summary=True по умолчанию


def test_export_csv_without_summary(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"],
        "format": "csv", "include_summary": False,
    })
    text = r.content.decode("utf-8-sig")
    assert "ИТОГО" not in text


# ── POST /api/export/{dataset_id}/table — XLSX ───────────────────────────────

def test_export_xlsx_returns_correct_content_type(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"], "format": "xlsx",
    })
    assert r.status_code == 200
    assert "spreadsheetml" in r.headers["content-type"]


def test_export_xlsx_is_valid_workbook(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"],
        "format": "xlsx", "title": "Мой отчёт",
    })
    wb = openpyxl.load_workbook(io.BytesIO(r.content))
    ws = wb.active
    assert ws.cell(row=1, column=1).value == "Мой отчёт"


def test_export_xlsx_currency_formatted(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"], "format": "xlsx",
    })
    wb = openpyxl.load_workbook(io.BytesIO(r.content))
    ws = wb.active
    assert "€" in ws.cell(row=3, column=2).number_format


# ── POST /api/export/{dataset_id}/table — PDF ────────────────────────────────

def test_export_pdf_returns_correct_content_type(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"], "format": "pdf",
    })
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/pdf"
    assert r.content[:4] == b"%PDF"


def test_export_pdf_with_filters(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["Выручка нетто (EUR)"],
        "filters": {"Год": {"type": "eq", "value": 2015}},
        "format": "pdf", "title": "Отчёт за 2015",
    })
    assert r.status_code == 200
    assert r.content[:4] == b"%PDF"


# ── Ошибки ────────────────────────────────────────────────────────────────────

def test_export_unknown_metric_returns_422(client, ds_id):
    r = client.post(f"/api/export/{ds_id}/table", json={
        "dimensions": ["Страна"], "metrics": ["НеСуществует"], "format": "csv",
    })
    assert r.status_code == 422


def test_export_unknown_dataset_returns_error(client):
    r = client.post("/api/export/00000000-0000-0000-0000-000000000000/table", json={
        "dimensions": [], "metrics": [], "format": "csv",
    })
    assert r.status_code in (404, 422, 500)


# ── GET /api/export/{dataset_id}/chart/*.png ─────────────────────────────────

_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


def test_export_category_chart_png(client, ds_id):
    r = client.get(f"/api/export/{ds_id}/chart/category.png", params={
        "dimension": "Страна", "metric": "Выручка нетто (EUR)",
    })
    assert r.status_code == 200
    assert r.headers["content-type"] == "image/png"
    assert r.content[:8] == _PNG_MAGIC


def test_export_pie_chart_png(client, ds_id):
    r = client.get(f"/api/export/{ds_id}/chart/pie.png", params={
        "dimension": "Страна", "metric": "Выручка нетто (EUR)",
    })
    assert r.status_code == 200
    assert r.content[:8] == _PNG_MAGIC


def test_export_timeseries_chart_png(client, ds_id):
    r = client.get(f"/api/export/{ds_id}/chart/timeseries.png", params={
        "dimensions": ["Год"], "metrics": ["Выручка нетто (EUR)"],
    })
    assert r.status_code == 200
    assert r.content[:8] == _PNG_MAGIC


def test_export_timeseries_chart_png_with_group_by(client, ds_id):
    r = client.get(f"/api/export/{ds_id}/chart/timeseries.png", params={
        "dimensions": ["Год"], "metrics": ["Выручка нетто (EUR)"], "group_by": "Страна",
    })
    assert r.status_code == 200
    assert r.content[:8] == _PNG_MAGIC


def test_export_png_unknown_dimension_returns_422(client, ds_id):
    r = client.get(f"/api/export/{ds_id}/chart/category.png", params={
        "dimension": "НеСуществует", "metric": "Выручка нетто (EUR)",
    })
    assert r.status_code == 422
