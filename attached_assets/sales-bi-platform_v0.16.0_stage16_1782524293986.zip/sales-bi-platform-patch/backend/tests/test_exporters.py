# VERSION: 1.0.0
# Path: backend/tests/test_exporters.py
# CHANGES v1.0.0:
#   - Этап 6: unit-тесты csv/xlsx/pdf/png экспортёров (magic bytes, содержимое)
"""Тесты app.modules.export.* — экспортёры без HTTP-слоя."""
import io

import openpyxl
import pytest

from app.modules.export.csv_exporter import export_csv
from app.modules.export.pdf_exporter import export_pdf
from app.modules.export.png_exporter import export_category_png, export_pie_png, export_timeseries_png
from app.modules.export.xlsx_exporter import export_xlsx

_COLS = ["Страна", "Выручка нетто (EUR)"]
_ROWS = [
    {"Страна": "Германия", "Выручка нетто (EUR)": 160000.0},
    {"Страна": "Франция", "Выручка нетто (EUR)": 31000.0},
]
_SUMMARY = {"Выручка нетто (EUR)": 191000.0}


# ── CSV ───────────────────────────────────────────────────────────────────────

def test_csv_has_bom_for_excel_compat():
    content = export_csv(_COLS, _ROWS)
    assert content[:3] == b"\xef\xbb\xbf"


def test_csv_contains_header_and_data():
    content = export_csv(_COLS, _ROWS).decode("utf-8-sig")
    assert "Страна" in content
    assert "Германия" in content
    assert "Франция" in content


def test_csv_summary_row_present():
    content = export_csv(_COLS, _ROWS, _SUMMARY).decode("utf-8-sig")
    assert "ИТОГО" in content
    assert "191000" in content


def test_csv_without_summary_has_no_itogo():
    content = export_csv(_COLS, _ROWS, summary_row=None).decode("utf-8-sig")
    assert "ИТОГО" not in content


def test_csv_row_count_matches():
    content = export_csv(_COLS, _ROWS).decode("utf-8-sig")
    # +1 заголовок, без summary
    data_lines = [l for l in content.strip().split("\r\n") if l]
    assert len(data_lines) == len(_ROWS) + 1


# ── XLSX ──────────────────────────────────────────────────────────────────────

def test_xlsx_is_valid_openpyxl_file():
    content = export_xlsx(_COLS, _ROWS, title="Тест")
    wb = openpyxl.load_workbook(io.BytesIO(content))
    assert wb.active is not None


def test_xlsx_title_in_first_row():
    content = export_xlsx(_COLS, _ROWS, title="Мой отчёт")
    wb = openpyxl.load_workbook(io.BytesIO(content))
    ws = wb.active
    assert ws.cell(row=1, column=1).value == "Мой отчёт"


def test_xlsx_header_in_second_row():
    content = export_xlsx(_COLS, _ROWS, title="Тест")
    wb = openpyxl.load_workbook(io.BytesIO(content))
    ws = wb.active
    assert ws.cell(row=2, column=1).value == "Страна"
    assert ws.cell(row=2, column=2).value == "Выручка нетто (EUR)"


def test_xlsx_data_rows():
    content = export_xlsx(_COLS, _ROWS, title="Тест")
    wb = openpyxl.load_workbook(io.BytesIO(content))
    ws = wb.active
    assert ws.cell(row=3, column=1).value == "Германия"
    assert ws.cell(row=3, column=2).value == 160000.0


def test_xlsx_summary_row():
    content = export_xlsx(_COLS, _ROWS, title="Тест", summary_row=_SUMMARY)
    wb = openpyxl.load_workbook(io.BytesIO(content))
    ws = wb.active
    summary_row_idx = len(_ROWS) + 3
    assert ws.cell(row=summary_row_idx, column=1).value == "ИТОГО"
    assert ws.cell(row=summary_row_idx, column=2).value == 191000.0


def test_xlsx_currency_format_applied():
    content = export_xlsx(
        _COLS, _ROWS, title="Тест",
        column_types={"Выручка нетто (EUR)": "currency"},
    )
    wb = openpyxl.load_workbook(io.BytesIO(content))
    ws = wb.active
    cell = ws.cell(row=3, column=2)
    assert "€" in cell.number_format


# ── PDF ───────────────────────────────────────────────────────────────────────

def test_pdf_has_magic_bytes():
    content = export_pdf(_COLS, _ROWS, title="Тест")
    assert content[:4] == b"%PDF"


def test_pdf_with_cyrillic_does_not_crash():
    content = export_pdf(
        _COLS, _ROWS, title="Отчёт о продажах",
        generated_at="2026-06-19 12:00 UTC", summary_row=_SUMMARY,
    )
    assert len(content) > 1000


def test_pdf_truncates_large_dataset():
    big_rows = [{"Страна": f"С{i}", "Выручка нетто (EUR)": float(i)} for i in range(50)]
    content = export_pdf(_COLS, big_rows, title="Тест", max_rows=10)
    assert len(content) > 0  # не падает, просто усекает


def test_pdf_empty_rows_does_not_crash():
    content = export_pdf(_COLS, [], title="Пустой отчёт")
    assert content[:4] == b"%PDF"


# ── PNG ───────────────────────────────────────────────────────────────────────

_PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


def test_png_category_has_magic_bytes():
    content = export_category_png("Тест", ["Германия", "Франция"], "Выручка", [160000, 31000])
    assert content[:8] == _PNG_MAGIC


def test_png_pie_has_magic_bytes():
    content = export_pie_png("Тест", ["Германия", "Франция"], [160000, 31000])
    assert content[:8] == _PNG_MAGIC


def test_png_timeseries_has_magic_bytes():
    content = export_timeseries_png("Тест", ["2015", "2026"], {"Выручка": [160000, 31000]})
    assert content[:8] == _PNG_MAGIC


def test_png_timeseries_multiple_series():
    content = export_timeseries_png(
        "Тест", ["2015", "2026"],
        {"Германия": [49000, 60000], "Франция": [31000, 33000]},
    )
    assert content[:8] == _PNG_MAGIC


def test_png_pie_with_none_values_does_not_crash():
    content = export_pie_png("Тест", ["А", "Б"], [100.0, None])
    assert content[:8] == _PNG_MAGIC


def test_png_category_empty_does_not_crash():
    content = export_category_png("Пусто", [], "Метрика", [])
    assert content[:8] == _PNG_MAGIC
