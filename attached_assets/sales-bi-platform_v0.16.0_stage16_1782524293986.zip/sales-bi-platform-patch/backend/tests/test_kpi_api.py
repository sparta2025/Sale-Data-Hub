# VERSION: 1.0.0
# Path: backend/tests/test_kpi_api.py
# CHANGES v1.0.0:
#   - Этап 16: тесты для KPI Analysis модуля
#     /api/kpi/{id}/scorecard и /api/kpi/{id}/compare.
"""Tests for KPI Analysis API endpoints."""
import pytest
from httpx import AsyncClient


class TestKpiScorecard:
    """GET /api/kpi/{dataset_id}/scorecard"""

    async def test_scorecard_requires_params(self, client: AsyncClient, uploaded_dataset_id: str):
        resp = await client.get(f"/api/kpi/{uploaded_dataset_id}/scorecard")
        assert resp.status_code == 422  # period_col, period_a, period_b обязательны

    async def test_scorecard_unknown_dataset(self, client: AsyncClient):
        resp = await client.get(
            "/api/kpi/00000000-0000-0000-0000-000000000000/scorecard",
            params={"period_col": "Год", "period_a": "2025", "period_b": "2024"},
        )
        assert resp.status_code in (404, 500)

    async def test_scorecard_valid(self, client: AsyncClient, uploaded_dataset_id: str):
        resp = await client.get(
            f"/api/kpi/{uploaded_dataset_id}/scorecard",
            params={"period_col": "Год", "period_a": "2025", "period_b": "2024"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["dataset_id"] == uploaded_dataset_id
        assert data["period_a"] == "2025"
        assert data["period_b"] == "2024"
        assert isinstance(data["metrics"], list)

    async def test_scorecard_metric_fields(self, client: AsyncClient, uploaded_dataset_id: str):
        resp = await client.get(
            f"/api/kpi/{uploaded_dataset_id}/scorecard",
            params={"period_col": "Год", "period_a": "2025", "period_b": "2024"},
        )
        assert resp.status_code == 200
        data = resp.json()
        if data["metrics"]:
            m = data["metrics"][0]
            assert "column_name"    in m
            assert "display_name"   in m
            assert "display_format" in m
            assert "value_a"        in m
            assert "value_b"        in m
            assert "delta_abs"      in m
            assert "delta_pct"      in m

    async def test_scorecard_delta_calculation(self, client: AsyncClient, uploaded_dataset_id: str):
        resp = await client.get(
            f"/api/kpi/{uploaded_dataset_id}/scorecard",
            params={"period_col": "Год", "period_a": "2025", "period_b": "2024"},
        )
        assert resp.status_code == 200
        for m in resp.json()["metrics"]:
            expected_abs = round(m["value_a"] - m["value_b"], 2)
            assert abs(m["delta_abs"] - expected_abs) < 0.1

    async def test_scorecard_nonexistent_period(self, client: AsyncClient, uploaded_dataset_id: str):
        resp = await client.get(
            f"/api/kpi/{uploaded_dataset_id}/scorecard",
            params={"period_col": "Год", "period_a": "9999", "period_b": "9998"},
        )
        assert resp.status_code == 200
        data = resp.json()
        for m in data["metrics"]:
            assert m["value_a"] == 0.0
            assert m["value_b"] == 0.0


class TestKpiCompare:
    """GET /api/kpi/{dataset_id}/compare"""

    async def test_compare_requires_params(self, client: AsyncClient, uploaded_dataset_id: str):
        resp = await client.get(f"/api/kpi/{uploaded_dataset_id}/compare")
        assert resp.status_code == 422

    async def test_compare_valid(
        self, client: AsyncClient, uploaded_dataset_id: str,
        dataset_dimensions: list, dataset_metrics: list,
    ):
        cat_dims = [d for d in dataset_dimensions if d.get("hierarchy_group") != "time"]
        if not cat_dims or not dataset_metrics:
            pytest.skip("No category dimensions or metrics")

        resp = await client.get(
            f"/api/kpi/{uploaded_dataset_id}/compare",
            params={
                "dimension":  cat_dims[0]["column_name"],
                "metric":     dataset_metrics[0]["column_name"],
                "period_col": "Год",
                "period_a":   "2025",
                "period_b":   "2024",
                "limit":      10,
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["dataset_id"]  == uploaded_dataset_id
        assert data["period_a"]    == "2025"
        assert isinstance(data["items"], list)
        assert len(data["items"])  <= 10

    async def test_compare_item_fields(
        self, client: AsyncClient, uploaded_dataset_id: str,
        dataset_dimensions: list, dataset_metrics: list,
    ):
        cat_dims = [d for d in dataset_dimensions if d.get("hierarchy_group") != "time"]
        if not cat_dims or not dataset_metrics:
            pytest.skip("No category dimensions or metrics")

        resp = await client.get(
            f"/api/kpi/{uploaded_dataset_id}/compare",
            params={
                "dimension":  cat_dims[0]["column_name"],
                "metric":     dataset_metrics[0]["column_name"],
                "period_col": "Год",
                "period_a":   "2025",
                "period_b":   "2024",
            },
        )
        assert resp.status_code == 200
        for item in resp.json()["items"]:
            assert "label"     in item
            assert "value_a"   in item
            assert "value_b"   in item
            assert "delta_pct" in item

    async def test_compare_limit(
        self, client: AsyncClient, uploaded_dataset_id: str,
        dataset_dimensions: list, dataset_metrics: list,
    ):
        cat_dims = [d for d in dataset_dimensions if d.get("hierarchy_group") != "time"]
        if not cat_dims or not dataset_metrics:
            pytest.skip("No category dimensions or metrics")

        for limit in [5, 10, 20]:
            resp = await client.get(
                f"/api/kpi/{uploaded_dataset_id}/compare",
                params={
                    "dimension":  cat_dims[0]["column_name"],
                    "metric":     dataset_metrics[0]["column_name"],
                    "period_col": "Год",
                    "period_a": "2025", "period_b": "2024",
                    "limit":   limit,
                },
            )
            assert resp.status_code == 200
            assert len(resp.json()["items"]) <= limit
