# VERSION: 1.0.0
# Path: backend/tests/test_sql_builder.py
# CHANGES v1.0.0:
#   - Этап 4: тесты sql_builder — корректность SQL, параметры, фильтры, агрегации
"""Тесты app.modules.query_engine.sql_builder."""
import pytest

from app.modules.query_engine.sql_builder import (
    build_aggregation_query,
    build_distinct_values_query,
    build_kpi_query,
)
from app.schemas.query import EqFilter, InFilter, RangeFilter

TABLE = "dataset_abc123"


# ── SELECT ────────────────────────────────────────────────────────────────────

def test_basic_group_by_query():
    plan = build_aggregation_query(
        table_name=TABLE,
        dimensions=["Страна"],
        metrics=[("Выручка нетто (EUR)", "sum")],
        filters={},
    )
    assert '"Страна"' in plan.sql
    assert 'SUM("Выручка нетто (EUR)")' in plan.sql
    assert "GROUP BY" in plan.sql
    assert TABLE in plan.sql


def test_multiple_dimensions_and_metrics():
    plan = build_aggregation_query(
        table_name=TABLE,
        dimensions=["Страна", "Год"],
        metrics=[("Выручка нетто (EUR)", "sum"), ("Маржа валовой прибыли (%)", "avg")],
        filters={},
    )
    assert '"Страна"' in plan.sql
    assert '"Год"' in plan.sql
    assert 'SUM("Выручка нетто (EUR)")' in plan.sql
    assert 'AVG("Маржа валовой прибыли (%)")' in plan.sql


def test_metrics_only_no_group_by():
    """Запрос только метрик (для KPI) не должен содержать GROUP BY."""
    plan = build_aggregation_query(
        table_name=TABLE,
        dimensions=[],
        metrics=[("Количество", "sum")],
        filters={},
    )
    assert "GROUP BY" not in plan.sql


def test_dimensions_only_no_aggregation():
    """Запрос только измерений (просмотр данных) — нет агрегации, нет GROUP BY."""
    plan = build_aggregation_query(
        table_name=TABLE,
        dimensions=["Страна"],
        metrics=[],
        filters={},
    )
    assert "GROUP BY" not in plan.sql
    assert "SUM" not in plan.sql


def test_empty_query_raises():
    with pytest.raises(ValueError, match="хотя бы одно"):
        build_aggregation_query(TABLE, [], [], {})


def test_invalid_aggregation_raises():
    with pytest.raises(ValueError, match="агрегация"):
        build_aggregation_query(TABLE, [], [("col", "INJECT DROP TABLE")], {})


# ── WHERE / filters ──────────────────────────────────────────────────────────

def test_eq_filter_generates_eq_clause():
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Страна"],
        metrics=[("Выручка нетто (EUR)", "sum")],
        filters={"Страна": EqFilter(value="Германия")},
    )
    assert "WHERE" in plan.sql
    assert '"Страна" = ?' in plan.sql
    assert "Германия" in plan.params


def test_in_filter_generates_in_clause():
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Страна"],
        metrics=[("Выручка нетто (EUR)", "sum")],
        filters={"Страна": InFilter(values=["Германия", "Франция"])},
    )
    assert "IN (?, ?)" in plan.sql
    assert plan.params == ["Германия", "Франция"]


def test_range_filter_both_bounds():
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Год"],
        metrics=[("Количество", "sum")],
        filters={"Год": RangeFilter(min=2015, max=2020)},
    )
    assert '"Год" BETWEEN ? AND ?' in plan.sql
    assert 2015 in plan.params
    assert 2020 in plan.params


def test_range_filter_only_min():
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Год"],
        metrics=[("Количество", "sum")],
        filters={"Год": RangeFilter(min=2018)},
    )
    assert '"Год" >= ?' in plan.sql
    assert 2018 in plan.params


def test_range_filter_only_max():
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Год"],
        metrics=[("Количество", "sum")],
        filters={"Год": RangeFilter(max=2020)},
    )
    assert '"Год" <= ?' in plan.sql


def test_empty_in_filter_is_skipped():
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Страна"],
        metrics=[("Выручка нетто (EUR)", "sum")],
        filters={"Страна": InFilter(values=[])},
    )
    assert "WHERE" not in plan.sql


def test_multiple_filters_combined():
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Страна", "Год"],
        metrics=[("Выручка нетто (EUR)", "sum")],
        filters={
            "Страна": InFilter(values=["Германия"]),
            "Год": RangeFilter(min=2015, max=2020),
        },
    )
    assert "WHERE" in plan.sql
    assert "AND" in plan.sql


# ── ORDER BY / LIMIT ─────────────────────────────────────────────────────────

def test_default_order_by_first_dimension():
    plan = build_aggregation_query(
        TABLE, ["Страна", "Год"], [("Выручка нетто (EUR)", "sum")], {}
    )
    assert '"Страна" ASC' in plan.sql


def test_custom_order_by_desc():
    plan = build_aggregation_query(
        TABLE, ["Страна"], [("Выручка нетто (EUR)", "sum")], {},
        order_by="Выручка нетто (EUR)", order_desc=True
    )
    assert '"Выручка нетто (EUR)" DESC' in plan.sql


def test_limit_in_sql():
    plan = build_aggregation_query(
        TABLE, ["Страна"], [("Выручка нетто (EUR)", "sum")], {}, limit=42
    )
    assert "LIMIT 42" in plan.sql


# ── Специальные запросы ──────────────────────────────────────────────────────

def test_kpi_query_has_no_group_by():
    plan = build_kpi_query(TABLE, [("Выручка нетто (EUR)", "sum")], {})
    assert "GROUP BY" not in plan.sql
    assert "LIMIT 1" in plan.sql


def test_distinct_values_query():
    plan = build_distinct_values_query(TABLE, "Страна")
    assert "DISTINCT" in plan.sql
    assert '"Страна"' in plan.sql
    assert plan.params == []


def test_column_names_are_quoted():
    """Проверяем, что двойные кавычки вокруг имён колонок есть — защита от SQL injection."""
    plan = build_aggregation_query(
        TABLE,
        dimensions=["Товарная группа"],  # имя с пробелом
        metrics=[("Выручка нетто (EUR)", "sum")],  # имя с круглыми скобками
        filters={},
    )
    assert '"Товарная группа"' in plan.sql
    assert '"Выручка нетто (EUR)"' in plan.sql
