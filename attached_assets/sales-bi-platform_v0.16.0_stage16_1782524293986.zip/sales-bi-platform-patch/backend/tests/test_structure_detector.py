# VERSION: 1.0.0
# Path: backend/tests/test_structure_detector.py
# CHANGES v1.0.0:
#   - Этап 2: тесты structure_detector (роль/тип колонок, «спасение» числовых)
"""Тесты app.modules.data_import.structure_detector."""
import pandas as pd

from app.modules.data_import.structure_detector import detect_column_profiles


def _profile_by_name(profiles, name):
    return next(p for p in profiles if p.name == name)


def test_text_column_detected_as_dimension():
    df = pd.DataFrame({"Страна": ["Германия", "Франция", "Польша"]})
    profile = detect_column_profiles(df)[0]
    assert profile.role == "dimension"
    assert profile.data_type == "text"
    assert profile.sample_values == ["Германия", "Польша", "Франция"]


def test_integer_column_detected_as_metric():
    df = pd.DataFrame({"Количество": [10, 20, 30]})
    profile = detect_column_profiles(df)[0]
    assert profile.role == "metric"
    assert profile.data_type == "integer"


def test_currency_column_detected_by_name_hint():
    df = pd.DataFrame({"Выручка нетто (EUR)": [100.5, 200.25, 300.0]})
    profile = detect_column_profiles(df)[0]
    assert profile.role == "metric"
    assert profile.data_type == "currency"


def test_percentage_column_detected_by_name_hint():
    df = pd.DataFrame({"Маржа валовой прибыли (%)": [0.1, 0.2, 0.3]})
    profile = detect_column_profiles(df)[0]
    assert profile.role == "metric"
    assert profile.data_type == "percentage"


def test_plain_float_without_hints_is_generic_metric():
    df = pd.DataFrame({"Какой-то коэффициент": [1.1, 2.2, 3.3]})
    profile = detect_column_profiles(df)[0]
    assert profile.role == "metric"
    assert profile.data_type == "float"


def test_year_and_month_columns_detected_as_time_dimensions():
    df = pd.DataFrame({"Год": [2015, 2016], "Месяц": [1, 12]})
    profiles = detect_column_profiles(df)
    assert _profile_by_name(profiles, "Год").data_type == "year"
    assert _profile_by_name(profiles, "Месяц").data_type == "month"
    assert _profile_by_name(profiles, "Год").role == "dimension"


def test_year_column_with_missing_values_still_detected_as_year():
    """Год с пропуском становится float64 в pandas — не должно ломать определение типа."""
    df = pd.DataFrame({"Год": [2015, None, 2026]})
    profile = detect_column_profiles(df)[0]
    assert profile.data_type == "year"
    assert profile.nullable is True


def test_numeric_column_with_one_typo_is_rescued_as_metric():
    """Реалистичный случай: 1 опечатка на 21 нормальное значение — не должна ломать тип колонки."""
    values = [1000.0 + i for i in range(20)] + ["н/д"]
    df = pd.DataFrame({"Выручка нетто (EUR)": values})
    profile = detect_column_profiles(df)[0]
    assert profile.role == "metric"
    assert profile.data_type in ("currency", "integer")


def test_numeric_column_with_too_many_typos_stays_text():
    """Если невалидных значений слишком много (выше порога) — это, скорее всего, не число."""
    df = pd.DataFrame({"Выручка нетто (EUR)": [100.0, "не число", "тоже не число"]})
    profile = detect_column_profiles(df)[0]
    assert profile.role == "dimension"
    assert profile.data_type == "text"


def test_sample_values_sorting_does_not_crash_on_mixed_types():
    """Регрессия: смешанные типы в одной колонке не должны ронять сортировку примеров."""
    df = pd.DataFrame({"Выручка нетто (EUR)": [100.0, "не число", "ещё не число"]})
    profile = detect_column_profiles(df)[0]
    assert isinstance(profile.sample_values, list)
