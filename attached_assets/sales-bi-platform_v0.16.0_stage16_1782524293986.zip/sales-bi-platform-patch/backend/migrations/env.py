# VERSION: 1.1.0
# Path: backend/migrations/env.py
# CHANGES v1.0.0:
#   - Этап 1: sqlalchemy.url берётся из app.core.config.Settings,
#     target_metadata = Base.metadata (таблицы появятся в Этапе 3)
# CHANGES v1.1.0:
#   - Этап 2: добавлен import app.models — Alembic теперь видит таблицу datasets
"""
Alembic env.py — URL подключения берём из app.core.config.Settings (через
переменные окружения / .env), а не из alembic.ini, чтобы не дублировать
конфигурацию. ORM-модели (app.db.postgres.Base.metadata) подключаются в
Этапе 3, когда появятся реальные таблицы метаданных.
"""
import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.config import get_settings  # noqa: E402
from app.db.postgres import Base  # noqa: E402
import app.models  # noqa: E402,F401  — регистрирует все ORM-модели на Base.metadata

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

settings = get_settings()
config.set_main_option("sqlalchemy.url", settings.database_url_sync)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(url=url, target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(config.get_section(config.config_ini_section, {}), prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
