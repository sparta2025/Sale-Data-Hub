<!--
VERSION: 1.0.0
Path: docs/PROGRESS.md
CHANGES v1.0.0:
  - Этап 1: журнал хода работ, профиль исходных данных, статусы этапов
-->
# PROGRESS.md — журнал хода работ по проекту "Sales BI Platform"

> Этот файл — единственный источник правды о состоянии проекта между сообщениями в чате.
> При возобновлении работы: сначала прочитать этот файл, потом продолжать с первого
> незакрытого пункта в разделе "Этапы".

## Профиль исходных данных (зафиксировано в Этапе 0)

Файл: `sales_report_2015_2026Q1.xlsx`, 3 листа:
- **"Данные продаж"** — основной лист с фактами, 5084 строк, 26 столбцов. Это единственный
  лист, который импортируется. Без пропусков.
- **"Сводка по стране-году"** — сводная таблица на формулах (COUNTIFS/SUMIFS), справочная,
  не импортируется.
- **"Справочник формул"** — текстовое описание формул, не импортируется.

Колонки листа "Данные продаж" и их роль (определены автоматически по эвристике, см. Этап 2):

| Колонка | Роль | Тип |
|---|---|---|
| Страна | измерение / география | текст (3 знач.: Германия, Франция, Польша) |
| Филиал | измерение / география | текст (9 знач., у каждой страны свой набор филиалов) |
| Год | измерение / время | целое (2015, 2026 — **не непрерывный ряд!** см. ниже) |
| Месяц | измерение / время | целое 1–12 |
| Товарная группа | измерение / категория | текст (10 групп) |
| Товар | измерение / категория | текст (100 товаров) |
| Количество | метрика | целое |
| Продажная цена (EUR) | метрика / деньги | float |
| Акциз (EUR), НДС (EUR) | метрика / деньги (за единицу) | float |
| Сумма с налогами (EUR) | метрика / деньги | float |
| Закупочная цена (EUR) | метрика / деньги | float |
| Накладные расходы / Логистические затраты / Таможенные платежи (EUR) | метрика / деньги | float |
| Выручка нетто (EUR) | метрика / деньги (ключевая) | float |
| Себестоимость продаж (EUR) | метрика / деньги | float |
| Валовая прибыль (EUR) | метрика / деньги (ключевая) | float |
| Маржа валовой прибыли (%) | метрика / процент | float 0..1 |
| Полные затраты (EUR) | метрика / деньги | float |
| Операционная прибыль (EUR) | метрика / деньги (ключевая) | float |
| Операц. маржа (%) | метрика / процент | float 0..1 |
| Акциз итого / НДС итого (EUR) | метрика / деньги | float |
| Наценка (%) | метрика / процент | float |
| Прибыль на единицу (EUR) | метрика / деньги | float |

Важные наблюдения:
- **Временной охват разрывный**: 2015 (полные 12 месяцев, ~4061 строк) и 2026 (только
  Q1, январь–март, ~1023 строки). Между ними данных нет. Линейные графики по времени должны
  это корректно показывать (разрыв на оси), а не интерполировать.
- 3 страны → 9 филиалов (Германия: Берлин/Мюнхен/Гамбург; Франция: Париж/Лион; Польша:
  Варшава/Краков/Гданьск/Познань) → 10 товарных групп → 100 товаров. Это и есть иерархия
  для Treemap и Drill-Down.
- В этом файле пропусков нет, но импортёр всё равно должен уметь обрабатывать пропуски
  (т.к. система должна работать с "аналогичными" отчётами).
- 5084 строк — для нагрузочного теста (500k записей) нужны будут синтетические данные
  (см. Этап 10).

## Архитектурные решения (Этап 1)

- Backend: Python 3.12, FastAPI, SQLAlchemy 2.0 (async, asyncpg) — метаданные в PostgreSQL,
  данные фактов — в DuckDB (файл на диске, путь из конфига).
- Хранилище загруженных исходных файлов — локальная ФС (`data/uploads`), путь настраивается.
- Интерфейсы расширяемости (`IDataProvider`, `IDashboardProvider`, `IChartProvider`,
  `IMetricProvider`, `IDataExporter`) заведены в `backend/app/interfaces/` как ABC уже на
  Этапе 1 — конкретные реализации добавляются в соответствующих этапах.
- Структура backend — модульная (`app/modules/<module>`), каждый модуль почти независим
  и появляется в своём этапе.
- Frontend: Vite + React + TypeScript + MUI, ECharts для графиков, Leaflet для карты.
- Docker Compose: сервисы `postgres`, `backend`, `frontend`. DuckDB-файл и загрузки — volume.

## Этапы (статус)

- [x] **Этап 0** — анализ ТЗ + анализ реального файла данных.
- [x] **Этап 1** — каркас проекта: структура репозитория, Docker Compose, базовые конфиги
      backend (FastAPI skeleton + health-check) и frontend (Vite/React/TS/MUI skeleton),
      интерфейсы расширяемости (заглушки).
- [ ] **Этап 2** — Data Import Module: загрузка CSV/XLSX, автоопределение структуры,
      очистка, обработка пропусков, сохранение в DuckDB + регистрация датасета в Postgres.
- [ ] **Этап 3** — Metadata Module: автоопределение измерений/метрик, схема метаданных в
      Postgres, API получения списка измерений/метрик/доступных фильтров.
- [ ] **Этап 4** — Query Engine: SQL-слой на DuckDB (агрегации, group by, фильтры,
      drill-down), кэширование результатов запросов.
- [ ] **Этап 5** — Dashboard Engine + backend API: JSON-конфигурации дашбордов, эндпоинты
      KPI/графиков (линии, столбцы, пироги, treemap, heatmap, waterfall), drill-down,
      глобальные фильтры, табличный эндпоинт (сортировка/фильтр/поиск/пагинация).
- [ ] **Этап 6** — Export Module: экспорт CSV/XLSX/PDF/PNG (backend).
- [ ] **Этап 7** — Frontend каркас: роутинг, layout, панель фильтров, API-клиент, состояние.
- [ ] **Этап 8** — Главная страница, KPI-карточки, графики ECharts.
- [ ] **Этап 9** — Карта филиалов (Leaflet+OSM+геокодирование), Drill-Down UI,
      интерактивная таблица.
- [ ] **Этап 10** — Производительность (тест на синтетике 5k/50k/500k), миграции,
      тестовые данные, финальная интеграция Docker Compose, документация по запуску.

## Как продолжить в новом сообщении

1. Прочитать этот файл.
2. Открыть следующий незакрытый пункт списка выше.
3. После выполнения — отметить чекбокс и дописать короткую сводку в раздел "Сводки по
   этапам" ниже.

## Конвенция версионирования файлов

Начиная с этого чекпойнта каждый файл с исходным кодом (`.py`, `.ts`, `.tsx`,
`Dockerfile`, `.yml`, `.ini`, `.gitignore`, `.txt`) содержит в начале заголовок:

```
# VERSION: <semver>
# Path: <путь от корня репозитория>
# CHANGES v<semver>:
#   - <что изменено>
```

(для `.ts`/`.tsx` — `//`, для `.md` — HTML-комментарий `<!-- -->` в самом верху).
При изменении файла версия в его заголовке увеличивается, и в `CHANGES`
добавляется новая запись (старые записи не удаляются — это история файла).
Исключения: `.json` (package.json, tsconfig.json) — формат не поддерживает
комментарии, версия файла не проставляется, изменения фиксируются здесь, в
PROGRESS.md.

## Среда разработки в песочнице (важно для возобновления в новом сообщении)

В контейнере установлен и запущен настоящий PostgreSQL 16 (не мок/SQLite):
- пользователь `bi_user` / пароль `bi_password` (SUPERUSER, только для разработки),
- БД `bi_metadata` (рабочая) и `bi_metadata_test` (создаётся тестами автоматически),
- слушает `localhost:5432` — совпадает с дефолтами `.env.example`.

Если в новом сообщении окажется, что сервис не запущен (`pg_isready` падает или
`/api/health` показывает `"postgres": "unavailable"` там, где ожидался "connected"),
поднять его командой:
```bash
service postgresql start
```
Роль/БД создавать повторно не нужно — данные кластера лежат на диске и переживают
перезапуск процесса (если не пересоздавался сам контейнер/песочница).

## Чекпойнт v1.0.0 (после Этапа 1) — упаковано для скачивания

Все файлы Этапа 1 имеют версию 1.0.0. Добавлены и прогнаны тесты backend
(17 тестов, см. `backend/tests/`): health-check, конфигурация, реальное
подключение к DuckDB (запись/чтение), проверка, что все 5 интерфейсов —
настоящие ABC. Frontend проверен `tsc -b` и полной `vite build` — собирается
без ошибок. Архив с этим состоянием — `sales-bi-platform_v1.0.0_stage1.zip`.

### Этап 2 (в работе) — промежуточная сводка по проверке

На момент этой сводки реализовано (но Этап 2 ещё не закрыт — впереди
DataImportService/IDataProvider, API-роутер /api/datasets, тесты на upload):

- `structure_detector.py` — автоопределение роли/типа колонки. Прогнан на
  реальном файле `sales_report_2015_2026Q1.xlsx`: все 26 колонок определены
  верно (6 измерений, 20 метрик) — совпадает с профилем из Этапа 0.
- При проверке на синтетических «грязных» данных найден и исправлен баг:
  числовая колонка с единичной нечисловой опечаткой получала dtype=object от
  pandas и ошибочно классифицировалась как текст, а сортировка примеров
  значений падала на смешанных типах. Добавлено «спасение» числовых колонок
  (порог 80% валидных значений) + защита сортировки `sample_values` (v1.1.0).
- `cleaner.py` — обработка пропусков проверена: текст -> плейсхолдер
  `(не указано)`, числа -> NULL (не 0), год/месяц без значения — отдельное
  предупреждение про drill-down.
- `duckdb_writer.py` — запись/чтение датасета в DuckDB проверена на реальных
  5084 строках (register + CREATE TABLE AS SELECT).
- Создана и применена к реальному PostgreSQL первая Alembic-миграция —
  таблица `datasets`.
- В песочнице развёрнут настоящий PostgreSQL 16 (не мок) — см. раздел выше.

### Скрипты создания БД (PostgreSQL и DuckDB)

Добавлены и проверены вживую (создание роли+БД с нуля, повторный идемпотентный
запуск, применение миграций, инициализация DuckDB):

- `scripts/setup_postgres.sh` — идемпотентно создаёт роль+БД PostgreSQL для
  локальной разработки (вне Docker Compose).
- `scripts/init_postgres.sql` — чистый SQL-эквивалент для ручного запуска
  на любом PostgreSQL-сервере (например, managed-сервис в облаке).
- `scripts/init_duckdb.py` — явная инициализация файла DuckDB (создание
  директории, служебная таблица `_meta` с версией схемы).
- `scripts/bootstrap_dev_env.sh` — всё вместе одной командой: Postgres ->
  Alembic-миграции -> DuckDB.

Важное архитектурное пояснение зафиксировано в комментариях `init_duckdb.py`:
DuckDB — встраиваемая БД без сервера, "создание БД" для неё означает просто
появление файла на диске (происходит автоматически даже без этого скрипта,
лениво, при первом подключении из `app/db/duckdb_conn.py`).

### Этап 1
Создан репозиторий `sales-bi-platform/` с backend (FastAPI, структура модулей,
заглушки интерфейсов IDataProvider/IDashboardProvider/IChartProvider/IMetricProvider/
IDataExporter), frontend (Vite+React+TS+MUI skeleton), docker-compose.yml (postgres +
backend + frontend), .env.example, README. Backend проверен локально: импортируется без
ошибок, `/health` отвечает 200 (тест через TestClient, без реального Postgres/DuckDB —
для этого подключение делается лениво). Добавлены 17 pytest-тестов — все проходят.
Frontend собирается (`tsc -b` + `vite build`) без ошибок. Все файлы получили заголовки
VERSION/Path/CHANGES (v1.0.0). Зафиксирован чекпойнт, упакован zip-архив.

### Этап 2 — ЗАКРЫТ (Data Import Module, v1.1.0)

**59 тестов, все проходят (было 17 в Этапе 1, добавлено 42).**

Реализован полный пайплайн импорта: file_reader → structure_detector →
cleaner → duckdb_writer, объединённые в DataImportService (IDataProvider).
Подключён API-роутер `/api/datasets` с эндпоинтами upload/list/get/columns/
preview/delete. Применена первая Alembic-миграция (таблица `datasets`).

Найден и исправлен баг в structure_detector v1.0.0: числовая колонка с
единичной опечаткой (dtype=object) ошибочно классифицировалась как текст,
а сортировка sample_values падала на смешанных типах. Исправлено в v1.1.0:
добавлен `_rescue_numeric` (порог 80%) + защита сортировки.

Также найдены два корневых дефекта в тестах cleaner (оба исправлены до
зелёного состояния без изменения кода производства):
- `dropna(how='all')` удалял строку с None при одноколоночном DF — исправлено
  добавлением вспомогательного столбца в тест-данные;
- тест для «грязной числовой колонки» использовал 2/3 = 67% < 80% порога —
  исправлено увеличением количества валидных значений.

Добавлены скрипты инициализации сред: setup_postgres.sh / init_postgres.sql /
init_duckdb.py / bootstrap_dev_env.sh — все протестированы вживую (оба пути:
создание с нуля и идемпотентный повторный запуск). Заархивировано:
`sales-bi-platform_v1.1.0_stage2.zip`.

### Этап 5 — ЗАКРЫТ (Dashboard Engine, v1.4.0)

**149 тестов, все проходят (+28 к Этапу 4).**

Реализован полный Dashboard Engine:

| Файл | Версия | Что сделано |
|---|---|---|
| `app/models/dashboard.py` | 1.0.0 | ORM Dashboard — конфиг дашборда в JSON |
| `app/schemas/dashboard.py` | 1.0.0 | CRUD-схемы + форматы KpiCard/Timeseries/Category/Pie/Treemap/Table/Drilldown |
| `app/modules/dashboard_engine/chart_formatters.py` | 1.0.0 | Форматировщики QueryResult → данные для ECharts |
| `app/modules/dashboard_engine/service.py` | 1.0.0 | DashboardService: CRUD + 7 методов данных |
| `app/modules/dashboard_engine/router.py` | 1.0.0 | API /api/dashboards — 12 эндпоинтов |
| `migrations/versions/de5cb779847d_*.py` | 1.0.0 | Миграция таблицы dashboards |
| `tests/test_chart_formatters.py` | 1.0.0 | 14 unit-тестов форматировщиков |
| `tests/test_dashboard_api.py` | 1.0.0 | 14 интеграционных тестов API |
| `scripts/init_schema.sql` | 1.1.0 | Добавлена таблица dashboards, COMMENT-ы, версия de5cb779847d |

Доступные эндпоинты Dashboard Engine:
- POST/GET /api/dashboards/{dataset_id} — создать/список дашбордов
- GET/PUT/DELETE /api/dashboards/item/{id} — получить/обновить/удалить
- GET /api/dashboards/{dataset_id}/kpi — KPI-карточки
- POST /api/dashboards/{dataset_id}/chart/timeseries — временной ряд
- GET /api/dashboards/{dataset_id}/chart/category — бар-чарт по категории
- GET /api/dashboards/{dataset_id}/chart/pie — круговая диаграмма
- GET /api/dashboards/{dataset_id}/chart/treemap — иерархическая treemap
- POST /api/dashboards/{dataset_id}/chart/table — агрегированная таблица
- POST /api/dashboards/{dataset_id}/drilldown — drill-down по иерархии

Архив: sales-bi-platform_v1.4.0_stage5.zip
Следующий этап: Этап 6 — Export Module (CSV/XLSX/PDF/PNG)

### Этап 6 — ЗАКРЫТ (Export Module, v1.5.0)

**185 тестов, все проходят (+36 к Этапу 5).**

Export Module не добавляет новых таблиц БД — он безсостояния (stateless):
берёт данные через QueryService/DashboardService и форматирует в файл.

| Файл | Версия | Что сделано |
|---|---|---|
| `app/schemas/export.py` | 1.0.0 | ExportRequest (csv/xlsx/pdf), include_summary |
| `app/modules/export/csv_exporter.py` | 1.0.0 | CSV с BOM (Excel), итоговая строка |
| `app/modules/export/xlsx_exporter.py` | 1.0.0 | XLSX: шапка, числовые форматы, авто-фильтр, заморозка шапки |
| `app/modules/export/pdf_exporter.py` | 1.0.0 | PDF: reportlab + DejaVuSans (кириллица), переносимая таблица |
| `app/modules/export/png_exporter.py` | 1.0.0 | PNG чартов: matplotlib Agg (category/pie/timeseries) |
| `app/modules/export/service.py` | 1.0.0 | ExportService — мост Query/Dashboard Engine ↔ экспортёры |
| `app/modules/export/router.py` | 1.0.0 | API /api/export — 4 эндпоинта |
| `requirements.txt` | 1.1.0 | + matplotlib |
| `Dockerfile` (backend) | 1.1.0 | + fonts-dejavu-core (кириллица в PDF/PNG) |
| `tests/test_exporters.py` | 1.0.0 | 21 unit-тест (magic bytes, содержимое) |
| `tests/test_export_api.py` | 1.0.0 | 15 интеграционных тестов |

Визуально проверено (рендер PDF→PNG через PyMuPDF): кириллица в заголовках,
шапке таблицы, данных и итоговой строке отображается корректно — DejaVuSans
покрывает кириллический алфавит. PNG-диаграммы (pie/category/timeseries)
также корректно отображают кириллические подписи.

Найден и исправлен баг: `QueryValidationError` из глубины `DashboardService`
не перехватывалась в `ExportService.export_chart_png` и доходила до роутера
как необработанное исключение (500 вместо ожидаемого 422). Обернул в
`ExportError` — единообразная обработка ошибок валидации по всему Export Module.

Доступные эндпоинты:
- POST /api/export/{dataset_id}/table — CSV/XLSX/PDF (тело = ExportRequest)
- GET /api/export/{dataset_id}/chart/category.png
- GET /api/export/{dataset_id}/chart/pie.png
- GET /api/export/{dataset_id}/chart/timeseries.png

Архив: sales-bi-platform_v1.5.0_stage6.zip
Следующий этап: Этап 7 — Frontend scaffold (роутинг, layout, фильтры, API-клиент)

### Этап 7 — ЗАКРЫТ (Frontend scaffold: роутинг, layout, фильтры, API-клиент, v1.6.0)

Backend не менялся (185 тестов по-прежнему проходят). Полностью реализован
frontend-каркас поверх существующего React+TS+Vite+MUI проекта из Этапа 1.

**Типизированный API-клиент** (`src/types/`, `src/api/`):
- TS-типы зеркалируют все backend Pydantic-схемы (dataset/metadata/query/dashboard/export).
- `api/client.ts` v1.1.0 — добавлен response interceptor, нормализующий ошибки
  FastAPI (`detail` строкой или списком ошибок валидации 422) в человекочитаемый `Error`.
- 5 типизированных API-сервисов: datasetsApi, metadataApi, queryApi, dashboardsApi, exportApi —
  по одному на каждый backend-модуль, обёрнуты в `src/hooks/` через @tanstack/react-query
  (кэширование, инвалидация по мутациям).

**Глобальный контекст фильтров** (`src/context/FiltersContext.tsx`):
- Хранит выбранный датасет (datasetId) и карту активных фильтров (FilterMap).
- Смена датасета автоматически сбрасывает фильтры (разные колонки/значения).
- `FilterBar` — UI поверх контекста: автокомплит с мультивыбором по каждому
  видимому измерению, значения подгружаются через distinct values API (Этап 4).

**Layout и роутинг**:
- `AppLayout` — AppBar (живой статус backend/Postgres через поллинг /api/health
  каждые 30с) + `Sidebar` (адаптируется к наличию выбранного датасета) + Outlet.
- 7 маршрутов: /datasets, /datasets/:id (превью+метаданные), /datasets/:id/overview
  (плейсхолдер под Этап 8, но с уже рабочим FilterBar), /datasets/:id/dashboards
  (список + CRUD дашбордов — полностью рабочий, API готов с Этапа 5),
  /datasets/:id/dashboards/:dashboardId (плейсхолдер просмотра — Этап 9),
  /status (техническая страница Этапа 1, оставлена для отладки), 404.

**Страницы с реальной функциональностью** (не заглушки):
- `DatasetsPage` — drag-n-drop загрузка (UploadDropzone) + сетка карточек +
  удаление с подтверждением.
- `DatasetDetailPage` — таб "Превью данных" (DataGrid, постраничный вывод) и
  таб "Метаданные" (DimensionsTable/MetricsTable с inline-редактированием
  display_name, агрегации, видимости — PATCH применяется по onBlur/onChange).
- `DashboardsListPage` — создание/удаление сохранённых дашбордов (использует
  Dashboard CRUD API из Этапа 5 напрямую).

**Найден и исправлен попутный баг**: `eslint.config.js` отсутствовал с Этапа 1
(ESLint 9 требует flat-конфиг, а не `.eslintrc`) — `npm run lint` падал с
ошибкой "couldn't find config file". Добавлен flat-конфиг + недостающие
eslint-plugin-react-hooks/eslint-plugin-react-refresh в devDependencies.

**Проверено перед упаковкой**:
- `tsc -b --noEmit` — 0 ошибок.
- `vite build` — собирается чисто (один JS-чанк 1MB/311KB gzip; предупреждение
  про размер чанка — не критично на этом этапе, можно адресовать code-splitting
  при необходимости позже).
- `eslint src` — 0 ошибок, 1 безопасное предупреждение (react-refresh про
  FiltersContext.tsx, экспортирующий и компонент, и хук — стандартный паттерн).
- Живая проверка: backend (`uvicorn`) и frontend (`vite dev`) подняты
  одновременно в песочнице, `/api/health` отвечает `{"status":"ok","postgres":"connected"}`,
  Vite dev-прокси `/api/datasets` корректно достучался до backend (`[]`).
- Backend: все 185 тестов по-прежнему проходят (регрессия не вносилась).

Архив: sales-bi-platform_v1.6.0_stage7.zip
Следующий этап: Этап 8 — главная страница, KPI-карточки, графики ECharts

### Этап 8 — ЗАКРЫТ (Главная страница: KPI-карточки, графики ECharts, v1.7.0)

**Backend-фикс (предпосылка)**: эндпоинты Dashboard Engine (`/api/dashboards/{id}/kpi`
и все `/chart/*`) технически поддерживали `filters` на уровне `DashboardService`
ещё с Этапа 5, но `router.py` никогда не пробрасывал их из query-параметров —
`FilterBar` (Этап 7) визуально работал, но не влиял на данные. Исправлено:
добавлен JSON-encoded query-параметр `filters` во все 6 эндпоинтов
(`router.py` v1.0.0 → v1.1.0). Попутно найден и исправлен баг: `HTTPException`,
поднятый внутри `_parse_filters` (422 на невалидный JSON), перехватывался общим
`except Exception` и заворачивался в 500 — поправлено в `_handle`.
Добавлено 8 новых тестов (`test_dashboard_api.py`), подтверждающих, что
фильтры реально меняют результат во всех типах чартов. **193/193 backend-тестов.**

**Frontend — типизированный слой данных**:
- `api/dashboards.ts` v1.1.0 — `filters?: FilterMap` во всех методах чартов,
  сериализуется в JSON через query-параметр `filters`.
- `hooks/useDashboardData.ts` — `useKpi`, `useTimeseriesChart`, `useCategoryChart`,
  `usePieChart`, `useTreemapChart`, `useTableChart`, `useHeatmapData` — все
  автоматически читают `datasetId`+`filters` из `FiltersContext` (Этап 7),
  компонентам чартов не нужно прокидывать фильтры вручную.
- `utils/formatValue.ts` — парсер Python-style format-строк backend
  (`"{:.2f}"`, `"€ {:,.2f}"`, `"{:.1%}"`, `"{:,.0f}"`) → `Intl.NumberFormat('ru-RU')`.
  Проверено на реальных значениях (валюта, проценты, целые, null, отрицательные).

**6 типов графиков на ECharts** (`components/charts/`):
LineChart (временной ряд, опциональная группировка по серии), BarChart
(горизонтальный, отсортирован по убыванию), PieChart (доли с процентами),
Treemap (рекурсивная конвертация 1-2-уровневой иерархии), Heatmap (Год×Месяц,
данные через Query Engine напрямую — отдельного backend-эндпоинта нет),
Waterfall (классическая ECharts-техника stacked-bar с невидимым основанием,
показывает вклад категорий в общий итог). Общая обёртка `EChartWrapper`
(loading/error/empty состояния), палитра `chartTheme.ts` согласована с MUI-темой.

**`DashboardOverviewPage` v2.0.0** — плейсхолдер Этапа 7 заменён на реальный
дашборд: набор графиков строится автоматически из структуры метаданных
(`pickCategoryDimension`/`pickTreemapDimensions` — эвристики выбора измерений
по иерархии и количеству уникальных значений), есть селектор метрики
(Select), KPI-ряд из первых 4 видимых метрик. Все графики реактивны к
`FilterBar` "из коробки" благодаря автоподключению фильтров в хуках.

**Проверено перед упаковкой**:
- `tsc -b --noEmit` — 0 ошибок (после правок типизации tooltip-formatter'ов
  ECharts: используется `any` с `eslint-disable` — стандартная практика для
  ECharts в TS-проектах, т.к. библиотека отдаёт widened union `CallbackDataParams`).
- `eslint src` — 0 ошибок, то же 1 безопасное предупреждение, что и в Этапе 7.
- `vite build` — собирается чисто (2.08MB/667KB gzip — заметно выросло из-за
  echarts; в будущем можно адресовать через code-splitting, не блокирует Этап 8).
- **Живая проверка на реальном датасете** (`sales_report_2015_2026Q1.xlsx`,
  5084 строки): backend поднят в sandbox, датасет загружен, проверены все
  6 chart-эндпоинтов + KPI + фильтрация (Страна=Германия: 508023 → 185696
  по метрике "Количество" — фильтр реально работает), heatmap-источник
  (Query Engine, Год×Месяц — 15 точек, 2015 Q1-Q4 + 2026 Q1), distinct values
  для FilterBar (Страна → 3 значения). Иерархии датасета подтверждены:
  geography (Страна→Филиал), product (Товарная группа→Товар), time (Год→Месяц).
- Backend: 193/193 тестов (185 + 8 новых на filters).

Архив: sales-bi-platform_v1.7.0_stage8.zip
Следующий этап: Этап 9 — drill-down по иерархии, карта филиалов, интерактивная таблица

### Этап 8 — патч v1.7.1 (устранение шума в консоли браузера)

Пользователь подтвердил Этап 8 рабочим в реальном Docker (datasets upload,
все chart/KPI-эндпоинты — 200 OK, фильтры по Страна+Филиал реально
применились к запросам). Сообщил про "немного некорректно работает" с логом
консоли браузера. Разбор показал: backend полностью корректен, два источника
шума в консоли не относились к нашему коду:

1. `Attempting to use a disconnected port object` — служебная ошибка
   расширения Яндекс.Браузера (`ContentMain.js`/`SherpaInitializeContent`),
   не связана с приложением.
2. `React Router Future Flag Warning` — информационное предупреждение про v7,
   не ошибка.

Дополнительно устранён настоящий косметический пробел:
3. `favicon.ico 404` — иконки не было вовсе.

**Исправлено**:
- `frontend/public/favicon.svg` — добавлена простая SVG-иконка (цвет темы).
- `frontend/index.html` v1.1.0 — подключена favicon.
- `frontend/src/App.tsx` v1.2.0 — включены React Router v7 future flags
  (`v7_startTransition`, `v7_relativeSplatPath`) — заранее переводит
  приложение на поведение v7 и убирает предупреждения.

Проверено: `tsc -b --noEmit` — 0 ошибок, `eslint` — 0 ошибок (то же 1
безопасное предупреждение), `vite build` — собирается чисто, favicon
подтверждён в `dist/`. Backend sanity-check — без изменений, тесты проходят.

Архив: sales-bi-platform_v1.7.1_stage8-patch.zip

### Этап 8 — патч v1.7.2 (каскадная фильтрация FilterBar)

Пользователь прислал скриншот: выбрал Страна=Германия, а в дропдауне
Филиал отображались все 9 филиалов всех трёх стран (Варшава, Гданьск,
Краков и т.д.). Проблема: "не соблюдается подчиненность Страна →
Филиалы → Товарные группы → Товары". Также: пустой график
"Количество по периодам" при активном фильтре.

**Корневая причина — два независимых пробела:**

1. **Backend** `GET /api/query/{id}/distinct/{column}` — никогда не принимал
   параметр `filters`. Каждый дропдаун всегда запрашивал ВСЕ уникальные
   значения независимо от остальных активных фильтров.

2. **Frontend** `useDistinctValues` — не передавал контекстные фильтры в API,
   и `staleTime: 5 min` означал, что данные не обновлялись при смене фильтров.

3. **Пустой линейный график** — следствие пункта 1 в dashboard_engine/router.py
   v1.1.0: теперь исправлено, 15 точек возвращаются корректно при filter+group_by.

**Backend-изменения:**
- `sql_builder.py` v1.1.0: WHERE-clause вынесен в `_build_where(filters)` —
  переиспользуется в `build_aggregation_query` и `build_distinct_values_query`
  (которая теперь принимает `filters`).
- `schemas/query.py` v1.1.0: добавлен `parse_filters_json()` — общий хелпер
  разбора JSON-encoded FilterMap; переиспользуется в обоих роутерах.
- `query_engine/service.py` v1.1.0: `get_distinct_values` принимает `filters`.
- `query_engine/router.py` v1.1.0: эндпоинт `distinct/{column}` принимает
  `filters` query-param, парсит через `parse_filters_json`.
- `dashboard_engine/router.py` v1.2.0: переключён на общий `parse_filters_json`
  вместо локального дубликата `_FilterMapAdapter`.
- +5 новых тестов каскадной фильтрации в `test_query_api.py`.
- **198/198 backend-тестов.**

**Frontend-изменения:**
- `api/query.ts` v1.1.0: `getDistinctValues` принимает `filters?: FilterMap`,
  сериализует в JSON query-param.
- `hooks/useQueryEngine.ts` v1.1.0: `useDistinctValues` читает `filters` из
  `useFilters()`, строит `effectiveFilters` = активные фильтры минус
  текущая колонка (чтобы дропдаун Филиал видел фильтр Страна, но не себя),
  передаёт в API. `staleTime` убран — данные реактивны.
  `FilterBar.tsx` изменений не требовал: он уже вызывает
  `useDistinctValues(datasetId, dimension.column_name)` — каскад
  полностью инкапсулирован в хуке.

Архив: sales-bi-platform_v1.7.2_stage8-patch2.zip

### .env аудит — v1.7.3 (все конфигурируемые значения вынесены в .env)

Аудит всего проекта на захардкоженные значения. Все параметры, которые
могут меняться при разных окружениях, вынесены в `.env.example` v2.0.0
с подробными комментариями на русском языке.

**`.env.example` v2.0.0 — 11 разделов:**
1. Окружение (ENVIRONMENT, DEBUG)
2. PostgreSQL (параметры подключения)
3. DuckDB (путь к файлу)
4. Файловое хранилище (UPLOAD_DIR, MAX_UPLOAD_SIZE_MB)
5. Сетевые порты docker-compose
6. CORS (CORS_ORIGINS — теперь как строка через запятую)
7. Лимиты Query Engine (QUERY_DEFAULT_LIMIT, QUERY_MAX_LIMIT,
   DISTINCT_VALUES_LIMIT, QUERY_CACHE_TTL_SECONDS)
8. Лимиты чартов Dashboard Engine (CHART_CATEGORY/PIE/WATERFALL/
   TIMESERIES/TABLE/DRILLDOWN/HEATMAP_QUERY_LIMIT)
9. Экспорт (EXPORT_PDF_MAX_ROWS, EXPORT_PNG_DPI, EXPORT_PNG_*_WIDTH/HEIGHT)
10. Metadata Detector (FORMAT_CURRENCY/PERCENTAGE/INTEGER/FLOAT,
    HIERARCHY_*_KEYWORDS — 6 иерархических уровней)
11. Frontend UI (VITE_APP_TITLE, VITE_HEALTH_POLL_INTERVAL_MS,
    VITE_API_TIMEOUT_MS, VITE_KPI_CARDS_COUNT, VITE_FILTER_MAX_VISIBLE_TAGS,
    VITE_CHART_GROUP_BY_MAX_DISTINCT, VITE_CHART_DEFAULT/TREEMAP_HEIGHT,
    VITE_SIDEBAR_WIDTH, VITE_QUERY_RETRY_COUNT)

**Backend-изменения:**
- `config.py` v2.0.0: все новые параметры добавлены в Settings.
- `metadata/detector.py` v2.0.0: _HIERARCHY_RULES и _FORMAT_MAP строятся
  через _build_hierarchy_rules()/_build_format_map() из Settings.
- `dashboard_engine/service.py` v1.1.0: лимиты чартов (7 методов) берутся
  из get_settings() при limit=None.
- `export/pdf_exporter.py` v1.1.0: max_rows из settings.export_pdf_max_rows.
- `export/png_exporter.py` v1.1.0: width/height/dpi из settings.export_png_*.

**Frontend-изменения:**
- `api/client.ts` v1.2.0: timeout из VITE_API_TIMEOUT_MS.
- `App.tsx` v1.3.0: retry из VITE_QUERY_RETRY_COUNT.
- `layout/Sidebar.tsx` v1.1.0: SIDEBAR_WIDTH из VITE_SIDEBAR_WIDTH.
- `layout/AppLayout.tsx` v1.1.0: poll interval из VITE_HEALTH_POLL_INTERVAL_MS.
- `filters/FilterBar.tsx` v1.1.0: max visible tags из VITE_FILTER_MAX_VISIBLE_TAGS.
- `pages/DashboardOverviewPage.tsx` v2.1.0: KPI_CARDS_COUNT и
  CHART_GROUP_BY_MAX_DISTINCT из env.

**Принцип внесения:** все значения сохраняют текущее поведение по умолчанию —
выход из строя при отсутствии .env не происходит (дефолты заложены в Settings
и через ?? в frontend). Добавление нового .env — только тонкая настройка.

198/198 backend-тестов (без изменений). tsc/eslint/vite build — чисто.

Архив: sales-bi-platform_v1.7.3_env-audit.zip

### Этап 9 — ЗАКРЫТ (Drill-down, карта филиалов, таблица, фикс таймаутов, v1.8.0)

**Критический фикс таймаутов (главная причина скриншотов "Превышено время ожидания"):**
`duckdb_conn.py` v1.1.0 — экспортирован `QUERY_LOCK = asyncio.Lock()`.
`query_engine/service.py` v1.2.0 — все три `asyncio.to_thread(_execute_query)`
обёрнуты в `async with QUERY_LOCK`. Без Lock 7 chart-запросов при смене
метрики конкурировали за единственное DuckDB-соединение (не thread-safe),
что вызывало взаимную блокировку и timeout. Таймаут axios увеличен до 60 сек
(в .env.example и в дефолте api/client.ts).

**Drill-down UI:**
- `hooks/useDrilldown.ts` — управляет открытым уровнем иерархии, запрашивает
  данные через `dashboardsApi.getDrilldown` с активными фильтрами контекста.
- `components/charts/DrilldownModal.tsx` — модальное окно с горизонтальным
  баром следующего уровня, форматирует значения через `formatValue`.
- `EChartWrapper` v1.1.0 — добавлен prop `onEvents` для ECharts event handlers.
- `BarChartCard` v1.1.0, `PieChartCard` v1.1.0, `TreemapChartCard` v1.1.0 —
  добавлен prop `onDrilldown(value: string)`, при клике на элемент открывается
  DrilldownModal с данными следующего уровня иерархии.

**Карта филиалов (Leaflet + OpenStreetMap):**
- `utils/branchCoordinates.ts` — lookup-таблица координат 9 городов из датасета
  (координаты lat/lng в XLSX отсутствуют, используем справочник).
- `components/charts/BranchMapCard.tsx` — CircleMarker с радиусом,
  пропорциональным значению метрики. Tooltip: название города + отформатированное
  значение. Данные через `useCategoryChart(dimension=Филиал)`.

**Интерактивная таблица:**
- `components/charts/DataTableCard.tsx` — MUI DataGrid с сортировкой,
  пагинацией и экспортом в CSV (BOM для корректного открытия в Excel).
  Данные через `useTableChart` с активными фильтрами контекста.

**DashboardOverviewPage v3.0.0** — добавлены карта (если есть "geography l1"),
таблица, drill-down обработчики на Bar/Pie/Treemap.

**DashboardViewPage v2.0.0** — плейсхолдер полностью заменён реальным рендером:
ChartRenderer рендерит правильный компонент по `chart.type` (line/bar/pie/
treemap/heatmap/waterfall/table/map), KpiRow, FilterBar, DrilldownModal всё
подключено. Сохранённые дашборды теперь реально отображаются.

**types/dashboard.ts** — расширен ChartType (добавлены line/category/waterfall/map),
CategoryPoint получил index signature для доступа по имени dimension-колонки.

**Тесты:** +2 новых теста для QUERY_LOCK в test_duckdb_conn.py.
**Итого: 200/200 backend-тестов.**

tsc — 0 ошибок, eslint — 0 ошибок (1 safe warning), vite build — чисто.

Архив: sales-bi-platform_v1.8.0_stage9.zip

### Промежуточный патч v0.7.1 → v0.8.0 — Контрастные фильтры (filter-contrast)

**FilterBar.tsx v1.2.0:**
- Chips выбранных значений — синий фон (`#2563eb`), белый текст, белая иконка удаления.
- Overflow-chip «+N» — тёмно-синий фон (`#1d4ed8`), белый текст.
- `disableCloseOnSelect` — список не закрывается при выборе опции (мультивыбор удобнее).
- Чекбоксы в dropdown (CheckBox/CheckBoxOutlineBlank icon), hover-фон — `#dbeafe`.
- Выбранная опция — синий текст + жирный шрифт, background `#2563eb18`.
- Рамка поля (fieldset) при наличии выбора — синяя 2px.
- Счётчик «Фильтры (N)» — заменён на badge-пилюлю (синий фон, белый текст).
- Рамка Paper-контейнера при активных фильтрах — синяя 1.5px.

### Промежуточный этап — Интерактивная карта с drill-down (v0.8.0)

**Новые файлы:**

`utils/countryPolygons.ts` (v1.0.0):
- GeoJSON FeatureCollection — упрощённые полигоны Германии, Польши, Франции
  (координаты из Natural Earth ne_110m, встроены inline, без внешних зависимостей).
- `COUNTRY_BOUNDS` — bounding-boxes для автозума `fitBounds`.

`components/charts/MapSidePanel.tsx` (v1.0.0):
- Drill-down панель справа от карты.
- Уровень 1 (groups): товарные группы выбранного филиала, отсортированы DESC.
- Уровень 2 (products): товары выбранных групп, отсортированы DESC.
- Строка — фоновый прогресс-бар пропорциональный метрике, чекбокс, label, значение.
- Ctrl+клик (Cmd+Mac) — мультивыбор. Обычный клик — выбор одного.
- Chips выбранных элементов в хедере (синие).
- Кнопка «Показать товары →» при выбранных группах.
- Футер: итоговая метрика по выбранным элементам.
- Кнопки «Назад» (groups←) и «Закрыть» в хедере.

**Обновлённые файлы:**

`components/charts/BranchMapCard.tsx` (v2.0.0):
- GeoJSON-слой полигонов стран: hover — синяя подсветка, клик — выделение + фильтр
  маркеров, 2× клик — автозум `fitBounds` на страну.
- `MapController` (useMap) — программный `fitBounds`/`setView` при смене страны.
- `doubleClickZoom={false}` — Leaflet не зумирует при двойном клике.
- `key={geoJsonKey}` на GeoJSON — пересоздание слоя при смене selectedCountry
  (единственный способ обновить стили в react-leaflet без ref).
- CircleMarkers: показываются все (уровень 0) или только выбранной страны (уровень 1).
  Одиночный клик — выбрать страну (если не выбрана). 2× клик — открыть MapSidePanel.
  Активный маркер — янтарный (#f59e0b), толстый border.
- Хлебные крошки: «Все страны › Германия › Берлин» — кликабельные.
- Кнопки Назад (ArrowBack) и Сброс (Home) в хедере.
- Счётчик «X из N филиалов» при выбранной стране.
- Подсказка пользователю в футере карты.

Архив: sales-bi-platform_v0.8.0_interactive-map.zip

### Промежуточный этап v0.9.0 — i18n + Темы + Масштаб диаграмм + Drag-and-drop

**Новые файлы:**

`locales/` (9 файлов + index):
- `ru.ts` — русский (базовый, все ключи). `Translation` type экспортируется отсюда.
- `en.ts`, `de.ts`, `zh.ts`, `be.ts`, `kk.ts`, `ar.ts`, `sr.ts`, `ko.ts` — переводы UI.
- `index.ts` — реестр `LOCALES`, `LOCALE_LABELS`, `RTL_LOCALES`, `LocaleCode`.
  Добавление нового языка: 1 файл + 1 строка в `index.ts`.

`context/I18nContext.tsx` (v1.0.0):
- `I18nProvider` + `useTranslation()` hook. Без внешних зависимостей (react-i18next).
- Язык сохраняется в `localStorage`. При арабском — `dir="rtl"` на `<html>`.
- Автодетект языка браузера как фоллбэк.

`context/ThemeContext.tsx` (v1.0.0):
- `AppThemeProvider` + `useAppTheme()`. 3 MUI-темы: `light` / `dark` / `neutral`.
- Тема сохраняется в `localStorage`. Добавление темы: 1 запись в `THEMES` + `THEME_LABELS`.
- `dark`: фон `#0f172a` / `#1e293b`, primary `#60a5fa`.
- `neutral`: серо-синяя светлая, primary `#475569`, приглушённые акценты.

`context/DashboardLayoutContext.tsx` (v1.0.0):
- `visibleCharts: Set<string>` — какие диаграммы показаны (чекбоксы в Sidebar).
- `layouts` — позиции react-grid-layout, сохраняются в `localStorage`.
- `ALL_CHARTS` — манифест всех диаграмм с defaultW/H для начальной раскладки.
- `toggleChart`, `showAll` — управление видимостью.

`components/common/ChartContextMenu.tsx` (v1.0.0):
- Контекстное меню по правой кнопке мыши для любой диаграммы.
- Пункт МАСШТАБ → «Расширить на ширину» / «Во весь экран» / «По умолчанию» / «Растянуть (угол)».
- Закрывается по клику снаружи или Escape. Позиция с учётом края экрана.

`components/common/ScalableChartWrapper.tsx` (v1.0.0):
- Обёртка `<ScalableChartWrapper chartId="...">`. Устанавливается на каждую диаграмму.
- `fullWidth` — ширина 100% колонки.
- `fullScreen` — Fullscreen API браузера (`requestFullscreen`), фоллбэк на CSS fixed.
- Resize-ручка в правом нижнем углу (активируется через меню «Растянуть»).
- Drag handle выводится верхней полосой, активируется через react-grid-layout.

`components/charts/ScatterChartCard.tsx` (v1.0.0):
- Точечная диаграмма: зависимость двух числовых метрик, группировка по dimension.
- Линия тренда (МНК) опциональна через prop `showTrendLine`.
- Labels на точках при ≤20 наблюдениях.

`components/charts/HistogramChartCard.tsx` (v1.0.0):
- Гистограмма распределения. Биннинг на frontend (N бинов, configurable).
- Tooltip: диапазон и количество наблюдений в бине.

**Обновлённые файлы:**

`context/DashboardLayoutContext.tsx` — управление видимостью + позициями диаграмм.
`components/layout/Sidebar.tsx` (v2.0.0) — полная переработка:
- 4 Accordion-секции: Датасеты / Дашборд / Сохранённые дашборды / Настройки.
- Список датасетов с индикатором текущего, клик → смена датасета.
- Список всех диаграмм с чекбоксами видимости + описанием.
- Inline-выбор темы (Select) и языка (Select) в секции Настройки.
- Chip-счётчик активных датасетов и видимых диаграмм.

`App.tsx` (v2.0.0) — порядок провайдеров: QueryClient → I18n → AppTheme → Theme → Filters → Layout → Router.

`pages/DashboardOverviewPage.tsx` (v4.0.0):
- `react-grid-layout` Responsive grid — drag-and-drop + resize всех диаграмм.
- Раскладка сохраняется через DashboardLayoutContext → localStorage.
- `draggableHandle=".chart-drag-handle"` — полупрозрачная ручка в верхней части карточки.
- `ScalableChartWrapper` на каждой диаграмме → правая кнопка → масштаб.
- Интеграция ScatterChartCard + HistogramChartCard.
- Диаграммы рендерятся только если `visibleCharts.has(id)`.

`package.json` — добавлен `react-grid-layout@^1.4.4`.
`components/charts/index.ts` (v1.2.0) — экспорт ScatterChartCard, HistogramChartCard.

Архив: sales-bi-platform_v0.9.0_mega-features.zip

### Этап 10 — v0.10.0 — Финальная полировка (i18n везде, dark theme ECharts, save dashboard)

**Новые файлы:**

`hooks/useChartTheme.ts` (v1.0.0):
- `useChartTheme()` → `ChartThemeVars` для каждой темы (light/dark/neutral).
- Поля: `echartsTheme`, `axisColor`, `splitLineColor`, `tooltipBg`, `bgColor: "transparent"`.
- Использовать в любом ChartCard для тема-зависимой стилизации ECharts option.

`components/error/ChartErrorBoundary.tsx` (v1.0.0):
- Class component — перехватывает ошибки рендера диаграмм.
- Выводит понятное сообщение + кнопку «Перезагрузить» вместо белого экрана.
- Оборачивает каждый `ScalableChartWrapper` в DashboardOverviewPage.

`hooks/useSavedDashboards.ts` (v1.0.0):
- `save({ name, datasetId, datasetName, primaryMetric, visibleCharts, filters, layouts })`.
- Авто-имя: «{datasetName} — ДД.ММ.ГГ ЧЧ:ММ». Хранится в localStorage, макс. 20 записей.
- `deleteById`, `rename`. Реактивный — useState внутри хука.

**Обновлённые файлы:**

`EChartWrapper v1.2.0`:
- `useChartTheme()` — в тёмной теме передаёт `theme="dark"` в ReactECharts.
- `backgroundColor: ct.bgColor` ("transparent") в enrichedOption — Paper даёт фон.
- `useTranslation()` — «Нет данных» через `t.charts.noData`.
- `ChartErrorBoundary` обёртка вокруг ReactECharts.

`KpiCard v1.1.0`:
- Агрегации через `t.kpi.sum / t.kpi.avg / t.kpi.count`.

`AppLayout v1.2.0`:
- z-index AppBar ниже Drawer (больше нет перекрытия сайдбара).
- Backend status chip: «…» в начальном состоянии (не мигает).

`MapSidePanel v1.1.0`:
- Все хардкоды → `t.map.*` (ctrlClickHint, showProducts, total, groups, items, noData).

`BranchMapCard v2.1.0`:
- `t.map.clickHint`, `t.map.dblClickHint`, `t.map.allCountries`, `t.map.branches`.

`DataTableCard v1.1.0`:
- `t.table.rowsPerPage`, `t.table.exportCsv`.

`DashboardLayoutContext v1.1.0`:
- `primaryMetric` state + `setPrimaryMetric`.
- `getSnapshot()` → `{ visibleCharts, layouts, primaryMetric }`.
- `restoreSnapshot(snap)` — восстанавливает всё состояние дашборда.

`Sidebar v2.1.0`:
- Секция «Сохранённые дашборды» — функциональная: список с именем, датой/временем,
  кнопки «Открыть» (RestoreIcon) и «Удалить» (DeleteOutline).
- При открытии — `restoreSnapshot` + навигация на датасет (если другой).
- Чипы: имя датасета + количество диаграмм.
- Кнопка «Сохранить дашборд» в секции Дашборд.

`DashboardOverviewPage v4.1.0`:
- `handleMetricChange` синхронизирует `primaryMetric` в `DashboardLayoutContext`.
- `ChartErrorBoundary` вокруг `ScalableChartWrapper`.
- Breadcrumbs + заголовки через `t.nav.*`, `t.dashboard.*`.

Архив: sales-bi-platform_v0.10.0_stage10.zip

### Этап 11 — v0.11.0 — Новые диаграммы + полный i18n всего приложения

**Новые диаграммы:**

`components/charts/BoxPlotChartCard.tsx` (v1.0.0):
- Ящик с усами (box & whisker). Вычисляет Q1/медиана/Q3/мин/макс на frontend.
- Параметры: `dimension` (подкатегории), `groupDimension` (родитель = один ящик).
- Tooltip: все 5 статистик с форматированием. Цвет ящика = CHART_COLORS[0] с прозрачностью.
- Без groupDimension — один ящик на весь датасет.

`components/charts/RadarChartCard.tsx` (v1.0.0):
- Радарная/паутинная диаграмма. Оптимальна для 2–5 метрик, 3–8 категорий.
- Каждая «паутинка» = значение dimension по всем метрикам (нормализовано к max).
- Легенда снизу. Tooltip: все метрики с форматированием.
- Рендерится только при `metrics.length >= 2`.

`components/charts/GaugeChartCard.tsx` (v1.0.0):
- Спидометр (gauge). Показывает сумму метрики как % от target или max.
- Зоны цветом: 0–50% красная / 50–80% жёлтая / 80–100% зелёная.
- Центральный detail: абсолютное значение + процент. Dark theme aware.

**i18n — новые ключи во всех 9 локалях:**

Добавлены секции `pages.datasets`, `pages.datasetDetail`, `pages.savedDashboards`
+ ключи `chartNames.boxplot`, `chartNames.radar`, `chartNames.gauge`.
Все 9 файлов (ru, en, de, zh, be, kk, ar, sr, ko) обновлены одним скриптом.

**Обновлённые компоненты:**

`DatasetsPage v1.1.0`:
- `t.pages.datasets.*` — заголовок, подсказка, диалог удаления (title/text/btn).

`DatasetDetailPage v1.1.0`:
- `t.pages.datasetDetail.*` — вкладки, кнопки, строки/колонки. Кнопка «Обновить метаданные».

`DashboardsListPage v1.1.0`:
- `t.pages.savedDashboards.*` — заголовок, создание, удаление, «нет данных».
- Интеграция localStorage-дашбордов (useSavedDashboards) рядом с API-дашбордами.
- Chips: датасет + количество диаграмм. Кнопка RestoreIcon.

`FilterBar v1.3.0`:
- Полный i18n: title, clearAll, all (placeholder), loading, noVisibleDimensions, noDataset.

`DashboardLayoutContext v1.2.0`:
- BoxPlot / Radar / Gauge добавлены в ALL_CHARTS (13 диаграмм итого).

`DashboardOverviewPage v4.2.0`:
- Новые case "boxplot" / "radar" / "gauge" в switch(id).
- BoxPlot: группировка по первым двум уровням иерархии.
- Radar: до 4 метрик, top-6 категорий.
- Gauge: сумма метрики как % от max.

`components/charts/index.ts v1.3.0`:
- Экспорт BoxPlotChartCard, RadarChartCard, GaugeChartCard.

Архив: sales-bi-platform_v0.11.0_stage11.zip

### Этап 12 — v0.12.0 — Bugfix + Backend Analytics + Funnel + StatSummary + FAB

**BUGFIX (критичный):**

`DashboardsListPage.tsx`: импортировал `useDashboards` которого нет — хук называется
`useDashboardsList`. Крашил всю страницу с `SyntaxError`. Исправлено.

`package.json`: добавлен `react-resizable@^3.0.5` (peer dependency react-grid-layout).
Без него CSS `react-resizable/css/styles.css` не находился при `npm install`.

**Backend — новый модуль `analytics/`:**

`backend/app/schemas/analytics.py` (v1.0.0):
- `ColumnStats` — 14 полей: column_name, display_name, count, null_count, null_pct,
  min, max, mean, median, std, q1, q3, iqr, cv.
- `DescribeResponse` — dataset_id + список ColumnStats.

`backend/app/modules/analytics/service.py` (v1.0.0):
- `AnalyticsService.describe(dataset_id)` — для каждой видимой метрики
  один SQL-запрос к DuckDB: COUNT, MIN, MAX, AVG, MEDIAN, STDDEV, PERCENTILE_CONT(0.25/0.75).
- Защита: QUERY_LOCK перед каждым запросом. Пустой датасет → пустой список.

`backend/app/modules/analytics/router.py` (v1.0.0):
- `GET /api/analytics/{dataset_id}/describe` → `DescribeResponse`.

`backend/app/api/router.py` (v1.4.0):
- Подключён `analytics_router` с prefix `/analytics`.

**Frontend:**

`api/analytics.ts` (v1.0.0) — `analyticsApi.describe(datasetId)`.
`hooks/useAnalytics.ts` (v1.0.0) — `useDescribe(datasetId)`, staleTime=5min.
`api/index.ts` — экспортирует `analyticsApi`.

`components/charts/FunnelChartCard.tsx` (v1.0.0):
- Воронка продаж (ECharts funnel series). Top-N категорий по метрике DESC.
- Лейбл внутри уровня: название + форматированное значение + % от максимума.
- Легенда слева, цвета из CHART_COLORS, tooltip с % от максимума.

`components/charts/StatSummaryCard.tsx` (v1.0.0):
- Таблица MUI DataGrid: все видимые метрики × статистика (min/max/mean/median/Q1/Q3/std/CV%/null%).
- CV% > 50 → оранжевый, > 100 → красный. null% > 5 → красный.
- Данные из `useDescribe` (backend /analytics/describe).

`pages/DashboardOverviewPage.tsx` (v4.3.0):
- Импорт `FunnelChartCard`, `StatSummaryCard`.
- case "funnel" — воронка по primary dimension.
- case "statsummary" — StatSummaryCard (без dimension, данные из describe).
- FAB (Floating Action Button) SaveIcon, bottom:32/right:32 — клик → `saveDash()`.
  Имя автоматическое: «{datasetName} — {дата} {время}».

`context/DashboardLayoutContext.tsx` (v1.3.0) — 15 диаграмм в ALL_CHARTS.
`components/charts/index.ts` (v1.4.0) — FunnelChartCard, StatSummaryCard.
Все 9 локалей — добавлены ключи `funnel` и `statsummary`.

Архив: sales-bi-platform_v0.12.0_stage12.zip

### Этап 13 — v0.13.0 — Модульная архитектура + Tools Board + KPI Analysis

**Bugfixes:**
- `DashboardOverviewPage`: TDZ crash — `getSnapshot` использовался до инициализации.
  Исправлен порядок: `useDashboardLayout()` + `useSavedDashboards()` + `useTranslation()`
  перенесены ПЕРЕД `handleSaveDashboard`.
- `DataTableCard`: дублирующийся `import { useTranslation }` — убран второй.
- `Sidebar`: `THEME_LABELS` были захардкожены на русском — заменены на `t.settings.themeLight/Dark/Neutral`.

**Модульная система:**

`modules/types.ts` (v1.0.0):
- `ModuleManifest` — манифест модуля (id, name, icon, color, tier, routePrefix, navItems, agentHooks, toolsBoard).
- `AgentHook` — точка интеграции агента (hookId, event, description).
- `UserSubscription` — состояние подписки (tier, activeModuleIds, trialModuleIds, isStandaloneMode).

`modules/registry.ts` (v1.0.0):
- `ALL_MODULES` — все зарегистрированные модули.
- `ENABLED_MODULES` — фильтрованные по `VITE_ENABLED_MODULES` env.
- Добавить модуль: 1 файл manifest.ts + 1 строка в registry.ts.

`modules/dashboards/manifest.ts` — манифест Dashboards (free, 4 agent hooks).
`modules/kpi/manifest.ts` — манифест KPI Analysis (pro, 3 agent hooks).
`modules/agents/manifest.ts` — заглушка AI Agents (enterprise, coming soon).

`context/ModulesContext.tsx` (v1.0.0):
- `isModuleActive`, `isModuleLocked`, `isModuleTrial`, `startTrial`, `upgradeTier`.
- STANDALONE mode (`VITE_STANDALONE_MODE=true`): все разрешённые модули → enterprise.
- Состояние подписки → localStorage.

**Новые страницы:**

`pages/ToolsBoardPage.tsx` (v1.0.0):
- Витрина всех модулей: иконка, описание, теги, версия, what's new.
- Tier-бейджи (free/pro/enterprise), статус (active/locked/trial/coming soon).
- Кнопки: «Открыть» / «Попробовать 14 дней» / «Скоро».
- Информационный блок об архитектуре модулей.

`modules/kpi/KpiAnalysisPage.tsx` (v1.0.0):
- KPI Скоркарта: все метрики с % изменением period-vs-period + тренд-иконка (↑↓→).
- Сравнение периодов: два BarChart рядом для периодов A и B.
- Радарная диаграмма: многомерное сравнение по всем метрикам.
- Статистическая сводка: StatSummaryCard.
- Выбор метрики + двух периодов через Select.

**Обновлённые файлы:**

`routes/AppRoutes.tsx` (v2.0.0):
- `/` → редирект на `/tools` (Tools Board).
- `/tools` — ToolsBoardPage (lazy).
- `/kpi/:datasetId` — KpiAnalysisPage (lazy).

`components/layout/Sidebar.tsx` (v2.2.0):
- Quick nav: кнопки «Tools Board» и «KPI» (показывается при выбранном датасете).
- Темы через `t.settings.themeLight/Dark/Neutral` (не захардкожены).

`App.tsx` (v2.1.0):
- `ModulesProvider` добавлен в цепочку провайдеров.

`docker-compose.yml` (v2.0.0):
- Профиль `dashboards`: только Dashboards, VITE_ENABLED_MODULES=dashboards.
- Профиль `kpi`: Dashboards+KPI, VITE_ENABLED_MODULES=dashboards,kpi.
- Default (без профиля): все модули.
- `VITE_STANDALONE_MODE` — enterprise tier без ограничений.

`.env.example`: добавлены `VITE_ENABLED_MODULES`, `VITE_STANDALONE_MODE`.

Архив: sales-bi-platform_v0.13.0_stage13.zip

### Этап 14 — v0.14.0 — Backend KPI + Agent Bus + Module Guard + Polish

**Backend — новый модуль `/api/kpi/`:**

`backend/app/schemas/kpi.py` (v1.0.0):
- `KpiMetricPeriod`: column_name, display_name, display_format, value_a, value_b, delta_abs, delta_pct.
- `KpiScorecardResponse`: dataset_id + period info + список KpiMetricPeriod.
- `KpiCompareItem`: label, value_a, value_b, delta_pct.
- `KpiCompareResponse`: dataset_id + dimension + metric + период + список KpiCompareItem.

`backend/app/modules/kpi/service.py` (v1.0.0):
- `scorecard()` — один SQL SELECT с условными агрегатами `FILTER WHERE period_col = A/B`
  для каждой метрики. Один проход по таблице вместо N запросов.
- `compare()` — GROUP BY dimension с двумя условными SUM. Top-N DESC, limit.

`backend/app/modules/kpi/router.py` (v1.0.0):
- `GET /api/kpi/{dataset_id}/scorecard?period_col=Год&period_a=2025&period_b=2024`
- `GET /api/kpi/{dataset_id}/compare?dimension=Страна&metric=...&period_col=...&period_a=...&period_b=...`

`backend/app/api/router.py` (v1.5.0): подключён `kpi_router` с prefix `/kpi`.

**Frontend — Agent Bus:**

`modules/agents/AgentBus.ts` (v1.0.0):
- Singleton `AgentEventBus` — pub/sub шина событий платформы.
- `emit(hookId, moduleId, payload)` — вызывается в точках AgentHook.
- `subscribe(hookId, handler)` → unsubscribe.
- `subscribeAll(handler)` → unsubscribe (для агентов-наблюдателей).
- `getLog(n)` — последние N событий для контекста агента.
- В DEV-режиме выводит события в console.debug.
- В production агенты подключаются через WebSocket/SSE поверх этой шины.

**Frontend — Module Guard:**

`components/common/ModuleGuard.tsx` (v1.0.0):
- Обёртка для страниц модулей: если `isModuleActive(moduleId) === false` →
  показывает upgrade-prompt с иконкой Lock, tier-badge, описанием.
- Кнопка «Попробовать 14 дней» → `startTrial(moduleId)`.
- Кнопка «Все инструменты» → `/tools`.
- `common/index.ts` обновлён: экспортирует ModuleGuard.

**Frontend — KPI Analysis v2.0:**

`modules/kpi/KpiAnalysisPage.tsx` (v2.0.0):
- Обёрнут в `ModuleGuard moduleId="kpi"`.
- `useKpiScorecard` → backend `/api/kpi/scorecard` (один проход вместо двух запросов).
- `useKpiCompare` → backend `/api/kpi/compare` → grouped bar chart.
- `AgentBus.emit("kpi.metric_select", ...)` при смене метрики/периода.
- `KpiCompareChart` — ECharts grouped bar, темно-зависимые цвета через `useChartTheme`.

`modules/kpi/hooks/useKpiScorecard.ts` (v1.0.0) — react-query wrapper.
`modules/kpi/hooks/useKpiCompare.ts` (v1.0.0) — react-query wrapper.
`api/kpi.ts` (v1.0.0) — `kpiApi.scorecard()` + `kpiApi.compare()`.
`api/index.ts` — экспортирует kpiApi.

**Локали:**
Все 9 файлов: добавлена секция `modules.dashboards/kpi/agents` (name + description).
Используется в ToolsBoardPage для i18n названий и описаний модулей.

Архив: sales-bi-platform_v0.14.0_stage14.zip

### Этап 15 — v0.15.0 — Platform Registry + Agent Console + KPI Targets + ARCHITECTURE.md

**Backend — Platform Registry:**

`backend/app/schemas/platform.py` (v1.0.0):
- `ModuleInfo`: id, name, version, tier, enabled, routes.
- `PlatformInfo`: platform_name, platform_version, api_version, started_at, enabled_modules, standalone_mode.

`backend/app/modules/platform_registry/router.py` (v1.0.0):
- `GET /api/platform/info` → `PlatformInfo` (версия платформы + активные модули + режим).
- `GET /api/platform/modules` → `list[ModuleInfo]` (для синхронизации с фронтом).
- Читает `ENABLED_MODULES` env и `STANDALONE_MODE` env.
- `ALL_BACKEND_MODULES` — реестр всех известных backend-модулей.

`backend/app/api/router.py` (v1.6.0): подключён `platform_router` с prefix `/platform`.

**Frontend — AgentConsole:**

`components/common/AgentConsole.tsx` (v1.0.0):
- Floating кнопка (левый нижний угол, z=1300) — SmartToyIcon с pulse-эффектом при новом событии.
- Клик → коллапсируемый drawer (340×440px, ElevationShadow=8).
- Хедер пурпурный (#7c3aed) с счётчиком событий + кнопки «Очистить» / «Закрыть».
- Лента событий: время, moduleId-badge, hookId, payload JSON (pre-formatted, max-height).
- Авто-обновление через `AgentBus.subscribeAll`.
- Показывается в DEV всегда; в PROD — при `VITE_AGENT_CONSOLE=true`.
- Подключён в `AppLayout v1.3.0`.

**Frontend — KPI Targets:**

`modules/kpi/KpiTargetsContext.tsx` (v1.0.0):
- `KpiTargetsProvider` + `useKpiTargets()`.
- `getTarget(datasetId, metricCol)` → number | null.
- `setTarget(...)` — сохраняет в localStorage.
- `getAllTargets(datasetId)` — все цели датасета.
- `clearTargets(datasetId)` — сброс.
- Добавлен в `App.tsx` v2.2.0 в цепочку провайдеров.

`modules/kpi/components/KpiTargetSetter.tsx` (v1.0.0):
- Таблица метрик с полем ввода цели.
- Chip текущей цели (зелёный) + кнопка удаления.
- Enter или CheckIcon → сохранить. Добавлен в `KpiAnalysisPage v2.1.0`.

`components/charts/GaugeChartCard.tsx` (v1.1.0):
- Читает target из `KpiTargetsContext` если prop `target` не задан.
- `effectiveTarget = props.target ?? contextTarget ?? max(data)`.

`api/platform.ts` (v1.0.0) — `platformApi.info()` + `platformApi.modules()`.
`hooks/usePlatform.ts` (v1.0.0) — `usePlatformInfo()`, `usePlatformModules()`.
`components/common/index.ts` (v1.2.0) — экспортирует `AgentConsole`.

**Документация:**

`docs/ARCHITECTURE.md` (249 строк):
- Полный гайд по добавлению нового модуля (7 шагов: manifest → registry → page → route → locales → backend → docker).
- Примеры кода для каждого шага.
- Описание AgentBus (emit, subscribe, subscribeAll, getLog).
- Структура каталогов.
- Таблица subscription tiers.
- Таблица environment variables.

`docker-compose.standalone.yml`:
- Standalone-конфиг с `VITE_STANDALONE_MODE=true`.
- `MODULES` env для выбора набора модулей.
- Отдельные named volumes (`_standalone` suffix).
- Один frontend-сервис (без profiles).

Sidebar: v0.15.0.

Архив: sales-bi-platform_v0.15.0_stage15.zip

### Этап 16 — v0.16.0 — Tests + Notifications + AgentBus + README

**Backend тесты:**

`tests/test_kpi_api.py` (v1.0.0, 154 строки):
- `TestKpiScorecard` (6 тестов): 422 без params, 404/500 неизвестный датасет,
  200 + schema validation, поля metrics, корректность delta_abs, нулевые значения при несуществующем периоде.
- `TestKpiCompare` (4 теста): 422 без params, 200 + schema, поля items, limit enforcement.

`tests/test_platform_api.py` (v1.0.0, 103 строки):
- `TestPlatformInfo` (6 тестов): 200, schema fields, platform_name, modules list + schema,
  started_at как ISO datetime.
- `TestPlatformModules` (6 тестов): 200, list type, dashboards present, tier values,
  routes is list, all enabled without ENABLED_MODULES env.

**Frontend — NotificationSystem:**

`context/NotificationContext.tsx` (v1.0.0):
- `NotificationProvider` — очередь уведомлений, одно одновременно.
- `useNotification()` → `{ success, error, info, warning }`.
- MUI Snackbar + Alert filled. Позиция: bottom-right (над FAB, mb:8).
- Добавлен в `App.tsx v2.3.0`.

**Подключение уведомлений:**
- `Sidebar v2.3.0`: success при сохранении дашборда, info при удалении.
- `DashboardOverviewPage v4.4.0`: success «Дашборд сохранён» при нажатии FAB.
- `DatasetsPage v1.2.0`: success при удалении датасета, error при ошибке.

**AgentBus — полное подключение (8 emit точек):**
- `FilterBar v1.4.0`: `dashboards.filter_change` при изменении любого фильтра.
- `DashboardOverviewPage v4.4.0`: `dashboards.metric_select` при смене метрики;
  `dashboards.save` при сохранении дашборда.
- `KpiAnalysisPage v2.1.0`: `kpi.metric_select` при смене метрики/периода.
- AgentConsole теперь показывает реальные события при работе с платформой.

**ToolsBoardPage v1.1.0:**
- Имена и описания модулей читаются из `t.modules.[id].name/description`.
- Перевод работает для всех 9 языков.

**AppLayout v1.4.0:**
- `PlatformVersionChip` — показывает `v{platform_version}` из `/api/platform/info`
  серым цветом перед чипом статуса backend.

**ModulesContext v1.1.0:**
- KPI модуль теперь в `trialModuleIds` по умолчанию — пользователь сразу видит
  KPI Analysis без необходимости нажимать «Попробовать».

**README.md v2.0.0** (полная переработка, 200+ строк):
- Quick Start, стек, структура репозитория, таблица диаграмм (15 типов).
- Таблица модулей + гайд «Добавить новый модуль».
- docker-compose full / standalone (примеры команд).
- Таблицы env переменных (backend + frontend).
- Раздел Development (запуск без docker).
- API эндпоинты список.
- AgentBus code examples.

Архив: sales-bi-platform_v0.16.0_stage16.zip
