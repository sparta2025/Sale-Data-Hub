# Sales BI Platform — Module Architecture Guide

## Версия: v0.15.0 | Этап: 15

---

## Концепция модульной системы

Платформа построена как **Tools Board** — витрина инструментов, каждый из которых
является самостоятельным модулем. Модуль можно:

- Включить/выключить через `VITE_ENABLED_MODULES` (frontend) и `ENABLED_MODULES` (backend)
- Развернуть отдельно через docker-compose профили
- Подключить как инструмент по подписке (free / pro / enterprise)
- Интегрировать с AI-агентами через AgentBus

---

## Как добавить новый модуль (например, «Анализ данных»)

### 1. Frontend — Манифест модуля

Создать файл `frontend/src/modules/analysis/manifest.ts`:

```typescript
import type { ModuleManifest } from "@/modules/types";

export const AnalysisModule: ModuleManifest = {
  id: "analysis",
  name: "Data Analysis",
  nameKey: "modules.analysis.name",
  version: "1.0.0",
  description: "Продвинутый анализ данных: корреляции, кластеризация, прогнозирование",
  descriptionKey: "modules.analysis.description",
  icon: "Analytics",           // MUI иконка
  color: "#0891b2",            // Акцентный цвет
  tier: "pro",                 // free | pro | enterprise
  routePrefix: "/analysis",
  navItems: [
    { label: "Анализ", path: "/analysis/:datasetId", icon: "Analytics", requiresDataset: true },
  ],
  tags: ["analysis", "statistics", "ml"],
  agentHooks: [
    {
      hookId: "analysis.result_ready",
      event: "on_drilldown",
      description: "Агент интерпретирует результат анализа"
    },
  ],
  toolsBoard: {
    featured: true,
    category: "analytics",
    screenshots: [],
    whatsnew: "v1.0.0: корреляции, кластеризация, PCA",
  },
};
```

### 2. Frontend — Регистрация в реестре

В `frontend/src/modules/registry.ts` добавить:

```typescript
import { AnalysisModule } from "./analysis/manifest";

export const ALL_MODULES: ModuleManifest[] = [
  DashboardsModule,
  KpiModule,
  AnalysisModule,   // ← добавить
  AgentsModule,
];
```

### 3. Frontend — Страница модуля

Создать `frontend/src/modules/analysis/AnalysisPage.tsx`:

```tsx
import { ModuleGuard } from "@/components/common/ModuleGuard";
import { AgentBus }    from "@/modules/agents/AgentBus";

function AnalysisContent() {
  // ... логика страницы
  
  // Интеграция с агентами
  AgentBus.emit("analysis.result_ready", "analysis", { result: "..." });
  
  return <Box>...</Box>;
}

export default function AnalysisPage() {
  return (
    <ModuleGuard moduleId="analysis">
      <AnalysisContent />
    </ModuleGuard>
  );
}
```

### 4. Frontend — Роут

В `frontend/src/routes/AppRoutes.tsx`:

```tsx
const AnalysisPage = lazy(() => import("@/modules/analysis/AnalysisPage"));

// Внутри <Routes>:
<Route path="/analysis/:datasetId" element={
  <Suspense fallback={<ModuleLoader />}><AnalysisPage /></Suspense>
} />
```

### 5. Frontend — Локали

В каждом locale файле добавить:

```typescript
modules: {
  // ... existing
  analysis: {
    name: "Анализ данных",
    description: "Продвинутый анализ: корреляции, кластеризация"
  }
}
```

### 6. Backend — Модуль (опционально)

Создать `backend/app/modules/analysis/`:

```
analysis/
├── __init__.py
├── service.py   — бизнес-логика (DuckDB запросы)
└── router.py    — FastAPI роутер
```

В `backend/app/api/router.py`:

```python
from app.modules.analysis.router import router as analysis_router
api_router.include_router(analysis_router, prefix="/analysis", tags=["analysis"])
```

В `backend/app/modules/platform_registry/router.py` — добавить в `ALL_BACKEND_MODULES`:

```python
ModuleInfo(id="analysis", name="Data Analysis", version="1.0.0",
           tier="pro", enabled=False, routes=["/api/analysis"]),
```

### 7. Docker-compose

Добавить profile если нужен standalone:

```yaml
frontend-analysis:
  profiles: ["analysis"]
  environment:
    VITE_ENABLED_MODULES: dashboards,kpi,analysis
    VITE_STANDALONE_MODE: "true"
```

---

## AgentBus — Интеграция агентов

### Публикация события из модуля:

```typescript
import { AgentBus } from "@/modules/agents/AgentBus";

AgentBus.emit("hookId", "moduleId", {
  datasetId, metric, result: "...",
});
```

### Подписка внешнего агента:

```typescript
const unsubscribe = AgentBus.subscribeAll((event) => {
  console.log(event.hookId, event.payload);
  // отправить на агент-сервер через WebSocket
});
```

### Последние события (для контекста агента):

```typescript
const log = AgentBus.getLog(20);
// → AgentEvent[]
```

---

## Структура каталогов

```
frontend/src/
├── modules/
│   ├── types.ts              — ModuleManifest, AgentHook, SubscriptionTier
│   ├── registry.ts           — ALL_MODULES, ENABLED_MODULES
│   ├── dashboards/
│   │   └── manifest.ts
│   ├── kpi/
│   │   ├── manifest.ts
│   │   ├── KpiAnalysisPage.tsx
│   │   ├── KpiTargetsContext.tsx
│   │   ├── hooks/
│   │   └── components/
│   ├── agents/
│   │   ├── manifest.ts
│   │   └── AgentBus.ts       — Singleton event bus
│   └── [your-module]/        ← сюда добавлять новые модули
│       ├── manifest.ts
│       ├── [ModulePage].tsx
│       └── ...
├── context/
│   ├── ModulesContext.tsx    — subscription + isModuleActive
│   └── ...
└── components/
    └── common/
        ├── ModuleGuard.tsx   — блокировка locked модулей
        └── AgentConsole.tsx  — UI для событий AgentBus
```

---

## Subscription Tiers

| Tier       | Модули                        |
|------------|-------------------------------|
| free       | dashboards, analytics         |
| pro        | + kpi, analysis               |
| enterprise | + agents, все будущие модули  |

Standalone mode (`VITE_STANDALONE_MODE=true`): все модули → enterprise.

---

## Environment Variables

| Variable               | Default | Описание                                |
|------------------------|---------|-----------------------------------------|
| VITE_ENABLED_MODULES   | (пусто) | Разрешённые модули через запятую        |
| VITE_STANDALONE_MODE   | false   | true = enterprise без ограничений       |
| VITE_AGENT_CONSOLE     | false   | true = показывать AgentConsole в PROD   |
| ENABLED_MODULES        | (пусто) | Backend: список модулей (через запятую) |
| STANDALONE_MODE        | false   | Backend: standalone mode flag           |
