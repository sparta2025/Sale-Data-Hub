# DATABASE REFERENCE — Sales BI Platform v1.3.0

## Подключение к PostgreSQL в Docker

### Быстрый вход (интерактивный psql)
```bash
# Войти в psql под пользователем приложения
docker exec -it bi_postgres psql -U bi_user -d bi_metadata

# Войти под postgres (суперпользователь)
docker exec -it bi_postgres psql -U postgres

# Выполнить одну команду без входа в интерактивный режим
docker exec -it bi_postgres psql -U bi_user -d bi_metadata -c "SELECT * FROM datasets"
```

### Запустить SQL-файл из хоста
```bash
# Скопировать файл внутрь контейнера и применить
docker cp scripts/init_schema.sql bi_postgres:/tmp/init_schema.sql
docker exec -it bi_postgres psql -U bi_user -d bi_metadata -f /tmp/init_schema.sql

# Или через pipe (если psql установлен на хосте)
psql -h localhost -p 5432 -U bi_user -d bi_metadata -f scripts/init_schema.sql
```

### Подключение с хоста (psql установлен локально)
```
Host:     localhost
Port:     5432
User:     bi_user
Password: bi_password
Database: bi_metadata

# Строка подключения:
postgresql://bi_user:bi_password@localhost:5432/bi_metadata
```

---

## Инициализация схемы с нуля

Если база пустая (новый сервер, managed PostgreSQL, облако) и Alembic недоступен:

```bash
# 1. Создать роль и БД (если их нет)
docker exec -it bi_postgres psql -U postgres -c "
  CREATE USER bi_user WITH PASSWORD 'bi_password' SUPERUSER;
  CREATE DATABASE bi_metadata OWNER bi_user;
"

# 2. Применить схему
docker cp scripts/init_schema.sql bi_postgres:/tmp/init_schema.sql
docker exec -it bi_postgres psql -U bi_user -d bi_metadata -f /tmp/init_schema.sql

# 3. Проверить
docker exec -it bi_postgres psql -U bi_user -d bi_metadata -c "\dt"
```

Если используется docker compose (стандартный путь):
```bash
# Alembic применяет миграции автоматически при каждом старте backend.
# Ничего делать не нужно — просто:
docker compose up --build
```

---

## Полезные команды psql внутри контейнера

```sql
-- Список таблиц
\dt

-- Структура таблицы
\d datasets
\d dimensions
\d metrics

-- Просмотр загруженных датасетов
SELECT id, name, row_count, column_count, status, created_at
FROM datasets ORDER BY created_at DESC;

-- Просмотр метаданных конкретного датасета
SELECT column_name, data_type, hierarchy_group, hierarchy_level
FROM dimensions WHERE dataset_id = '<uuid>' ORDER BY hierarchy_group, hierarchy_level;

SELECT column_name, data_type, aggregation, display_format
FROM metrics WHERE dataset_id = '<uuid>';

-- Проверить версию схемы
SELECT version_num FROM alembic_version;

-- Очистить все данные (каскадно удаляет dimensions и metrics)
TRUNCATE TABLE datasets CASCADE;

-- Удалить конкретный датасет (dimensions/metrics удалятся автоматически через CASCADE)
DELETE FROM datasets WHERE id = '<uuid>';

-- Выйти из psql
\q
```

---

## Структура схемы (краткая)

```
datasets          — реестр загруженных файлов (CSV/XLSX)
  └── dimensions  — измерения: Страна, Год, Месяц, Филиал...  (ON DELETE CASCADE)
  └── metrics     — метрики: Выручка, Прибыль, Маржа...       (ON DELETE CASCADE)

alembic_version   — текущая версия миграций (68f0e9eb15c8)
```

Аналитические данные (строки таблиц) хранятся **не в PostgreSQL**, а в DuckDB:
```bash
# Войти в контейнер backend и посмотреть DuckDB
docker exec -it bi_backend python3 -c "
import duckdb
conn = duckdb.connect('/data/duckdb/analytics.duckdb')
print(conn.execute(\"SHOW TABLES\").fetchall())
"

# Или интерактивно
docker exec -it bi_backend python3 -c "
import duckdb, os
conn = duckdb.connect('/data/duckdb/analytics.duckdb')
tables = conn.execute(\"SHOW TABLES\").fetchall()
for t in tables:
    cnt = conn.execute(f'SELECT COUNT(*) FROM \"{t[0]}\"').fetchone()[0]
    print(f'{t[0]}: {cnt} rows')
"
```
