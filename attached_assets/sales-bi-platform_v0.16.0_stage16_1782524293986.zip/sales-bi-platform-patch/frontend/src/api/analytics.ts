// VERSION: 1.0.0
// Path: frontend/src/api/analytics.ts
// CHANGES v1.0.0:
//   - Этап 12: analyticsApi.describe() → GET /api/analytics/{datasetId}/describe
import { apiClient } from "./client";

export interface ColumnStats {
  column_name: string;
  display_name: string;
  count: number;
  null_count: number;
  null_pct: number;
  min: number;
  max: number;
  mean: number;
  median: number;
  std: number;
  q1: number;
  q3: number;
  iqr: number;
  cv: number;
}

export interface DescribeResponse {
  dataset_id: string;
  columns: ColumnStats[];
}

export const analyticsApi = {
  describe: (datasetId: string) =>
    apiClient
      .get<DescribeResponse>(`/analytics/${datasetId}/describe`)
      .then((r) => r.data),
};
