// VERSION: 1.1.0
// Path: frontend/src/api/dashboards.ts
// CHANGES v1.0.0:
//   - Этап 7: типизированные функции для /api/dashboards
// CHANGES v1.1.0:
//   - Этап 8: добавлен опциональный filters: FilterMap во все методы данных
//     чартов (getKpi/getTimeseries/getCategory/getPie/getTreemap/getTable) —
//     сериализуется в JSON и передаётся как query-параметр filters, в паре
//     с backend-фиксом dashboard_engine/router.py v1.1.0
import { apiClient } from "./client";
import type {
  DashboardOut, DashboardCreate, DashboardUpdate,
  KpiCard, TimeseriesData, CategoryData, PieData, TreemapData, TableData,
  DrilldownRequest, DrilldownData, FilterMap,
} from "@/types";

/** undefined, если фильтров нет — чтобы не передавать пустой query-параметр зря. */
function serializeFilters(filters?: FilterMap): string | undefined {
  if (!filters || Object.keys(filters).length === 0) return undefined;
  return JSON.stringify(filters);
}

export const dashboardsApi = {
  create: async (datasetId: string, payload: DashboardCreate): Promise<DashboardOut> => {
    const { data } = await apiClient.post<DashboardOut>(`/dashboards/${datasetId}`, payload);
    return data;
  },

  listByDataset: async (datasetId: string): Promise<DashboardOut[]> => {
    const { data } = await apiClient.get<DashboardOut[]>(`/dashboards/${datasetId}`);
    return data;
  },

  get: async (dashboardId: string): Promise<DashboardOut> => {
    const { data } = await apiClient.get<DashboardOut>(`/dashboards/item/${dashboardId}`);
    return data;
  },

  update: async (dashboardId: string, payload: DashboardUpdate): Promise<DashboardOut> => {
    const { data } = await apiClient.put<DashboardOut>(`/dashboards/item/${dashboardId}`, payload);
    return data;
  },

  remove: async (dashboardId: string): Promise<void> => {
    await apiClient.delete(`/dashboards/item/${dashboardId}`);
  },

  getKpi: async (datasetId: string, metrics: string[], filters?: FilterMap): Promise<KpiCard[]> => {
    const { data } = await apiClient.get<KpiCard[]>(`/dashboards/${datasetId}/kpi`, {
      params: { metrics, filters: serializeFilters(filters) },
      paramsSerializer: { indexes: null },
    });
    return data;
  },

  getTimeseries: async (
    datasetId: string,
    params: {
      time_dimensions: string[]; metrics: string[]; chart_id?: string;
      title?: string; group_by?: string; limit?: number; filters?: FilterMap;
    },
  ): Promise<TimeseriesData> => {
    const { filters, ...rest } = params;
    const { data } = await apiClient.post<TimeseriesData>(
      `/dashboards/${datasetId}/chart/timeseries`, null,
      { params: { ...rest, filters: serializeFilters(filters) }, paramsSerializer: { indexes: null } },
    );
    return data;
  },

  getCategory: async (
    datasetId: string,
    params: {
      dimension: string; metrics: string[]; chart_id?: string; title?: string;
      limit?: number; filters?: FilterMap;
    },
  ): Promise<CategoryData> => {
    const { filters, ...rest } = params;
    const { data } = await apiClient.get<CategoryData>(
      `/dashboards/${datasetId}/chart/category`,
      { params: { ...rest, filters: serializeFilters(filters) }, paramsSerializer: { indexes: null } },
    );
    return data;
  },

  getPie: async (
    datasetId: string,
    params: {
      dimension: string; metric: string; chart_id?: string; title?: string;
      limit?: number; filters?: FilterMap;
    },
  ): Promise<PieData> => {
    const { filters, ...rest } = params;
    const { data } = await apiClient.get<PieData>(
      `/dashboards/${datasetId}/chart/pie`,
      { params: { ...rest, filters: serializeFilters(filters) } },
    );
    return data;
  },

  getTreemap: async (
    datasetId: string,
    params: {
      dimensions: string[]; metric: string; chart_id?: string; title?: string;
      filters?: FilterMap;
    },
  ): Promise<TreemapData> => {
    const { filters, ...rest } = params;
    const { data } = await apiClient.get<TreemapData>(
      `/dashboards/${datasetId}/chart/treemap`,
      { params: { ...rest, filters: serializeFilters(filters) }, paramsSerializer: { indexes: null } },
    );
    return data;
  },

  getTable: async (
    datasetId: string,
    params: {
      dimensions: string[]; metrics: string[]; chart_id?: string; title?: string;
      order_by?: string; order_desc?: boolean; limit?: number; filters?: FilterMap;
    },
  ): Promise<TableData> => {
    const { filters, ...rest } = params;
    const { data } = await apiClient.post<TableData>(
      `/dashboards/${datasetId}/chart/table`, null,
      { params: { ...rest, filters: serializeFilters(filters) }, paramsSerializer: { indexes: null } },
    );
    return data;
  },

  getDrilldown: async (datasetId: string, request: DrilldownRequest): Promise<DrilldownData> => {
    const { data } = await apiClient.post<DrilldownData>(
      `/dashboards/${datasetId}/drilldown`, request,
    );
    return data;
  },
};

export type { FilterMap };
