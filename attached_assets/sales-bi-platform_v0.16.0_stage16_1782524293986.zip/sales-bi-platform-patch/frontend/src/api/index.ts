// VERSION: 1.0.0
// Path: frontend/src/api/index.ts
// CHANGES v1.0.0:
//   - Этап 7: единая точка импорта всех API-сервисов
export { apiClient } from "./client";
export { datasetsApi } from "./datasets";
export { metadataApi } from "./metadata";
export { queryApi } from "./query";
export { dashboardsApi } from "./dashboards";
export { exportApi } from "./export";

export { analyticsApi } from './analytics';
export { kpiApi } from './kpi';
export { platformApi } from './platform';
