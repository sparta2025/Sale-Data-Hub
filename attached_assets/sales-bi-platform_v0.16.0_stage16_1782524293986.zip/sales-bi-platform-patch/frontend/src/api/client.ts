// VERSION: 1.2.0
// Path: frontend/src/api/client.ts
// CHANGES v1.0.0:
//   - Этап 1: axios-инстанс с baseURL='/api'
// CHANGES v1.1.0:
//   - Этап 7: response interceptor — нормализует ошибки FastAPI в человекочитаемый Error
// CHANGES v1.2.0:
//   - Этап 8: таймаут читается из VITE_API_TIMEOUT_MS (.env)
// CHANGES v1.1.0:
//   - Этап 7: response interceptor — нормализует ошибки FastAPI (detail) в Error
//     с человекочитаемым сообщением, чтобы хуки/компоненты не разбирали axios-формат вручную
import axios from "axios";

// Базовый URL — относительный путь "/api". В dev-режиме Vite проксирует его
// на backend (см. vite.config.ts), в проде nginx/Docker делает то же самое.
export const apiClient = axios.create({
  baseURL: "/api",
  timeout: Number(import.meta.env.VITE_API_TIMEOUT_MS ?? 60_000),
});

/**
 * FastAPI возвращает ошибки в виде { detail: "..." } (HTTPException) или
 * { detail: [{ msg, loc, ... }] } (ошибки валидации Pydantic, 422).
 * Приводим оба варианта к единому читаемому сообщению.
 */
function extractErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const detail = error.response?.data?.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) {
      return detail.map((d: { msg?: string }) => d.msg).filter(Boolean).join("; ") || "Ошибка валидации запроса";
    }
    if (error.code === "ECONNABORTED") return "Превышено время ожидания ответа сервера";
    if (!error.response) return "Не удалось связаться с сервером";
    return `Ошибка сервера (${error.response.status})`;
  }
  return "Неизвестная ошибка";
}

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = extractErrorMessage(error);
    return Promise.reject(new Error(message));
  },
);
