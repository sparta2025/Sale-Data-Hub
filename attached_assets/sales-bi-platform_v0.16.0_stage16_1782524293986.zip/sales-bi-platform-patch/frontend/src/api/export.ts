// VERSION: 1.0.0
// Path: frontend/src/api/export.ts
// CHANGES v1.0.0:
//   - Этап 7: функции экспорта — скачивание CSV/XLSX/PDF, URL для PNG-чартов
import { apiClient } from "./client";
import type { ExportRequest } from "@/types";

/**
 * Извлекает имя файла из заголовка Content-Disposition.
 * Бэкенд всегда возвращает 'attachment; filename="<name>"' (см. export/router.py).
 */
function filenameFromContentDisposition(header: string | undefined, fallback: string): string {
  if (!header) return fallback;
  const match = header.match(/filename="?([^"]+)"?/);
  return match ? match[1] : fallback;
}

/** Скачивает Blob как файл через временную ссылку <a download>. */
function triggerBrowserDownload(blob: Blob, filename: string): void {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

export const exportApi = {
  /** Запрашивает файл (CSV/XLSX/PDF) и сразу инициирует скачивание в браузере. */
  downloadTable: async (datasetId: string, request: ExportRequest): Promise<void> => {
    const response = await apiClient.post(`/export/${datasetId}/table`, request, {
      responseType: "blob",
    });
    const filename = filenameFromContentDisposition(
      response.headers["content-disposition"],
      `export.${request.format}`,
    );
    triggerBrowserDownload(response.data as Blob, filename);
  },

  /** Прямые URL для PNG-чартов — удобно подставлять в <img src=...>. */
  chartPngUrl: {
    category: (datasetId: string, dimension: string, metric: string, title = ""): string =>
      `/api/export/${datasetId}/chart/category.png?${new URLSearchParams({ dimension, metric, title })}`,

    pie: (datasetId: string, dimension: string, metric: string, title = ""): string =>
      `/api/export/${datasetId}/chart/pie.png?${new URLSearchParams({ dimension, metric, title })}`,

    timeseries: (
      datasetId: string,
      dimensions: string[],
      metrics: string[],
      groupBy?: string,
      title = "",
    ): string => {
      const params = new URLSearchParams({ title });
      dimensions.forEach((d) => params.append("dimensions", d));
      metrics.forEach((m) => params.append("metrics", m));
      if (groupBy) params.append("group_by", groupBy);
      return `/api/export/${datasetId}/chart/timeseries.png?${params}`;
    },
  },
};
