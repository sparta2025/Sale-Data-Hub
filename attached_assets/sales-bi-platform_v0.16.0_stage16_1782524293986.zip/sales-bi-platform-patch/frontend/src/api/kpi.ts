// VERSION: 1.0.0
// Path: frontend/src/api/kpi.ts
import { apiClient } from "./client";

export interface KpiMetricPeriod {
  column_name: string;
  display_name: string;
  display_format: string;
  value_a: number;
  value_b: number;
  delta_abs: number;
  delta_pct: number;
}

export interface KpiScorecardResponse {
  dataset_id: string;
  period_col: string;
  period_a: string;
  period_b: string;
  metrics: KpiMetricPeriod[];
}

export interface KpiCompareItem {
  label: string;
  value_a: number;
  value_b: number;
  delta_pct: number;
}

export interface KpiCompareResponse {
  dataset_id: string;
  dimension: string;
  metric: string;
  metric_display: string;
  period_a: string;
  period_b: string;
  items: KpiCompareItem[];
}

export const kpiApi = {
  scorecard: (
    datasetId: string,
    params: { period_col: string; period_a: string; period_b: string },
  ) =>
    apiClient
      .get<KpiScorecardResponse>(`/kpi/${datasetId}/scorecard`, { params })
      .then((r) => r.data),

  compare: (
    datasetId: string,
    params: {
      dimension: string;
      metric: string;
      period_col: string;
      period_a: string;
      period_b: string;
      limit?: number;
    },
  ) =>
    apiClient
      .get<KpiCompareResponse>(`/kpi/${datasetId}/compare`, { params })
      .then((r) => r.data),
};
