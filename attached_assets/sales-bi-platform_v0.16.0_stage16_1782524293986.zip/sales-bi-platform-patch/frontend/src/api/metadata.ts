// VERSION: 1.0.0
// Path: frontend/src/api/metadata.ts
// CHANGES v1.0.0:
//   - Этап 7: типизированные функции для /api/metadata
import { apiClient } from "./client";
import type {
  MetadataOverview, DimensionOut, DimensionPatch, MetricOut, MetricPatch,
} from "@/types";

export const metadataApi = {
  getOverview: async (datasetId: string): Promise<MetadataOverview> => {
    const { data } = await apiClient.get<MetadataOverview>(`/metadata/${datasetId}`);
    return data;
  },

  getDimensions: async (datasetId: string): Promise<DimensionOut[]> => {
    const { data } = await apiClient.get<DimensionOut[]>(`/metadata/${datasetId}/dimensions`);
    return data;
  },

  getMetrics: async (datasetId: string): Promise<MetricOut[]> => {
    const { data } = await apiClient.get<MetricOut[]>(`/metadata/${datasetId}/metrics`);
    return data;
  },

  refresh: async (datasetId: string): Promise<MetadataOverview> => {
    const { data } = await apiClient.post<MetadataOverview>(`/metadata/${datasetId}/refresh`);
    return data;
  },

  patchDimension: async (dimensionId: string, patch: DimensionPatch): Promise<DimensionOut> => {
    const { data } = await apiClient.patch<DimensionOut>(`/metadata/dimensions/${dimensionId}`, patch);
    return data;
  },

  patchMetric: async (metricId: string, patch: MetricPatch): Promise<MetricOut> => {
    const { data } = await apiClient.patch<MetricOut>(`/metadata/metrics/${metricId}`, patch);
    return data;
  },
};
