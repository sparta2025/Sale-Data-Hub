// VERSION: 1.0.0
// Path: frontend/src/api/datasets.ts
// CHANGES v1.0.0:
//   - Этап 7: типизированные функции для /api/datasets (зеркалирует backend router.py)
import { apiClient } from "./client";
import type { DatasetOut, ImportResponse, ColumnProfile, PreviewResponse } from "@/types";

export const datasetsApi = {
  upload: async (file: File): Promise<ImportResponse> => {
    const formData = new FormData();
    formData.append("file", file);
    const { data } = await apiClient.post<ImportResponse>("/datasets/upload", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return data;
  },

  list: async (): Promise<DatasetOut[]> => {
    const { data } = await apiClient.get<DatasetOut[]>("/datasets");
    return data;
  },

  get: async (datasetId: string): Promise<DatasetOut> => {
    const { data } = await apiClient.get<DatasetOut>(`/datasets/${datasetId}`);
    return data;
  },

  getColumns: async (datasetId: string): Promise<ColumnProfile[]> => {
    const { data } = await apiClient.get<ColumnProfile[]>(`/datasets/${datasetId}/columns`);
    return data;
  },

  getPreview: async (datasetId: string, limit = 50): Promise<PreviewResponse> => {
    const { data } = await apiClient.get<PreviewResponse>(`/datasets/${datasetId}/preview`, {
      params: { limit },
    });
    return data;
  },

  remove: async (datasetId: string): Promise<void> => {
    await apiClient.delete(`/datasets/${datasetId}`);
  },
};
