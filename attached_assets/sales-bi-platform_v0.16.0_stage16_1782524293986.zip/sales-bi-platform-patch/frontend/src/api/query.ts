// VERSION: 1.1.0
// Path: frontend/src/api/query.ts
// CHANGES v1.0.0:
//   - Этап 7: типизированные функции для /api/query
// CHANGES v1.1.0:
//   - Этап 8 фикс: getDistinctValues принимает filters?: FilterMap —
//     сериализуется в JSON query-параметр, чтобы backend возвращал только
//     значения, актуальные при текущих активных фильтрах (каскад)
import { apiClient } from "./client";
import type { QueryRequest, QueryResult, AggregatedValue, FilterMap } from "@/types";

function serializeFilters(filters?: FilterMap): string | undefined {
  if (!filters || Object.keys(filters).length === 0) return undefined;
  return JSON.stringify(filters);
}

export const queryApi = {
  run: async (datasetId: string, request: QueryRequest): Promise<QueryResult> => {
    const { data } = await apiClient.post<QueryResult>(`/query/${datasetId}`, request);
    return data;
  },

  getKpiTotals: async (datasetId: string, metrics: string[]): Promise<AggregatedValue[]> => {
    const { data } = await apiClient.get<AggregatedValue[]>(`/query/${datasetId}/kpi`, {
      params: { metrics },
      paramsSerializer: { indexes: null },
    });
    return data;
  },

  getDistinctValues: async (
    datasetId: string,
    columnName: string,
    limit = 200,
    filters?: FilterMap,
  ): Promise<unknown[]> => {
    const { data } = await apiClient.get<unknown[]>(
      `/query/${datasetId}/distinct/${encodeURIComponent(columnName)}`,
      { params: { limit, filters: serializeFilters(filters) } },
    );
    return data;
  },
};
