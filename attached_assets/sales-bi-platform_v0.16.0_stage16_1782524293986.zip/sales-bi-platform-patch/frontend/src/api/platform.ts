// VERSION: 1.0.0
// Path: frontend/src/api/platform.ts
import { apiClient } from "./client";

export interface BackendModuleInfo {
  id: string; name: string; version: string;
  tier: string; enabled: boolean; routes: string[];
}

export interface PlatformInfo {
  platform_name: string; platform_version: string;
  api_version: string; started_at: string;
  enabled_modules: BackendModuleInfo[];
  standalone_mode: boolean;
}

export const platformApi = {
  info:    () => apiClient.get<PlatformInfo>("/platform/info").then((r) => r.data),
  modules: () => apiClient.get<BackendModuleInfo[]>("/platform/modules").then((r) => r.data),
};
