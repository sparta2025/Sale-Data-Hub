// VERSION: 1.0.0
// Path: frontend/src/context/ThemeContext.tsx
// CHANGES v1.0.0:
//   - Новый: контекст темы (light/dark/neutral). Тема сохраняется в localStorage.
//     Добавление новой темы: добавить ключ в ThemeMode + createTheme в THEMES.
import {
  createContext, useContext, useState, useCallback, type ReactNode,
} from "react";
import { createTheme, type Theme } from "@mui/material/styles";

export type ThemeMode = "light" | "dark" | "neutral";

const LS_KEY = "bi_theme";
const DEFAULT_THEME: ThemeMode = "light";

const BASE_FONT = '"Inter", "Roboto", "Helvetica", "Arial", sans-serif';
const PRIMARY = "#2563eb";

export const THEMES: Record<ThemeMode, Theme> = {
  light: createTheme({
    palette: {
      mode: "light",
      primary: { main: PRIMARY },
      secondary: { main: "#7c3aed" },
      background: { default: "#f5f7fa", paper: "#ffffff" },
    },
    typography: { fontFamily: BASE_FONT },
    shape: { borderRadius: 8 },
  }),

  dark: createTheme({
    palette: {
      mode: "dark",
      primary: { main: "#60a5fa" },
      secondary: { main: "#a78bfa" },
      background: { default: "#0f172a", paper: "#1e293b" },
      text: { primary: "#f1f5f9", secondary: "#94a3b8" },
      divider: "#334155",
    },
    typography: { fontFamily: BASE_FONT },
    shape: { borderRadius: 8 },
  }),

  neutral: createTheme({
    palette: {
      mode: "light",
      primary: { main: "#475569" },
      secondary: { main: "#64748b" },
      background: { default: "#f1f5f9", paper: "#f8fafc" },
      text: { primary: "#1e293b", secondary: "#64748b" },
      divider: "#e2e8f0",
    },
    typography: { fontFamily: BASE_FONT },
    shape: { borderRadius: 6 },
    components: {
      MuiPaper: { styleOverrides: { root: { backgroundImage: "none" } } },
    },
  }),
};

export const THEME_LABELS: Record<ThemeMode, string> = {
  light: "Светлая",
  dark: "Тёмная",
  neutral: "Нейтральная",
};

interface ThemeContextValue {
  mode: ThemeMode;
  theme: Theme;
  setMode: (mode: ThemeMode) => void;
}

const ThemeCtx = createContext<ThemeContextValue | null>(null);

export function AppThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ThemeMode>(
    () => (localStorage.getItem(LS_KEY) as ThemeMode | null) ?? DEFAULT_THEME,
  );

  const setMode = useCallback((m: ThemeMode) => {
    setModeState(m);
    localStorage.setItem(LS_KEY, m);
  }, []);

  return (
    <ThemeCtx.Provider value={{ mode, theme: THEMES[mode], setMode }}>
      {children}
    </ThemeCtx.Provider>
  );
}

export function useAppTheme() {
  const ctx = useContext(ThemeCtx);
  if (!ctx) throw new Error("useAppTheme must be used within AppThemeProvider");
  return ctx;
}
