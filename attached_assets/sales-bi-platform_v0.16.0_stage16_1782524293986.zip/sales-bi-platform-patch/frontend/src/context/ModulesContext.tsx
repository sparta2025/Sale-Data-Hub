// VERSION: 1.1.0
// Path: frontend/src/context/ModulesContext.tsx
// CHANGES v1.0.0:
//   - Этап 13: контекст модулей и подписки.
// CHANGES v1.1.0:
//   - Этап 16: KPI в trialModuleIds по умолчанию (демонстрация без upgrade)
//     isModuleActive(id) — модуль включён в подписку И доступен в env.
//     isModuleLocked(id) — модуль существует, но требует upgrade.
//     startTrial(id) — 14-дневный trial (localStorage, без бэкенда).
//     Standalone mode: все разрешённые модули считаются active.
import {
  createContext, useContext, useState, useCallback, type ReactNode,
} from "react";
import type { UserSubscription, ModuleManifest, SubscriptionTier } from "@/modules/types";
import { ALL_MODULES, isModuleEnabled, getModule } from "@/modules/registry";

const LS_KEY = "bi_subscription";
const STANDALONE = import.meta.env.VITE_STANDALONE_MODE === "true";

const TIER_RANK: Record<SubscriptionTier, number> = { free: 0, pro: 1, enterprise: 2 };

function loadSubscription(): UserSubscription {
  if (STANDALONE) {
    return {
      tier: "enterprise",
      activeModuleIds: ALL_MODULES.map((m) => m.id),
      trialModuleIds: [],
      isStandaloneMode: true,
    };
  }
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  // Default: free tier, dashboards enabled
  return {
    tier: "free",
    activeModuleIds: ["dashboards"],
    trialModuleIds: ["kpi"],  // KPI в trial по умолчанию для демонстрации
    isStandaloneMode: false,
  };
}

function saveSubscription(s: UserSubscription) {
  localStorage.setItem(LS_KEY, JSON.stringify(s));
}

interface ModulesContextValue {
  subscription: UserSubscription;
  modules: ModuleManifest[];           // все enabled в этом развёртывании
  isModuleActive:  (id: string) => boolean;
  isModuleLocked:  (id: string) => boolean;
  isModuleTrial:   (id: string) => boolean;
  startTrial:      (id: string) => void;
  upgradeTier:     (tier: SubscriptionTier) => void; // demo — без платёжки
  getModule:       (id: string) => ModuleManifest | undefined;
}

const Ctx = createContext<ModulesContextValue | null>(null);

export function ModulesProvider({ children }: { children: ReactNode }) {
  const [sub, setSub] = useState<UserSubscription>(loadSubscription);

  const modules = ALL_MODULES.filter((m) => isModuleEnabled(m.id));

  const isModuleActive = useCallback((id: string) => {
    if (STANDALONE) return isModuleEnabled(id);
    const manifest = getModule(id);
    if (!manifest) return false;
    if (!isModuleEnabled(id)) return false;
    const tierOk = TIER_RANK[sub.tier] >= TIER_RANK[manifest.tier];
    const explicit = sub.activeModuleIds.includes(id) || sub.trialModuleIds.includes(id);
    return tierOk || explicit;
  }, [sub]);

  const isModuleLocked = useCallback((id: string) => {
    const manifest = getModule(id);
    if (!manifest) return false;
    return TIER_RANK[sub.tier] < TIER_RANK[manifest.tier] &&
      !sub.activeModuleIds.includes(id) &&
      !sub.trialModuleIds.includes(id);
  }, [sub]);

  const isModuleTrial = useCallback((id: string) => {
    return sub.trialModuleIds.includes(id);
  }, [sub]);

  const startTrial = useCallback((id: string) => {
    setSub((prev) => {
      const next = {
        ...prev,
        trialModuleIds: [...new Set([...prev.trialModuleIds, id])],
      };
      saveSubscription(next);
      return next;
    });
  }, []);

  const upgradeTier = useCallback((tier: SubscriptionTier) => {
    setSub((prev) => {
      const next = { ...prev, tier };
      saveSubscription(next);
      return next;
    });
  }, []);

  return (
    <Ctx.Provider value={{
      subscription: sub,
      modules,
      isModuleActive,
      isModuleLocked,
      isModuleTrial,
      startTrial,
      upgradeTier,
      getModule,
    }}>
      {children}
    </Ctx.Provider>
  );
}

export function useModules() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useModules must be used within ModulesProvider");
  return ctx;
}
