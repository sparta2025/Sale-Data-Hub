// VERSION: 1.0.0
// Path: frontend/src/context/NotificationContext.tsx
// CHANGES v1.0.0:
//   - Этап 16: глобальная система уведомлений (Snackbar/toast).
//     useNotification() — хук для показа success/error/info/warning.
//     notify.success("Сохранено") / notify.error("Ошибка") / notify.info(...)
//     Очередь уведомлений — одновременно одно, следующее после закрытия.
import {
  createContext, useContext, useState, useCallback,
  type ReactNode,
} from "react";
import { Snackbar, Alert, type AlertColor } from "@mui/material";

interface NotifItem {
  id: number;
  message: string;
  severity: AlertColor;
  duration?: number;
}

interface NotifCtxValue {
  notify: {
    success: (msg: string, duration?: number) => void;
    error:   (msg: string, duration?: number) => void;
    info:    (msg: string, duration?: number) => void;
    warning: (msg: string, duration?: number) => void;
  };
}

const Ctx = createContext<NotifCtxValue | null>(null);
let _id = 0;

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [queue, setQueue] = useState<NotifItem[]>([]);

  const push = useCallback((message: string, severity: AlertColor, duration = 3500) => {
    setQueue((prev) => [...prev, { id: ++_id, message, severity, duration }]);
  }, []);

  const notify = {
    success: (msg: string, d?: number) => push(msg, "success", d),
    error:   (msg: string, d?: number) => push(msg, "error",   d ?? 5000),
    info:    (msg: string, d?: number) => push(msg, "info",    d),
    warning: (msg: string, d?: number) => push(msg, "warning", d),
  };

  const current = queue[0];

  const handleClose = useCallback((_: unknown, reason?: string) => {
    if (reason === "clickaway") return;
    setQueue((prev) => prev.slice(1));
  }, []);

  return (
    <Ctx.Provider value={{ notify }}>
      {children}
      <Snackbar
        open={Boolean(current)}
        autoHideDuration={current?.duration ?? 3500}
        onClose={handleClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        sx={{ mb: 8 }}
      >
        <Alert
          onClose={handleClose}
          severity={current?.severity ?? "info"}
          variant="filled"
          sx={{ minWidth: 260 }}
          elevation={6}
        >
          {current?.message ?? ""}
        </Alert>
      </Snackbar>
    </Ctx.Provider>
  );
}

export function useNotification() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useNotification must be within NotificationProvider");
  return ctx.notify;
}
