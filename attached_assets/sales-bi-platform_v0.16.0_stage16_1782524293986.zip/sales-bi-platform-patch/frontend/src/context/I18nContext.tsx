// VERSION: 1.0.0
// Path: frontend/src/context/I18nContext.tsx
// CHANGES v1.0.0:
//   - Новый: лёгкий i18n-контекст без внешних зависимостей.
//     useTranslation() возвращает объект t с переводами текущего языка.
//     Язык сохраняется в localStorage. RTL (арабский) — автоматически
//     устанавливает dir="rtl" на <html>. Компонент LanguageSelector встроен.
import {
  createContext, useContext, useState, useEffect, useCallback,
  type ReactNode,
} from "react";
import { LOCALES, LOCALE_LABELS, RTL_LOCALES, type LocaleCode, type Translation } from "@/locales";

interface I18nContextValue {
  locale: LocaleCode;
  t: Translation;
  setLocale: (code: LocaleCode) => void;
  isRtl: boolean;
  availableLocales: { code: LocaleCode; label: string }[];
}

const I18nContext = createContext<I18nContextValue | null>(null);

const LS_KEY = "bi_locale";
const DEFAULT_LOCALE: LocaleCode = "ru";

function detectLocale(): LocaleCode {
  const stored = localStorage.getItem(LS_KEY) as LocaleCode | null;
  if (stored && stored in LOCALES) return stored;
  const browser = navigator.language.slice(0, 2) as LocaleCode;
  if (browser in LOCALES) return browser;
  return DEFAULT_LOCALE;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<LocaleCode>(detectLocale);

  const setLocale = useCallback((code: LocaleCode) => {
    setLocaleState(code);
    localStorage.setItem(LS_KEY, code);
  }, []);

  // Направление текста для арабского
  useEffect(() => {
    const isRtl = RTL_LOCALES.has(locale);
    document.documentElement.setAttribute("dir", isRtl ? "rtl" : "ltr");
    document.documentElement.setAttribute("lang", locale);
  }, [locale]);

  const t = LOCALES[locale];
  const isRtl = RTL_LOCALES.has(locale);
  const availableLocales = Object.entries(LOCALE_LABELS).map(([code, label]) => ({
    code: code as LocaleCode,
    label,
  }));

  return (
    <I18nContext.Provider value={{ locale, t, setLocale, isRtl, availableLocales }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useTranslation() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useTranslation must be used within I18nProvider");
  return ctx;
}
