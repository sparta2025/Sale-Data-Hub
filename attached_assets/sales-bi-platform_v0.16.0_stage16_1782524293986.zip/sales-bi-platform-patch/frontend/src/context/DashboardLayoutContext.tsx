// VERSION: 1.3.0
// Path: frontend/src/context/DashboardLayoutContext.tsx
// CHANGES v1.0.0:
//   - Этап 9.1: visibleCharts + layouts + toggleChart/showAll
// CHANGES v1.1.0:
//   - Этап 10: добавлен primaryMetric state для сохранения дашборда;
//     restoreSnapshot() восстанавливает visibleCharts + layouts из сохранённого.
import {
  createContext, useContext, useState, useCallback, type ReactNode,
} from "react";

export interface ChartMeta {
  id: string;
  nameKey: string;
  description: string;
  defaultW: number;
  defaultH: number;
}

export const ALL_CHARTS: ChartMeta[] = [
  { id: "line",      nameKey: "line",      description: "Динамика метрики по времени, разбивка по категориям", defaultW: 12, defaultH: 5 },
  { id: "bar",       nameKey: "bar",       description: "Столбчатый — сравнение категорий, drill-down",         defaultW: 6,  defaultH: 5 },
  { id: "pie",       nameKey: "pie",       description: "Доля каждой категории в общем объёме",                 defaultW: 6,  defaultH: 5 },
  { id: "treemap",   nameKey: "treemap",   description: "Иерархия двух уровней (группа → подгруппа)",          defaultW: 6,  defaultH: 5 },
  { id: "heatmap",   nameKey: "heatmap",   description: "Год × месяц, плотность значений",                     defaultW: 6,  defaultH: 5 },
  { id: "waterfall", nameKey: "waterfall", description: "Вклад каждой категории в итоговое значение",          defaultW: 12, defaultH: 5 },
  { id: "map",       nameKey: "map",       description: "Карта филиалов с drill-down по товарным группам",      defaultW: 6,  defaultH: 7 },
  { id: "table",     nameKey: "table",     description: "Сводная таблица с сортировкой и экспортом",            defaultW: 6,  defaultH: 7 },
  { id: "scatter",   nameKey: "scatter",   description: "Точечная: зависимость двух числовых метрик",           defaultW: 6,  defaultH: 5 },
  { id: "histogram", nameKey: "histogram", description: "Распределение значений метрики по бинам",              defaultW: 6,  defaultH: 5 },
  { id: "boxplot",   nameKey: "boxplot",   description: "Ящик с усами — распределение по подкатегориям",       defaultW: 6,  defaultH: 5 },
  { id: "radar",     nameKey: "radar",     description: "Радарная — сравнение по нескольким метрикам (≥2)",     defaultW: 6,  defaultH: 5 },
  { id: "gauge",     nameKey: "gauge",     description: "Спидометр — KPI как % от максимального значения",      defaultW: 4,  defaultH: 5 },
  { id: "funnel",    nameKey: "funnel",    description: "Воронка — доля Top-N категорий (страны, группы)",       defaultW: 6,  defaultH: 6 },
  { id: "statsummary", nameKey: "statsummary", description: "Статистическая сводка: min/max/mean/median/Q1/Q3/std",  defaultW: 12, defaultH: 6 },
];

const DEFAULT_VISIBLE = new Set(["line", "bar", "pie", "treemap", "heatmap", "waterfall", "map", "table"]);
const LS_VISIBLE  = "bi_visible_charts";
const LS_LAYOUTS  = "bi_chart_layouts";

function loadVisible(): Set<string> {
  try { const raw = localStorage.getItem(LS_VISIBLE); if (raw) return new Set(JSON.parse(raw)); } catch { /* ignore */ }
  return new Set(DEFAULT_VISIBLE);
}
function loadLayouts(): Record<string, unknown[]> {
  try { const raw = localStorage.getItem(LS_LAYOUTS); if (raw) return JSON.parse(raw); } catch { /* ignore */ }
  return {};
}

interface DashboardSnapshot {
  visibleCharts: string[];
  layouts: Record<string, unknown[]>;
  primaryMetric?: string;
}

interface DashboardLayoutContextValue {
  visibleCharts: Set<string>;
  toggleChart: (id: string) => void;
  showAll: () => void;
  layouts: Record<string, unknown[]>;
  setLayouts: (l: Record<string, unknown[]>) => void;
  primaryMetric: string;
  setPrimaryMetric: (m: string) => void;
  getSnapshot: () => DashboardSnapshot;
  restoreSnapshot: (snap: DashboardSnapshot) => void;
}

const Ctx = createContext<DashboardLayoutContextValue | null>(null);

export function DashboardLayoutProvider({ children }: { children: ReactNode }) {
  const [visibleCharts, setVisibleCharts] = useState<Set<string>>(loadVisible);
  const [layouts,       setLayoutsState]  = useState<Record<string, unknown[]>>(loadLayouts);
  const [primaryMetric, setPrimaryMetric] = useState<string>("");

  const toggleChart = useCallback((id: string) => {
    setVisibleCharts((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      localStorage.setItem(LS_VISIBLE, JSON.stringify([...next]));
      return next;
    });
  }, []);

  const showAll = useCallback(() => {
    const all = new Set(ALL_CHARTS.map((c) => c.id));
    setVisibleCharts(all);
    localStorage.setItem(LS_VISIBLE, JSON.stringify([...all]));
  }, []);

  const setLayouts = useCallback((l: Record<string, unknown[]>) => {
    setLayoutsState(l);
    localStorage.setItem(LS_LAYOUTS, JSON.stringify(l));
  }, []);

  const getSnapshot = useCallback((): DashboardSnapshot => ({
    visibleCharts: [...visibleCharts],
    layouts,
    primaryMetric,
  }), [visibleCharts, layouts, primaryMetric]);

  const restoreSnapshot = useCallback((snap: DashboardSnapshot) => {
    const next = new Set(snap.visibleCharts);
    setVisibleCharts(next);
    localStorage.setItem(LS_VISIBLE, JSON.stringify(snap.visibleCharts));
    setLayoutsState(snap.layouts);
    localStorage.setItem(LS_LAYOUTS, JSON.stringify(snap.layouts));
    if (snap.primaryMetric) setPrimaryMetric(snap.primaryMetric);
  }, []);

  return (
    <Ctx.Provider value={{
      visibleCharts, toggleChart, showAll,
      layouts, setLayouts,
      primaryMetric, setPrimaryMetric,
      getSnapshot, restoreSnapshot,
    }}>
      {children}
    </Ctx.Provider>
  );
}

export function useDashboardLayout() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useDashboardLayout must be used within DashboardLayoutProvider");
  return ctx;
}
