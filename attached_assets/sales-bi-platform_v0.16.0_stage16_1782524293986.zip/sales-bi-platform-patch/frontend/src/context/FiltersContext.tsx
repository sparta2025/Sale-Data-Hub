// VERSION: 1.0.0
// Path: frontend/src/context/FiltersContext.tsx
// CHANGES v1.0.0:
//   - Этап 7: глобальный контекст фильтров — выбранный датасет + карта активных
//     фильтров (FilterMap), используется панелью фильтров и всеми страницами с чартами
import {
  createContext, useContext, useMemo, useState, useCallback, type ReactNode,
} from "react";
import type { FilterSpec, FilterMap } from "@/types";

interface FiltersContextValue {
  /** Текущий выбранный датасет (null, если ничего не выбрано). */
  datasetId: string | null;
  setDatasetId: (id: string | null) => void;

  /** Активные фильтры: имя_колонки -> FilterSpec. */
  filters: FilterMap;
  /** Установить/заменить фильтр по одной колонке. */
  setFilter: (columnName: string, filter: FilterSpec) => void;
  /** Убрать фильтр по одной колонке. */
  removeFilter: (columnName: string) => void;
  /** Сбросить все фильтры (датасет остаётся выбранным). */
  clearFilters: () => void;
  /** Сколько фильтров сейчас активно — удобно для бейджа в UI. */
  activeFilterCount: number;
}

const FiltersContext = createContext<FiltersContextValue | undefined>(undefined);

export function FiltersProvider({ children }: { children: ReactNode }) {
  const [datasetId, setDatasetIdState] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterMap>({});

  // Смена датасета сбрасывает фильтры — фильтр по колонке одного датасета
  // не имеет смысла для другого (разные имена колонок/значения).
  const setDatasetId = useCallback((id: string | null) => {
    setDatasetIdState(id);
    setFilters({});
  }, []);

  const setFilter = useCallback((columnName: string, filter: FilterSpec) => {
    setFilters((prev) => ({ ...prev, [columnName]: filter }));
  }, []);

  const removeFilter = useCallback((columnName: string) => {
    setFilters((prev) => {
      const next = { ...prev };
      delete next[columnName];
      return next;
    });
  }, []);

  const clearFilters = useCallback(() => setFilters({}), []);

  const value = useMemo<FiltersContextValue>(
    () => ({
      datasetId,
      setDatasetId,
      filters,
      setFilter,
      removeFilter,
      clearFilters,
      activeFilterCount: Object.keys(filters).length,
    }),
    [datasetId, setDatasetId, filters, setFilter, removeFilter, clearFilters],
  );

  return <FiltersContext.Provider value={value}>{children}</FiltersContext.Provider>;
}

export function useFilters(): FiltersContextValue {
  const ctx = useContext(FiltersContext);
  if (!ctx) {
    throw new Error("useFilters должен использоваться внутри <FiltersProvider>");
  }
  return ctx;
}
