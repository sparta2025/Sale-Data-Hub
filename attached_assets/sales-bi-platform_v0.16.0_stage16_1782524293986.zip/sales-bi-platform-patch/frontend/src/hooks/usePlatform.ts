// VERSION: 1.0.0
// Path: frontend/src/hooks/usePlatform.ts
// CHANGES v1.0.0:
//   - Этап 15: usePlatformInfo() — загружает /api/platform/info при старте.
//     Используется ModulesContext для синхронизации активных модулей с backend.
import { useQuery } from "@tanstack/react-query";
import { platformApi } from "@/api/platform";

export function usePlatformInfo() {
  return useQuery({
    queryKey: ["platform", "info"],
    queryFn: platformApi.info,
    staleTime: 5 * 60 * 1000,
    retry: 2,
  });
}

export function usePlatformModules() {
  return useQuery({
    queryKey: ["platform", "modules"],
    queryFn: platformApi.modules,
    staleTime: 5 * 60 * 1000,
    retry: 2,
  });
}
