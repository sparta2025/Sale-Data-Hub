// VERSION: 1.1.0
// Path: frontend/src/hooks/useQueryEngine.ts
// CHANGES v1.0.0:
//   - Этап 7: react-query хуки поверх queryApi (выполнение запросов, KPI, distinct values)
// CHANGES v1.1.0:
//   - Этап 8 фикс: useDistinctValues читает filters из useFilters() и передаёт
//     в getDistinctValues БЕЗ текущей колонки — каскадная фильтрация:
//     при выбранной Страна=Германия дропдаун Филиал покажет только филиалы
//     Германии, а не все 9 филиалов датасета. Убран staleTime — значения
//     должны реактивно меняться при изменении любого фильтра.
import { useQuery } from "@tanstack/react-query";
import { queryApi } from "@/api";
import { useFilters } from "@/context/FiltersContext";
import type { QueryRequest, FilterMap } from "@/types";

export const queryEngineKeys = {
  all: ["query-engine"] as const,
  run: (datasetId: string, request: QueryRequest) =>
    [...queryEngineKeys.all, "run", datasetId, request] as const,
  kpi: (datasetId: string, metrics: string[]) =>
    [...queryEngineKeys.all, "kpi", datasetId, metrics] as const,
  distinct: (datasetId: string, column: string, filters: FilterMap) =>
    [...queryEngineKeys.all, "distinct", datasetId, column, filters] as const,
};

export function useRunQuery(datasetId: string | undefined, request: QueryRequest, enabled = true) {
  return useQuery({
    queryKey: queryEngineKeys.run(datasetId ?? "", request),
    queryFn: () => queryApi.run(datasetId as string, request),
    enabled: Boolean(datasetId) && enabled && (request.dimensions.length > 0 || request.metrics.length > 0),
  });
}

export function useKpiTotals(datasetId: string | undefined, metrics: string[]) {
  return useQuery({
    queryKey: queryEngineKeys.kpi(datasetId ?? "", metrics),
    queryFn: () => queryApi.getKpiTotals(datasetId as string, metrics),
    enabled: Boolean(datasetId) && metrics.length > 0,
  });
}

/**
 * Уникальные значения измерения для FilterBar.
 *
 * Ключевое: передаём активные фильтры БЕЗ текущей колонки columnName.
 * Это даёт каскадный эффект — Филиал видит фильтр по Стране, но не по себе:
 *   - Страна=Германия → Филиал: [Берлин, Гамбург, Мюнхен]  ✓
 *   - Если бы передавали Филиал=Берлин → Филиал: [Берлин] только  ✗
 *
 * queryKey включает effectiveFilters — react-query сам инвалидирует кэш
 * при смене любого фильтра, без дополнительного staleTime.
 */
export function useDistinctValues(datasetId: string | undefined, columnName: string | undefined) {
  const { filters } = useFilters();

  // Фильтры для этого дропдауна = все активные фильтры кроме самой этой колонки
  const effectiveFilters: FilterMap = Object.fromEntries(
    Object.entries(filters).filter(([key]) => key !== columnName),
  );

  return useQuery({
    queryKey: queryEngineKeys.distinct(datasetId ?? "", columnName ?? "", effectiveFilters),
    queryFn: () =>
      queryApi.getDistinctValues(datasetId as string, columnName as string, 200, effectiveFilters),
    enabled: Boolean(datasetId) && Boolean(columnName),
    // staleTime намеренно убран — значения должны обновляться при смене фильтров
  });
}
