// VERSION: 1.0.0
// Path: frontend/src/hooks/useAnalytics.ts
// CHANGES v1.0.0:
//   - Этап 12: useDescribe(datasetId) — react-query хук для /analytics/describe.
//     Кэширует 5 минут — статистика меняется только при перезагрузке датасета.
import { useQuery } from "@tanstack/react-query";
import { analyticsApi } from "@/api/analytics";

export const analyticsKeys = {
  describe: (datasetId: string) => ["analytics", "describe", datasetId] as const,
};

export function useDescribe(datasetId: string | null | undefined) {
  return useQuery({
    queryKey: analyticsKeys.describe(datasetId ?? ""),
    queryFn: () => analyticsApi.describe(datasetId as string),
    enabled: Boolean(datasetId),
    staleTime: 5 * 60 * 1000, // 5 минут
  });
}
