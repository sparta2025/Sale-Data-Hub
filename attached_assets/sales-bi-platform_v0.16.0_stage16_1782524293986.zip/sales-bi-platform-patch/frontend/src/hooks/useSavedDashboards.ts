// VERSION: 1.0.0
// Path: frontend/src/hooks/useSavedDashboards.ts
// CHANGES v1.0.0:
//   - Этап 10: localStorage-based сохранение/загрузка конфигураций дашборда.
//     Каждый сохранённый дашборд содержит: id, имя (авто = датасет + дата),
//     datasetId, datasetName, primaryMetric, visibleCharts, filters, layouts.
//     save() — текущее состояние → в список. load() — восстановить состояние.
//     deleteById() — удалить. Реактивный — useState + useCallback.
import { useState, useCallback } from "react";
import type { FilterMap } from "@/types";

export interface SavedDashboardEntry {
  id: string;
  name: string;
  datasetId: string;
  datasetName: string;
  createdAt: string;        // ISO string
  primaryMetric: string;
  visibleCharts: string[];
  filters: FilterMap;
  layouts: Record<string, unknown[]>;
}

const LS_KEY = "bi_saved_dashboards";

function load(): SavedDashboardEntry[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw) as SavedDashboardEntry[];
  } catch { /* ignore */ }
  return [];
}

function persist(list: SavedDashboardEntry[]) {
  localStorage.setItem(LS_KEY, JSON.stringify(list));
}

export function useSavedDashboards() {
  const [list, setList] = useState<SavedDashboardEntry[]>(load);

  const save = useCallback((entry: Omit<SavedDashboardEntry, "id" | "createdAt">) => {
    const newEntry: SavedDashboardEntry = {
      ...entry,
      id: `dash_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setList((prev) => {
      const next = [newEntry, ...prev].slice(0, 20); // максимум 20 сохранений
      persist(next);
      return next;
    });
    return newEntry;
  }, []);

  const deleteById = useCallback((id: string) => {
    setList((prev) => {
      const next = prev.filter((e) => e.id !== id);
      persist(next);
      return next;
    });
  }, []);

  const rename = useCallback((id: string, name: string) => {
    setList((prev) => {
      const next = prev.map((e) => e.id === id ? { ...e, name } : e);
      persist(next);
      return next;
    });
  }, []);

  return { list, save, deleteById, rename };
}
