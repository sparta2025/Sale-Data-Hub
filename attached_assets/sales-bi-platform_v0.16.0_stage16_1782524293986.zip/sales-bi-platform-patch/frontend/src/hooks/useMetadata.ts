// VERSION: 1.0.0
// Path: frontend/src/hooks/useMetadata.ts
// CHANGES v1.0.0:
//   - Этап 7: react-query хуки поверх metadataApi
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { metadataApi } from "@/api";
import type { DimensionPatch, MetricPatch } from "@/types";

export const metadataKeys = {
  all: ["metadata"] as const,
  overview: (datasetId: string) => [...metadataKeys.all, "overview", datasetId] as const,
};

export function useMetadataOverview(datasetId: string | undefined) {
  return useQuery({
    queryKey: metadataKeys.overview(datasetId ?? ""),
    queryFn: () => metadataApi.getOverview(datasetId as string),
    enabled: Boolean(datasetId),
  });
}

export function useRefreshMetadata(datasetId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => metadataApi.refresh(datasetId as string),
    onSuccess: () => {
      if (datasetId) {
        queryClient.invalidateQueries({ queryKey: metadataKeys.overview(datasetId) });
      }
    },
  });
}

export function usePatchDimension(datasetId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ dimensionId, patch }: { dimensionId: string; patch: DimensionPatch }) =>
      metadataApi.patchDimension(dimensionId, patch),
    onSuccess: () => {
      if (datasetId) {
        queryClient.invalidateQueries({ queryKey: metadataKeys.overview(datasetId) });
      }
    },
  });
}

export function usePatchMetric(datasetId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ metricId, patch }: { metricId: string; patch: MetricPatch }) =>
      metadataApi.patchMetric(metricId, patch),
    onSuccess: () => {
      if (datasetId) {
        queryClient.invalidateQueries({ queryKey: metadataKeys.overview(datasetId) });
      }
    },
  });
}
