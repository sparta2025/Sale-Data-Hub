// VERSION: 1.0.0
// Path: frontend/src/hooks/useChartTheme.ts
// CHANGES v1.0.0:
//   - Этап 10: хук useChartTheme() — возвращает тема-зависимые цвета для ECharts
//     (цвета осей, сетки, тултипов, фона). Реагирует на AppThemeProvider.
//     Использовать в каждом ChartCard: const ct = useChartTheme();
//     затем передавать ct.axisColor, ct.splitLineColor и т.д. в option.
import { useAppTheme } from "@/context/ThemeContext";

export interface ChartThemeVars {
  /** ECharts theme name для prop theme= */
  echartsTheme: "dark" | undefined;
  axisColor: string;
  axisLineColor: string;
  splitLineColor: string;
  tooltipBg: string;
  tooltipBorder: string;
  tooltipTextColor: string;
  labelColor: string;
  /** Прозрачный фон — Paper даёт нужный цвет */
  bgColor: "transparent";
}

const LIGHT: ChartThemeVars = {
  echartsTheme:    undefined,
  axisColor:       "#64748b",
  axisLineColor:   "#e2e8f0",
  splitLineColor:  "#f1f5f9",
  tooltipBg:       "#ffffff",
  tooltipBorder:   "#e2e8f0",
  tooltipTextColor:"#1e293b",
  labelColor:      "#64748b",
  bgColor:         "transparent",
};

const DARK: ChartThemeVars = {
  echartsTheme:    "dark",
  axisColor:       "#94a3b8",
  axisLineColor:   "#334155",
  splitLineColor:  "#1e293b",
  tooltipBg:       "#1e293b",
  tooltipBorder:   "#334155",
  tooltipTextColor:"#f1f5f9",
  labelColor:      "#94a3b8",
  bgColor:         "transparent",
};

const NEUTRAL: ChartThemeVars = {
  echartsTheme:    undefined,
  axisColor:       "#64748b",
  axisLineColor:   "#e2e8f0",
  splitLineColor:  "#f1f5f9",
  tooltipBg:       "#f8fafc",
  tooltipBorder:   "#e2e8f0",
  tooltipTextColor:"#1e293b",
  labelColor:      "#64748b",
  bgColor:         "transparent",
};

const THEME_MAP = { light: LIGHT, dark: DARK, neutral: NEUTRAL };

export function useChartTheme(): ChartThemeVars {
  const { mode } = useAppTheme();
  return THEME_MAP[mode];
}
