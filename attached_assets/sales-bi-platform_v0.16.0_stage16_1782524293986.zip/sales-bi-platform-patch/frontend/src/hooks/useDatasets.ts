// VERSION: 1.0.0
// Path: frontend/src/hooks/useDatasets.ts
// CHANGES v1.0.0:
//   - Этап 7: react-query хуки поверх datasetsApi (кэширование, инвалидация)
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { datasetsApi } from "@/api";

export const datasetsKeys = {
  all: ["datasets"] as const,
  list: () => [...datasetsKeys.all, "list"] as const,
  detail: (id: string) => [...datasetsKeys.all, "detail", id] as const,
  columns: (id: string) => [...datasetsKeys.all, "columns", id] as const,
  preview: (id: string, limit: number) => [...datasetsKeys.all, "preview", id, limit] as const,
};

export function useDatasets() {
  return useQuery({
    queryKey: datasetsKeys.list(),
    queryFn: datasetsApi.list,
  });
}

export function useDataset(datasetId: string | undefined) {
  return useQuery({
    queryKey: datasetsKeys.detail(datasetId ?? ""),
    queryFn: () => datasetsApi.get(datasetId as string),
    enabled: Boolean(datasetId),
  });
}

export function useDatasetColumns(datasetId: string | undefined) {
  return useQuery({
    queryKey: datasetsKeys.columns(datasetId ?? ""),
    queryFn: () => datasetsApi.getColumns(datasetId as string),
    enabled: Boolean(datasetId),
  });
}

export function useDatasetPreview(datasetId: string | undefined, limit = 50) {
  return useQuery({
    queryKey: datasetsKeys.preview(datasetId ?? "", limit),
    queryFn: () => datasetsApi.getPreview(datasetId as string, limit),
    enabled: Boolean(datasetId),
  });
}

export function useUploadDataset() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (file: File) => datasetsApi.upload(file),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: datasetsKeys.list() });
    },
  });
}

export function useDeleteDataset() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (datasetId: string) => datasetsApi.remove(datasetId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: datasetsKeys.list() });
    },
  });
}
