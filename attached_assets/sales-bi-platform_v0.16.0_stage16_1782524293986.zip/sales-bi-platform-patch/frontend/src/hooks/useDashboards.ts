// VERSION: 1.0.0
// Path: frontend/src/hooks/useDashboards.ts
// CHANGES v1.0.0:
//   - Этап 7: react-query хуки поверх dashboardsApi (CRUD + данные чартов)
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { dashboardsApi } from "@/api";
import type { DashboardCreate, DashboardUpdate } from "@/types";

export const dashboardsKeys = {
  all: ["dashboards"] as const,
  list: (datasetId: string) => [...dashboardsKeys.all, "list", datasetId] as const,
  detail: (dashboardId: string) => [...dashboardsKeys.all, "detail", dashboardId] as const,
};

export function useDashboardsList(datasetId: string | undefined) {
  return useQuery({
    queryKey: dashboardsKeys.list(datasetId ?? ""),
    queryFn: () => dashboardsApi.listByDataset(datasetId as string),
    enabled: Boolean(datasetId),
  });
}

export function useDashboard(dashboardId: string | undefined) {
  return useQuery({
    queryKey: dashboardsKeys.detail(dashboardId ?? ""),
    queryFn: () => dashboardsApi.get(dashboardId as string),
    enabled: Boolean(dashboardId),
  });
}

export function useCreateDashboard(datasetId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: DashboardCreate) => dashboardsApi.create(datasetId as string, payload),
    onSuccess: () => {
      if (datasetId) {
        queryClient.invalidateQueries({ queryKey: dashboardsKeys.list(datasetId) });
      }
    },
  });
}

export function useUpdateDashboard(datasetId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ dashboardId, payload }: { dashboardId: string; payload: DashboardUpdate }) =>
      dashboardsApi.update(dashboardId, payload),
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: dashboardsKeys.detail(variables.dashboardId) });
      if (datasetId) {
        queryClient.invalidateQueries({ queryKey: dashboardsKeys.list(datasetId) });
      }
    },
  });
}

export function useDeleteDashboard(datasetId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (dashboardId: string) => dashboardsApi.remove(dashboardId),
    onSuccess: () => {
      if (datasetId) {
        queryClient.invalidateQueries({ queryKey: dashboardsKeys.list(datasetId) });
      }
    },
  });
}
