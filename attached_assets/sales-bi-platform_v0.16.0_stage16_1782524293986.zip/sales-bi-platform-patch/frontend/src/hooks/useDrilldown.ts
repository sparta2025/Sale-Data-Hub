// VERSION: 1.0.0
// Path: frontend/src/hooks/useDrilldown.ts
// CHANGES v1.0.0:
//   - Этап 9: хук drill-down — управляет стеком уровней иерархии (push/pop),
//     запрашивает данные через dashboardsApi.getDrilldown с учётом активных
//     фильтров из FiltersContext
import { useState, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { dashboardsApi } from "@/api";
import { useFilters } from "@/context/FiltersContext";
import type { DrilldownRequest, DrilldownData, MetricOut } from "@/types";

export interface DrilldownLevel {
  hierarchyGroup: string;
  level: number;
  parentValue: string | null;
  metricColumn: string;
  metricMeta: MetricOut;
}

export interface UseDrilldownReturn {
  /** Текущий активный уровень (null = закрыто) */
  current: DrilldownLevel | null;
  /** Открыть drill-down по клику на элемент чарта */
  open: (level: DrilldownLevel) => void;
  /** Закрыть / вернуться */
  close: () => void;
  /** Данные следующего уровня */
  data: DrilldownData | undefined;
  isLoading: boolean;
  error: Error | null;
}

export function useDrilldown(datasetId: string | undefined): UseDrilldownReturn {
  const [current, setCurrent] = useState<DrilldownLevel | null>(null);
  const { filters } = useFilters();

  const open = useCallback((level: DrilldownLevel) => {
    setCurrent(level);
  }, []);

  const close = useCallback(() => {
    setCurrent(null);
  }, []);

  const req: DrilldownRequest | null = current
    ? {
        hierarchy_group: current.hierarchyGroup,
        current_level: current.level,
        parent_value: current.parentValue,
        metrics: [current.metricColumn],
        extra_filters: filters,
      }
    : null;

  const { data, isLoading, error } = useQuery({
    queryKey: ["drilldown", datasetId, req],
    queryFn: () => dashboardsApi.getDrilldown(datasetId as string, req as DrilldownRequest),
    enabled: Boolean(datasetId) && Boolean(req),
  });

  return {
    current,
    open,
    close,
    data,
    isLoading,
    error: error as Error | null,
  };
}
