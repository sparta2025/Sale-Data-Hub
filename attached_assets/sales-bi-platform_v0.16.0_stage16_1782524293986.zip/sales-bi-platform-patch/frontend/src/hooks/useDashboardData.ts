// VERSION: 1.0.0
// Path: frontend/src/hooks/useDashboardData.ts
// CHANGES v1.0.0:
//   - Этап 8: хуки данных чартов (KPI/timeseries/category/pie/treemap/table) —
//     обёртка над dashboardsApi, автоматически подключённая к useFilters()
//     (datasetId + активные фильтры), чтобы страницам не нужно было
//     прокидывать их вручную в каждый компонент чарта
import { useQuery } from "@tanstack/react-query";
import { dashboardsApi, queryApi } from "@/api";
import { useFilters } from "@/context/FiltersContext";
import type { FilterMap } from "@/types";

const chartKeys = {
  all: ["chart-data"] as const,
  kpi: (datasetId: string, metrics: string[], filters: FilterMap) =>
    [...chartKeys.all, "kpi", datasetId, metrics, filters] as const,
  timeseries: (datasetId: string, params: unknown) =>
    [...chartKeys.all, "timeseries", datasetId, params] as const,
  category: (datasetId: string, params: unknown) =>
    [...chartKeys.all, "category", datasetId, params] as const,
  pie: (datasetId: string, params: unknown) =>
    [...chartKeys.all, "pie", datasetId, params] as const,
  treemap: (datasetId: string, params: unknown) =>
    [...chartKeys.all, "treemap", datasetId, params] as const,
  table: (datasetId: string, params: unknown) =>
    [...chartKeys.all, "table", datasetId, params] as const,
};

export function useKpi(metrics: string[]) {
  const { datasetId, filters } = useFilters();
  return useQuery({
    queryKey: chartKeys.kpi(datasetId ?? "", metrics, filters),
    queryFn: () => dashboardsApi.getKpi(datasetId as string, metrics, filters),
    enabled: Boolean(datasetId) && metrics.length > 0,
  });
}

export function useTimeseriesChart(params: {
  time_dimensions: string[]; metrics: string[]; chart_id?: string;
  title?: string; group_by?: string; limit?: number; enabled?: boolean;
}) {
  const { datasetId, filters } = useFilters();
  const { enabled = true, ...rest } = params;
  return useQuery({
    queryKey: chartKeys.timeseries(datasetId ?? "", { ...rest, filters }),
    queryFn: () => dashboardsApi.getTimeseries(datasetId as string, { ...rest, filters }),
    enabled: Boolean(datasetId) && enabled && rest.time_dimensions.length > 0 && rest.metrics.length > 0,
  });
}

export function useCategoryChart(params: {
  dimension: string; metrics: string[]; chart_id?: string; title?: string;
  limit?: number; enabled?: boolean;
}) {
  const { datasetId, filters } = useFilters();
  const { enabled = true, ...rest } = params;
  return useQuery({
    queryKey: chartKeys.category(datasetId ?? "", { ...rest, filters }),
    queryFn: () => dashboardsApi.getCategory(datasetId as string, { ...rest, filters }),
    enabled: Boolean(datasetId) && enabled && Boolean(rest.dimension) && rest.metrics.length > 0,
  });
}

export function usePieChart(params: {
  dimension: string; metric: string; chart_id?: string; title?: string;
  limit?: number; enabled?: boolean;
}) {
  const { datasetId, filters } = useFilters();
  const { enabled = true, ...rest } = params;
  return useQuery({
    queryKey: chartKeys.pie(datasetId ?? "", { ...rest, filters }),
    queryFn: () => dashboardsApi.getPie(datasetId as string, { ...rest, filters }),
    enabled: Boolean(datasetId) && enabled && Boolean(rest.dimension) && Boolean(rest.metric),
  });
}

export function useTreemapChart(params: {
  dimensions: string[]; metric: string; chart_id?: string; title?: string; enabled?: boolean;
}) {
  const { datasetId, filters } = useFilters();
  const { enabled = true, ...rest } = params;
  return useQuery({
    queryKey: chartKeys.treemap(datasetId ?? "", { ...rest, filters }),
    queryFn: () => dashboardsApi.getTreemap(datasetId as string, { ...rest, filters }),
    enabled: Boolean(datasetId) && enabled && rest.dimensions.length > 0 && Boolean(rest.metric),
  });
}

export function useTableChart(params: {
  dimensions: string[]; metrics: string[]; chart_id?: string; title?: string;
  order_by?: string; order_desc?: boolean; limit?: number; enabled?: boolean;
}) {
  const { datasetId, filters } = useFilters();
  const { enabled = true, ...rest } = params;
  return useQuery({
    queryKey: chartKeys.table(datasetId ?? "", { ...rest, filters }),
    queryFn: () => dashboardsApi.getTable(datasetId as string, { ...rest, filters }),
    enabled: Boolean(datasetId) && enabled && (rest.dimensions.length > 0 || rest.metrics.length > 0),
  });
}

/**
 * Данные для heatmap (например Год × Месяц). Отдельного backend-эндпоинта
 * нет — переиспользуем Query Engine напрямую (POST /api/query/{id}),
 * объединяя dimensions=[rowDim, colDim] с активными фильтрами контекста.
 */
export function useHeatmapData(rowDim: string, colDim: string, metric: string, enabled = true) {
  const { datasetId, filters } = useFilters();
  return useQuery({
    queryKey: ["chart-data", "heatmap", datasetId ?? "", rowDim, colDim, metric, filters] as const,
    queryFn: () =>
      queryApi.run(datasetId as string, {
        dimensions: [rowDim, colDim],
        metrics: [metric],
        filters,
        limit: 5000,
      }),
    enabled: Boolean(datasetId) && enabled && Boolean(rowDim) && Boolean(colDim) && Boolean(metric),
  });
}
