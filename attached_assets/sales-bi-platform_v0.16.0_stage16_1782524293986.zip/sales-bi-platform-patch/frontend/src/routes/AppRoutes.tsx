// VERSION: 2.0.0
// Path: frontend/src/routes/AppRoutes.tsx
// CHANGES v1.0.0:
//   - Этап 7: базовое дерево маршрутов
// CHANGES v2.0.0:
//   - Этап 13: модульная маршрутизация.
//     /tools — Tools Board (витрина модулей)
//     /kpi/:datasetId — KPI Analysis module
//     Маршруты загружаются lazy для оптимизации бандла.
import { lazy, Suspense } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { CircularProgress, Box } from "@mui/material";
import { AppLayout } from "@/components/layout/AppLayout";
import DatasetsPage from "@/pages/DatasetsPage";
import DatasetDetailPage from "@/pages/DatasetDetailPage";
import DashboardOverviewPage from "@/pages/DashboardOverviewPage";
import DashboardsListPage from "@/pages/DashboardsListPage";
import DashboardViewPage from "@/pages/DashboardViewPage";
import NotFoundPage from "@/pages/NotFoundPage";
import { StatusPage } from "@/pages/StatusPage";

// Модульные страницы — lazy load
const ToolsBoardPage  = lazy(() => import("@/pages/ToolsBoardPage"));
const KpiAnalysisPage = lazy(() => import("@/modules/kpi/KpiAnalysisPage"));

function ModuleLoader() {
  return (
    <Box display="flex" justifyContent="center" alignItems="center" height={300}>
      <CircularProgress />
    </Box>
  );
}

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        {/* Редирект с корня на Tools Board */}
        <Route path="/" element={<Navigate to="/tools" replace />} />

        {/* Tools Board — витрина модулей */}
        <Route path="/tools" element={
          <Suspense fallback={<ModuleLoader />}><ToolsBoardPage /></Suspense>
        } />

        {/* Dashboards module */}
        <Route path="/datasets" element={<DatasetsPage />} />
        <Route path="/datasets/:datasetId" element={<DatasetDetailPage />} />
        <Route path="/datasets/:datasetId/overview" element={<DashboardOverviewPage />} />
        <Route path="/datasets/:datasetId/dashboards" element={<DashboardsListPage />} />
        <Route path="/datasets/:datasetId/dashboards/:dashboardId" element={<DashboardViewPage />} />

        {/* KPI Analysis module */}
        <Route path="/kpi/:datasetId" element={
          <Suspense fallback={<ModuleLoader />}><KpiAnalysisPage /></Suspense>
        } />

        {/* Утилиты */}
        <Route path="/status" element={<StatusPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
