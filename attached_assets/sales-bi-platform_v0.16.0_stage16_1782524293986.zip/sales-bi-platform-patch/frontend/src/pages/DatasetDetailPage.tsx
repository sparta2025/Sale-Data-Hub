// VERSION: 1.1.0
// Path: frontend/src/pages/DatasetDetailPage.tsx
// CHANGES v1.0.0:
//   - Этап 7: превью данных + метаданные + кнопка дашборда
// CHANGES v1.1.0:
//   - Этап 11: i18n через useTranslation().t.pages.datasetDetail
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Box, Typography, Tabs, Tab, CircularProgress, Alert, Button, Stack,
  Breadcrumbs, Link as MuiLink,
} from "@mui/material";
import DashboardIcon from "@mui/icons-material/Dashboard";
import RefreshIcon from "@mui/icons-material/Refresh";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import { useDataset, useDatasetPreview } from "@/hooks/useDatasets";
import { useMetadataOverview, useRefreshMetadata } from "@/hooks/useMetadata";
import { useFilters } from "@/context/FiltersContext";
import { useTranslation } from "@/context/I18nContext";
import { DimensionsTable } from "@/components/datasets/DimensionsTable";
import { MetricsTable } from "@/components/datasets/MetricsTable";

export default function DatasetDetailPage() {
  const { datasetId } = useParams<{ datasetId: string }>();
  const navigate = useNavigate();
  const { setDatasetId } = useFilters();
  const { t } = useTranslation();
  const [tab, setTab] = useState<"preview" | "metadata">("preview");

  useEffect(() => {
    if (datasetId) setDatasetId(datasetId);
  }, [datasetId, setDatasetId]);

  const { data: dataset, isLoading: datasetLoading, error: datasetError } = useDataset(datasetId);
  const { data: preview, isLoading: previewLoading } = useDatasetPreview(datasetId, 100);
  const { data: metadata, isLoading: metadataLoading } = useMetadataOverview(datasetId);
  const refreshMetadata = useRefreshMetadata(datasetId);

  if (datasetLoading) return <CircularProgress />;
  if (datasetError) return <Alert severity="error">{datasetError.message}</Alert>;
  if (!dataset) return null;

  const columns: GridColDef[] = (preview?.columns ?? []).map((col) => ({
    field: col, headerName: col, flex: 1, minWidth: 140,
  }));
  const rows = (preview?.rows ?? []).map((row, idx) => ({ id: idx, ...row }));

  return (
    <Box>
      <Breadcrumbs sx={{ mb: 1 }}>
        <MuiLink component="button" underline="hover" onClick={() => navigate("/datasets")}>
          {t.nav.datasets}
        </MuiLink>
        <Typography color="text.primary">{dataset.name}</Typography>
      </Breadcrumbs>

      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <Box>
          <Typography variant="h5" fontWeight={700}>{dataset.name}</Typography>
          <Typography variant="body2" color="text.secondary">
            {dataset.original_filename} · {dataset.row_count.toLocaleString("ru-RU")} {t.pages.datasetDetail.rows} ·{" "}
            {dataset.column_count} {t.pages.datasetDetail.columns}
          </Typography>
        </Box>
        <Stack direction="row" gap={1}>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={() => refreshMetadata.mutate()}
            disabled={refreshMetadata.isPending}
          >
            {t.pages.datasetDetail.refreshMeta}
          </Button>
          <Button
            variant="contained"
            startIcon={<DashboardIcon />}
            onClick={() => navigate(`/datasets/${dataset.id}/overview`)}
          >
            {t.pages.datasetDetail.openDashboard}
          </Button>
        </Stack>
      </Stack>

      <Tabs value={tab} onChange={(_e, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab label={t.pages.datasetDetail.previewTab} value="preview" />
        <Tab label={t.pages.datasetDetail.metadataTab} value="metadata" />
      </Tabs>

      {tab === "preview" && (
        <Box>
          {previewLoading && <CircularProgress />}
          {!previewLoading && (
            <DataGrid
              rows={rows}
              columns={columns}
              initialState={{ pagination: { paginationModel: { pageSize: 25 } } }}
              pageSizeOptions={[10, 25, 50]}
              disableRowSelectionOnClick
              density="compact"
              autoHeight
              sx={{ "& .MuiDataGrid-cell": { fontSize: "0.8rem" } }}
            />
          )}
        </Box>
      )}

      {tab === "metadata" && (
        <Box>
          {metadataLoading && <CircularProgress />}
          {!metadataLoading && metadata && (
            <Stack gap={3}>
              <DimensionsTable dimensions={metadata.dimensions} datasetId={datasetId!} />
              <MetricsTable metrics={metadata.metrics} datasetId={datasetId!} />
            </Stack>
          )}
        </Box>
      )}
    </Box>
  );
}
