// VERSION: 1.0.0
// Path: frontend/src/pages/StatusPage.tsx
// CHANGES v1.0.0:
//   - Этап 1: техническая страница статуса frontend/backend/Postgres
//     (заменится полноценной главной страницей в Этапе 8)
import { useEffect, useState } from "react";
import { Box, Chip, Stack, Typography } from "@mui/material";
import { apiClient } from "@/api/client";

type HealthResponse = {
  status: string;
  postgres: string;
};

// Это техническая заглушка для Этапа 1: подтверждает, что frontend и backend
// связаны друг с другом. Полноценная главная страница с KPI и графиками —
// Этап 8.
export function StatusPage() {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiClient
      .get<HealthResponse>("/health")
      .then((res) => setHealth(res.data))
      .catch(() => setError("Backend недоступен"));
  }, []);

  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom>
        Sales BI Platform
      </Typography>
      <Typography variant="body1" color="text.secondary" gutterBottom>
        Этап 1: каркас проекта. Главная страница с KPI и дашбордами появится в Этапе 8.
      </Typography>
      <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
        <Chip label="Frontend: OK" color="success" />
        <Chip
          label={
            error
              ? "Backend: недоступен"
              : health
                ? `Backend: ${health.status}`
                : "Backend: проверка..."
          }
          color={error ? "error" : health ? "success" : "default"}
        />
        {health && (
          <Chip
            label={`Postgres: ${health.postgres}`}
            color={health.postgres === "connected" ? "success" : "warning"}
          />
        )}
      </Stack>
    </Box>
  );
}
