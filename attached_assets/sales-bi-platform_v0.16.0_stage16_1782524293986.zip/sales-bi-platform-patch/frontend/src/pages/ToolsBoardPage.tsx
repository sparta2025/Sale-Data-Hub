// VERSION: 1.1.0
// Path: frontend/src/pages/ToolsBoardPage.tsx
// CHANGES v1.0.0:
//   - Этап 13: Tools Board — витрина модулей платформы.
//     Каждый модуль — карточка с иконкой, описанием, версией, статусом.
//     Кнопки: «Открыть» / «Попробовать» / «Pro план» / «Скоро».
//     Tier-бейджи: free/pro/enterprise. Trial кнопка — 14 дней.
import { useNavigate } from "react-router-dom";
import {
  Box, Typography, Grid, Paper, Stack, Chip, Button, Divider, Alert,
} from "@mui/material";
import DashboardIcon from "@mui/icons-material/Dashboard";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import SmartToyIcon from "@mui/icons-material/SmartToy";
import LockIcon from "@mui/icons-material/Lock";
import RocketLaunchIcon from "@mui/icons-material/RocketLaunch";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import { useModules } from "@/context/ModulesContext";
import { useTranslation } from "@/context/I18nContext";
import { useFilters } from "@/context/FiltersContext";
import type { ModuleManifest } from "@/modules/types";

const ICONS: Record<string, React.ElementType> = {
  Dashboard: DashboardIcon,
  TrendingUp: TrendingUpIcon,
  SmartToy: SmartToyIcon,
};

const TIER_COLORS: Record<string, string> = {
  free: "#22c55e",
  pro: "#7c3aed",
  enterprise: "#f59e0b",
};

const TIER_LABELS: Record<string, string> = {
  free: "Бесплатно",
  pro: "Pro",
  enterprise: "Enterprise",
};

function ModuleCard({ manifest }: { manifest: ModuleManifest }) {
  const navigate     = useNavigate();
  const { datasetId } = useFilters();
  const { isModuleActive, isModuleLocked, isModuleTrial, startTrial } = useModules();
  const { t } = useTranslation();
  const moduleT = (t as Record<string, Record<string, Record<string, string>>>)?.modules?.[manifest.id];
  const localName = moduleT?.name ?? manifest.name;
  const localDesc = moduleT?.description ?? manifest.description;

  const active  = isModuleActive(manifest.id);
  const locked  = isModuleLocked(manifest.id);
  const trial   = isModuleTrial(manifest.id);
  const IconCmp = ICONS[manifest.icon] ?? DashboardIcon;

  const handleOpen = () => {
    if (manifest.id === "dashboards") {
      navigate(datasetId ? `/datasets/${datasetId}/overview` : "/datasets");
    } else if (manifest.id === "kpi") {
      navigate(datasetId ? `/kpi/${datasetId}` : "/datasets");
    }
  };

  return (
    <Paper
      variant="outlined"
      sx={{
        p: 2.5,
        height: "100%",
        display: "flex",
        flexDirection: "column",
        borderColor: active ? manifest.color : "divider",
        borderWidth: active ? 2 : 1,
        position: "relative",
        overflow: "hidden",
        transition: "border-color 0.2s, box-shadow 0.2s",
        "&:hover": { boxShadow: 3 },
      }}
    >
      {/* Цветная полоска сверху */}
      <Box sx={{ position: "absolute", top: 0, left: 0, right: 0, height: 4, backgroundColor: manifest.color }} />

      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" mt={0.5}>
        <Box
          sx={{
            width: 44, height: 44, borderRadius: 2,
            backgroundColor: `${manifest.color}18`,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <IconCmp sx={{ color: manifest.color, fontSize: 24 }} />
        </Box>
        <Stack direction="row" gap={0.5} alignItems="center">
          <Chip
            label={TIER_LABELS[manifest.tier]}
            size="small"
            sx={{ backgroundColor: `${TIER_COLORS[manifest.tier]}18`, color: TIER_COLORS[manifest.tier], fontWeight: 700, fontSize: "0.65rem" }}
          />
          {active && <CheckCircleIcon sx={{ fontSize: 18, color: "#22c55e" }} />}
          {locked && <LockIcon sx={{ fontSize: 18, color: "#94a3b8" }} />}
        </Stack>
      </Stack>

      <Box sx={{ flex: 1, mt: 1.5 }}>
        <Stack direction="row" alignItems="center" gap={0.75} mb={0.5}>
          <Typography variant="subtitle1" fontWeight={700}>{localName}</Typography>
          <Chip label={`v${manifest.version}`} size="small" sx={{ height: 16, fontSize: "0.6rem", backgroundColor: "action.hover" }} />
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5, fontSize: "0.82rem" }}>
          {localDesc}
        </Typography>

        <Stack direction="row" flexWrap="wrap" gap={0.5} mb={1.5}>
          {manifest.tags.map((tag) => (
            <Chip key={tag} label={tag} size="small"
              sx={{ height: 18, fontSize: "0.62rem", backgroundColor: "action.selected" }} />
          ))}
        </Stack>

        {manifest.agentHooks.length > 0 && (
          <Typography variant="caption" color="text.disabled" display="block" mb={1}>
            🤖 {manifest.agentHooks.length} точек интеграции агентов
          </Typography>
        )}
      </Box>

      <Divider sx={{ my: 1.5 }} />

      {manifest.toolsBoard.whatsnew && (
        <Typography variant="caption" color="text.secondary" display="block" mb={1.5} sx={{ fontSize: "0.72rem" }}>
          ✨ {manifest.toolsBoard.whatsnew}
        </Typography>
      )}

      {/* Кнопки действий */}
      {active && (
        <Button variant="contained" fullWidth onClick={handleOpen}
          sx={{ backgroundColor: manifest.color, "&:hover": { backgroundColor: manifest.color, opacity: 0.9 } }}>
          Открыть
        </Button>
      )}
      {!active && !locked && (
        <Button variant="outlined" fullWidth onClick={handleOpen}
          sx={{ borderColor: manifest.color, color: manifest.color }}>
          Открыть
        </Button>
      )}
      {locked && !trial && manifest.id !== "agents" && (
        <Button variant="outlined" fullWidth startIcon={<RocketLaunchIcon />}
          onClick={() => startTrial(manifest.id)}
          sx={{ borderColor: manifest.color, color: manifest.color }}>
          Попробовать 14 дней
        </Button>
      )}
      {trial && !active && (
        <Stack gap={0.5}>
          <Chip label="Trial активен" size="small" sx={{ backgroundColor: "#f59e0b22", color: "#f59e0b" }} />
          <Button variant="contained" fullWidth onClick={handleOpen}
            sx={{ backgroundColor: manifest.color }}>
            Открыть (Trial)
          </Button>
        </Stack>
      )}
      {manifest.id === "agents" && (
        <Button variant="outlined" disabled fullWidth>Скоро</Button>
      )}
    </Paper>
  );
}

export default function ToolsBoardPage() {
  const { modules, subscription } = useModules();

  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight={700}>Tools Board</Typography>
          <Typography variant="body2" color="text.secondary">
            Доступные инструменты платформы Sales BI
          </Typography>
        </Box>
        <Chip
          label={`Подписка: ${subscription.tier.toUpperCase()}${subscription.isStandaloneMode ? " (Standalone)" : ""}`}
          sx={{
            backgroundColor: `${TIER_COLORS[subscription.tier]}18`,
            color: TIER_COLORS[subscription.tier],
            fontWeight: 700,
          }}
        />
      </Stack>

      {subscription.isStandaloneMode && (
        <Alert severity="success" sx={{ mb: 3 }}>
          Standalone режим — все модули активны без ограничений подписки.
        </Alert>
      )}

      <Grid container spacing={3}>
        {modules.map((manifest) => (
          <Grid item xs={12} sm={6} md={4} key={manifest.id}>
            <ModuleCard manifest={manifest} />
          </Grid>
        ))}
      </Grid>

      <Box mt={4} p={2} sx={{ border: "1px dashed", borderColor: "divider", borderRadius: 2 }}>
        <Typography variant="subtitle2" color="text.secondary" mb={0.5}>
          🔌 Архитектура модулей
        </Typography>
        <Typography variant="caption" color="text.disabled">
          Каждый инструмент — самостоятельный модуль с манифестом, роутами и точками интеграции агентов.
          Добавить новый: создать <code>modules/[name]/manifest.ts</code> и зарегистрировать в <code>modules/registry.ts</code>.
          Standalone: <code>VITE_ENABLED_MODULES=dashboards,kpi</code> в .env.
        </Typography>
      </Box>
    </Box>
  );
}
