// VERSION: 1.0.0
// Path: frontend/src/pages/NotFoundPage.tsx
// CHANGES v1.0.0:
//   - Этап 7: страница 404 для несуществующих маршрутов
import { Typography, Button, Stack } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <Stack alignItems="center" justifyContent="center" spacing={2} sx={{ mt: 10 }}>
      <Typography variant="h2" fontWeight={700} color="text.disabled">404</Typography>
      <Typography variant="body1" color="text.secondary">
        Страница не найдена
      </Typography>
      <Button variant="contained" onClick={() => navigate("/datasets")}>
        К списку датасетов
      </Button>
    </Stack>
  );
}
