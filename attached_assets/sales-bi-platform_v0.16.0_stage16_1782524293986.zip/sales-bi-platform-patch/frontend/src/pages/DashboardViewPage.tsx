// VERSION: 2.0.0
// Path: frontend/src/pages/DashboardViewPage.tsx
// CHANGES v1.0.0:
//   - Этап 7: просмотр дашборда — список chart-конфигов (плейсхолдер)
// CHANGES v2.0.0:
//   - Этап 9: полноценный рендер сохранённого дашборда — KPI-ряд и все
//     графики из config.charts/config.kpi_metrics реально отображаются.
//     ChartConfig.type → соответствующий компонент (line/bar/pie/treemap/
//     heatmap/waterfall/table/map). FilterBar активна, drill-down работает.
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Box, Typography, CircularProgress, Alert, Breadcrumbs, Link as MuiLink,
  FormControl, InputLabel, Select, MenuItem, Grid, Stack,
} from "@mui/material";
import { useDataset } from "@/hooks/useDatasets";
import { useDashboard } from "@/hooks/useDashboards";
import { useMetadataOverview } from "@/hooks/useMetadata";
import { FilterBar } from "@/components/filters/FilterBar";
import { KpiRow } from "@/components/kpi/KpiRow";
import {
  LineChartCard, BarChartCard, PieChartCard, TreemapChartCard,
  HeatmapChartCard, WaterfallChartCard, BranchMapCard, DataTableCard, DrilldownModal,
} from "@/components/charts";
import { useDrilldown } from "@/hooks/useDrilldown";
import { useFilters } from "@/context/FiltersContext";
import type { ChartConfig, MetricOut, DimensionOut } from "@/types";

const DEFAULT_FORMAT = "{:,.2f}";

function ChartRenderer({
  chart,
  metricMetas,
  dimensionMetas,
  onDrilldown,
}: {
  chart: ChartConfig;
  metricMetas: MetricOut[];
  dimensionMetas: DimensionOut[];
  onDrilldown: (value: string) => void;
}) {
  const primaryMetricMeta = metricMetas.find((m) => m.column_name === chart.metrics[0]);
  const valueFormat = primaryMetricMeta?.display_format ?? DEFAULT_FORMAT;

  switch (chart.type) {
    case "line":
    case "timeseries":
      return (
        <LineChartCard
          title={chart.title || "Динамика"}
          timeDimensions={chart.dimensions}
          metric={chart.metrics[0]}
          valueFormat={valueFormat}
        />
      );
    case "bar":
    case "category":
      return (
        <BarChartCard
          title={chart.title || "По категориям"}
          dimension={chart.dimensions[0]}
          metric={chart.metrics[0]}
          valueFormat={valueFormat}
          onDrilldown={onDrilldown}
        />
      );
    case "pie":
      return (
        <PieChartCard
          title={chart.title || "Доли"}
          dimension={chart.dimensions[0]}
          metric={chart.metrics[0]}
          valueFormat={valueFormat}
          onDrilldown={onDrilldown}
        />
      );
    case "treemap":
      return (
        <TreemapChartCard
          title={chart.title || "Структура"}
          dimensions={chart.dimensions}
          metric={chart.metrics[0]}
          valueFormat={valueFormat}
          onDrilldown={onDrilldown}
        />
      );
    case "heatmap":
      return chart.dimensions.length >= 2 ? (
        <HeatmapChartCard
          title={chart.title || "Тепловая карта"}
          rowDim={chart.dimensions[0]}
          colDim={chart.dimensions[1]}
          metric={chart.metrics[0]}
          valueFormat={valueFormat}
        />
      ) : null;
    case "waterfall":
      return (
        <WaterfallChartCard
          title={chart.title || "Вклад в итог"}
          dimension={chart.dimensions[0]}
          metric={chart.metrics[0]}
          valueFormat={valueFormat}
        />
      );
    case "map":
      return (
        <BranchMapCard
          title={chart.title || "Карта"}
          dimension={chart.dimensions[0]}
          metric={chart.metrics[0]}
          valueFormat={valueFormat}
        />
      );
    case "table":
      return (
        <DataTableCard
          title={chart.title || "Таблица"}
          dimensions={chart.dimensions}
          metrics={chart.metrics}
          dimensionMetas={dimensionMetas}
          metricMetas={metricMetas}
        />
      );
    default:
      return (
        <Alert severity="warning">Неизвестный тип графика: {chart.type}</Alert>
      );
  }
}

export default function DashboardViewPage() {
  const { datasetId, dashboardId } = useParams<{ datasetId: string; dashboardId: string }>();
  const navigate = useNavigate();
  const { setDatasetId } = useFilters();
  const { data: dataset } = useDataset(datasetId);
  const { data: dashboard, isLoading, error } = useDashboard(dashboardId);
  const { data: metadata } = useMetadataOverview(datasetId);
  const drilldown = useDrilldown(datasetId);
  const [selectedMetric, setSelectedMetric] = useState<string>("");

  useEffect(() => {
    if (datasetId) setDatasetId(datasetId);
  }, [datasetId, setDatasetId]);

  const visibleMetrics = useMemo<MetricOut[]>(
    () => (metadata?.metrics ?? []).filter((m) => m.is_visible),
    [metadata],
  );
  const visibleDimensions = useMemo<DimensionOut[]>(
    () => (metadata?.dimensions ?? []).filter((d) => d.is_visible),
    [metadata],
  );

  const kpiMetrics = useMemo(
    () => dashboard?.config.kpi_metrics ?? [],
    [dashboard],
  );

  const charts = useMemo(
    () => dashboard?.config.charts ?? [],
    [dashboard],
  );

  const handleDrilldown = (value: string, chart: ChartConfig) => {
    const metricMeta = visibleMetrics.find((m) => m.column_name === chart.metrics[0]);
    const dimMeta = visibleDimensions.find((d) => d.column_name === chart.dimensions[0]);
    if (!metricMeta || !dimMeta) return;
    drilldown.open({
      hierarchyGroup: dimMeta.hierarchy_group ?? "geography",
      level: dimMeta.hierarchy_level ?? 0,
      parentValue: value,
      metricColumn: chart.metrics[0],
      metricMeta,
    });
  };

  if (isLoading) return <CircularProgress />;
  if (error) return <Alert severity="error">{error.message}</Alert>;
  if (!dashboard) return null;

  return (
    <Box>
      <Breadcrumbs sx={{ mb: 1 }}>
        <MuiLink component="button" underline="hover" onClick={() => navigate("/datasets")}>
          Датасеты
        </MuiLink>
        <MuiLink component="button" underline="hover" onClick={() => navigate(`/datasets/${datasetId}`)}>
          {dataset?.name ?? "…"}
        </MuiLink>
        <MuiLink component="button" underline="hover" onClick={() => navigate(`/datasets/${datasetId}/dashboards`)}>
          Сохранённые дашборды
        </MuiLink>
        <Typography color="text.primary">{dashboard.name}</Typography>
      </Breadcrumbs>

      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2} flexWrap="wrap" gap={2}>
        <Box>
          <Typography variant="h5" fontWeight={700}>{dashboard.name}</Typography>
          {dashboard.description && (
            <Typography variant="body2" color="text.secondary">{dashboard.description}</Typography>
          )}
        </Box>
        {visibleMetrics.length > 0 && charts.length > 0 && (
          <FormControl size="small" sx={{ minWidth: 220 }}>
            <InputLabel>Метрика</InputLabel>
            <Select
              label="Метрика"
              value={selectedMetric || charts[0]?.metrics[0] || ""}
              onChange={(e) => setSelectedMetric(e.target.value)}
            >
              {visibleMetrics.map((m) => (
                <MenuItem key={m.column_name} value={m.column_name}>{m.display_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
        )}
      </Stack>

      <FilterBar />

      {kpiMetrics.length > 0 && (
        <Box mb={2}>
          <KpiRow metrics={kpiMetrics} />
        </Box>
      )}

      {charts.length === 0 && (
        <Alert severity="info">
          В этом дашборде нет настроенных графиков.
          Вернитесь к обзорному дашборду для автоматической визуализации.
        </Alert>
      )}

      <Grid container spacing={2}>
        {charts.map((chart) => (
          <Grid item xs={12} md={chart.type === "table" ? 12 : 6} key={chart.id}>
            <ChartRenderer
              chart={chart}
              metricMetas={visibleMetrics}
              dimensionMetas={visibleDimensions}
              onDrilldown={(value) => handleDrilldown(value, chart)}
            />
          </Grid>
        ))}
      </Grid>

      <DrilldownModal
        open={Boolean(drilldown.current)}
        onClose={drilldown.close}
        data={drilldown.data}
        isLoading={drilldown.isLoading}
        error={drilldown.error}
        parentValue={drilldown.current?.parentValue ?? null}
        metricMeta={drilldown.current?.metricMeta}
      />
    </Box>
  );
}
