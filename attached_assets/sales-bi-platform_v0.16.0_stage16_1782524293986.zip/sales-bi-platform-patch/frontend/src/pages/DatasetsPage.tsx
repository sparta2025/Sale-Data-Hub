// VERSION: 1.2.0
// Path: frontend/src/pages/DatasetsPage.tsx
// CHANGES v1.0.0:
//   - Этап 7: список датасетов + UploadDropzone + удаление
// CHANGES v1.1.0:
//   - Этап 11: i18n через useTranslation().t.pages.datasets
import { useState } from "react";
import {
  Box, Typography, Grid, CircularProgress, Alert, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions, Button,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useDatasets, useDeleteDataset } from "@/hooks/useDatasets";
import { useFilters } from "@/context/FiltersContext";
import { useTranslation } from "@/context/I18nContext";
import { useNotification } from "@/context/NotificationContext";
import { DatasetCard } from "@/components/datasets/DatasetCard";
import { UploadDropzone } from "@/components/datasets/UploadDropzone";
import type { DatasetOut } from "@/types";

export default function DatasetsPage() {
  const navigate = useNavigate();
  const { setDatasetId } = useFilters();
  const { t } = useTranslation();
  const { data: datasets, isLoading, error } = useDatasets();
  const deleteMutation = useDeleteDataset();
  const notify = useNotification();
  const [pendingDelete, setPendingDelete] = useState<DatasetOut | null>(null);

  const openDataset = (dataset: DatasetOut) => {
    setDatasetId(dataset.id);
    navigate(`/datasets/${dataset.id}`);
  };

  const confirmDelete = () => {
    if (!pendingDelete) return;
    deleteMutation.mutate(pendingDelete.id, {
      onSuccess: () => notify.success(`Датасет «${pendingDelete?.name}» удалён`),
      onError:   (e) => notify.error(`Ошибка удаления: ${e.message}`),
      onSettled: () => setPendingDelete(null),
    });
  };

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} mb={2}>
        {t.pages.datasets.title}
      </Typography>

      <Box mb={3}>
        <UploadDropzone onUploaded={(datasetId) => navigate(`/datasets/${datasetId}`)} />
      </Box>

      {isLoading && <CircularProgress />}
      {error && <Alert severity="error">{error.message}</Alert>}

      {datasets && datasets.length === 0 && (
        <Alert severity="info">{t.pages.datasets.noDatasets}</Alert>
      )}

      {datasets && datasets.length > 0 && (
        <Grid container spacing={2}>
          {datasets.map((dataset) => (
            <Grid item xs={12} sm={6} md={4} key={dataset.id}>
              <DatasetCard
                dataset={dataset}
                onOpen={() => openDataset(dataset)}
                onDelete={() => setPendingDelete(dataset)}
              />
            </Grid>
          ))}
        </Grid>
      )}

      <Dialog
        open={Boolean(pendingDelete)}
        onClose={() => setPendingDelete(null)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>{t.pages.datasets.deleteTitle}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {t.pages.datasets.deleteText}
            {pendingDelete && (
              <Box component="span" fontWeight={700}> «{pendingDelete.name}»</Box>
            )}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPendingDelete(null)}>
            {t.pages.datasets.cancelBtn}
          </Button>
          <Button
            color="error"
            variant="contained"
            onClick={confirmDelete}
            disabled={deleteMutation.isPending}
          >
            {t.pages.datasets.deleteBtn}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
