// VERSION: 4.4.0
// Path: frontend/src/pages/DashboardOverviewPage.tsx
// CHANGES v1-v3: Этапы 7-9 (см. PROGRESS.md)
// CHANGES v4.0.0:
//   - Этап 9.1: react-grid-layout — диаграммы перетаскиваются мышью,
//     раскладка сохраняется в localStorage через DashboardLayoutContext.
//     ScalableChartWrapper — правая кнопка → масштаб на каждой диаграмме.
//     Диаграммы скрываются/показываются через Sidebar (DashboardLayoutContext).
//     Добавлены ScatterChartCard (точечная) и HistogramChartCard (распределение).
import { useMemo, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Box, Typography, Stack, Breadcrumbs, Link as MuiLink,
  FormControl, InputLabel, Select, MenuItem, Alert, Fab, Tooltip as MuiTooltip,
} from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import { Responsive, WidthProvider } from "react-grid-layout";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
// @ts-expect-error — types installed at runtime
import { useDataset } from "@/hooks/useDatasets";
import { useMetadataOverview } from "@/hooks/useMetadata";
import { FilterBar } from "@/components/filters/FilterBar";
import { KpiRow } from "@/components/kpi/KpiRow";
import {
  LineChartCard, BarChartCard, PieChartCard, TreemapChartCard,
  HeatmapChartCard, WaterfallChartCard, BranchMapCard, DataTableCard,
  DrilldownModal, ScatterChartCard, HistogramChartCard,
  BoxPlotChartCard, RadarChartCard, GaugeChartCard,
  FunnelChartCard, StatSummaryCard,
} from "@/components/charts";
import { ScalableChartWrapper } from "@/components/common/ScalableChartWrapper";
import { ChartErrorBoundary } from "@/components/error/ChartErrorBoundary";
import { useDrilldown } from "@/hooks/useDrilldown";
import { useDashboardLayout } from "@/context/DashboardLayoutContext";
import { useSavedDashboards } from "@/hooks/useSavedDashboards";
import { AgentBus } from "@/modules/agents/AgentBus";
import { useNotification } from "@/context/NotificationContext";
import { useTranslation } from "@/context/I18nContext";
import type { DimensionOut, MetricOut } from "@/types";

const ResponsiveGridLayout = WidthProvider(Responsive);

const DEFAULT_FORMAT = "{:,.2f}";
const COLS = { lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 };
const ROW_HEIGHT = 60;

function pickCategoryDimension(dims: DimensionOut[]): DimensionOut | undefined {
  const candidates = dims.filter((d) => d.is_visible && d.hierarchy_group !== "time");
  if (!candidates.length) return undefined;
  return [...candidates].sort((a, b) => {
    if (a.hierarchy_level !== b.hierarchy_level) return a.hierarchy_level - b.hierarchy_level;
    return a.distinct_count - b.distinct_count;
  })[0];
}

function pickTreemapDimensions(dims: DimensionOut[]): DimensionOut[] {
  const groups = new Map<string, DimensionOut[]>();
  for (const d of dims) {
    if (!d.is_visible || !d.hierarchy_group || d.hierarchy_group === "time") continue;
    const list = groups.get(d.hierarchy_group) ?? [];
    list.push(d);
    groups.set(d.hierarchy_group, list);
  }
  for (const list of groups.values()) {
    if (list.length >= 2) return [...list].sort((a, b) => a.hierarchy_level - b.hierarchy_level).slice(0, 2);
  }
  const fallback = pickCategoryDimension(dims);
  return fallback ? [fallback] : [];
}

function pickBranchDimension(dims: DimensionOut[]): DimensionOut | undefined {
  return dims.find((d) => d.is_visible && d.hierarchy_group === "geography" && d.hierarchy_level === 1);
}

/** Дефолтная раскладка если нет сохранённой */
function buildDefaultLayouts(charts: string[]): import("react-grid-layout").Layouts {
  const positions: Record<string, { x: number; y: number; w: number; h: number }> = {
    line:      { x: 0, y: 0,  w: 12, h: 5 },
    bar:       { x: 0, y: 5,  w: 6,  h: 5 },
    pie:       { x: 6, y: 5,  w: 6,  h: 5 },
    treemap:   { x: 0, y: 10, w: 6,  h: 5 },
    heatmap:   { x: 6, y: 10, w: 6,  h: 5 },
    waterfall: { x: 0, y: 15, w: 12, h: 5 },
    map:       { x: 0, y: 20, w: 6,  h: 7 },
    table:     { x: 6, y: 20, w: 6,  h: 7 },
    scatter:   { x: 0, y: 27, w: 6,  h: 5 },
    histogram: { x: 6, y: 27, w: 6,  h: 5 },
  };
  const lg = charts
    .filter((id) => positions[id])
    .map((id) => ({ i: id, ...positions[id] }));
  return { lg };
}

export default function DashboardOverviewPage() {
  const { datasetId }  = useParams<{ datasetId: string }>();
  const navigate       = useNavigate();
  const { data: dataset } = useDataset(datasetId);
  const { data: metadata, isLoading: metadataLoading, error: metadataError } = useMetadataOverview(datasetId);
  const [selectedMetric, setSelectedMetric] = useState<string>("");
  const drilldown = useDrilldown(datasetId);

  const { visibleCharts, layouts, setLayouts, setPrimaryMetric, getSnapshot } = useDashboardLayout();
  const { save: saveDash } = useSavedDashboards();
  const notify = useNotification();
  const { t } = useTranslation();

  // Синхронизируем primaryMetric в контекст для сохранения дашборда
  const handleMetricChange = useCallback((metric: string) => {
    setSelectedMetric(metric);
    setPrimaryMetric(metric);
    AgentBus.emit("dashboards.metric_select", "dashboards", { metric, datasetId });
  }, [setPrimaryMetric, datasetId]);

  // Сохранение дашборда
  const handleSaveDashboard = useCallback(() => {
    if (!datasetId) return;
    const snap = getSnapshot();
    const now = new Date();
    const label = `${dataset?.name ?? "Датасет"} — ${now.toLocaleDateString("ru-RU")} ${now.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}`;
    saveDash({
      name: label,
      datasetId,
      datasetName: dataset?.name ?? "",
      primaryMetric: snap.primaryMetric ?? primaryMetric,
      visibleCharts: snap.visibleCharts,
      filters: {},
      layouts: snap.layouts,
    });
    notify.success("Дашборд сохранён");
    AgentBus.emit("dashboards.save", "dashboards", { name: label, datasetId });
  }, [datasetId, dataset, getSnapshot, saveDash, primaryMetric, notify]);

  const visibleMetrics = useMemo<MetricOut[]>(
    () => (metadata?.metrics ?? []).filter((m) => m.is_visible), [metadata]);
  const visibleDimensions = useMemo<DimensionOut[]>(
    () => (metadata?.dimensions ?? []).filter((d) => d.is_visible), [metadata]);

  const primaryMetric     = selectedMetric || visibleMetrics[0]?.column_name || "";
  const primaryMetricMeta = visibleMetrics.find((m) => m.column_name === primaryMetric);
  const valueFormat       = primaryMetricMeta?.display_format ?? DEFAULT_FORMAT;

  const timeDimensions = useMemo<DimensionOut[]>(
    () => (metadata?.dimensions ?? [])
      .filter((d) => d.hierarchy_group === "time" && d.is_visible)
      .sort((a, b) => a.hierarchy_level - b.hierarchy_level),
    [metadata]);

  const categoryDim = useMemo(() => pickCategoryDimension(metadata?.dimensions ?? []), [metadata]);
  const treemapDims = useMemo(() => pickTreemapDimensions(metadata?.dimensions ?? []), [metadata]);
  const branchDim   = useMemo(() => pickBranchDimension(metadata?.dimensions ?? []), [metadata]);
  const kpiMetrics  = visibleMetrics.slice(0, Number(import.meta.env.VITE_KPI_CARDS_COUNT ?? 4)).map((m) => m.column_name);
  const groupByMaxDistinct = Number(import.meta.env.VITE_CHART_GROUP_BY_MAX_DISTINCT ?? 6);

  const secondaryMetric = visibleMetrics[1]?.column_name;

  const handleDrilldown = useCallback((value: string) => {
    if (!primaryMetricMeta || !categoryDim) return;
    drilldown.open({
      hierarchyGroup: categoryDim.hierarchy_group ?? "",
      level: categoryDim.hierarchy_level ?? 0,
      parentValue: value,
      metricColumn: primaryMetric,
      metricMeta: primaryMetricMeta,
    });
  }, [drilldown, primaryMetric, primaryMetricMeta, categoryDim]);

  const visibleList = useMemo(
    () => Array.from(visibleCharts),
    [visibleCharts],
  );

  const gridLayouts = useMemo(
    () => (layouts && Object.keys(layouts).length > 0) ? layouts : buildDefaultLayouts(visibleList),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [visibleList],
  );

  const renderChart = useCallback((id: string) => {
    if (!primaryMetric) return null;
    const hasTime     = timeDimensions.length > 0;
    const hasYearMonth = timeDimensions.length >= 2;

    switch (id) {
      case "line":
        return hasTime ? (
          <LineChartCard
            title={`${primaryMetricMeta?.display_name ?? primaryMetric} по периодам`}
            timeDimensions={timeDimensions.map((d) => d.column_name)}
            metric={primaryMetric}
            groupBy={categoryDim && categoryDim.distinct_count <= groupByMaxDistinct ? categoryDim.column_name : undefined}
            valueFormat={valueFormat}
          />
        ) : null;

      case "bar":
        return categoryDim ? (
          <BarChartCard
            title={`${primaryMetricMeta?.display_name ?? primaryMetric} по: ${categoryDim.display_name}`}
            dimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
            onDrilldown={handleDrilldown}
          />
        ) : null;

      case "pie":
        return categoryDim ? (
          <PieChartCard
            title={`Доли по: ${categoryDim.display_name}`}
            dimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
            onDrilldown={handleDrilldown}
          />
        ) : null;

      case "treemap":
        return treemapDims.length > 0 ? (
          <TreemapChartCard
            title={`Структура: ${treemapDims.map((d) => d.display_name).join(" → ")}`}
            dimensions={treemapDims.map((d) => d.column_name)}
            metric={primaryMetric}
            valueFormat={valueFormat}
            onDrilldown={handleDrilldown}
          />
        ) : null;

      case "heatmap":
        return hasYearMonth ? (
          <HeatmapChartCard
            title={`${primaryMetricMeta?.display_name ?? primaryMetric}: ${timeDimensions[0].display_name} × ${timeDimensions[1].display_name}`}
            rowDim={timeDimensions[0].column_name}
            colDim={timeDimensions[1].column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
          />
        ) : null;

      case "waterfall":
        return categoryDim ? (
          <WaterfallChartCard
            title={`Вклад в итог: ${categoryDim.display_name}`}
            dimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
          />
        ) : null;

      case "map":
        return branchDim ? (
          <BranchMapCard
            title={`${primaryMetricMeta?.display_name ?? primaryMetric} по филиалам (карта)`}
            dimension={branchDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
          />
        ) : null;

      case "table":
        return categoryDim ? (
          <DataTableCard
            title={`Сводная таблица по: ${categoryDim.display_name}`}
            dimensions={visibleDimensions.filter((d) => d.hierarchy_level === 0).slice(0, 3).map((d) => d.column_name)}
            metrics={visibleMetrics.slice(0, 4).map((m) => m.column_name)}
            dimensionMetas={visibleDimensions}
            metricMetas={visibleMetrics}
          />
        ) : null;

      case "scatter":
        return categoryDim && secondaryMetric ? (
          <ScatterChartCard
            title={`${primaryMetricMeta?.display_name} vs ${visibleMetrics[1]?.display_name ?? secondaryMetric}`}
            dimension={categoryDim.column_name}
            metricX={primaryMetric}
            metricY={secondaryMetric}
            metricXLabel={primaryMetricMeta?.display_name}
            metricYLabel={visibleMetrics[1]?.display_name}
            valueFormat={valueFormat}
            showTrendLine
          />
        ) : null;

      case "histogram":
        return categoryDim ? (
          <HistogramChartCard
            title={`Распределение: ${primaryMetricMeta?.display_name ?? primaryMetric}`}
            dimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
            bins={10}
          />
        ) : null;

      case "boxplot":
        return categoryDim && treemapDims.length >= 2 ? (
          <BoxPlotChartCard
            title={`Распределение: ${primaryMetricMeta?.display_name ?? primaryMetric} по ${treemapDims[1]?.display_name ?? categoryDim.display_name}`}
            dimension={treemapDims[1]?.column_name ?? categoryDim.column_name}
            groupDimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
          />
        ) : categoryDim ? (
          <BoxPlotChartCard
            title={`Распределение: ${primaryMetricMeta?.display_name ?? primaryMetric}`}
            dimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
          />
        ) : null;

      case "radar":
        return categoryDim && visibleMetrics.length >= 2 ? (
          <RadarChartCard
            title={`Сравнение по метрикам: ${categoryDim.display_name}`}
            dimension={categoryDim.column_name}
            metrics={visibleMetrics.slice(0, 4).map((m) => m.column_name)}
            metricLabels={visibleMetrics.slice(0, 4).map((m) => m.display_name)}
            valueFormat={valueFormat}
            topN={6}
          />
        ) : null;

      case "funnel":
        return categoryDim ? (
          <FunnelChartCard
            title={`Воронка: ${primaryMetricMeta?.display_name ?? primaryMetric} по ${categoryDim.display_name}`}
            dimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
            topN={8}
          />
        ) : null;

      case "statsummary":
        return (
          <StatSummaryCard
            title="Статистическая сводка по метрикам"
            valueFormat={valueFormat}
          />
        );

      case "gauge":
        return categoryDim ? (
          <GaugeChartCard
            title={`${primaryMetricMeta?.display_name ?? primaryMetric}: выполнение`}
            dimension={categoryDim.column_name}
            metric={primaryMetric}
            valueFormat={valueFormat}
          />
        ) : null;

      default:
        return null;
    }
  }, [
    primaryMetric, primaryMetricMeta, valueFormat, timeDimensions, categoryDim,
    treemapDims, branchDim, visibleDimensions, visibleMetrics, groupByMaxDistinct,
    secondaryMetric, handleDrilldown,
  ]);

  return (
    <Box>
      <Breadcrumbs sx={{ mb: 1 }}>
        <MuiLink component="button" underline="hover" onClick={() => navigate("/datasets")}>
          {t.nav.datasets}
        </MuiLink>
        <MuiLink component="button" underline="hover" onClick={() => navigate(`/datasets/${datasetId}`)}>
          {dataset?.name ?? "…"}
        </MuiLink>
        <Typography color="text.primary">{t.nav.dashboard}</Typography>
      </Breadcrumbs>

      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2} flexWrap="wrap" gap={2}>
        <Typography variant="h5" fontWeight={700}>{t.dashboard.title}: {dataset?.name}</Typography>
        {visibleMetrics.length > 1 && (
          <FormControl size="small" sx={{ minWidth: 240 }}>
            <InputLabel>{t.dashboard.metricForCharts}</InputLabel>
            <Select
              label={t.dashboard.metricForCharts}
              value={primaryMetric}
              onChange={(e) => handleMetricChange(e.target.value)}
            >
              {visibleMetrics.map((m) => (
                <MenuItem key={m.column_name} value={m.column_name}>{m.display_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
        )}
      </Stack>

      <FilterBar />

      {metadataError && <Alert severity="error">{metadataError.message}</Alert>}
      {!metadataLoading && metadata && kpiMetrics.length === 0 && (
        <Alert severity="info">
          Нет видимых метрик. Включите их на странице датасета (вкладка «Метаданные»).
        </Alert>
      )}

      {kpiMetrics.length > 0 && <KpiRow metrics={kpiMetrics} />}

      {primaryMetric && visibleList.length > 0 && (
        <Box sx={{ "& .react-grid-item": { transition: "none" }, "& .react-resizable-handle": { opacity: 0.4, "&:hover": { opacity: 1 } } }}>
          <ResponsiveGridLayout
            className="layout"
            layouts={gridLayouts}
            cols={COLS}
            rowHeight={ROW_HEIGHT}
            isDraggable
            isResizable
            draggableHandle=".chart-drag-handle"
            onLayoutChange={(_layout, allLayouts) => setLayouts(allLayouts)}
            margin={[12, 12]}
          >
            {visibleList.map((chartId) => {
              const content = renderChart(chartId);
              if (!content) return null;
              return (
                <div key={chartId}>
                  {/* Ручка для перетаскивания — верхняя полоса при hover */}
                  <Box
                    className="chart-drag-handle"
                    sx={{
                      position: "absolute",
                      top: 0, left: 0, right: 0,
                      height: 24,
                      cursor: "grab",
                      zIndex: 10,
                      borderRadius: "8px 8px 0 0",
                      backgroundColor: "transparent",
                      "&:hover": { backgroundColor: "rgba(37,99,235,0.08)" },
                      "&:active": { cursor: "grabbing" },
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Box sx={{
                      width: 32, height: 3, borderRadius: 2,
                      backgroundColor: "rgba(148,163,184,0)",
                      ".chart-drag-handle:hover &": { backgroundColor: "rgba(37,99,235,0.35)" },
                    }} />
                  </Box>
                  <ChartErrorBoundary height={ROW_HEIGHT * 5}>
                    <ScalableChartWrapper chartId={chartId} sx={{ height: "100%", pt: "24px" }}>
                      {content}
                    </ScalableChartWrapper>
                  </ChartErrorBoundary>
                </div>
              );
            })}
          </ResponsiveGridLayout>
        </Box>
      )}

      {visibleList.length === 0 && primaryMetric && (
        <Alert severity="info">
          Все диаграммы скрыты. Включите нужные в боковой панели (Дашборд).
        </Alert>
      )}

      {/* FAB — сохранить дашборд */}
      <MuiTooltip title="Сохранить дашборд" placement="left">
        <Fab
          color="primary"
          size="medium"
          onClick={handleSaveDashboard}
          disabled={!primaryMetric}
          sx={{ position: "fixed", bottom: 32, right: 32, zIndex: 1200 }}
        >
          <SaveIcon />
        </Fab>
      </MuiTooltip>

      <DrilldownModal
        open={Boolean(drilldown.current)}
        onClose={drilldown.close}
        data={drilldown.data}
        isLoading={drilldown.isLoading}
        error={drilldown.error}
        parentValue={drilldown.current?.parentValue ?? null}
        metricMeta={drilldown.current?.metricMeta}
      />
    </Box>
  );
}
