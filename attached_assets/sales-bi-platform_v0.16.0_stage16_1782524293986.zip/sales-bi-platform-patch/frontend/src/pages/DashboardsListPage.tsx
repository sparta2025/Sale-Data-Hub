// VERSION: 1.1.0
// Path: frontend/src/pages/DashboardsListPage.tsx
// CHANGES v1.0.0:
//   - Этап 7: список сохранённых дашбордов + создание + удаление
// CHANGES v1.1.0:
//   - Этап 11: i18n через t.pages.savedDashboards + t.common.*;
//     интеграция с useSavedDashboards (localStorage) + api-дашборды рядом;
//     улучшен UI: chips метрики и диаграмм, форматированная дата.
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Box, Typography, CircularProgress, Alert, Button, Stack, Paper, List,
  ListItemButton, ListItemText, IconButton, Breadcrumbs, Link as MuiLink,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, Chip,
} from "@mui/material";
import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import AddIcon from "@mui/icons-material/Add";
import RestoreIcon from "@mui/icons-material/Restore";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import { useDashboardsList, useCreateDashboard, useDeleteDashboard } from "@/hooks/useDashboards";
import { useTranslation } from "@/context/I18nContext";
import { useSavedDashboards } from "@/hooks/useSavedDashboards";
import { useDashboardLayout } from "@/context/DashboardLayoutContext";
import { useFilters } from "@/context/FiltersContext";

function formatDate(iso: string, locale: string): string {
  try {
    return new Date(iso).toLocaleDateString(locale === "zh" ? "zh-CN" : locale === "ar" ? "ar-SA" : "ru-RU", {
      day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit",
    });
  } catch { return iso; }
}

export default function DashboardsListPage() {
  const { datasetId } = useParams<{ datasetId: string }>();
  const navigate = useNavigate();
  const { t, locale } = useTranslation();
  const p = t.pages.savedDashboards;

  // API дашборды
  const { data: dashboards, isLoading, error } = useDashboardsList(datasetId);
  const createMutation = useCreateDashboard(datasetId);
  const deleteMutation = useDeleteDashboard(datasetId);

  // localStorage дашборды
  const { list: localList, deleteById: localDelete } = useSavedDashboards();
  const { restoreSnapshot } = useDashboardLayout();
  const { setDatasetId } = useFilters();

  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState("");

  const handleCreate = () => {
    if (!newName.trim()) return;
    createMutation.mutate({ name: newName.trim(), description: "" }, {
      onSuccess: (dash) => {
        setCreateOpen(false);
        setNewName("");
        navigate(`/datasets/${datasetId}/dashboards/${dash.id}`);
      },
    });
  };

  const handleLoadLocal = (entry: typeof localList[number]) => {
    if (entry.datasetId !== datasetId) {
      setDatasetId(entry.datasetId);
      navigate(`/datasets/${entry.datasetId}/overview`);
    } else {
      navigate(`/datasets/${datasetId}/overview`);
    }
    restoreSnapshot({
      visibleCharts: entry.visibleCharts,
      layouts: entry.layouts,
      primaryMetric: entry.primaryMetric,
    });
  };

  return (
    <Box>
      <Breadcrumbs sx={{ mb: 1 }}>
        <MuiLink component="button" underline="hover" onClick={() => navigate("/datasets")}>
          {t.nav.datasets}
        </MuiLink>
        <MuiLink component="button" underline="hover" onClick={() => navigate(`/datasets/${datasetId}`)}>
          {datasetId?.slice(0, 8)}…
        </MuiLink>
        <Typography color="text.primary">{p.title}</Typography>
      </Breadcrumbs>

      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5" fontWeight={700}>{p.title}</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => setCreateOpen(true)}>
          {p.newDashboard}
        </Button>
      </Stack>

      {/* === localStorage-сохранённые === */}
      {localList.length > 0 && (
        <Box mb={3}>
          <Typography variant="subtitle2" color="text.secondary" mb={1}>
            Локально сохранённые
          </Typography>
          <Paper variant="outlined">
            <List disablePadding>
              {localList.map((entry, idx) => (
                <ListItemButton
                  key={entry.id}
                  divider={idx < localList.length - 1}
                  onClick={() => handleLoadLocal(entry)}
                  sx={{ "&:hover": { backgroundColor: "action.hover" } }}
                >
                  <SpaceDashboardIcon sx={{ mr: 2, color: "primary.main" }} />
                  <ListItemText
                    primary={
                      <Stack direction="row" alignItems="center" gap={1} flexWrap="wrap">
                        <Typography variant="body2" fontWeight={600} noWrap>{entry.name}</Typography>
                        <Chip label={entry.datasetName} size="small"
                          sx={{ height: 18, fontSize: "0.6rem", backgroundColor: "primary.main", color: "#fff" }} />
                        <Chip label={`${entry.visibleCharts.length} диаграмм`} size="small"
                          sx={{ height: 18, fontSize: "0.6rem" }} />
                      </Stack>
                    }
                    secondary={
                      <Stack direction="row" alignItems="center" gap={0.5} mt={0.25}>
                        <AccessTimeIcon sx={{ fontSize: 11 }} />
                        <Typography variant="caption">
                          {p.updated}: {formatDate(entry.createdAt, locale)}
                        </Typography>
                      </Stack>
                    }
                  />
                  <Stack direction="row">
                    <IconButton size="small" onClick={(e) => { e.stopPropagation(); handleLoadLocal(entry); }}>
                      <RestoreIcon fontSize="small" color="primary" />
                    </IconButton>
                    <IconButton size="small" onClick={(e) => { e.stopPropagation(); localDelete(entry.id); }}>
                      <DeleteOutlineIcon fontSize="small" color="error" />
                    </IconButton>
                  </Stack>
                </ListItemButton>
              ))}
            </List>
          </Paper>
        </Box>
      )}

      {/* === API-дашборды === */}
      {isLoading && <CircularProgress />}
      {error && <Alert severity="error">{error.message}</Alert>}

      {dashboards && dashboards.length === 0 && localList.length === 0 && (
        <Alert severity="info">{p.noSaved}</Alert>
      )}

      {dashboards && dashboards.length > 0 && (
        <Box>
          <Typography variant="subtitle2" color="text.secondary" mb={1}>
            Серверные дашборды
          </Typography>
          <Paper variant="outlined">
            <List disablePadding>
              {dashboards.map((dash, idx) => (
                <ListItemButton
                  key={dash.id}
                  divider={idx < dashboards.length - 1}
                  onClick={() => navigate(`/datasets/${datasetId}/dashboards/${dash.id}`)}
                >
                  <SpaceDashboardIcon sx={{ mr: 2 }} color="action" />
                  <ListItemText
                    primary={dash.name}
                    secondary={`${p.updated}: ${new Date(dash.updated_at).toLocaleDateString("ru-RU")}`}
                  />
                  <IconButton
                    edge="end" color="error"
                    onClick={(e) => { e.stopPropagation(); deleteMutation.mutate(dash.id); }}
                  >
                    <DeleteOutlineIcon fontSize="small" />
                  </IconButton>
                </ListItemButton>
              ))}
            </List>
          </Paper>
        </Box>
      )}

      {/* Диалог создания */}
      <Dialog open={createOpen} onClose={() => setCreateOpen(false)} fullWidth maxWidth="xs">
        <DialogTitle>{p.newDashboard}</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus fullWidth margin="dense"
            label={p.nameLabel}
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
          />
          {createMutation.error && (
            <Alert severity="error" sx={{ mt: 2 }}>{createMutation.error.message}</Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCreateOpen(false)}>{t.common.cancel}</Button>
          <Button variant="contained" onClick={handleCreate}
            disabled={!newName.trim() || createMutation.isPending}>
            {p.createBtn}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
