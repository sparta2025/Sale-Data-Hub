// VERSION: 1.0.0
// Path: frontend/src/vite-env.d.ts
// CHANGES v1.0.0:
//   - Этап 1: типы Vite client
/// <reference types="vite/client" />
