// VERSION: 1.0.0
// Path: frontend/src/theme/index.ts
// CHANGES v1.0.0:
//   - Этап 1: базовая MUI-тема (палитра/типографика — уточнение в Этапе 7/8)
import { createTheme } from "@mui/material/styles";

// Базовая тема — палитра и типографика будут уточнены в Этапе 7/8, когда
// появится реальный UI дашбордов. Сейчас важно, чтобы тема просто существовала
// и подключалась глобально через ThemeProvider.
export const theme = createTheme({
  palette: {
    mode: "light",
    primary: { main: "#2563eb" },
    secondary: { main: "#7c3aed" },
    background: { default: "#f5f7fa" },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
  },
  shape: {
    borderRadius: 8,
  },
});
