// VERSION: 1.0.0
// Path: frontend/src/types/query.ts
// CHANGES v1.0.0:
//   - Этап 7: типы Query Engine, зеркалирующие backend/app/schemas/query.py
export interface EqFilter {
  type: "eq";
  value: string | number;
}

export interface InFilter {
  type: "in";
  values: (string | number)[];
}

export interface RangeFilter {
  type: "range";
  min?: number | null;
  max?: number | null;
}

export type FilterSpec = EqFilter | InFilter | RangeFilter;

/** Карта активных фильтров: имя_колонки -> спецификация фильтра. */
export type FilterMap = Record<string, FilterSpec>;

export interface QueryRequest {
  dimensions: string[];
  metrics: string[];
  filters: FilterMap;
  order_by?: string | null;
  order_desc?: boolean;
  limit?: number;
}

export interface QueryResult {
  dataset_id: string;
  columns: string[];
  rows: Record<string, unknown>[];
  total_rows: number;
  sql: string;
  execution_ms: number;
}

export interface AggregatedValue {
  metric: string;
  display_name: string;
  value: number | null;
  aggregation: string;
  display_format: string;
}
