// VERSION: 1.0.0
// Path: frontend/src/types/metadata.ts
// CHANGES v1.0.0:
//   - Этап 7: типы метаданных, зеркалирующие backend/app/schemas/metadata.py
export type AggregationMethod = "sum" | "avg" | "count" | "min" | "max";

export interface DimensionOut {
  id: string;
  dataset_id: string;
  column_name: string;
  display_name: string;
  data_type: string;
  hierarchy_group: string | null;
  hierarchy_level: number;
  sample_values: unknown[];
  distinct_count: number;
  is_visible: boolean;
}

export interface DimensionPatch {
  display_name?: string;
  hierarchy_group?: string | null;
  hierarchy_level?: number;
  is_visible?: boolean;
}

export interface MetricOut {
  id: string;
  dataset_id: string;
  column_name: string;
  display_name: string;
  data_type: string;
  aggregation: AggregationMethod;
  display_format: string;
  is_visible: boolean;
}

export interface MetricPatch {
  display_name?: string;
  aggregation?: AggregationMethod;
  display_format?: string;
  is_visible?: boolean;
}

export interface HierarchyInfo {
  name: string;
  label: string;
  levels: DimensionOut[];
}

export interface MetadataOverview {
  dataset_id: string;
  dimensions_count: number;
  metrics_count: number;
  hierarchies: HierarchyInfo[];
  dimensions: DimensionOut[];
  metrics: MetricOut[];
}
