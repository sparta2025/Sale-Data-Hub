// VERSION: 1.0.0
// Path: frontend/src/types/dataset.ts
// CHANGES v1.0.0:
//   - Этап 7: типы датасета, зеркалирующие backend/app/schemas/dataset.py
export type ColumnRole = "dimension" | "metric";
export type ColumnDataType =
  | "text"
  | "integer"
  | "float"
  | "percentage"
  | "currency"
  | "year"
  | "month";

export interface ColumnProfile {
  name: string;
  role: ColumnRole;
  data_type: ColumnDataType;
  nullable: boolean;
  distinct_count: number;
  sample_values: unknown[];
}

export interface DatasetOut {
  id: string;
  name: string;
  original_filename: string;
  source_format: "csv" | "xlsx";
  row_count: number;
  column_count: number;
  status: "ready" | "failed";
  created_at: string;
}

export interface ImportResponse {
  dataset: DatasetOut;
  warnings: string[];
  columns: ColumnProfile[];
}

export interface PreviewResponse {
  dataset_id: string;
  columns: string[];
  rows: Record<string, unknown>[];
  total_rows: number;
}
