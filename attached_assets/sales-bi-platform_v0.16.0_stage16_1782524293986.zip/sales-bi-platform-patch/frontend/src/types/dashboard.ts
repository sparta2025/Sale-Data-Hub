// VERSION: 1.0.0
// Path: frontend/src/types/dashboard.ts
// CHANGES v1.0.0:
//   - Этап 7: типы Dashboard Engine, зеркалирующие backend/app/schemas/dashboard.py
import type { FilterMap } from "./query";

export type ChartType = "timeseries" | "line" | "bar" | "category" | "pie" | "treemap" | "heatmap" | "waterfall" | "table" | "map";

export interface ChartConfig {
  id: string;
  type: ChartType;
  title: string;
  dimensions: string[];
  metrics: string[];
  group_by?: string | null;
  limit?: number;
}

export interface DashboardConfig {
  kpi_metrics: string[];
  default_filters: FilterMap;
  charts: ChartConfig[];
}

export interface DashboardOut {
  id: string;
  dataset_id: string;
  name: string;
  description: string | null;
  config: DashboardConfig;
  created_at: string;
  updated_at: string;
}

export interface DashboardCreate {
  name: string;
  description?: string | null;
  config?: Partial<DashboardConfig>;
}

export interface DashboardUpdate {
  name?: string;
  description?: string | null;
  config?: Partial<DashboardConfig>;
}

// ── Форматы данных для чартов ──────────────────────────────────────────────

export interface KpiCard {
  metric: string;
  display_name: string;
  value: number | null;
  aggregation: string;
  display_format: string;
}

export interface TimeseriesPoint {
  period: string;
  value: number | null;
  series: string | null;
}

export interface TimeseriesData {
  chart_id: string;
  title: string;
  series_names: string[];
  points: TimeseriesPoint[];
  execution_ms: number;
}

export interface CategoryPoint {
  category: string;
  values: Record<string, number | null>;
  [key: string]: unknown;  // для доступа по имени dimension-колонки
}

export interface CategoryData {
  chart_id: string;
  title: string;
  categories: string[];
  metrics: string[];
  points: CategoryPoint[];
  execution_ms: number;
}

export interface PieSlice {
  name: string;
  value: number | null;
  percentage: number | null;
}

export interface PieData {
  chart_id: string;
  title: string;
  metric: string;
  total: number | null;
  slices: PieSlice[];
  execution_ms: number;
}

export interface TreemapNode {
  name: string;
  value: number | null;
  children: TreemapNode[];
}

export interface TreemapData {
  chart_id: string;
  title: string;
  metric: string;
  root: TreemapNode;
  execution_ms: number;
}

export interface TableData {
  chart_id: string;
  title: string;
  columns: string[];
  rows: Record<string, unknown>[];
  total_rows: number;
  execution_ms: number;
}

export interface DrilldownRequest {
  hierarchy_group: string;
  current_level: number;
  parent_value?: string | null;
  metrics: string[];
  extra_filters?: FilterMap;
}

export interface DrilldownData {
  next_dimension: string;
  parent_value: string | null;
  points: CategoryPoint[];
  execution_ms: number;
}
