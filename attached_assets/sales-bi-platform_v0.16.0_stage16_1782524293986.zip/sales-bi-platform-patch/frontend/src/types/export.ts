// VERSION: 1.0.0
// Path: frontend/src/types/export.ts
// CHANGES v1.0.0:
//   - Этап 7: типы Export Module, зеркалирующие backend/app/schemas/export.py
import type { FilterMap } from "./query";

export type ExportFormat = "csv" | "xlsx" | "pdf";

export interface ExportRequest {
  dimensions: string[];
  metrics: string[];
  filters: FilterMap;
  order_by?: string | null;
  order_desc?: boolean;
  limit?: number;
  format: ExportFormat;
  title?: string;
  include_summary?: boolean;
}
