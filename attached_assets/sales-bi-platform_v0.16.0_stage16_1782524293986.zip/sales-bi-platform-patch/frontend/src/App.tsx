// VERSION: 2.3.0
// Path: frontend/src/App.tsx
// CHANGES v1.0.0:
//   - Этап 1: ThemeProvider + QueryClientProvider + StatusPage
// CHANGES v1.1.0:
//   - Этап 7: BrowserRouter + FiltersProvider + AppRoutes
// CHANGES v1.2.0:
//   - Этап 8: React Router v7 future flags
// CHANGES v2.0.0:
//   - Этап 9.1: добавлены AppThemeProvider (light/dark/neutral),
//     I18nProvider (9 языков), DashboardLayoutProvider (visible charts),
//     ThemeProvider берёт тему из AppThemeProvider динамически.
import { CssBaseline, ThemeProvider } from "@mui/material";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter } from "react-router-dom";
import { FiltersProvider } from "@/context/FiltersContext";
import { AppThemeProvider, useAppTheme } from "@/context/ThemeContext";
import { I18nProvider } from "@/context/I18nContext";
import { DashboardLayoutProvider } from "@/context/DashboardLayoutContext";
import { ModulesProvider } from "@/context/ModulesContext";
import { KpiTargetsProvider } from "@/modules/kpi/KpiTargetsContext";
import { NotificationProvider } from "@/context/NotificationContext";
import { AppRoutes } from "@/routes/AppRoutes";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: Number(import.meta.env.VITE_QUERY_RETRY_COUNT ?? 1),
      refetchOnWindowFocus: false,
    },
  },
});

/** Внутренний компонент — берёт тему из AppThemeProvider */
function ThemedApp() {
  const { theme } = useAppTheme();
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <FiltersProvider>
        <NotificationProvider>
        <ModulesProvider>
          <KpiTargetsProvider>
          <DashboardLayoutProvider>
          <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
            <AppRoutes />
          </BrowserRouter>
          </DashboardLayoutProvider>
          </KpiTargetsProvider>
        </ModulesProvider>
        </NotificationProvider>
      </FiltersProvider>
    </ThemeProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <AppThemeProvider>
          <ThemedApp />
        </AppThemeProvider>
      </I18nProvider>
    </QueryClientProvider>
  );
}
