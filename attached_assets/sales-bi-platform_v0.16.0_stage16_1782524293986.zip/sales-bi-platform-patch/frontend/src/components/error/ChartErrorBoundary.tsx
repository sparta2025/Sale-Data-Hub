// VERSION: 1.0.0
// Path: frontend/src/components/error/ChartErrorBoundary.tsx
// CHANGES v1.0.0:
//   - Этап 10: error boundary для диаграмм — перехватывает runtime-ошибки
//     рендера, выводит понятное сообщение вместо белого экрана.
//     Кнопка «Перезагрузить» сбрасывает состояние boundary.
import { Component, type ReactNode, type ErrorInfo } from "react";
import { Paper, Typography, Box, Button } from "@mui/material";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import RefreshIcon from "@mui/icons-material/Refresh";

interface Props { children: ReactNode; title?: string; height?: number; }
interface State { hasError: boolean; message: string; }

export class ChartErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[ChartErrorBoundary]", error, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <Paper
        variant="outlined"
        sx={{
          p: 2, height: this.props.height ?? 380,
          display: "flex", flexDirection: "column",
          alignItems: "center", justifyContent: "center",
          gap: 1, color: "text.secondary",
        }}
      >
        <ErrorOutlineIcon color="warning" sx={{ fontSize: 40 }} />
        <Typography variant="subtitle2" color="text.secondary">
          {this.props.title ? `Ошибка диаграммы: ${this.props.title}` : "Ошибка отрисовки диаграммы"}
        </Typography>
        <Typography variant="caption" color="text.disabled" sx={{ maxWidth: 320, textAlign: "center" }}>
          {this.state.message}
        </Typography>
        <Button
          size="small"
          startIcon={<RefreshIcon />}
          onClick={() => this.setState({ hasError: false, message: "" })}
        >
          Перезагрузить
        </Button>
      </Paper>
    );
  }
}
