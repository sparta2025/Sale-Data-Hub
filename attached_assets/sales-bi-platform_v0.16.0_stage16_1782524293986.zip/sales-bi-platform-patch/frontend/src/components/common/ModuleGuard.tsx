// VERSION: 1.0.0
// Path: frontend/src/components/common/ModuleGuard.tsx
// CHANGES v1.0.0:
//   - Этап 14: HOC-заглушка для locked-модулей.
//     Если модуль заблокирован подпиской — показывает upgrade-prompt
//     вместо контента. Кнопка «Попробовать» активирует trial.
//     Кнопка «Все инструменты» → Tools Board.
import type { ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { Box, Typography, Button, Paper, Stack, Chip } from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import RocketLaunchIcon from "@mui/icons-material/RocketLaunch";
import GridViewIcon from "@mui/icons-material/GridView";
import { useModules } from "@/context/ModulesContext";

const TIER_LABELS: Record<string, string> = {
  free: "Free", pro: "Pro", enterprise: "Enterprise",
};
const TIER_COLORS: Record<string, string> = {
  free: "#22c55e", pro: "#7c3aed", enterprise: "#f59e0b",
};

interface ModuleGuardProps {
  moduleId: string;
  children: ReactNode;
}

export function ModuleGuard({ moduleId, children }: ModuleGuardProps) {
  const navigate   = useNavigate();
  const { isModuleActive, isModuleLocked, startTrial, getModule } = useModules();

  if (isModuleActive(moduleId)) return <>{children}</>;

  const manifest = getModule(moduleId);
  const tier     = manifest?.tier ?? "pro";
  const color    = TIER_COLORS[tier];

  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight={400}>
      <Paper
        variant="outlined"
        sx={{ p: 4, maxWidth: 440, textAlign: "center", borderColor: color, borderWidth: 2 }}
      >
        <Box
          sx={{
            width: 64, height: 64, borderRadius: "50%",
            backgroundColor: `${color}18`,
            display: "flex", alignItems: "center", justifyContent: "center",
            mx: "auto", mb: 2,
          }}
        >
          <LockIcon sx={{ color, fontSize: 32 }} />
        </Box>

        <Chip
          label={`Требуется ${TIER_LABELS[tier]} план`}
          size="small"
          sx={{ mb: 2, backgroundColor: `${color}18`, color, fontWeight: 700 }}
        />

        <Typography variant="h6" fontWeight={700} mb={1}>
          {manifest?.name ?? moduleId}
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          {manifest?.description ?? "Этот модуль недоступен в вашем текущем плане."}
        </Typography>

        <Stack gap={1.5}>
          {isModuleLocked(moduleId) && (
            <Button
              variant="contained"
              startIcon={<RocketLaunchIcon />}
              onClick={() => startTrial(moduleId)}
              sx={{ backgroundColor: color, "&:hover": { backgroundColor: color, opacity: 0.9 } }}
              fullWidth
            >
              Попробовать бесплатно 14 дней
            </Button>
          )}
          <Button
            variant="outlined"
            startIcon={<GridViewIcon />}
            onClick={() => navigate("/tools")}
            fullWidth
          >
            Все инструменты
          </Button>
        </Stack>
      </Paper>
    </Box>
  );
}
