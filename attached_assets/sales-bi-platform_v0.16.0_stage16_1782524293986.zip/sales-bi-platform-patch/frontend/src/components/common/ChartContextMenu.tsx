// VERSION: 1.0.0
// Path: frontend/src/components/common/ChartContextMenu.tsx
// CHANGES v1.0.0:
//   - Новый: контекстное меню (правая кнопка мыши) для любой диаграммы.
//     Пункт МАСШТАБ → Расширить на ширину / Во весь экран / По умолчанию / Растянуть.
//     Закрывается по клику снаружи или Escape.
import { useEffect, useRef } from "react";
import {
  Paper, MenuList, MenuItem, ListItemIcon, ListItemText,
  Divider, Typography,
} from "@mui/material";
import FullscreenIcon from "@mui/icons-material/Fullscreen";
import FullscreenExitIcon from "@mui/icons-material/FullscreenExit";
import AspectRatioIcon from "@mui/icons-material/AspectRatio";
import OpenInFullIcon from "@mui/icons-material/OpenInFull";
import PhotoSizeSelectSmallIcon from "@mui/icons-material/PhotoSizeSelectSmall";

export type ScaleMode = "default" | "fullWidth" | "fullScreen";

interface ChartContextMenuProps {
  open: boolean;
  x: number;
  y: number;
  onClose: () => void;
  currentScale: ScaleMode;
  onScale: (mode: ScaleMode) => void;
  onResizeCorner?: () => void;
}

export function ChartContextMenu({
  open, x, y, onClose, currentScale, onScale, onResizeCorner,
}: ChartContextMenuProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handle = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent && e.key === "Escape") { onClose(); return; }
      if (e instanceof MouseEvent && ref.current && !ref.current.contains(e.target as Node)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handle);
    document.addEventListener("keydown", handle);
    return () => {
      document.removeEventListener("mousedown", handle);
      document.removeEventListener("keydown", handle);
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <Paper
      ref={ref}
      elevation={8}
      sx={{
        position: "fixed",
        top: y,
        left: x,
        zIndex: 9999,
        minWidth: 230,
        py: 0.5,
        borderRadius: 2,
        border: "1px solid",
        borderColor: "divider",
      }}
    >
      <Typography variant="caption" sx={{ px: 2, py: 0.5, display: "block", color: "text.secondary", fontWeight: 700, letterSpacing: 0.5 }}>
        МАСШТАБ
      </Typography>
      <Divider sx={{ mb: 0.5 }} />
      <MenuList dense disablePadding>
        <MenuItem
          selected={currentScale === "fullWidth"}
          onClick={() => { onScale("fullWidth"); onClose(); }}
        >
          <ListItemIcon><OpenInFullIcon fontSize="small" /></ListItemIcon>
          <ListItemText primary="Расширить на ширину страницы" />
        </MenuItem>
        <MenuItem
          selected={currentScale === "fullScreen"}
          onClick={() => { onScale("fullScreen"); onClose(); }}
        >
          <ListItemIcon><FullscreenIcon fontSize="small" /></ListItemIcon>
          <ListItemText primary="Во весь экран" />
        </MenuItem>
        <MenuItem
          selected={currentScale === "default"}
          onClick={() => { onScale("default"); onClose(); }}
        >
          <ListItemIcon><FullscreenExitIcon fontSize="small" /></ListItemIcon>
          <ListItemText primary="По умолчанию" />
        </MenuItem>
        {onResizeCorner && (
          <MenuItem onClick={() => { onResizeCorner(); onClose(); }}>
            <ListItemIcon><AspectRatioIcon fontSize="small" /></ListItemIcon>
            <ListItemText primary="Растянуть (потянуть за угол)" secondary="Появится ручка в правом нижнем углу" />
          </MenuItem>
        )}
      </MenuList>
    </Paper>
  );
}
