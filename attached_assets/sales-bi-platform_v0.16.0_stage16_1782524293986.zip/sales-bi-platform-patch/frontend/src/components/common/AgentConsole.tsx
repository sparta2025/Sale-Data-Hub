// VERSION: 1.0.0
// Path: frontend/src/components/common/AgentConsole.tsx
// CHANGES v1.0.0:
//   - Этап 15: консоль событий AgentBus.
//     Floating кнопка (FAB) в левом нижнем углу → открывает коллапсируемый
//     drawer с лентой последних событий. Полезно для отладки интеграций
//     и разработки AI-агентов. В production можно скрыть через env.
//     Каждое событие: время, moduleId::hookId, payload JSON.
import { useState, useEffect, useRef } from "react";
import {
  Box, Typography, Paper, IconButton, Chip, Stack,
  Collapse, Divider, Tooltip,
} from "@mui/material";
import SmartToyIcon      from "@mui/icons-material/SmartToy";
import CloseIcon         from "@mui/icons-material/Close";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import CircleIcon        from "@mui/icons-material/Circle";
import { AgentBus, type AgentEvent } from "@/modules/agents/AgentBus";

const SHOW_IN_PROD = import.meta.env.VITE_AGENT_CONSOLE === "true";
const IS_DEV       = import.meta.env.DEV;

function EventRow({ evt }: { evt: AgentEvent }) {
  const time = new Date(evt.timestamp).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  return (
    <Box sx={{ py: 0.75, borderBottom: "1px solid", borderColor: "divider" }}>
      <Stack direction="row" alignItems="center" gap={0.75} mb={0.25}>
        <Typography variant="caption" color="text.disabled" sx={{ fontSize: "0.65rem", flexShrink: 0 }}>
          {time}
        </Typography>
        <Chip
          label={evt.moduleId}
          size="small"
          sx={{ height: 16, fontSize: "0.6rem", backgroundColor: "#7c3aed22", color: "#7c3aed" }}
        />
        <Typography variant="caption" sx={{ fontWeight: 700, fontSize: "0.7rem" }}>
          {evt.hookId}
        </Typography>
      </Stack>
      <Box
        component="pre"
        sx={{
          m: 0, fontSize: "0.65rem", color: "text.secondary",
          maxHeight: 60, overflow: "auto",
          backgroundColor: "action.hover",
          borderRadius: 0.5, px: 0.75, py: 0.25,
        }}
      >
        {JSON.stringify(evt.payload, null, 2)}
      </Box>
    </Box>
  );
}

export function AgentConsole() {
  const [open,   setOpen]   = useState(false);
  const [events, setEvents] = useState<AgentEvent[]>([]);
  const [pulse,  setPulse]  = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Загружаем существующие события
    setEvents(AgentBus.getLog(50));
    // Подписываемся на новые
    const unsub = AgentBus.subscribeAll((evt) => {
      setEvents(AgentBus.getLog(50));
      setPulse(true);
      setTimeout(() => setPulse(false), 1000);
    });
    return unsub;
  }, []);

  // Авто-скролл вниз при новом событии
  useEffect(() => {
    if (open && listRef.current) {
      listRef.current.scrollTop = 0; // новые события сверху
    }
  }, [events, open]);

  if (!IS_DEV && !SHOW_IN_PROD) return null;

  return (
    <Box sx={{ position: "fixed", bottom: 100, left: 16, zIndex: 1300 }}>
      {/* Floating кнопка */}
      <Tooltip title="Agent Console" placement="right">
        <Box
          onClick={() => setOpen((v) => !v)}
          sx={{
            width: 40, height: 40, borderRadius: "50%",
            backgroundColor: open ? "#7c3aed" : "background.paper",
            border: "2px solid",
            borderColor: pulse ? "#22c55e" : open ? "#7c3aed" : "divider",
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer", boxShadow: 3,
            transition: "border-color 0.3s, background-color 0.2s",
            "&:hover": { boxShadow: 6 },
          }}
        >
          <SmartToyIcon sx={{ fontSize: 20, color: open ? "#fff" : "text.secondary" }} />
          {events.length > 0 && (
            <CircleIcon sx={{
              position: "absolute", top: -2, right: -2, fontSize: 10,
              color: pulse ? "#22c55e" : "#7c3aed",
              transition: "color 0.3s",
            }} />
          )}
        </Box>
      </Tooltip>

      {/* Консоль */}
      <Collapse in={open} timeout={200}>
        <Paper
          elevation={8}
          sx={{
            position: "absolute",
            bottom: 48, left: 0,
            width: 340, maxHeight: 440,
            display: "flex", flexDirection: "column",
            border: "1px solid", borderColor: "#7c3aed44",
            borderRadius: 2, overflow: "hidden",
          }}
        >
          {/* Хедер */}
          <Stack direction="row" alignItems="center" justifyContent="space-between"
            sx={{ px: 1.5, py: 1, backgroundColor: "#7c3aed", color: "#fff" }}>
            <Stack direction="row" alignItems="center" gap={0.75}>
              <SmartToyIcon sx={{ fontSize: 16 }} />
              <Typography variant="caption" fontWeight={700}>Agent Console</Typography>
              <Chip label={events.length} size="small"
                sx={{ height: 16, fontSize: "0.6rem", backgroundColor: "rgba(255,255,255,0.2)", color: "#fff" }} />
            </Stack>
            <Stack direction="row">
              <IconButton size="small" sx={{ color: "#fff" }} onClick={() => { AgentBus.clearLog(); setEvents([]); }}>
                <DeleteOutlineIcon sx={{ fontSize: 16 }} />
              </IconButton>
              <IconButton size="small" sx={{ color: "#fff" }} onClick={() => setOpen(false)}>
                <CloseIcon sx={{ fontSize: 16 }} />
              </IconButton>
            </Stack>
          </Stack>

          <Divider />

          {/* Список событий */}
          <Box ref={listRef} sx={{ flex: 1, overflowY: "auto", p: 1 }}>
            {events.length === 0 && (
              <Typography variant="caption" color="text.disabled" display="block" textAlign="center" py={2}>
                Нет событий. Взаимодействуйте с платформой.
              </Typography>
            )}
            {events.map((evt, i) => <EventRow key={i} evt={evt} />)}
          </Box>

          {/* Футер */}
          <Box sx={{ px: 1.5, py: 0.75, backgroundColor: "action.hover" }}>
            <Typography variant="caption" color="text.disabled" sx={{ fontSize: "0.62rem" }}>
              AgentBus • подписки: active • {IS_DEV ? "DEV" : "PROD"}
            </Typography>
          </Box>
        </Paper>
      </Collapse>
    </Box>
  );
}
