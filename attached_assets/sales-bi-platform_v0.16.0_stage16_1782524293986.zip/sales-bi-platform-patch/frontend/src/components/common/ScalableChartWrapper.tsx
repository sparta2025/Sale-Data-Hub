// VERSION: 1.0.0
// Path: frontend/src/components/common/ScalableChartWrapper.tsx
// CHANGES v1.0.0:
//   - Новый: обёртка диаграмм с поддержкой контекстного меню (правая кнопка),
//     масштабирования (fullWidth / fullScreen / default) и ручки ресайза (правый нижний угол).
//     fullScreen использует Fullscreen API браузера с фоллбэком на CSS fixed.
import {
  useState, useRef, useCallback, useEffect, type ReactNode,
} from "react";
import { Box, Portal } from "@mui/material";
import { ChartContextMenu, type ScaleMode } from "./ChartContextMenu";

interface ScalableChartWrapperProps {
  children: ReactNode;
  /** Уникальный id для drag-and-drop (используется react-grid-layout) */
  chartId: string;
  /** Дополнительные sx для корневого Box */
  sx?: object;
}

export function ScalableChartWrapper({ children, chartId, sx }: ScalableChartWrapperProps) {
  const [scale, setScale]           = useState<ScaleMode>("default");
  const [menu, setMenu]             = useState<{ x: number; y: number } | null>(null);
  const [resizable, setResizable]   = useState(false);
  const [customHeight, setCustomH]  = useState<number | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const resizingRef = useRef(false);
  const startRef    = useRef({ y: 0, h: 0 });

  // Контекстное меню
  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Позиция с учётом края экрана
    const x = Math.min(e.clientX, window.innerWidth  - 240);
    const y = Math.min(e.clientY, window.innerHeight - 220);
    setMenu({ x, y });
  }, []);

  // Fullscreen API
  const handleScale = useCallback(async (mode: ScaleMode) => {
    setScale(mode);
    if (mode === "fullScreen" && wrapperRef.current) {
      try {
        await wrapperRef.current.requestFullscreen?.();
      } catch { /* браузер запретил */ }
    } else if (mode !== "fullScreen" && document.fullscreenElement) {
      document.exitFullscreen?.();
    }
  }, []);

  // Выход из fullscreen по кнопке браузера (Esc)
  useEffect(() => {
    const handler = () => {
      if (!document.fullscreenElement) setScale((s) => s === "fullScreen" ? "default" : s);
    };
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);

  // Ручка ресайза (нижний правый угол)
  const handleResizeStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    resizingRef.current = true;
    startRef.current = {
      y: e.clientY,
      h: wrapperRef.current?.getBoundingClientRect().height ?? 400,
    };
    const onMove = (ev: MouseEvent) => {
      if (!resizingRef.current) return;
      const delta = ev.clientY - startRef.current.y;
      setCustomH(Math.max(200, startRef.current.h + delta));
    };
    const onUp = () => { resizingRef.current = false; };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp, { once: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  // Стили контейнера в зависимости от режима
  const wrapperSx = scale === "fullWidth"
    ? { position: "relative" as const, width: "100%", mx: 0 }
    : scale === "fullScreen"
    ? { width: "100%", height: "100%", overflow: "auto", backgroundColor: "background.paper" }
    : { position: "relative" as const };

  return (
    <>
      <Box
        ref={wrapperRef}
        data-chart-id={chartId}
        onContextMenu={handleContextMenu}
        sx={{
          ...wrapperSx,
          ...(customHeight && scale === "default" ? { "& .recharts-wrapper, & .echarts-for-react": { height: `${customHeight}px !important` } } : {}),
          ...sx,
          // fullscreen нативный стиль
          "&:fullscreen": { p: 2, overflowY: "auto", backgroundColor: "background.default" },
          "&:-webkit-full-screen": { p: 2, overflowY: "auto" },
        }}
      >
        {children}

        {/* Ручка ресайза */}
        {resizable && scale === "default" && (
          <Box
            onMouseDown={handleResizeStart}
            sx={{
              position: "absolute",
              bottom: 4,
              right: 4,
              width: 16,
              height: 16,
              cursor: "nwse-resize",
              backgroundImage: "radial-gradient(circle, #94a3b8 1.5px, transparent 1.5px)",
              backgroundSize: "5px 5px",
              backgroundPosition: "0 0",
              opacity: 0.6,
              "&:hover": { opacity: 1 },
              zIndex: 10,
            }}
          />
        )}
      </Box>

      {/* Портал для меню — поверх всего */}
      <Portal>
        <ChartContextMenu
          open={Boolean(menu)}
          x={menu?.x ?? 0}
          y={menu?.y ?? 0}
          currentScale={scale}
          onClose={() => setMenu(null)}
          onScale={handleScale}
          onResizeCorner={() => setResizable((v) => !v)}
        />
      </Portal>
    </>
  );
}
