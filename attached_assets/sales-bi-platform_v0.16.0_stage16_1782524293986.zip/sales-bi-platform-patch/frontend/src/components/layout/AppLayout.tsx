// VERSION: 1.4.0
// Path: frontend/src/components/layout/AppLayout.tsx
// CHANGES v1.0.0:
//   - Этап 7: AppBar + Sidebar + Outlet
// CHANGES v1.1.0:
//   - Этап 8: поллинг /api/health через VITE_HEALTH_POLL_INTERVAL_MS
// CHANGES v1.2.0:
//   - Этап 10: i18n для статуса backend; статус «checking» больше не мигает
//     при каждом поллинге (только начальное состояние); заголовок из переводов.
import { useEffect, useState } from "react";
import { AppBar, Toolbar, Typography, Box, Chip, Stack } from "@mui/material";
import { Outlet } from "react-router-dom";
import { Sidebar, SIDEBAR_WIDTH } from "./Sidebar";
import { apiClient } from "@/api";
import { AgentConsole } from "@/components/common/AgentConsole";
import { usePlatformInfo } from "@/hooks/usePlatform";
import { useTranslation } from "@/context/I18nContext";

type BackendStatus = "checking" | "connected" | "unavailable";

function useBackendStatus() {
  const [status, setStatus] = useState<BackendStatus>("checking");
  const pollInterval = Number(import.meta.env.VITE_HEALTH_POLL_INTERVAL_MS ?? 30_000);

  useEffect(() => {
    let cancelled = false;
    const check = async () => {
      try {
        const { data } = await apiClient.get<{ status: string; postgres: string }>("/health");
        if (!cancelled) {
          setStatus(data.postgres === "connected" ? "connected" : "unavailable");
        }
      } catch {
        if (!cancelled) setStatus("unavailable");
      }
    };
    check();
    const interval = setInterval(check, pollInterval);
    return () => { cancelled = true; clearInterval(interval); };
  }, [pollInterval]);

  return status;
}

function PlatformVersionChip() {
  const { data } = usePlatformInfo();
  if (!data) return null;
  return (
    <Typography variant="caption" color="text.disabled" sx={{ mr: 1, fontSize: "0.7rem" }}>
      v{data.platform_version}
    </Typography>
  );
}

function StatusChip() {
  const status = useBackendStatus();

  // Метки статуса — не через i18n чтобы не зависеть от hook в дочернем компоненте
  // (хук уже в AppLayout, передаём лейблы напрямую)
  const CONFIG: Record<BackendStatus, { label: string; color: "success" | "warning" | "default" }> = {
    checking:    { label: "…",               color: "default"  },
    connected:   { label: "Backend подключён", color: "success" },
    unavailable: { label: "Backend недоступен", color: "warning" },
  };
  const { label, color } = CONFIG[status];
  return <Chip size="small" label={label} color={color} variant="outlined" />;
}

export function AppLayout() {
  return (
    <Box sx={{ display: "flex", minHeight: "100vh" }}>
      <AppBar
        position="fixed"
        color="inherit"
        elevation={0}
        sx={{
          width: `calc(100% - ${SIDEBAR_WIDTH}px)`,
          ml: `${SIDEBAR_WIDTH}px`,
          borderBottom: "1px solid",
          borderColor: "divider",
          zIndex: (theme) => theme.zIndex.drawer - 1,
        }}
      >
        <Toolbar>
          <Stack direction="row" justifyContent="space-between" alignItems="center" width="100%">
            <Typography variant="h6" noWrap fontWeight={600}>
              Sales BI Platform
            </Typography>
            <PlatformVersionChip />
            <StatusChip />
          </Stack>
        </Toolbar>
      </AppBar>

      <Sidebar />

      <Box
        component="main"
        sx={{ flexGrow: 1, p: 3, width: `calc(100% - ${SIDEBAR_WIDTH}px)`, minWidth: 0 }}
      >
        <Toolbar />
        <Outlet />
      </Box>
      <AgentConsole />
    </Box>
  );
}
