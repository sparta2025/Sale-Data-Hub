// VERSION: 2.3.0
// Path: frontend/src/components/layout/Sidebar.tsx
// CHANGES v1.0.0:
//   - Этап 7: базовая навигация
// CHANGES v1.1.0:
//   - Этап 8: ширина из .env
// CHANGES v2.0.0:
//   - Этап 9.1: accordion, список датасетов, чекбоксы диаграмм, настройки
// CHANGES v2.1.0:
//   - Этап 10: функциональный раздел «Сохранённые дашборды» — список с датой,
//     кнопка загрузки и удаления; useSavedDashboards из localStorage;
//     кнопка «Сохранить дашборд» в секции Дашборд; i18n через useTranslation.
import { useState } from "react";
import {
  Drawer, Toolbar, Box, Typography, Divider, IconButton, Tooltip,
  Accordion, AccordionSummary, AccordionDetails, List, ListItemButton,
  ListItemText, ListItemIcon, Checkbox, Chip, Stack, Select, MenuItem,
  FormControl, InputLabel, Button,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import FolderOpenIcon from "@mui/icons-material/FolderOpen";
import DashboardIcon from "@mui/icons-material/Dashboard";
import SpaceDashboardIcon from "@mui/icons-material/SpaceDashboard";
import SettingsIcon from "@mui/icons-material/Settings";
import PaletteIcon from "@mui/icons-material/Palette";
import TranslateIcon from "@mui/icons-material/Translate";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import SaveIcon from "@mui/icons-material/Save";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import GridViewIcon from "@mui/icons-material/GridView";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import RestoreIcon from "@mui/icons-material/Restore";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import { useNavigate } from "react-router-dom";
import { useFilters } from "@/context/FiltersContext";
import { useDatasets, useDataset } from "@/hooks/useDatasets";
import { useAppTheme, type ThemeMode } from "@/context/ThemeContext";
import { useTranslation } from "@/context/I18nContext";
import { useDashboardLayout, ALL_CHARTS } from "@/context/DashboardLayoutContext";
import { useSavedDashboards } from "@/hooks/useSavedDashboards";
import { useNotification } from "@/context/NotificationContext";
import { LOCALE_LABELS, type LocaleCode } from "@/locales";
import type { DatasetOut } from "@/types";

export const SIDEBAR_WIDTH = Number(import.meta.env.VITE_SIDEBAR_WIDTH ?? 260);

const PRIMARY = "#2563eb";
const PRIMARY_LIGHT = "#dbeafe";

function DatasetItem({ dataset, isActive, onClick }: {
  dataset: DatasetOut; isActive: boolean; onClick: () => void;
}) {
  return (
    <ListItemButton
      selected={isActive}
      onClick={onClick}
      sx={{
        borderRadius: 1, mb: 0.25, py: 0.75,
        "&.Mui-selected": { backgroundColor: `${PRIMARY}14`, "& .MuiListItemText-primary": { color: PRIMARY, fontWeight: 700 } },
        "&.Mui-selected:hover": { backgroundColor: `${PRIMARY}1e` },
      }}
    >
      <ListItemIcon sx={{ minWidth: 32 }}>
        <FolderOpenIcon fontSize="small" sx={{ color: isActive ? PRIMARY : "text.secondary" }} />
      </ListItemIcon>
      <ListItemText
        primary={dataset.name}
        primaryTypographyProps={{ variant: "body2", noWrap: true }}
        secondary={isActive ? "Текущий" : undefined}
        secondaryTypographyProps={{ variant: "caption", color: PRIMARY }}
      />
      {isActive && <Box sx={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: PRIMARY, flexShrink: 0 }} />}
    </ListItemButton>
  );
}

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });
  } catch { return iso; }
}

export function Sidebar() {
  const navigate   = useNavigate();
  const { datasetId, setDatasetId, filters } = useFilters();
  const { data: datasets }          = useDatasets();
  const { data: currentDataset }    = useDataset(datasetId ?? undefined);
  const { mode: themeMode, setMode: setThemeMode } = useAppTheme();
  const { locale, setLocale, t }    = useTranslation();
  const { visibleCharts, toggleChart, showAll, getSnapshot, restoreSnapshot } = useDashboardLayout();
  const { list: savedList, save: saveDash, deleteById } = useSavedDashboards();
  const notify = useNotification();
  const [expanded, setExpanded]     = useState<string | false>("datasets");

  const handleAccordion = (panel: string) => (_: React.SyntheticEvent, isOpen: boolean) => {
    setExpanded(isOpen ? panel : false);
  };

  const handleDatasetClick = (id: string) => {
    setDatasetId(id);
    navigate(`/datasets/${id}/overview`);
  };

  const handleSave = () => {
    if (!datasetId) return;
    const snap = getSnapshot();
    const date = new Date().toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "2-digit" });
    const time = new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
    saveDash({
      name: `${currentDataset?.name ?? "Датасет"} — ${date} ${time}`,
      datasetId: datasetId,
      datasetName: currentDataset?.name ?? "",
      primaryMetric: snap.primaryMetric ?? "",
      visibleCharts: snap.visibleCharts,
      filters,
      layouts: snap.layouts,
    });
    notify.success(`Дашборд сохранён: ${currentDataset?.name ?? "Датасет"} — ${date} ${time}`);
  };

  const handleLoad = (entry: ReturnType<typeof useSavedDashboards>["list"][number]) => {
    if (entry.datasetId !== datasetId) {
      setDatasetId(entry.datasetId);
      navigate(`/datasets/${entry.datasetId}/overview`);
    }
    restoreSnapshot({
      visibleCharts: entry.visibleCharts,
      layouts: entry.layouts,
      primaryMetric: entry.primaryMetric,
    });
  };

  const accordionSx = {
    boxShadow: "none",
    "&:before": { display: "none" },
    borderRadius: "0 !important",
    backgroundColor: "transparent",
  };
  const summarySx = {
    minHeight: 44,
    "&.Mui-expanded": { minHeight: 44 },
    px: 2,
    "& .MuiAccordionSummary-content": { my: 0.75 },
  };

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: SIDEBAR_WIDTH, flexShrink: 0,
        [`& .MuiDrawer-paper`]: { width: SIDEBAR_WIDTH, boxSizing: "border-box", display: "flex", flexDirection: "column", overflow: "hidden" },
      }}
    >
      <Toolbar sx={{ px: 2, flexShrink: 0 }}>
        <Typography variant="h6" noWrap fontWeight={700} color="primary">Sales BI</Typography>
      </Toolbar>
      <Divider />

      {/* Quick nav — Tools Board + KPI */}
      <Box sx={{ px: 1.5, py: 1, borderBottom: "1px solid", borderColor: "divider" }}>
        <Stack direction="row" gap={0.75}>
          <Button size="small" startIcon={<GridViewIcon sx={{ fontSize: 14 }} />}
            onClick={() => navigate("/tools")}
            sx={{ fontSize: "0.7rem", color: "text.secondary", flex: 1, justifyContent: "flex-start" }}>
            Tools Board
          </Button>
          {datasetId && (
            <Button size="small" startIcon={<TrendingUpIcon sx={{ fontSize: 14 }} />}
              onClick={() => navigate(`/kpi/${datasetId}`)}
              sx={{ fontSize: "0.7rem", color: "#7c3aed", flex: 1, justifyContent: "flex-start" }}>
              KPI
            </Button>
          )}
        </Stack>
      </Box>

      <Box sx={{ flex: 1, overflowY: "auto" }}>

        {/* === Датасеты === */}
        <Accordion expanded={expanded === "datasets"} onChange={handleAccordion("datasets")} sx={accordionSx}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={summarySx}>
            <Stack direction="row" alignItems="center" gap={1}>
              <FolderOpenIcon fontSize="small" color="primary" />
              <Typography variant="body2" fontWeight={600}>{t.nav.datasets}</Typography>
              {datasets?.length ? (
                <Chip label={datasets.length} size="small"
                  sx={{ height: 18, fontSize: "0.65rem", backgroundColor: PRIMARY, color: "#fff" }} />
              ) : null}
            </Stack>
          </AccordionSummary>
          <AccordionDetails sx={{ px: 1, pt: 0, pb: 1 }}>
            {!datasets?.length && <Typography variant="caption" color="text.secondary" sx={{ px: 1 }}>{t.datasets.noDatasets}</Typography>}
            <List dense disablePadding>
              {(datasets ?? []).map((ds) => (
                <DatasetItem key={ds.id} dataset={ds} isActive={ds.id === datasetId} onClick={() => handleDatasetClick(ds.id)} />
              ))}
            </List>
            <Button size="small" fullWidth variant="outlined"
              sx={{ mt: 1, borderColor: PRIMARY, color: PRIMARY, fontSize: "0.72rem" }}
              onClick={() => navigate("/datasets")}
            >{t.datasets.upload}</Button>
          </AccordionDetails>
        </Accordion>

        <Divider />

        {/* === Дашборд — диаграммы + кнопка сохранить === */}
        <Accordion expanded={expanded === "dashboard"} onChange={handleAccordion("dashboard")} sx={accordionSx} disabled={!datasetId}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={summarySx}>
            <Stack direction="row" alignItems="center" gap={1}>
              <DashboardIcon fontSize="small" color={datasetId ? "primary" : "disabled"} />
              <Typography variant="body2" fontWeight={600} color={datasetId ? "text.primary" : "text.disabled"}>{t.nav.dashboard}</Typography>
              <Chip label={`${visibleCharts.size}/${ALL_CHARTS.length}`} size="small"
                sx={{ height: 18, fontSize: "0.65rem", backgroundColor: visibleCharts.size > 0 ? PRIMARY : "#94a3b8", color: "#fff" }} />
            </Stack>
          </AccordionSummary>
          <AccordionDetails sx={{ px: 1, pt: 0, pb: 1 }}>
            <Stack direction="row" gap={0.5} mb={0.5}>
              <Button size="small" onClick={showAll} sx={{ color: PRIMARY, fontSize: "0.7rem", flex: 1 }}>Все</Button>
              <Button size="small" startIcon={<SaveIcon sx={{ fontSize: 14 }} />}
                onClick={handleSave} disabled={!datasetId}
                sx={{ color: PRIMARY, fontSize: "0.7rem", flex: 1 }}>
                {t.savedDashboards.save}
              </Button>
            </Stack>
            <List dense disablePadding>
              {ALL_CHARTS.map((chart) => {
                const isVisible = visibleCharts.has(chart.id);
                return (
                  <ListItemButton key={chart.id} onClick={() => toggleChart(chart.id)}
                    sx={{ borderRadius: 1, py: 0.5, mb: 0.25,
                      backgroundColor: isVisible ? `${PRIMARY}0d` : "transparent",
                      "&:hover": { backgroundColor: isVisible ? `${PRIMARY}18` : PRIMARY_LIGHT } }}>
                    <ListItemIcon sx={{ minWidth: 28 }}>
                      {isVisible
                        ? <CheckBoxIcon fontSize="small" sx={{ color: PRIMARY }} />
                        : <CheckBoxOutlineBlankIcon fontSize="small" sx={{ color: "#94a3b8" }} />}
                    </ListItemIcon>
                    <ListItemText
                      primary={(t.chartNames as Record<string, string>)[chart.id] ?? chart.id}
                      secondary={chart.description}
                      primaryTypographyProps={{ variant: "caption", fontWeight: isVisible ? 700 : 400, color: isVisible ? PRIMARY : "text.primary" }}
                      secondaryTypographyProps={{ variant: "caption", fontSize: "0.64rem", noWrap: true }}
                    />
                  </ListItemButton>
                );
              })}
            </List>
          </AccordionDetails>
        </Accordion>

        <Divider />

        {/* === Сохранённые дашборды === */}
        <Accordion expanded={expanded === "saved"} onChange={handleAccordion("saved")} sx={accordionSx}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={summarySx}>
            <Stack direction="row" alignItems="center" gap={1}>
              <SpaceDashboardIcon fontSize="small" color="primary" />
              <Typography variant="body2" fontWeight={600}>{t.nav.savedDashboards}</Typography>
              {savedList.length > 0 && (
                <Chip label={savedList.length} size="small"
                  sx={{ height: 18, fontSize: "0.65rem", backgroundColor: PRIMARY, color: "#fff" }} />
              )}
            </Stack>
          </AccordionSummary>
          <AccordionDetails sx={{ px: 1, pt: 0, pb: 1 }}>
            {savedList.length === 0 && (
              <Typography variant="caption" color="text.secondary" sx={{ px: 1, display: "block", py: 0.5 }}>
                {t.savedDashboards.noSaved}
              </Typography>
            )}
            <List dense disablePadding>
              {savedList.map((entry) => (
                <Box key={entry.id} sx={{
                  borderRadius: 1, mb: 0.5, border: "1px solid", borderColor: "divider",
                  "&:hover": { borderColor: PRIMARY, backgroundColor: `${PRIMARY}06` },
                  transition: "border-color 0.15s",
                }}>
                  <Stack direction="row" alignItems="center" px={1} pt={0.75} pb={0.25}>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography variant="caption" fontWeight={700} noWrap display="block" title={entry.name}>
                        {entry.name}
                      </Typography>
                      <Stack direction="row" alignItems="center" gap={0.5}>
                        <AccessTimeIcon sx={{ fontSize: 10, color: "text.disabled" }} />
                        <Typography variant="caption" color="text.disabled" sx={{ fontSize: "0.62rem" }}>
                          {formatDate(entry.createdAt)}
                        </Typography>
                      </Stack>
                    </Box>
                    <Stack direction="row">
                      <Tooltip title={t.savedDashboards.open}>
                        <IconButton size="small" onClick={() => handleLoad(entry)}>
                          <RestoreIcon sx={{ fontSize: 16, color: PRIMARY }} />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title={t.savedDashboards.delete}>
                        <IconButton size="small" onClick={() => { deleteById(entry.id); notify.info("Дашборд удалён"); }}>
                          <DeleteOutlineIcon sx={{ fontSize: 16, color: "#ef4444" }} />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </Stack>
                  <Box px={1} pb={0.75}>
                    <Stack direction="row" gap={0.5} flexWrap="wrap">
                      <Chip label={entry.datasetName} size="small"
                        sx={{ height: 16, fontSize: "0.6rem", backgroundColor: `${PRIMARY}14`, color: PRIMARY }} />
                      <Chip label={`${entry.visibleCharts.length} диаграмм`} size="small"
                        sx={{ height: 16, fontSize: "0.6rem" }} />
                    </Stack>
                  </Box>
                </Box>
              ))}
            </List>
          </AccordionDetails>
        </Accordion>

        <Divider />

        {/* === Настройки === */}
        <Accordion expanded={expanded === "settings"} onChange={handleAccordion("settings")} sx={accordionSx}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={summarySx}>
            <Stack direction="row" alignItems="center" gap={1}>
              <SettingsIcon fontSize="small" sx={{ color: "text.secondary" }} />
              <Typography variant="body2" fontWeight={600}>Настройки</Typography>
            </Stack>
          </AccordionSummary>
          <AccordionDetails sx={{ px: 2, pt: 0.5, pb: 1.5 }}>
            <Stack gap={1.5}>
              <FormControl size="small" fullWidth>
                <InputLabel sx={{ fontSize: "0.78rem" }}>
                  <Stack direction="row" alignItems="center" gap={0.5}>
                    <PaletteIcon sx={{ fontSize: 14 }} />{t.settings.theme}
                  </Stack>
                </InputLabel>
                <Select value={themeMode} label={`  ${t.settings.theme}`}
                  onChange={(e) => setThemeMode(e.target.value as ThemeMode)}
                  sx={{ fontSize: "0.8rem" }}>
                  {([
                    ["light",   t.settings.themeLight],
                    ["dark",    t.settings.themeDark],
                    ["neutral", t.settings.themeNeutral],
                  ] as [ThemeMode, string][]).map(([key, label]) => (
                    <MenuItem key={key} value={key} sx={{ fontSize: "0.8rem" }}>{label}</MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl size="small" fullWidth>
                <InputLabel sx={{ fontSize: "0.78rem" }}>
                  <Stack direction="row" alignItems="center" gap={0.5}>
                    <TranslateIcon sx={{ fontSize: 14 }} />{t.settings.language}
                  </Stack>
                </InputLabel>
                <Select value={locale} label={`  ${t.settings.language}`}
                  onChange={(e) => setLocale(e.target.value as LocaleCode)}
                  sx={{ fontSize: "0.8rem" }}>
                  {(Object.entries(LOCALE_LABELS) as [LocaleCode, string][]).map(([code, label]) => (
                    <MenuItem key={code} value={code} sx={{ fontSize: "0.8rem" }}>{label}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>
          </AccordionDetails>
        </Accordion>
      </Box>

      <Divider />
      <Box sx={{ p: 1.5, flexShrink: 0 }}>
        <Typography variant="caption" color="text.secondary">
          Sales BI Platform · v0.15.0
        </Typography>
      </Box>
    </Drawer>
  );
}
