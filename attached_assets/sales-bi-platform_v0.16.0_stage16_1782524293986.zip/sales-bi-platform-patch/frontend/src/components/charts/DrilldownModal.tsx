// VERSION: 1.0.0
// Path: frontend/src/components/charts/DrilldownModal.tsx
// CHANGES v1.0.0:
//   - Этап 9: модальное окно drill-down — отображает CategoryData следующего
//     уровня иерархии (горизонтальный бар ECharts) при клике на элемент чарта
import { useMemo } from "react";
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Typography, Stack, Chip, CircularProgress, Alert,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ReactECharts from "echarts-for-react";
import type { EChartsOption } from "echarts";
import { formatValue, formatCompact } from "@/utils/formatValue";
import { CHART_COLORS, CHART_GRID_DEFAULT, AXIS_LABEL_COLOR, AXIS_LINE_COLOR } from "./chartTheme";
import type { DrilldownData, MetricOut } from "@/types";

interface DrilldownModalProps {
  open: boolean;
  onClose: () => void;
  data: DrilldownData | undefined;
  isLoading: boolean;
  error: Error | null;
  parentValue: string | null;
  metricMeta: MetricOut | undefined;
}

export function DrilldownModal({
  open: isOpen, onClose, data, isLoading, error, parentValue, metricMeta,
}: DrilldownModalProps) {
  const valueFormat = metricMeta?.display_format ?? "{:,.2f}";

  const option = useMemo<EChartsOption | null>(() => {
    if (!data || data.points.length === 0) return null;

    const sorted = [...data.points].sort(
      (a, b) => ((b.values[metricMeta?.column_name ?? ""] as number) ?? 0)
               - ((a.values[metricMeta?.column_name ?? ""] as number) ?? 0),
    );

    const metricKey = metricMeta?.column_name ?? Object.keys(data.points[0]?.values ?? {})[0] ?? "";
    const categories = sorted.map((p) => p[data.next_dimension] as string ?? String(p));
    const values = sorted.map((p) => (p.values[metricKey] as number) ?? 0);

    return {
      grid: { ...CHART_GRID_DEFAULT, left: 16, bottom: 8 },
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "shadow" },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        valueFormatter: (v: any) => formatValue(v as number, valueFormat),
      },
      xAxis: {
        type: "value",
        axisLabel: { color: AXIS_LABEL_COLOR, formatter: (v: number) => formatCompact(v) },
        splitLine: { lineStyle: { color: AXIS_LINE_COLOR } },
      },
      yAxis: {
        type: "category",
        data: [...categories].reverse(),
        axisLine: { lineStyle: { color: AXIS_LINE_COLOR } },
        axisLabel: { color: AXIS_LABEL_COLOR },
      },
      series: [{
        type: "bar",
        data: [...values].reverse(),
        color: CHART_COLORS[1],
        barMaxWidth: 24,
        itemStyle: { borderRadius: [0, 4, 4, 0] },
      }],
    };
  }, [data, metricMeta, valueFormat]);

  const metricName = metricMeta?.display_name ?? "Метрика";

  return (
    <Dialog open={isOpen} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap">
          <Typography variant="h6">Детализация</Typography>
          {parentValue && (
            <Chip size="small" label={parentValue} color="primary" variant="outlined" />
          )}
          {data?.next_dimension && (
            <Typography variant="body2" color="text.secondary">
              → {data.next_dimension}
            </Typography>
          )}
        </Stack>
      </DialogTitle>

      <DialogContent>
        {isLoading && (
          <Stack alignItems="center" py={4}>
            <CircularProgress />
            <Typography variant="body2" color="text.secondary" mt={1}>Загружаем данные…</Typography>
          </Stack>
        )}
        {error && <Alert severity="error">{error.message}</Alert>}

        {!isLoading && !error && data && (
          <>
            {data.points.length === 0 ? (
              <Alert severity="info">
                Нет данных для детализации на следующем уровне.
              </Alert>
            ) : (
              <>
                <Typography variant="body2" color="text.secondary" mb={2}>
                  {metricName} · {data.points.length} позиций
                  {data.execution_ms > 0 && ` · ${data.execution_ms.toFixed(0)} мс`}
                </Typography>
                {option && (
                  <ReactECharts
                    option={option}
                    style={{ height: Math.max(240, data.points.length * 32), width: "100%" }}
                    notMerge
                  />
                )}
              </>
            )}
          </>
        )}
      </DialogContent>

      <DialogActions>
        <Button startIcon={<ArrowBackIcon />} onClick={onClose}>
          Назад
        </Button>
      </DialogActions>
    </Dialog>
  );
}
