// VERSION: 1.0.0
// Path: frontend/src/components/charts/ScatterChartCard.tsx
// CHANGES v1.0.0:
//   - Новый: точечная диаграмма (scatter plot) — зависимость двух числовых метрик,
//     группировка по категориальному измерению. Каждая точка — агрегат по категории.
//     Tooltip показывает категорию и оба значения. Регрессионная линия опциональна.
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useRunQuery } from "@/hooks/useQueryEngine";
import { useFilters } from "@/context/FiltersContext";
import { formatValue } from "@/utils/formatValue";
import { CHART_COLORS } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface ScatterChartCardProps {
  title: string;
  dimension: string;
  metricX: string;
  metricY: string;
  metricXLabel?: string;
  metricYLabel?: string;
  valueFormat?: string;
  height?: number;
  showTrendLine?: boolean;
  limit?: number;
}

export function ScatterChartCard({
  title, dimension, metricX, metricY,
  metricXLabel, metricYLabel,
  valueFormat = "{:,.0f}",
  height = 340,
  showTrendLine = true,
  limit = 100,
}: ScatterChartCardProps) {
  const { datasetId, filters } = useFilters();

  const { data, isLoading, error } = useRunQuery(
    datasetId ?? undefined,
    {
      dimensions: [dimension],
      metrics: [metricX, metricY],
      filters,
      limit,
    },
  );

  const { option, isEmpty } = useMemo<{ option: EChartsOption | null; isEmpty: boolean }>(() => {
    if (!data?.rows?.length) return { option: null, isEmpty: true };

    const points = data.rows.map((r) => [
      Number(r[metricX] ?? 0),
      Number(r[metricY] ?? 0),
      String(r[dimension] ?? ""),
    ]);

    // Простая линия тренда (МНК)
    let markLine: EChartsOption["series"] extends Array<infer S> ? S : never = undefined as never;
    if (showTrendLine && points.length >= 2) {
      const xs = points.map((p) => p[0] as number);
      const ys = points.map((p) => p[1] as number);
      const n = xs.length;
      const sx  = xs.reduce((a, b) => a + b, 0);
      const sy  = ys.reduce((a, b) => a + b, 0);
      const sxy = xs.reduce((a, b, i) => a + b * ys[i], 0);
      const sx2 = xs.reduce((a, b) => a + b * b, 0);
      const slope = (n * sxy - sx * sy) / (n * sx2 - sx * sx);
      const intercept = (sy - slope * sx) / n;
      const xMin = Math.min(...xs);
      const xMax = Math.max(...xs);
      markLine = {
        type: "line" as const,
        data: [[{ coord: [xMin, slope * xMin + intercept] }, { coord: [xMax, slope * xMax + intercept] }]],
        lineStyle: { type: "dashed", color: "#94a3b8", width: 1.5 },
        symbol: ["none", "none"],
      } as never;
    }

    const option: EChartsOption = {
      grid: { left: 64, right: 24, top: 24, bottom: 64 },
      tooltip: {
        trigger: "item",
        formatter: (params: { data: unknown[] }) => {
          const [x, y, name] = params.data as [number, number, string];
          return `<strong>${name}</strong><br/>${metricXLabel ?? metricX}: ${formatValue(x, valueFormat)}<br/>${metricYLabel ?? metricY}: ${formatValue(y, valueFormat)}`;
        },
      },
      xAxis: {
        type: "value",
        name: metricXLabel ?? metricX,
        nameLocation: "middle",
        nameGap: 40,
        axisLabel: { formatter: (v: number) => formatValue(v, "{:,.0f}") },
      },
      yAxis: {
        type: "value",
        name: metricYLabel ?? metricY,
        nameLocation: "middle",
        nameGap: 56,
        axisLabel: { formatter: (v: number) => formatValue(v, "{:,.0f}") },
      },
      series: [
        {
          type: "scatter",
          data: points,
          symbolSize: 10,
          itemStyle: { color: CHART_COLORS[0], opacity: 0.82 },
          label: {
            show: points.length <= 20,
            formatter: (p: { data: unknown[] }) => String((p.data as unknown[])[2]),
            position: "top",
            fontSize: 11,
            color: "#64748b",
          },
          ...(showTrendLine && markLine ? { markLine } : {}),
        },
      ],
    };
    return { option, isEmpty: false };
  }, [data, dimension, metricX, metricY, metricXLabel, metricYLabel, valueFormat, showTrendLine]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      height={height}
      isEmpty={isEmpty}
    />
  );
}
