// VERSION: 2.1.0
// Path: frontend/src/components/charts/BranchMapCard.tsx
// CHANGES v1.0.0:
//   - Этап 9: базовая карта филиалов Leaflet + CircleMarker по метрике
// CHANGES v2.0.0:
//   - Этап 9.1 (промежуточный): полная интерактивная карта.
//     • GeoJSON-слой полигонов стран (Германия, Польша, Франция) — hover-подсветка
//       синим (#2563eb), одиночный клик — выделение + фильтрация маркеров,
//       двойной клик — автозум на страну (fitBounds).
//     • CircleMarker'ы: показываются все или только выбранной страны;
//       двойной клик → открывает MapSidePanel.
//     • MapSidePanel справа: Товарные группы → Товары, Ctrl+клик — мультивыбор,
//       суммарная метрика в футере.
//     • Хлебные крошки (Все страны › Германия › Берлин) + кнопки Назад/Сброс.
// CHANGES v2.1.0:
//   - Этап 10: i18n — хлебные крошки, подсказки, счётчик через useTranslation()
//     • doubleClickZoom={false} — Leaflet не зумирует на двойной клик.
//     • MapController (useMap) — программный fitBounds/setView.
import { useMemo, useEffect, useState, useCallback } from "react";
import {
  Paper, Typography, CircularProgress, Alert, Box, Stack, IconButton, Tooltip,
} from "@mui/material";
import {
  MapContainer, TileLayer, CircleMarker, Tooltip as LeafletTooltip,
  GeoJSON, useMap,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import type { Feature } from "geojson";
import { useCategoryChart } from "@/hooks/useDashboardData";
import { formatValue } from "@/utils/formatValue";
import { findCoord } from "@/utils/branchCoordinates";
import { CHART_COLORS } from "./chartTheme";
import { COUNTRY_GEOJSON, COUNTRY_BOUNDS } from "@/utils/countryPolygons";
import { MapSidePanel } from "./MapSidePanel";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import HomeIcon from "@mui/icons-material/Home";
import { useTranslation } from "@/context/I18nContext";

// Fix Leaflet default icon (известная проблема с Vite)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

const PRIMARY = "#2563eb";
const PRIMARY_HOVER = "#1d4ed8";
const MAP_CENTER: [number, number] = [51.5, 10.0];

const MAP_ZOOM = 4;

// ---------------------------------------------------------------------------
// MapController — программное управление картой внутри MapContainer
// ---------------------------------------------------------------------------
function MapController({ selectedCountry }: { selectedCountry: string | null }) {
  const map = useMap();
  useEffect(() => {
    if (selectedCountry && COUNTRY_BOUNDS[selectedCountry]) {
      map.fitBounds(COUNTRY_BOUNDS[selectedCountry], { padding: [30, 30], animate: true });
    } else if (!selectedCountry) {
      map.setView(MAP_CENTER, MAP_ZOOM, { animate: true });
    }
  }, [selectedCountry, map]);
  return null;
}

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------
interface BranchMapCardProps {
  title: string;
  /** Колонка для маркеров — по умолчанию «Филиал» */
  dimension?: string;
  metric: string;
  valueFormat?: string;
  height?: number;
  // Имена колонок датасета (для передачи в MapSidePanel)
  countryDimension?: string;
  branchDimension?: string;
  categoryDimension?: string;
  productDimension?: string;
}

// ---------------------------------------------------------------------------
// BranchMapCard
// ---------------------------------------------------------------------------
export function BranchMapCard({
  title,
  dimension = "Филиал",
  metric,
  valueFormat = "{:,.2f}",
  height = 440,
  countryDimension = "Страна",
  branchDimension = "Филиал",
  categoryDimension = "Товарная группа",
  productDimension = "Наименование товара",
}: BranchMapCardProps) {
  const { t } = useTranslation();
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [selectedBranch,  setSelectedBranch]  = useState<string | null>(null);
  const [sidePanelOpen,   setSidePanelOpen]   = useState(false);

  // key заставляет GeoJSON пересоздаться (обновить стили) при смене selectedCountry
  const geoJsonKey = `geo-${selectedCountry ?? "all"}`;

  // ---- данные маркеров ----
  const { data, isLoading, error } = useCategoryChart({
    dimension, metrics: [metric], chart_id: "map", title, limit: 50,
  });

  const allPoints = useMemo(() => {
    if (!data) return [];
    return data.points
      .map((p) => {
        const name  = p[dimension] as string ?? "";
        const value = (p.values[metric] as number) ?? 0;
        const coord = findCoord(name);
        return coord ? { name, value, ...coord } : null;
      })
      .filter(Boolean) as Array<{ name: string; value: number; lat: number; lng: number; country: string }>;
  }, [data, dimension, metric]);

  const visiblePoints = useMemo(() =>
    selectedCountry ? allPoints.filter((p) => p.country === selectedCountry) : allPoints,
  [allPoints, selectedCountry]);

  const maxValue = useMemo(() => Math.max(...allPoints.map((p) => p.value), 1), [allPoints]);
  const markerRadius = (v: number) => 6 + (v / maxValue) * 22;

  // ---- стили полигонов ----
  const getCountryStyle = useCallback((feature?: Feature) => {
    const isSelected = feature?.properties?.name === selectedCountry;
    return {
      fillColor:   isSelected ? PRIMARY : "#64748b",
      fillOpacity: isSelected ? 0.22 : 0.10,
      color:       isSelected ? PRIMARY : "#94a3b8",
      weight:      isSelected ? 2.5 : 1,
    };
  }, [selectedCountry]);

  const onEachCountry = useCallback((feature: Feature, layer: L.Layer) => {
    const name = feature.properties?.name as string;
    const poly = layer as L.Path;

    poly.on({
      mouseover: () => {
        if (name !== selectedCountry) {
          poly.setStyle({ fillColor: PRIMARY, fillOpacity: 0.22, color: PRIMARY, weight: 2 });
        }
      },
      mouseout: () => poly.setStyle(getCountryStyle(feature)),
      click: () => {
        setSelectedCountry((prev) => (prev === name ? null : name));
        setSidePanelOpen(false);
        setSelectedBranch(null);
      },
      dblclick: (e: L.LeafletEvent) => {
        L.DomEvent.stop(e as unknown as Event);
        setSelectedCountry(name);
        setSidePanelOpen(false);
        setSelectedBranch(null);
      },
    });

    poly.bindTooltip(`<strong>${name}</strong><br/><span style="font-size:11px;color:#64748b">2× клик — зум на страну</span>`, {
      sticky: true,
      opacity: 0.95,
      className: "bi-country-tooltip",
    });
  }, [selectedCountry, getCountryStyle]);

  // ---- навигация ----
  const handleBranchDblClick = (branchName: string) => {
    setSelectedBranch(branchName);
    setSidePanelOpen(true);
  };

  const handleBack = () => {
    if (sidePanelOpen) {
      setSidePanelOpen(false);
      setSelectedBranch(null);
    } else {
      setSelectedCountry(null);
    }
  };

  const handleReset = () => {
    setSelectedCountry(null);
    setSelectedBranch(null);
    setSidePanelOpen(false);
  };

  // ---- хлебные крошки ----
  type Crumb = { label: string; onClick?: () => void };
  const breadcrumbs: Crumb[] = [
    {
      label: "Все страны",
      onClick: selectedCountry ? handleReset : undefined,
    },
    ...(selectedCountry
      ? [{ label: selectedCountry,
           onClick: sidePanelOpen ? () => { setSidePanelOpen(false); setSelectedBranch(null); } : undefined }]
      : []),
    ...(selectedBranch ? [{ label: selectedBranch }] : []),
  ];

  return (
    <Paper variant="outlined" sx={{ p: 2, overflow: "hidden" }}>
      {/* Заголовок + хлебные крошки */}
      <Stack direction="row" alignItems="flex-start" justifyContent="space-between" mb={1}>
        <Box sx={{ minWidth: 0, flex: 1 }}>
          <Typography variant="subtitle2" color="text.secondary" noWrap mb={0.25}>
            {title}
          </Typography>
          <Stack direction="row" alignItems="center" flexWrap="wrap" gap={0}>
            {breadcrumbs.map((crumb, i) => (
              <Stack key={i} direction="row" alignItems="center">
                {i > 0 && (
                  <Typography variant="caption" color="text.disabled" sx={{ mx: 0.4 }}>›</Typography>
                )}
                <Typography
                  variant="caption"
                  onClick={crumb.onClick}
                  sx={{
                    cursor: crumb.onClick ? "pointer" : "default",
                    color: crumb.onClick ? PRIMARY : "text.primary",
                    fontWeight: i === breadcrumbs.length - 1 ? 700 : 400,
                    "&:hover": crumb.onClick ? { textDecoration: "underline" } : {},
                  }}
                >
                  {crumb.label}
                </Typography>
              </Stack>
            ))}
          </Stack>
        </Box>
        <Stack direction="row" gap={0.25} flexShrink={0}>
          {(selectedCountry || sidePanelOpen) && (
            <Tooltip title="Назад">
              <IconButton size="small" onClick={handleBack}>
                <ArrowBackIcon sx={{ fontSize: 18 }} />
              </IconButton>
            </Tooltip>
          )}
          {(selectedCountry || selectedBranch) && (
            <Tooltip title="Сброс">
              <IconButton size="small" onClick={handleReset}>
                <HomeIcon sx={{ fontSize: 18 }} />
              </IconButton>
            </Tooltip>
          )}
        </Stack>
      </Stack>

      {isLoading && <CircularProgress size={24} />}
      {error && <Alert severity="error">{error.message}</Alert>}

      {!isLoading && !error && (
        <Box
          sx={{
            display: "flex",
            height,
            borderRadius: 1,
            overflow: "hidden",
            border: "1px solid",
            borderColor: "divider",
          }}
        >
          {/* ---- Карта ---- */}
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <MapContainer
              center={MAP_CENTER}
              zoom={MAP_ZOOM}
              style={{ height: "100%", width: "100%" }}
              scrollWheelZoom={false}
              doubleClickZoom={false}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <MapController selectedCountry={selectedCountry} />

              {/* Полигоны стран */}
              <GeoJSON
                key={geoJsonKey}
                data={COUNTRY_GEOJSON}
                style={getCountryStyle}
                onEachFeature={onEachCountry}
              />

              {/* Маркеры филиалов */}
              {visiblePoints.map((p) => (
                <CircleMarker
                  key={p.name}
                  center={[p.lat, p.lng]}
                  radius={markerRadius(p.value)}
                  pathOptions={{
                    fillColor:   p.name === selectedBranch ? "#f59e0b" : CHART_COLORS[0],
                    fillOpacity: 0.88,
                    color:       "#fff",
                    weight:      p.name === selectedBranch ? 3 : 2,
                  }}
                  eventHandlers={{
                    click: () => {
                      // Одиночный клик — выбираем страну (если не выбрана)
                      if (!selectedCountry) setSelectedCountry(p.country);
                    },
                    dblclick: () => handleBranchDblClick(p.name),
                  }}
                >
                  <LeafletTooltip>
                    <strong>{p.name}</strong>{" "}
                    <span style={{ color: "#64748b" }}>({p.country})</span>
                    <br />
                    {formatValue(p.value, valueFormat)}
                    <br />
                    <em style={{ fontSize: "0.78em", color: "#94a3b8" }}>
                      2× клик — товарные группы
                    </em>
                  </LeafletTooltip>
                </CircleMarker>
              ))}
            </MapContainer>
          </Box>

          {/* ---- Сайдпанель ---- */}
          {sidePanelOpen && selectedBranch && selectedCountry && (
            <MapSidePanel
              country={selectedCountry}
              branch={selectedBranch}
              metric={metric}
              valueFormat={valueFormat}
              countryDimension={countryDimension}
              branchDimension={branchDimension}
              categoryDimension={categoryDimension}
              productDimension={productDimension}
              onClose={() => { setSidePanelOpen(false); setSelectedBranch(null); }}
            />
          )}
        </Box>
      )}

      {/* Подсказка + счётчик */}
      {!isLoading && !error && (
        <Stack direction="row" alignItems="center" justifyContent="space-between" mt={0.75} flexWrap="wrap">
          <Typography variant="caption" color="text.secondary">
            💡 Клик на страну — выделение. 2× клик на маркер — анализ по товарам.
          </Typography>
          {selectedCountry && visiblePoints.length < allPoints.length && (
            <Typography variant="caption" sx={{ color: PRIMARY, fontWeight: 600 }}>
              {visiblePoints.length} из {allPoints.length} филиалов
            </Typography>
          )}
        </Stack>
      )}

      {/* Нет координат */}
      {!isLoading && !error && allPoints.length === 0 && data && (
        <Alert severity="info" sx={{ mt: 1 }}>
          Не удалось найти координаты для отображения.
          Убедитесь, что колонка «{dimension}» содержит названия городов из справочника.
        </Alert>
      )}
    </Paper>
  );
}
