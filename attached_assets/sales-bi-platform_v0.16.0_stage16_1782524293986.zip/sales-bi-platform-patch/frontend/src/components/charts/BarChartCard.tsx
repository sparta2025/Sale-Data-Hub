// VERSION: 1.1.0
// Path: frontend/src/components/charts/BarChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 8: горизонтальный бар-чарт по категории — useCategoryChart,
//     данные уже отсортированы по убыванию на backend (Этап 5)
// CHANGES v1.1.0:
//   - Этап 9: добавлен prop onDrilldown(value: string) — вызывается при клике
//     на бар, передаёт имя категории для drill-down в следующий уровень иерархии
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useCategoryChart } from "@/hooks/useDashboardData";
import { formatValue, formatCompact } from "@/utils/formatValue";
import { CHART_COLORS, CHART_GRID_DEFAULT, AXIS_LABEL_COLOR, AXIS_LINE_COLOR } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface BarChartCardProps {
  title: string;
  dimension: string;
  metric: string;
  valueFormat?: string;
  limit?: number;
  height?: number;
  onDrilldown?: (value: string) => void;
}

export function BarChartCard({
  title, dimension, metric, valueFormat = "{:,.2f}", limit = 10, height = 320,
  onDrilldown,
}: BarChartCardProps) {
  const { data, isLoading, error } = useCategoryChart({
    dimension, metrics: [metric], chart_id: "bar", title, limit,
  });

  const option = useMemo<EChartsOption | null>(() => {
    if (!data) return null;

    // ECharts рисует горизонтальные бары снизу вверх — разворачиваем,
    // чтобы наибольшее значение оказалось сверху (привычный вид рейтинга).
    const categories = [...data.categories].reverse();
    const values = [...data.points].reverse().map((p) => p.values[metric] ?? 0);

    return {
      grid: CHART_GRID_DEFAULT,
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "shadow" },
        valueFormatter: (value) => formatValue(value as number, valueFormat),
      },
      xAxis: {
        type: "value",
        axisLabel: { color: AXIS_LABEL_COLOR, formatter: (v: number) => formatCompact(v) },
        splitLine: { lineStyle: { color: AXIS_LINE_COLOR } },
      },
      yAxis: {
        type: "category",
        data: categories,
        axisLine: { lineStyle: { color: AXIS_LINE_COLOR } },
        axisLabel: { color: AXIS_LABEL_COLOR },
      },
      series: [
        {
          type: "bar",
          data: values,
          color: CHART_COLORS[0],
          barMaxWidth: 28,
          itemStyle: { borderRadius: [0, 4, 4, 0] },
        },
      ],
    };
  }, [data, metric, valueFormat]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      isEmpty={Boolean(data) && data!.categories.length === 0}
      height={height}
      onEvents={onDrilldown ? {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        click: (params: any) => onDrilldown(params.name as string),
      } : undefined}
    />
  );
}
