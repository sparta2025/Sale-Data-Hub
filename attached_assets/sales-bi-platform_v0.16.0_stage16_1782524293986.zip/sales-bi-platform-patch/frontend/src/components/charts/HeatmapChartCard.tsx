// VERSION: 1.0.0
// Path: frontend/src/components/charts/HeatmapChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 8: heatmap по двум измерениям (типично Год×Месяц) — данные через
//     useHeatmapData (Query Engine напрямую, см. hooks/useDashboardData.ts)
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useHeatmapData } from "@/hooks/useDashboardData";
import { formatValue } from "@/utils/formatValue";
import { AXIS_LABEL_COLOR } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface HeatmapChartCardProps {
  title: string;
  rowDim: string;   // напр. "Год" — строки (ось Y)
  colDim: string;   // напр. "Месяц" — столбцы (ось X)
  metric: string;
  valueFormat?: string;
  height?: number;
}

export function HeatmapChartCard({
  title, rowDim, colDim, metric, valueFormat = "{:,.2f}", height = 320,
}: HeatmapChartCardProps) {
  const { data, isLoading, error } = useHeatmapData(rowDim, colDim, metric);

  const option = useMemo<EChartsOption | null>(() => {
    if (!data) return null;

    const rows = Array.from(new Set(data.rows.map((r) => String(r[rowDim])))).sort();
    const cols = Array.from(new Set(data.rows.map((r) => String(r[colDim])))).sort(
      (a, b) => Number(a) - Number(b),
    );

    const cells: [number, number, number | null][] = [];
    let maxValue = 0;
    for (const row of data.rows) {
      const ri = rows.indexOf(String(row[rowDim]));
      const ci = cols.indexOf(String(row[colDim]));
      const value = row[metric] as number | null;
      if (value !== null && value > maxValue) maxValue = value;
      cells.push([ci, ri, value]);
    }

    return {
      tooltip: {
        position: "top",
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        formatter: (params: any) => {
          const [ci, ri, value] = params.data as [number, number, number | null];
          return `${rowDim}: ${rows[ri]}<br/>${colDim}: ${cols[ci]}<br/>${formatValue(value, valueFormat)}`;
        },
      },
      grid: { left: 60, right: 16, top: 16, bottom: 40 },
      xAxis: {
        type: "category",
        data: cols,
        splitArea: { show: true },
        axisLabel: { color: AXIS_LABEL_COLOR },
      },
      yAxis: {
        type: "category",
        data: rows,
        splitArea: { show: true },
        axisLabel: { color: AXIS_LABEL_COLOR },
      },
      visualMap: {
        min: 0,
        max: maxValue || 1,
        calculable: true,
        orient: "horizontal",
        left: "center",
        bottom: 0,
        inRange: { color: ["#eff6ff", "#2563eb"] },
      },
      series: [
        {
          type: "heatmap",
          data: cells,
          label: {
            show: cells.length <= 60,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            formatter: (p: any) => formatValue(p.value[2], valueFormat),
          },
          emphasis: { itemStyle: { shadowBlur: 8, shadowColor: "rgba(0,0,0,0.3)" } },
        },
      ],
    };
  }, [data, rowDim, colDim, metric, valueFormat]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      isEmpty={Boolean(data) && data!.rows.length === 0}
      height={height}
    />
  );
}
