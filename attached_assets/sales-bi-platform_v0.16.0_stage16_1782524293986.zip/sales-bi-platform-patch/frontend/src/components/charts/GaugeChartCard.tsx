// VERSION: 1.1.0
// Path: frontend/src/components/charts/GaugeChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 11: базовый gauge
// CHANGES v1.1.0:
//   - Этап 15: читает target из KpiTargetsContext (если не задан prop target)
//   - Этап 11: спидометр (gauge) для KPI-метрики.
//     Показывает агрегированное значение как процент от максимума (или target).
//     Зоны: 0–50% красная, 50–80% жёлтая, 80–100% зелёная.
//     Используется для KPI-панели: «насколько мы достигли целевого значения».
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useRunQuery } from "@/hooks/useQueryEngine";
import { useFilters } from "@/context/FiltersContext";
import { formatValue } from "@/utils/formatValue";
import { useChartTheme } from "@/hooks/useChartTheme";
import { EChartWrapper } from "./EChartWrapper";
import { useFilters } from "@/context/FiltersContext";
import { useKpiTargets } from "@/modules/kpi/KpiTargetsContext";

interface GaugeChartCardProps {
  title: string;
  dimension: string;
  metric: string;
  /** Целевое значение (100% = этот target). Если не задан — берётся из KpiTargetsContext или max */
  target?: number;
  valueFormat?: string;
  height?: number;
}

export function GaugeChartCard({
  title, dimension, metric, target,
  valueFormat = "{:,.0f}", height = 300,
}: GaugeChartCardProps) {
  const { datasetId, filters } = useFilters();
  const ct = useChartTheme();
  const { datasetId } = useFilters();
  const { getTarget } = useKpiTargets();
  const contextTarget = datasetId ? getTarget(datasetId, metric) : null;
  const effectiveTarget = target ?? contextTarget ?? undefined;

  const { data, isLoading, error } = useRunQuery(
    datasetId ?? undefined,
    { dimensions: [dimension], metrics: [metric], filters, order_by: metric, order_desc: true, limit: 50 },
  );

  const { option, isEmpty } = useMemo<{ option: EChartsOption | null; isEmpty: boolean }>(() => {
    if (!data?.rows?.length) return { option: null, isEmpty: true };

    const values   = data.rows.map((r) => Number(r[metric] ?? 0));
    const total    = values.reduce((s, v) => s + v, 0);
    const maxVal   = effectiveTarget ?? Math.max(...values);
    const pct      = maxVal > 0 ? Math.min((total / maxVal) * 100, 100) : 0;
    const isDark   = ct.echartsTheme === "dark";
    const textColor = isDark ? "#f1f5f9" : "#1e293b";

    const option: EChartsOption = {
      series: [
        {
          type: "gauge",
          radius: "80%",
          startAngle: 210,
          endAngle: -30,
          min: 0,
          max: 100,
          splitNumber: 5,
          progress: { show: true, width: 18 },
          axisLine: {
            lineStyle: {
              width: 18,
              color: [[0.5, "#ef4444"], [0.8, "#f59e0b"], [1, "#22c55e"]],
            },
          },
          axisTick: { show: false },
          splitLine: { show: false },
          axisLabel: {
            distance: 28,
            fontSize: 11,
            color: ct.axisColor,
            formatter: (v: number) => `${v}%`,
          },
          pointer: { width: 6, length: "65%", itemStyle: { color: "auto" } },
          anchor: { show: true, size: 14, itemStyle: { borderColor: textColor, borderWidth: 2 } },
          detail: {
            valueAnimation: true,
            fontSize: 28,
            fontWeight: 700,
            color: textColor,
            offsetCenter: [0, "30%"],
            formatter: () =>
              `${formatValue(total, valueFormat)}\n${pct.toFixed(1)}%`,
          },
          title: {
            offsetCenter: [0, "60%"],
            fontSize: 12,
            color: ct.axisColor,
          },
          data: [{ value: parseFloat(pct.toFixed(1)), name: target ? `от цели ${formatValue(maxVal, valueFormat)}` : "от макс." }],
        },
      ],
    };
    return { option, isEmpty: false };
  }, [data, metric, target, valueFormat, ct]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      height={height}
      isEmpty={isEmpty}
    />
  );
}
