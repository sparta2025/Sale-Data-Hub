// VERSION: 1.1.0
// Path: frontend/src/components/charts/PieChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 8: круговая диаграмма — usePieChart, проценты уже посчитаны backend
// CHANGES v1.1.0:
//   - Этап 9: добавлен prop onDrilldown(value: string) для drill-down по клику на сектор
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { usePieChart } from "@/hooks/useDashboardData";
import { formatValue } from "@/utils/formatValue";
import { CHART_COLORS } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface PieChartCardProps {
  title: string;
  dimension: string;
  metric: string;
  valueFormat?: string;
  limit?: number;
  height?: number;
  onDrilldown?: (value: string) => void;
}

export function PieChartCard({
  title, dimension, metric, valueFormat = "{:,.2f}", limit = 10, height = 320,
  onDrilldown,
}: PieChartCardProps) {
  const { data, isLoading, error } = usePieChart({
    dimension, metric, chart_id: "pie", title, limit,
  });

  const option = useMemo<EChartsOption | null>(() => {
    if (!data) return null;

    return {
      tooltip: {
        trigger: "item",
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        formatter: (params: any) =>
          `${params.name}<br/>${formatValue(params.value, valueFormat)} (${params.percent}%)`,
      },
      legend: { bottom: 0, type: "scroll" },
      color: CHART_COLORS,
      series: [
        {
          type: "pie",
          radius: ["40%", "70%"],
          center: ["50%", "45%"],
          itemStyle: { borderRadius: 4, borderColor: "#fff", borderWidth: 2 },
          label: { formatter: "{b}: {d}%", fontSize: 11 },
          data: data.slices.map((s) => ({ name: s.name, value: s.value ?? 0 })),
        },
      ],
    };
  }, [data, valueFormat]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      isEmpty={Boolean(data) && data!.slices.length === 0}
      height={height}
      onEvents={onDrilldown ? {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        click: (params: any) => onDrilldown(params.name as string),
      } : undefined}
    />
  );
}
