// VERSION: 1.1.0
// Path: frontend/src/components/charts/TreemapChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 8: treemap по иерархии (1-2 уровня) — useTreemapChart, рекурсивно
//     конвертирует TreemapNode дерева backend в формат ECharts series.data
// CHANGES v1.1.0:
//   - Этап 9: добавлен prop onDrilldown(value: string) для drill-down по клику на ячейку
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useTreemapChart } from "@/hooks/useDashboardData";
import { formatValue } from "@/utils/formatValue";
import { CHART_COLORS } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";
import type { TreemapNode } from "@/types";

interface TreemapChartCardProps {
  title: string;
  dimensions: string[];
  metric: string;
  valueFormat?: string;
  height?: number;
  onDrilldown?: (value: string) => void;
}

interface EChartsTreemapNode {
  name: string;
  value: number;
  children?: EChartsTreemapNode[];
}

function convertNode(node: TreemapNode): EChartsTreemapNode {
  return {
    name: node.name,
    value: node.value ?? 0,
    children: node.children.length > 0 ? node.children.map(convertNode) : undefined,
  };
}

export function TreemapChartCard({
  title, dimensions, metric, valueFormat = "{:,.2f}", height = 360, onDrilldown,
}: TreemapChartCardProps) {
  const { data, isLoading, error } = useTreemapChart({
    dimensions, metric, chart_id: "treemap", title,
  });

  const option = useMemo<EChartsOption | null>(() => {
    if (!data) return null;

    return {
      tooltip: {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        formatter: (params: any) =>
          `${params.name}<br/>${formatValue(params.value, valueFormat)}`,
      },
      color: CHART_COLORS,
      series: [
        {
          type: "treemap",
          roam: false,
          nodeClick: false,
          breadcrumb: { show: false },
          label: { fontSize: 11, color: "#fff" },
          upperLabel: { show: true, height: 24, color: "#fff" },
          itemStyle: { borderRadius: 2, gapWidth: 2 },
          levels: [
            { itemStyle: { borderWidth: 0, gapWidth: 2 } },
            { itemStyle: { borderWidth: 2, gapWidth: 2 } },
          ],
          data: data.root.children.map(convertNode),
        },
      ],
    };
  }, [data, valueFormat]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      isEmpty={Boolean(data) && data!.root.children.length === 0}
      height={height}
      onEvents={onDrilldown ? {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        click: (params: any) => onDrilldown(params.name as string),
      } : undefined}
    />
  );
}
