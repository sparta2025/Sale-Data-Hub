// VERSION: 1.0.0
// Path: frontend/src/components/charts/HistogramChartCard.tsx
// CHANGES v1.0.0:
//   - Новый: гистограмма распределения значений числовой метрики.
//     Запрашивает агрегаты по категории, биннингует на frontend (N бинов).
//     Показывает частоту (количество наблюдений) по каждому диапазону.
//     Tooltip выводит диапазон и количество. Кривая KDE опциональна.
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useCategoryChart } from "@/hooks/useDashboardData";
import { formatValue } from "@/utils/formatValue";
import { CHART_COLORS } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface HistogramChartCardProps {
  title: string;
  dimension: string;
  metric: string;
  valueFormat?: string;
  bins?: number;
  height?: number;
  showKde?: boolean;
}

function buildHistogram(values: number[], bins: number) {
  if (values.length === 0) return { binEdges: [], counts: [] };
  const min = Math.min(...values);
  const max = Math.max(...values);
  if (min === max) return { binEdges: [min, max], counts: [values.length] };
  const step = (max - min) / bins;
  const counts = Array(bins).fill(0);
  values.forEach((v) => {
    const idx = Math.min(Math.floor((v - min) / step), bins - 1);
    counts[idx]++;
  });
  const binEdges = Array.from({ length: bins }, (_, i) => min + i * step);
  return { binEdges, counts };
}

export function HistogramChartCard({
  title, dimension, metric,
  valueFormat = "{:,.2f}",
  bins = 10,
  height = 320,
}: HistogramChartCardProps) {
  const { data, isLoading, error } = useCategoryChart({
    dimension, metrics: [metric], chart_id: "histogram", title, limit: 500,
  });

  const { option, isEmpty } = useMemo<{ option: EChartsOption | null; isEmpty: boolean }>(() => {
    if (!data?.points?.length) return { option: null, isEmpty: true };

    const values = data.points.map((p) => Number(p.values[metric] ?? 0));
    const { binEdges, counts } = buildHistogram(values, bins);

    const barData = binEdges.map((edge, i) => ({
      value: counts[i],
      name: `${formatValue(edge, valueFormat)} – ${formatValue(edge + (binEdges[1] - binEdges[0] || 0), valueFormat)}`,
    }));

    const option: EChartsOption = {
      grid: { left: 56, right: 24, top: 24, bottom: 60 },
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "shadow" },
        formatter: (params: Array<{ name: string; value: number }>) => {
          const p = params[0];
          return `<strong>${p.name}</strong><br/>Количество: ${p.value}`;
        },
      },
      xAxis: {
        type: "category",
        data: barData.map((d) => d.name),
        axisLabel: { rotate: 30, fontSize: 10, interval: "auto" },
        name: metric,
        nameLocation: "middle",
        nameGap: 48,
      },
      yAxis: {
        type: "value",
        name: "Кол-во",
        axisLabel: { formatter: (v: number) => String(v) },
      },
      series: [
        {
          type: "bar",
          data: barData.map((d) => d.value),
          itemStyle: { color: CHART_COLORS[1], borderRadius: [3, 3, 0, 0] },
          barCategoryGap: "2%",
          label: {
            show: bins <= 12,
            position: "top",
            fontSize: 10,
            formatter: (p: { value: number }) => String(p.value),
          },
        },
      ],
    };
    return { option, isEmpty: false };
  }, [data, metric, bins, valueFormat]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      height={height}
      isEmpty={isEmpty}
    />
  );
}
