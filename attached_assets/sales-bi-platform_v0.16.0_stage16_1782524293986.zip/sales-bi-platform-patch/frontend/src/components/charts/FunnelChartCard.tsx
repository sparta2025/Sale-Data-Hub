// VERSION: 1.0.0
// Path: frontend/src/components/charts/FunnelChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 12: воронка продаж (funnel chart).
//     Top-N значений dimension по метрике, отсортированы DESC.
//     Каждый уровень воронки = одно значение категории.
//     Лейбл: название + значение метрики + % от верхнего уровня.
//     Полезна для: анализа доли стран/групп от общего объёма.
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useCategoryChart } from "@/hooks/useDashboardData";
import { formatValue } from "@/utils/formatValue";
import { useChartTheme } from "@/hooks/useChartTheme";
import { CHART_COLORS } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface FunnelChartCardProps {
  title: string;
  dimension: string;
  metric: string;
  valueFormat?: string;
  height?: number;
  topN?: number;
}

export function FunnelChartCard({
  title, dimension, metric,
  valueFormat = "{:,.2f}", height = 360, topN = 8,
}: FunnelChartCardProps) {
  const ct = useChartTheme();
  const { data, isLoading, error } = useCategoryChart({
    dimension, metrics: [metric], chart_id: "funnel", title, limit: topN,
  });

  const { option, isEmpty } = useMemo<{ option: EChartsOption | null; isEmpty: boolean }>(() => {
    if (!data?.points?.length) return { option: null, isEmpty: true };

    const sorted = [...data.points].sort(
      (a, b) => (b.values[metric] as number) - (a.values[metric] as number),
    );
    const maxVal = (sorted[0]?.values[metric] as number) || 1;

    const funnelData = sorted.map((p, i) => {
      const val = p.values[metric] as number;
      const pct = ((val / maxVal) * 100).toFixed(1);
      return {
        name:  String(p[dimension] ?? ""),
        value: val,
        pct,
        itemStyle: { color: CHART_COLORS[i % CHART_COLORS.length] },
      };
    });

    const option: EChartsOption = {
      tooltip: {
        trigger: "item",
        formatter: (params: { name: string; value: number; data: { pct: string } }) =>
          `<strong>${params.name}</strong><br/>` +
          `${formatValue(params.value, valueFormat)}<br/>` +
          `${params.data.pct}% от максимума`,
      },
      legend: {
        orient: "vertical",
        left: "left",
        top: "middle",
        textStyle: { color: ct.axisColor, fontSize: 11 },
        data: funnelData.map((d) => d.name),
      },
      series: [
        {
          type: "funnel",
          left: "25%",
          width: "70%",
          top: 20,
          bottom: 20,
          sort: "descending",
          gap: 3,
          label: {
            show: true,
            position: "inside",
            formatter: (params: { name: string; data: { pct: string }; value: number }) =>
              `${params.name}\n${formatValue(params.value, valueFormat)} (${params.data.pct}%)`,
            color: "#fff",
            fontSize: 11,
            fontWeight: 600,
            textShadowBlur: 2,
            textShadowColor: "rgba(0,0,0,0.4)",
          },
          labelLine: { show: false },
          itemStyle: { borderWidth: 0 },
          data: funnelData,
        },
      ],
    };
    return { option, isEmpty: false };
  }, [data, dimension, metric, valueFormat, ct]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      height={height}
      isEmpty={isEmpty}
    />
  );
}
