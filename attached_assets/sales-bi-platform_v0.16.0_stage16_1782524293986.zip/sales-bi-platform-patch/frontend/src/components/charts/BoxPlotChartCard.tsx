// VERSION: 1.0.0
// Path: frontend/src/components/charts/BoxPlotChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 11: ящик с усами (box & whisker plot).
//     Вычисляет Q1/медиану/Q3/мин/макс на frontend из значений метрики
//     по подкатегориям. Запрашивает dimension + metric, group по parent dimension.
//     Каждый ящик = распределение значений подкатегорий внутри родителя.
//     Если parent не задан — один ящик на весь датасет.
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useRunQuery } from "@/hooks/useQueryEngine";
import { useFilters } from "@/context/FiltersContext";
import { formatValue } from "@/utils/formatValue";
import { useChartTheme } from "@/hooks/useChartTheme";
import { CHART_COLORS } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface BoxPlotChartCardProps {
  title: string;
  /** Измерение для подкатегорий (значения которых формируют ящики) */
  dimension: string;
  /** Измерение-группировщик (одна группа = один ящик); если не задан — один ящик */
  groupDimension?: string;
  metric: string;
  valueFormat?: string;
  height?: number;
  limit?: number;
}

function quartiles(sorted: number[]): [number, number, number, number, number] {
  if (sorted.length === 0) return [0, 0, 0, 0, 0];
  const q = (arr: number[], p: number) => {
    const pos = (arr.length - 1) * p;
    const base = Math.floor(pos);
    const rest = pos - base;
    return arr[base + 1] !== undefined ? arr[base] + rest * (arr[base + 1] - arr[base]) : arr[base];
  };
  return [sorted[0], q(sorted, 0.25), q(sorted, 0.5), q(sorted, 0.75), sorted[sorted.length - 1]];
}

export function BoxPlotChartCard({
  title, dimension, groupDimension, metric,
  valueFormat = "{:,.2f}", height = 340, limit = 300,
}: BoxPlotChartCardProps) {
  const { datasetId, filters } = useFilters();
  const ct = useChartTheme();

  const dims = groupDimension ? [groupDimension, dimension] : [dimension];
  const { data, isLoading, error } = useRunQuery(
    datasetId ?? undefined,
    { dimensions: dims, metrics: [metric], filters, order_by: metric, order_desc: false, limit },
  );

  const { option, isEmpty } = useMemo<{ option: EChartsOption | null; isEmpty: boolean }>(() => {
    if (!data?.rows?.length) return { option: null, isEmpty: true };

    let groups: Map<string, number[]>;

    if (groupDimension) {
      groups = new Map();
      for (const row of data.rows) {
        const grp = String(row[groupDimension] ?? "–");
        const val = Number(row[metric] ?? 0);
        if (!groups.has(grp)) groups.set(grp, []);
        groups.get(grp)!.push(val);
      }
    } else {
      const all = data.rows.map((r) => Number(r[metric] ?? 0));
      groups = new Map([["Все", all]]);
    }

    const labels: string[] = [];
    const boxData: number[][] = [];

    for (const [grp, vals] of groups) {
      const sorted = [...vals].sort((a, b) => a - b);
      const [mn, q1, med, q3, mx] = quartiles(sorted);
      labels.push(grp);
      boxData.push([mn, q1, med, q3, mx]);
    }

    const option: EChartsOption = {
      grid: { left: 72, right: 24, top: 24, bottom: 80 },
      tooltip: {
        trigger: "item",
        formatter: (params: { data: number[] }) => {
          const [mn, q1, med, q3, mx] = params.data;
          return [
            `<strong>${labels[(params as { dataIndex: number }).dataIndex] ?? ""}</strong>`,
            `Мин: ${formatValue(mn, valueFormat)}`,
            `Q1: ${formatValue(q1, valueFormat)}`,
            `Медиана: ${formatValue(med, valueFormat)}`,
            `Q3: ${formatValue(q3, valueFormat)}`,
            `Макс: ${formatValue(mx, valueFormat)}`,
          ].join("<br/>");
        },
      },
      xAxis: {
        type: "category",
        data: labels,
        axisLabel: { rotate: labels.length > 5 ? 30 : 0, color: ct.axisColor, fontSize: 11 },
        axisLine: { lineStyle: { color: ct.axisLineColor } },
      },
      yAxis: {
        type: "value",
        name: metric,
        nameTextStyle: { color: ct.axisColor },
        axisLabel: { color: ct.axisColor, formatter: (v: number) => formatValue(v, "{:,.0f}") },
        splitLine: { lineStyle: { color: ct.splitLineColor } },
      },
      series: [
        {
          type: "boxplot",
          data: boxData,
          itemStyle: { color: `${CHART_COLORS[0]}99`, borderColor: CHART_COLORS[0], borderWidth: 2 },
          boxWidth: ["20%", "50%"],
        },
      ],
    };
    return { option, isEmpty: false };
  }, [data, groupDimension, metric, valueFormat, ct]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      height={height}
      isEmpty={isEmpty}
    />
  );
}
