// VERSION: 1.2.0
// Path: frontend/src/components/charts/EChartWrapper.tsx
// CHANGES v1.0.0:
//   - Этап 8: общая обёртка ECharts — Paper, заголовок, loading/error/empty
// CHANGES v1.1.0:
//   - Этап 9: prop onEvents для drill-down
// CHANGES v1.2.0:
//   - Этап 10: тема ECharts через useChartTheme() — в тёмной теме передаёт
//     theme="dark" в ReactECharts; i18n для «Нет данных»;
//     ChartErrorBoundary обёртка внутри компонента.
import { Paper, Typography, Skeleton, Alert, Box } from "@mui/material";
import ReactECharts from "echarts-for-react";
import type { EChartsOption } from "echarts";
import { useChartTheme } from "@/hooks/useChartTheme";
import { useTranslation } from "@/context/I18nContext";
import { ChartErrorBoundary } from "@/components/error/ChartErrorBoundary";

interface EChartWrapperProps {
  title: string;
  option: EChartsOption | null;
  loading?: boolean;
  error?: Error | null;
  height?: number;
  isEmpty?: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onEvents?: Record<string, (params: any) => void>;
}

export function EChartWrapper({
  title, option, loading, error, height = 320, isEmpty, onEvents,
}: EChartWrapperProps) {
  const ct = useChartTheme();
  const { t } = useTranslation();

  const enrichedOption: EChartsOption | null = option
    ? {
        backgroundColor: ct.bgColor,
        ...option,
      }
    : null;

  return (
    <Paper variant="outlined" sx={{ p: 2, height: height + 56 }}>
      <Typography variant="subtitle2" color="text.secondary" mb={1} noWrap>
        {title}
      </Typography>

      {error && <Alert severity="error">{error.message}</Alert>}

      {!error && loading && <Skeleton variant="rounded" width="100%" height={height} />}

      {!error && !loading && isEmpty && (
        <Box sx={{ height, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Typography variant="body2" color="text.secondary">
            {t.charts.noData}
          </Typography>
        </Box>
      )}

      {!error && !loading && !isEmpty && enrichedOption && (
        <ChartErrorBoundary title={title} height={height}>
          <ReactECharts
            option={enrichedOption}
            theme={ct.echartsTheme}
            style={{ height, width: "100%" }}
            notMerge
            lazyUpdate
            onEvents={onEvents}
          />
        </ChartErrorBoundary>
      )}
    </Paper>
  );
}
