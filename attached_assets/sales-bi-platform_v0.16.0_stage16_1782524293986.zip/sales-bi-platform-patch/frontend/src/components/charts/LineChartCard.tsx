// VERSION: 1.0.0
// Path: frontend/src/components/charts/LineChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 8: линейный график временного ряда — useTimeseriesChart, поддержка
//     нескольких серий (group_by), числовая сортировка периодов "Год[-Месяц]"
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useTimeseriesChart } from "@/hooks/useDashboardData";
import { formatValue, formatCompact } from "@/utils/formatValue";
import { CHART_COLORS, CHART_GRID_DEFAULT, AXIS_LABEL_COLOR, AXIS_LINE_COLOR } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface LineChartCardProps {
  title: string;
  timeDimensions: string[];
  metric: string;
  groupBy?: string;
  valueFormat?: string;
  height?: number;
}

/** Числовое сравнение периодов "2015" / "2015-1" / "2015-12" — лексикографика дала бы неверный порядок. */
function comparePeriods(a: string, b: string): number {
  const partsA = a.split("-").map(Number);
  const partsB = b.split("-").map(Number);
  for (let i = 0; i < Math.max(partsA.length, partsB.length); i++) {
    const diff = (partsA[i] ?? 0) - (partsB[i] ?? 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

export function LineChartCard({
  title, timeDimensions, metric, groupBy, valueFormat = "{:,.2f}", height = 320,
}: LineChartCardProps) {
  const { data, isLoading, error } = useTimeseriesChart({
    time_dimensions: timeDimensions,
    metrics: [metric],
    group_by: groupBy,
    chart_id: "line",
    title,
  });

  const option = useMemo<EChartsOption | null>(() => {
    if (!data) return null;

    const periods = Array.from(new Set(data.points.map((p) => p.period))).sort(comparePeriods);
    const seriesNames = data.series_names.length > 0 ? data.series_names : [metric];

    const series = seriesNames.map((seriesName, idx) => {
      const valueByPeriod = new Map(
        data.points.filter((p) => (p.series ?? metric) === seriesName).map((p) => [p.period, p.value]),
      );
      return {
        name: seriesName,
        type: "line" as const,
        smooth: true,
        showSymbol: periods.length <= 24,
        symbolSize: 6,
        lineStyle: { width: 2 },
        color: CHART_COLORS[idx % CHART_COLORS.length],
        data: periods.map((p) => valueByPeriod.get(p) ?? null),
      };
    });

    return {
      grid: CHART_GRID_DEFAULT,
      tooltip: {
        trigger: "axis",
        valueFormatter: (value) => formatValue(value as number, valueFormat),
      },
      legend: seriesNames.length > 1 ? { bottom: 0, type: "scroll" } : undefined,
      xAxis: {
        type: "category",
        data: periods,
        axisLine: { lineStyle: { color: AXIS_LINE_COLOR } },
        axisLabel: { color: AXIS_LABEL_COLOR },
      },
      yAxis: {
        type: "value",
        axisLabel: { color: AXIS_LABEL_COLOR, formatter: (v: number) => formatCompact(v) },
        splitLine: { lineStyle: { color: AXIS_LINE_COLOR } },
      },
      series,
    };
  }, [data, metric, valueFormat]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      isEmpty={Boolean(data) && data!.points.length === 0}
      height={height}
    />
  );
}
