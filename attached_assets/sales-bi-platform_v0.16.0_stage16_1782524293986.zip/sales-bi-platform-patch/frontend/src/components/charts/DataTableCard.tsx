// VERSION: 1.1.0
// Path: frontend/src/components/charts/DataTableCard.tsx
// CHANGES v1.0.0:
//   - Этап 9: DataGrid, экспорт CSV
// CHANGES v1.1.0:
//   - Этап 10: i18n для «Строк на странице» и «Экспорт CSV»
//   - Этап 9: интерактивная агрегированная таблица — MUI DataGrid (сортировка,
//     пагинация), кнопка экспорта CSV. Данные через useTableChart с активными
//     фильтрами контекста. Значения форматируются через formatValue.
import { useTranslation } from "@/context/I18nContext";
import { useMemo, useCallback } from "react";
import {
  Paper, Typography, Box, Skeleton, Alert, Button, Stack, Tooltip,
} from "@mui/material";
import DownloadIcon from "@mui/icons-material/Download";
import { DataGrid, type GridColDef, type GridRenderCellParams } from "@mui/x-data-grid";
import { useTableChart } from "@/hooks/useDashboardData";
import { formatValue } from "@/utils/formatValue";
import type { MetricOut, DimensionOut } from "@/types";

interface DataTableCardProps {
  title: string;
  dimensions: string[];
  metrics: string[];
  dimensionMetas: DimensionOut[];
  metricMetas: MetricOut[];
  height?: number;
}

export function DataTableCard({
  title, dimensions, metrics, dimensionMetas, metricMetas, height = 420,
}: DataTableCardProps) {
  const { t } = useTranslation();
  const { data, isLoading, error } = useTableChart({
    dimensions, metrics, chart_id: "table", title, order_desc: true,
    order_by: metrics[0],
  });

  const columns = useMemo<GridColDef[]>(() => {
    const dimCols: GridColDef[] = dimensions.map((col) => {
      const meta = dimensionMetas.find((d) => d.column_name === col);
      return {
        field: col,
        headerName: meta?.display_name ?? col,
        flex: 1,
        minWidth: 120,
      };
    });
    const metCols: GridColDef[] = metrics.map((col) => {
      const meta = metricMetas.find((m) => m.column_name === col);
      const fmt = meta?.display_format ?? "{:,.2f}";
      return {
        field: col,
        headerName: meta?.display_name ?? col,
        flex: 1,
        minWidth: 140,
        type: "number",
        renderCell: (params: GridRenderCellParams) =>
          formatValue(params.value as number, fmt),
      };
    });
    return [...dimCols, ...metCols];
  }, [dimensions, metrics, dimensionMetas, metricMetas]);

  const rows = useMemo(
    () => (data?.rows ?? []).map((row, idx) => ({ id: idx, ...row })),
    [data],
  );

  const exportCsv = useCallback(() => {
    if (!data) return;
    const header = [...dimensions, ...metrics].join(",");
    const body = data.rows
      .map((row) => [...dimensions, ...metrics].map((k) => row[k] ?? "").join(","))
      .join("\n");
    const blob = new Blob(["\ufeff" + header + "\n" + body], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title || "table"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, [data, dimensions, metrics, title]);

  return (
    <Paper variant="outlined" sx={{ p: 2 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1}>
        <Typography variant="subtitle2" color="text.secondary" noWrap>
          {title}
        </Typography>
        <Tooltip title="Экспорт в CSV">
          <span>
            <Button
              size="small"
              startIcon={<DownloadIcon />}
              onClick={exportCsv}
              disabled={!data || data.rows.length === 0}
            >
              CSV
            </Button>
          </span>
        </Tooltip>
      </Stack>

      {error && <Alert severity="error">{error.message}</Alert>}

      {isLoading && (
        <Stack spacing={0.5}>
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} variant="rectangular" height={36} />
          ))}
        </Stack>
      )}

      {!isLoading && !error && (
        <Box sx={{ height }}>
          <DataGrid
            rows={rows}
            columns={columns}
            density="compact"
            disableRowSelectionOnClick
            pageSizeOptions={[25, 50, 100]}
            initialState={{ pagination: { paginationModel: { pageSize: 25 } } }}
            sx={{
              "& .MuiDataGrid-columnHeaders": { bgcolor: "background.default" },
              "& .MuiDataGrid-cell": { fontSize: 13 },
            }}
          />
        </Box>
      )}
    </Paper>
  );
}
