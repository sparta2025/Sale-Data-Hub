// VERSION: 1.0.0
// Path: frontend/src/components/charts/RadarChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 11: радарная диаграмма (spider/web chart).
//     Сравнивает top-N значений dimension по нескольким метрикам.
//     Каждая ось радара = одна метрика, нормализована к [0, 100%].
//     Каждая «паутинка» = одно значение dimension (страна, группа и т.д.).
//     Оптимально для 2–5 метрик и 3–8 категорий.
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useRunQuery } from "@/hooks/useQueryEngine";
import { useFilters } from "@/context/FiltersContext";
import { formatValue } from "@/utils/formatValue";
import { useChartTheme } from "@/hooks/useChartTheme";
import { CHART_COLORS } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface RadarChartCardProps {
  title: string;
  dimension: string;
  metrics: string[];
  metricLabels?: string[];
  valueFormat?: string;
  height?: number;
  topN?: number;
}

export function RadarChartCard({
  title, dimension, metrics, metricLabels,
  valueFormat = "{:,.0f}", height = 380, topN = 6,
}: RadarChartCardProps) {
  const { datasetId, filters } = useFilters();
  const ct = useChartTheme();

  const { data, isLoading, error } = useRunQuery(
    datasetId ?? undefined,
    { dimensions: [dimension], metrics, filters, order_by: metrics[0], order_desc: true, limit: topN },
    metrics.length >= 2,
  );

  const { option, isEmpty } = useMemo<{ option: EChartsOption | null; isEmpty: boolean }>(() => {
    if (!data?.rows?.length || metrics.length < 2) return { option: null, isEmpty: true };

    // Максимумы для нормализации
    const maxValues = metrics.map((m) =>
      Math.max(...data.rows.map((r) => Number(r[m] ?? 0)), 1),
    );

    const indicators = metrics.map((m, i) => ({
      name: (metricLabels?.[i] ?? m).slice(0, 20),
      max: maxValues[i],
    }));

    const series = data.rows.map((row, idx) => ({
      value: metrics.map((m) => Number(row[m] ?? 0)),
      name: String(row[dimension] ?? ""),
      itemStyle: { color: CHART_COLORS[idx % CHART_COLORS.length] },
      areaStyle: { color: `${CHART_COLORS[idx % CHART_COLORS.length]}22` },
    }));

    const option: EChartsOption = {
      legend: {
        bottom: 0,
        textStyle: { color: ct.axisColor, fontSize: 11 },
        data: series.map((s) => s.name),
      },
      tooltip: {
        trigger: "item",
        formatter: (params: { name: string; value: number[] }) => {
          const lines = metrics.map((m, i) =>
            `${metricLabels?.[i] ?? m}: <strong>${formatValue(params.value[i], valueFormat)}</strong>`,
          );
          return `<strong>${params.name}</strong><br/>${lines.join("<br/>")}`;
        },
      },
      radar: {
        indicator: indicators,
        radius: "65%",
        center: ["50%", "45%"],
        nameGap: 8,
        name: { textStyle: { color: ct.axisColor, fontSize: 11 } },
        axisLine: { lineStyle: { color: ct.axisLineColor } },
        splitLine: { lineStyle: { color: ct.splitLineColor } },
        splitArea: { areaStyle: { color: ["transparent"] } },
      },
      series: [
        {
          type: "radar",
          data: series,
          lineStyle: { width: 2 },
          symbol: "circle",
          symbolSize: 5,
        },
      ],
    };
    return { option, isEmpty: false };
  }, [data, dimension, metrics, metricLabels, valueFormat, ct]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      height={height}
      isEmpty={isEmpty || metrics.length < 2}
    />
  );
}
