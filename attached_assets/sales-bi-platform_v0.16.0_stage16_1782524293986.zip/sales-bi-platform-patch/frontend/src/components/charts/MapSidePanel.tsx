// VERSION: 1.1.0
// Path: frontend/src/components/charts/MapSidePanel.tsx
// CHANGES v1.0.0:
//   - Этап 9.1: drill-down панель карты (товарные группы → товары, Ctrl+клик)
// CHANGES v1.1.0:
//   - Этап 10: i18n — все хардкоды через useTranslation().t.map
import { useState, useCallback } from "react";
import {
  Box, Typography, IconButton, Divider, CircularProgress,
  Alert, Chip, Stack,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import CloseIcon from "@mui/icons-material/Close";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import { useRunQuery } from "@/hooks/useQueryEngine";
import { useFilters } from "@/context/FiltersContext";
import { useTranslation } from "@/context/I18nContext";
import { formatValue } from "@/utils/formatValue";
import type { FilterMap, InFilter } from "@/types";

const PRIMARY = "#2563eb";
const PRIMARY_DARK = "#1d4ed8";
const PRIMARY_LIGHT = "#dbeafe";

interface MapSidePanelProps {
  country: string;
  branch: string;
  metric: string;
  valueFormat?: string;
  countryDimension?: string;
  branchDimension?: string;
  categoryDimension?: string;
  productDimension?: string;
  onClose: () => void;
}

interface RowItem { label: string; value: number; }

function SidePanelRow({ item, selected, maxValue, valueFormat, onClick }: {
  item: RowItem; selected: boolean; maxValue: number;
  valueFormat: string; onClick: (e: React.MouseEvent) => void;
}) {
  const pct = maxValue > 0 ? (item.value / maxValue) * 100 : 0;
  return (
    <Box
      onClick={onClick}
      sx={{
        px: 1.5, py: 0.9, cursor: "pointer", borderRadius: 1, position: "relative",
        userSelect: "none", mb: 0.4,
        backgroundColor: selected ? `${PRIMARY}12` : "transparent",
        border: `1.5px solid ${selected ? PRIMARY : "transparent"}`,
        "&:hover": { backgroundColor: selected ? `${PRIMARY}1c` : PRIMARY_LIGHT },
        overflow: "hidden", transition: "background-color 0.15s",
      }}
    >
      <Box sx={{
        position: "absolute", left: 0, top: 0, bottom: 0, width: `${pct}%`,
        backgroundColor: selected ? `${PRIMARY}1a` : "#e2e8f022",
        pointerEvents: "none", transition: "width 0.4s ease",
      }} />
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ position: "relative", gap: 1 }}>
        <Stack direction="row" alignItems="center" gap={0.75} sx={{ minWidth: 0 }}>
          {selected
            ? <CheckBoxIcon fontSize="small" sx={{ color: PRIMARY, flexShrink: 0, fontSize: 18 }} />
            : <CheckBoxOutlineBlankIcon fontSize="small" sx={{ color: "#94a3b8", flexShrink: 0, fontSize: 18 }} />}
          <Typography variant="body2" noWrap sx={{ fontWeight: selected ? 600 : 400, color: selected ? PRIMARY : "text.primary" }}>
            {item.label}
          </Typography>
        </Stack>
        <Typography variant="body2" sx={{ fontWeight: 600, color: selected ? PRIMARY : "text.secondary", flexShrink: 0, fontSize: "0.75rem" }}>
          {formatValue(item.value, valueFormat)}
        </Typography>
      </Stack>
    </Box>
  );
}

export function MapSidePanel({
  country, branch, metric, valueFormat = "{:,.2f}",
  countryDimension = "Страна", branchDimension = "Филиал",
  categoryDimension = "Товарная группа", productDimension = "Наименование товара",
  onClose,
}: MapSidePanelProps) {
  const { datasetId } = useFilters();
  const { t } = useTranslation();
  const [selectedGroups,   setSelectedGroups]   = useState<string[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [level, setLevel] = useState<"groups" | "products">("groups");

  const baseFilters: FilterMap = {
    [countryDimension]: { type: "eq", value: country },
    [branchDimension]:  { type: "eq", value: branch  },
  };
  const productsFilters: FilterMap = {
    ...baseFilters,
    ...(selectedGroups.length > 0 && { [categoryDimension]: { type: "in", values: selectedGroups } as InFilter }),
  };

  const { data: groupsData,   isLoading: groupsLoading }   = useRunQuery(
    datasetId ?? undefined,
    { dimensions: [categoryDimension], metrics: [metric], filters: baseFilters,    order_by: metric, order_desc: true, limit: 50  },
    level === "groups",
  );
  const { data: productsData, isLoading: productsLoading } = useRunQuery(
    datasetId ?? undefined,
    { dimensions: [productDimension],  metrics: [metric], filters: productsFilters, order_by: metric, order_desc: true, limit: 100 },
    level === "products",
  );

  const toggle = useCallback((item: string, current: string[], set: (v: string[]) => void, multi: boolean) => {
    if (multi) set(current.includes(item) ? current.filter((i) => i !== item) : [...current, item]);
    else       set(current.includes(item) && current.length === 1 ? [] : [item]);
  }, []);

  const isLoading    = level === "groups" ? groupsLoading : productsLoading;
  const rows: RowItem[] = level === "groups"
    ? (groupsData?.rows   ?? []).map((r) => ({ label: String(r[categoryDimension] ?? ""), value: Number(r[metric] ?? 0) }))
    : (productsData?.rows ?? []).map((r) => ({ label: String(r[productDimension]  ?? ""), value: Number(r[metric] ?? 0) }));

  const maxValue      = Math.max(...rows.map((r) => r.value), 1);
  const selectedItems = level === "groups" ? selectedGroups : selectedProducts;
  const setSelected   = level === "groups" ? setSelectedGroups : setSelectedProducts;
  const selectedSum   = rows.filter((r) => selectedItems.includes(r.label)).reduce((s, r) => s + r.value, 0);

  const levelTitle = level === "groups"
    ? t.map.categories
    : selectedGroups.length === 1 ? selectedGroups[0] : `${selectedGroups.length} ${t.map.groups}`;

  return (
    <Box sx={{
      width: 300, flexShrink: 0, borderLeft: "1px solid", borderColor: "divider",
      display: "flex", flexDirection: "column", height: "100%", overflow: "hidden",
      backgroundColor: "background.paper",
    }}>
      {/* Header */}
      <Box sx={{ px: 1.5, pt: 1.5, pb: 1, borderBottom: "1px solid", borderColor: "divider" }}>
        <Stack direction="row" alignItems="flex-start" justifyContent="space-between">
          <Stack direction="row" alignItems="center" gap={0.5}>
            {level === "products" && (
              <IconButton size="small" onClick={() => { setLevel("groups"); setSelectedProducts([]); }} sx={{ mr: 0.25 }}>
                <ArrowBackIcon sx={{ fontSize: 18 }} />
              </IconButton>
            )}
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="caption" color="text.secondary" display="block" noWrap>
                {country} › {branch}
              </Typography>
              <Typography variant="subtitle2" fontWeight={700} noWrap sx={{ color: PRIMARY }}>
                {levelTitle}
              </Typography>
            </Box>
          </Stack>
          <IconButton size="small" onClick={onClose} sx={{ flexShrink: 0 }}>
            <CloseIcon sx={{ fontSize: 18 }} />
          </IconButton>
        </Stack>

        {selectedItems.length > 0 && (
          <Box sx={{ mt: 1, display: "flex", flexWrap: "wrap", gap: 0.5 }}>
            {selectedItems.slice(0, 2).map((item) => (
              <Chip key={item} label={item} size="small"
                onDelete={() => setSelected(selectedItems.filter((i) => i !== item))}
                sx={{ maxWidth: 120, backgroundColor: PRIMARY, color: "#fff", fontSize: "0.68rem",
                  "& .MuiChip-deleteIcon": { color: "rgba(255,255,255,0.75)", "&:hover": { color: "#fff" } } }} />
            ))}
            {selectedItems.length > 2 && (
              <Chip label={`+${selectedItems.length - 2}`} size="small"
                sx={{ backgroundColor: PRIMARY_DARK, color: "#fff", fontSize: "0.68rem", fontWeight: 700 }} />
            )}
          </Box>
        )}

        {level === "groups" && selectedGroups.length > 0 && (
          <Box onClick={() => { setSelectedProducts([]); setLevel("products"); }}
            sx={{ mt: 1, px: 1.5, py: 0.5, borderRadius: 1, cursor: "pointer",
              backgroundColor: PRIMARY, color: "#fff", textAlign: "center",
              "&:hover": { backgroundColor: PRIMARY_DARK }, transition: "background-color 0.15s" }}>
            <Typography variant="caption" fontWeight={700}>{t.map.showProducts}</Typography>
          </Box>
        )}
      </Box>

      <Box sx={{ px: 1.5, py: 0.6, backgroundColor: "action.hover" }}>
        <Typography variant="caption" color="text.secondary" sx={{ fontSize: "0.68rem" }}>
          {t.map.ctrlClickHint}
        </Typography>
      </Box>
      <Divider />

      <Box sx={{ flex: 1, overflowY: "auto", p: 1 }}>
        {isLoading && <Box display="flex" justifyContent="center" py={3}><CircularProgress size={24} sx={{ color: PRIMARY }} /></Box>}
        {!isLoading && rows.length === 0 && <Alert severity="info" sx={{ m: 1, fontSize: "0.78rem" }}>{t.map.noData}</Alert>}
        {!isLoading && rows.map((row) => (
          <SidePanelRow key={row.label} item={row} selected={selectedItems.includes(row.label)}
            maxValue={maxValue} valueFormat={valueFormat}
            onClick={(e) => toggle(row.label, selectedItems, setSelected, e.ctrlKey || e.metaKey)} />
        ))}
      </Box>

      {selectedItems.length > 0 && (
        <>
          <Divider />
          <Box sx={{ px: 1.5, py: 1.25, backgroundColor: `${PRIMARY}08` }}>
            <Typography variant="caption" color="text.secondary">
              {t.map.total}: {selectedItems.length} {level === "groups" ? t.map.groups : t.map.items}
            </Typography>
            <Typography variant="subtitle2" fontWeight={700} sx={{ color: PRIMARY }}>
              {formatValue(selectedSum, valueFormat)}
            </Typography>
          </Box>
        </>
      )}
    </Box>
  );
}
