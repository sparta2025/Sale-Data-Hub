// VERSION: 1.0.0
// Path: frontend/src/components/charts/StatSummaryCard.tsx
// CHANGES v1.0.0:
//   - Этап 12: статистическая сводка по метрикам датасета.
//     Использует GET /api/analytics/{datasetId}/describe.
//     Таблица: метрика | min | max | mean | median | Q1 | Q3 | std | CV% | null%.
//     Пустые ячейки (нет данных) = серые. CV% > 50 = оранжевый (высокая вариация).
import { Paper, Typography, Skeleton, Alert, Box } from "@mui/material";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import { useDescribe } from "@/hooks/useAnalytics";
import { useFilters } from "@/context/FiltersContext";
import { useTranslation } from "@/context/I18nContext";
import { formatValue } from "@/utils/formatValue";

interface StatSummaryCardProps {
  title?: string;
  valueFormat?: string;
  height?: number;
}

const FMT = (v: number, fmt: string) => formatValue(v, fmt);

export function StatSummaryCard({
  title, valueFormat = "{:,.2f}", height = 380,
}: StatSummaryCardProps) {
  const { datasetId } = useFilters();
  const { t } = useTranslation();
  const { data, isLoading, error } = useDescribe(datasetId);

  const cardTitle = title ?? "Статистическая сводка по метрикам";

  if (error) {
    return (
      <Paper variant="outlined" sx={{ p: 2 }}>
        <Typography variant="subtitle2" color="text.secondary" mb={1}>{cardTitle}</Typography>
        <Alert severity="error">{error.message}</Alert>
      </Paper>
    );
  }

  const columns: GridColDef[] = [
    { field: "display_name", headerName: "Метрика",   flex: 1.5, minWidth: 140 },
    { field: "min",     headerName: "Min",      flex: 1, minWidth: 100,
      renderCell: (p) => FMT(p.value, valueFormat) },
    { field: "max",     headerName: "Max",      flex: 1, minWidth: 100,
      renderCell: (p) => FMT(p.value, valueFormat) },
    { field: "mean",    headerName: "Среднее",  flex: 1, minWidth: 110,
      renderCell: (p) => FMT(p.value, valueFormat) },
    { field: "median",  headerName: "Медиана",  flex: 1, minWidth: 110,
      renderCell: (p) => FMT(p.value, valueFormat) },
    { field: "q1",      headerName: "Q1 (25%)", flex: 1, minWidth: 100,
      renderCell: (p) => FMT(p.value, valueFormat) },
    { field: "q3",      headerName: "Q3 (75%)", flex: 1, minWidth: 100,
      renderCell: (p) => FMT(p.value, valueFormat) },
    { field: "std",     headerName: "Станд. отк.", flex: 1, minWidth: 110,
      renderCell: (p) => FMT(p.value, valueFormat) },
    {
      field: "cv",
      headerName: "CV%",
      flex: 0.8,
      minWidth: 80,
      renderCell: (p) => (
        <Typography
          variant="caption"
          sx={{ fontWeight: 700, color: p.value > 50 ? "#f59e0b" : p.value > 100 ? "#ef4444" : "text.primary" }}
        >
          {p.value.toFixed(1)}%
        </Typography>
      ),
    },
    {
      field: "null_pct",
      headerName: "Пропуски%",
      flex: 0.8,
      minWidth: 90,
      renderCell: (p) => (
        <Typography
          variant="caption"
          sx={{ color: p.value > 5 ? "#ef4444" : "text.secondary" }}
        >
          {p.value.toFixed(1)}%
        </Typography>
      ),
    },
  ];

  const rows = (data?.columns ?? []).map((col, idx) => ({ id: idx, ...col }));

  return (
    <Paper variant="outlined" sx={{ p: 2 }}>
      <Typography variant="subtitle2" color="text.secondary" mb={1} noWrap>
        {cardTitle}
      </Typography>

      {isLoading && <Skeleton variant="rounded" width="100%" height={height} />}

      {!isLoading && rows.length === 0 && (
        <Box sx={{ height: 80, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Typography variant="body2" color="text.secondary">{t.charts.noData}</Typography>
        </Box>
      )}

      {!isLoading && rows.length > 0 && (
        <DataGrid
          rows={rows}
          columns={columns}
          density="compact"
          disableRowSelectionOnClick
          hideFooter={rows.length <= 10}
          autoHeight
          sx={{
            border: "none",
            "& .MuiDataGrid-columnHeader": { backgroundColor: "action.hover", fontWeight: 700 },
            "& .MuiDataGrid-cell": { fontSize: "0.78rem" },
          }}
        />
      )}
    </Paper>
  );
}
