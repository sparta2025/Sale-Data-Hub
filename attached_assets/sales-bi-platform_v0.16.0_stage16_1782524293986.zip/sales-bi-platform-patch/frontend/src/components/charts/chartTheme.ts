// VERSION: 1.0.0
// Path: frontend/src/components/charts/chartTheme.ts
// CHANGES v1.0.0:
//   - Этап 8: палитра цветов графиков, согласованная с MUI-темой (primary
//     #2563eb / secondary #7c3aed), общие константы для ECharts-компонентов
export const CHART_COLORS = [
  "#2563eb", // primary (тема)
  "#7c3aed", // secondary (тема)
  "#0ea5e9",
  "#10b981",
  "#f59e0b",
  "#ef4444",
  "#8b5cf6",
  "#06b6d4",
  "#84cc16",
  "#ec4899",
];

export const CHART_GRID_DEFAULT = {
  left: 8,
  right: 16,
  top: 32,
  bottom: 8,
  containLabel: true,
};

export const AXIS_LABEL_COLOR = "#64748b";
export const AXIS_LINE_COLOR = "#e2e8f0";
