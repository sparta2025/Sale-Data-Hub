// VERSION: 1.0.0
// Path: frontend/src/components/charts/WaterfallChartCard.tsx
// CHANGES v1.0.0:
//   - Этап 8: waterfall — вклад каждой категории в итог, классическая техника
//     ECharts (stacked bar с невидимым "базовым" слоем), данные через
//     useCategoryChart, итоговый столбец считается на клиенте
import { useMemo } from "react";
import type { EChartsOption } from "echarts";
import { useCategoryChart } from "@/hooks/useDashboardData";
import { formatValue, formatCompact } from "@/utils/formatValue";
import { CHART_GRID_DEFAULT, AXIS_LABEL_COLOR, AXIS_LINE_COLOR } from "./chartTheme";
import { EChartWrapper } from "./EChartWrapper";

interface WaterfallChartCardProps {
  title: string;
  dimension: string;
  metric: string;
  valueFormat?: string;
  limit?: number;
  height?: number;
}

const POSITIVE_COLOR = "#2563eb";
const TOTAL_COLOR = "#10b981";

export function WaterfallChartCard({
  title, dimension, metric, valueFormat = "{:,.2f}", limit = 8, height = 320,
}: WaterfallChartCardProps) {
  const { data, isLoading, error } = useCategoryChart({
    dimension, metrics: [metric], chart_id: "waterfall", title, limit,
  });

  const option = useMemo<EChartsOption | null>(() => {
    if (!data) return null;

    const categories = [...data.categories, "Итого"];
    const values = data.points.map((p) => p.values[metric] ?? 0);

    // Классическая техника waterfall: невидимый "base" поднимает видимый
    // столбец на нужную высоту, создавая эффект "лестницы" вверх.
    const base: number[] = [];
    const increments: number[] = [];
    let cumulative = 0;
    for (const v of values) {
      base.push(cumulative);
      increments.push(v);
      cumulative += v;
    }
    base.push(0);
    increments.push(cumulative); // итоговый столбец — от нуля до полной суммы

    return {
      grid: CHART_GRID_DEFAULT,
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "shadow" },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        formatter: (params: any) => {
          const valueParam = (params as Array<{ axisValue: string; data: number; seriesName: string }>)
            .find((p) => p.seriesName === "value");
          if (!valueParam) return "";
          return `${valueParam.axisValue}<br/>${formatValue(valueParam.data, valueFormat)}`;
        },
      },
      xAxis: {
        type: "category",
        data: categories,
        axisLine: { lineStyle: { color: AXIS_LINE_COLOR } },
        axisLabel: { color: AXIS_LABEL_COLOR, interval: 0, rotate: categories.length > 6 ? 30 : 0 },
      },
      yAxis: {
        type: "value",
        axisLabel: { color: AXIS_LABEL_COLOR, formatter: (v: number) => formatCompact(v) },
        splitLine: { lineStyle: { color: AXIS_LINE_COLOR } },
      },
      series: [
        {
          name: "base",
          type: "bar",
          stack: "total",
          silent: true,
          itemStyle: { color: "transparent" },
          emphasis: { itemStyle: { color: "transparent" } },
          data: base,
        },
        {
          name: "value",
          type: "bar",
          stack: "total",
          barMaxWidth: 36,
          itemStyle: {
            color: (params: { dataIndex: number }) =>
              params.dataIndex === categories.length - 1 ? TOTAL_COLOR : POSITIVE_COLOR,
            borderRadius: [3, 3, 0, 0],
          },
          data: increments,
        },
      ],
    };
  }, [data, metric, valueFormat]);

  return (
    <EChartWrapper
      title={title}
      option={option}
      loading={isLoading}
      error={error}
      isEmpty={Boolean(data) && data!.categories.length === 0}
      height={height}
    />
  );
}
