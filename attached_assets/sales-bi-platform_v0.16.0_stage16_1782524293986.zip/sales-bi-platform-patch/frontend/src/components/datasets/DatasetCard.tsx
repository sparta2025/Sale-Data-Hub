// VERSION: 1.0.0
// Path: frontend/src/components/datasets/DatasetCard.tsx
// CHANGES v1.0.0:
//   - Этап 7: карточка датасета для списка — имя, формат, размер, статус, действия
import {
  Card, CardActionArea, CardContent, Typography, Chip, Stack, IconButton, Tooltip,
} from "@mui/material";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import TableChartIcon from "@mui/icons-material/TableChart";
import type { DatasetOut } from "@/types";

interface DatasetCardProps {
  dataset: DatasetOut;
  onOpen: (dataset: DatasetOut) => void;
  onDelete: (dataset: DatasetOut) => void;
}

const formatDate = (iso: string) =>
  new Date(iso).toLocaleString("ru-RU", { dateStyle: "medium", timeStyle: "short" });

export function DatasetCard({ dataset, onOpen, onDelete }: DatasetCardProps) {
  const isFailed = dataset.status === "failed";

  return (
    <Card variant="outlined">
      <CardActionArea onClick={() => onOpen(dataset)} disabled={isFailed}>
        <CardContent>
          <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
            <Stack direction="row" spacing={1} alignItems="center">
              <TableChartIcon color={isFailed ? "disabled" : "primary"} fontSize="small" />
              <Typography variant="subtitle1" fontWeight={600}>
                {dataset.name}
              </Typography>
            </Stack>
            <Chip
              size="small"
              label={isFailed ? "Ошибка импорта" : "Готов"}
              color={isFailed ? "error" : "success"}
              variant="outlined"
            />
          </Stack>

          <Typography variant="body2" color="text.secondary" mt={0.5}>
            {dataset.original_filename} · {dataset.source_format.toUpperCase()}
          </Typography>

          <Stack direction="row" spacing={2} mt={1.5}>
            <Typography variant="caption" color="text.secondary">
              {dataset.row_count.toLocaleString("ru-RU")} строк
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {dataset.column_count} колонок
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {formatDate(dataset.created_at)}
            </Typography>
          </Stack>
        </CardContent>
      </CardActionArea>
      <Stack direction="row" justifyContent="flex-end" sx={{ px: 1, pb: 0.5 }}>
        <Tooltip title="Удалить датасет">
          <IconButton
            size="small"
            color="error"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(dataset);
            }}
          >
            <DeleteOutlineIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Stack>
    </Card>
  );
}
