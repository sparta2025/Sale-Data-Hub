// VERSION: 1.0.0
// Path: frontend/src/components/datasets/DimensionsTable.tsx
// CHANGES v1.0.0:
//   - Этап 7: таблица измерений датасета — inline-редактирование display_name,
//     переключатель видимости, отображение иерархии (group/level)
import { useState } from "react";
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, TextField, Switch, Chip, Stack,
} from "@mui/material";
import { usePatchDimension } from "@/hooks/useMetadata";
import type { DimensionOut } from "@/types";

function EditableName({ dimension, datasetId }: { dimension: DimensionOut; datasetId: string }) {
  const [value, setValue] = useState(dimension.display_name);
  const { mutate } = usePatchDimension(datasetId);

  return (
    <TextField
      variant="standard"
      size="small"
      value={value}
      onChange={(e) => setValue(e.target.value)}
      onBlur={() => {
        if (value.trim() && value !== dimension.display_name) {
          mutate({ dimensionId: dimension.id, patch: { display_name: value.trim() } });
        }
      }}
    />
  );
}

export function DimensionsTable({ dimensions, datasetId }: { dimensions: DimensionOut[]; datasetId: string }) {
  const { mutate: patchVisibility } = usePatchDimension(datasetId);

  return (
    <TableContainer component={Paper} variant="outlined">
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Отображаемое имя</TableCell>
            <TableCell>Колонка</TableCell>
            <TableCell>Тип</TableCell>
            <TableCell>Иерархия</TableCell>
            <TableCell align="right">Уникальных значений</TableCell>
            <TableCell align="center">Видимо</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {dimensions.map((dim) => (
            <TableRow key={dim.id} hover>
              <TableCell>
                <EditableName dimension={dim} datasetId={datasetId} />
              </TableCell>
              <TableCell>
                <Stack direction="row" alignItems="center" spacing={0.5}>
                  <code style={{ fontSize: 12, opacity: 0.7 }}>{dim.column_name}</code>
                </Stack>
              </TableCell>
              <TableCell>{dim.data_type}</TableCell>
              <TableCell>
                {dim.hierarchy_group ? (
                  <Chip
                    size="small"
                    label={`${dim.hierarchy_group} · уровень ${dim.hierarchy_level}`}
                    variant="outlined"
                  />
                ) : (
                  "—"
                )}
              </TableCell>
              <TableCell align="right">{dim.distinct_count.toLocaleString("ru-RU")}</TableCell>
              <TableCell align="center">
                <Switch
                  size="small"
                  checked={dim.is_visible}
                  onChange={(e) =>
                    patchVisibility({
                      dimensionId: dim.id,
                      patch: { is_visible: e.target.checked },
                    })
                  }
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
