// VERSION: 1.0.0
// Path: frontend/src/components/datasets/MetricsTable.tsx
// CHANGES v1.0.0:
//   - Этап 7: таблица метрик датасета — inline-редактирование display_name,
//     выбор агрегации, переключатель видимости
import { useState } from "react";
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, TextField, Switch, Select, MenuItem, type SelectChangeEvent,
} from "@mui/material";
import { usePatchMetric } from "@/hooks/useMetadata";
import type { AggregationMethod, MetricOut } from "@/types";

const AGGREGATION_LABELS: Record<AggregationMethod, string> = {
  sum: "Сумма",
  avg: "Среднее",
  count: "Количество",
  min: "Минимум",
  max: "Максимум",
};

function EditableName({ metric, datasetId }: { metric: MetricOut; datasetId: string }) {
  const [value, setValue] = useState(metric.display_name);
  const { mutate } = usePatchMetric(datasetId);

  return (
    <TextField
      variant="standard"
      size="small"
      value={value}
      onChange={(e) => setValue(e.target.value)}
      onBlur={() => {
        if (value.trim() && value !== metric.display_name) {
          mutate({ metricId: metric.id, patch: { display_name: value.trim() } });
        }
      }}
    />
  );
}

export function MetricsTable({ metrics, datasetId }: { metrics: MetricOut[]; datasetId: string }) {
  const { mutate: patchMetric } = usePatchMetric(datasetId);

  const handleAggregationChange = (metric: MetricOut, event: SelectChangeEvent) => {
    patchMetric({
      metricId: metric.id,
      patch: { aggregation: event.target.value as AggregationMethod },
    });
  };

  return (
    <TableContainer component={Paper} variant="outlined">
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Отображаемое имя</TableCell>
            <TableCell>Колонка</TableCell>
            <TableCell>Тип</TableCell>
            <TableCell>Агрегация</TableCell>
            <TableCell>Формат</TableCell>
            <TableCell align="center">Видимо</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {metrics.map((metric) => (
            <TableRow key={metric.id} hover>
              <TableCell>
                <EditableName metric={metric} datasetId={datasetId} />
              </TableCell>
              <TableCell>
                <code style={{ fontSize: 12, opacity: 0.7 }}>{metric.column_name}</code>
              </TableCell>
              <TableCell>{metric.data_type}</TableCell>
              <TableCell>
                <Select
                  variant="standard"
                  size="small"
                  value={metric.aggregation}
                  onChange={(e) => handleAggregationChange(metric, e)}
                >
                  {Object.entries(AGGREGATION_LABELS).map(([value, label]) => (
                    <MenuItem key={value} value={value}>{label}</MenuItem>
                  ))}
                </Select>
              </TableCell>
              <TableCell>
                <code style={{ fontSize: 12, opacity: 0.7 }}>{metric.display_format}</code>
              </TableCell>
              <TableCell align="center">
                <Switch
                  size="small"
                  checked={metric.is_visible}
                  onChange={(e) =>
                    patchMetric({
                      metricId: metric.id,
                      patch: { is_visible: e.target.checked },
                    })
                  }
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
