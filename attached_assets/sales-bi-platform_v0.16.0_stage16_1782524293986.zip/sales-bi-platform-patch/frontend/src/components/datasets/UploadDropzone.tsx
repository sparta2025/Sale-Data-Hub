// VERSION: 1.0.0
// Path: frontend/src/components/datasets/UploadDropzone.tsx
// CHANGES v1.0.0:
//   - Этап 7: drag-n-drop зона загрузки CSV/XLSX поверх useUploadDataset
import { useRef, useState, type DragEvent } from "react";
import { Box, Typography, CircularProgress, Alert, Stack } from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { useUploadDataset } from "@/hooks/useDatasets";

const ACCEPTED_EXTENSIONS = [".csv", ".tsv", ".xlsx", ".xlsm"];

interface UploadDropzoneProps {
  onUploaded?: (datasetId: string) => void;
}

export function UploadDropzone({ onUploaded }: UploadDropzoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const { mutate, isPending, error, reset } = useUploadDataset();

  const handleFile = (file: File) => {
    reset();
    mutate(file, {
      onSuccess: (response) => onUploaded?.(response.dataset.id),
    });
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  return (
    <Stack spacing={1.5}>
      <Box
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        sx={{
          border: "2px dashed",
          borderColor: isDragging ? "primary.main" : "divider",
          borderRadius: 2,
          p: 4,
          textAlign: "center",
          cursor: "pointer",
          bgcolor: isDragging ? "action.hover" : "background.paper",
          transition: "all 0.15s ease",
        }}
      >
        <input
          ref={inputRef}
          type="file"
          hidden
          accept={ACCEPTED_EXTENSIONS.join(",")}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
            e.target.value = ""; // позволяет повторно выбрать тот же файл
          }}
        />
        {isPending ? (
          <Stack alignItems="center" spacing={1}>
            <CircularProgress size={32} />
            <Typography variant="body2" color="text.secondary">Загружаем и анализируем файл…</Typography>
          </Stack>
        ) : (
          <Stack alignItems="center" spacing={1}>
            <CloudUploadIcon fontSize="large" color="action" />
            <Typography variant="body2">
              Перетащите CSV/XLSX сюда или нажмите, чтобы выбрать файл
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Поддерживаются: {ACCEPTED_EXTENSIONS.join(", ")}
            </Typography>
          </Stack>
        )}
      </Box>
      {error && <Alert severity="error">{error.message}</Alert>}
    </Stack>
  );
}
