// VERSION: 1.1.0
// Path: frontend/src/components/kpi/KpiCard.tsx
// CHANGES v1.0.0:
//   - Этап 8: карточка KPI — значение + агрегация
// CHANGES v1.1.0:
//   - Этап 10: i18n — метки агрегаций через useTranslation().t.kpi
import { Paper, Typography, Stack, Chip, Skeleton } from "@mui/material";
import { formatValue } from "@/utils/formatValue";
import { useTranslation } from "@/context/I18nContext";
import type { KpiCard as KpiCardData } from "@/types";

interface KpiCardProps {
  data?: KpiCardData;
  loading?: boolean;
}

export function KpiCard({ data, loading }: KpiCardProps) {
  const { t } = useTranslation();

  const AGGREGATION_LABELS: Record<string, string> = {
    sum: t.kpi.sum,
    avg: t.kpi.avg,
    count: t.kpi.count,
    min: "min",
    max: "max",
  };

  if (loading || !data) {
    return (
      <Paper variant="outlined" sx={{ p: 2, minWidth: 200, flex: 1 }}>
        <Skeleton width="60%" height={20} />
        <Skeleton width="80%" height={36} sx={{ mt: 1 }} />
      </Paper>
    );
  }

  return (
    <Paper variant="outlined" sx={{ p: 2, minWidth: 200, flex: 1 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" mb={0.5}>
        <Typography variant="body2" color="text.secondary" noWrap title={data.display_name}>
          {data.display_name}
        </Typography>
        <Chip
          size="small"
          label={AGGREGATION_LABELS[data.aggregation] ?? data.aggregation}
          variant="outlined"
          sx={{ height: 18, fontSize: 10 }}
        />
      </Stack>
      <Typography variant="h5" fontWeight={700}>
        {formatValue(data.value, data.display_format)}
      </Typography>
    </Paper>
  );
}
