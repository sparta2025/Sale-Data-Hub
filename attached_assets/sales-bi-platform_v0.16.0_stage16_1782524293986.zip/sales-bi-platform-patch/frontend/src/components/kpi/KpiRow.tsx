// VERSION: 1.0.0
// Path: frontend/src/components/kpi/KpiRow.tsx
// CHANGES v1.0.0:
//   - Этап 8: ряд KPI-карточек — useKpi(metrics) + skeleton при загрузке,
//     реагирует на фильтры автоматически (через useFilters внутри useKpi)
import { Stack, Alert } from "@mui/material";
import { useKpi } from "@/hooks/useDashboardData";
import { KpiCard } from "./KpiCard";

interface KpiRowProps {
  metrics: string[];
}

export function KpiRow({ metrics }: KpiRowProps) {
  const { data, isLoading, error } = useKpi(metrics);

  if (metrics.length === 0) return null;
  if (error) return <Alert severity="error">{error.message}</Alert>;

  return (
    <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap mb={3}>
      {isLoading
        ? metrics.map((m) => <KpiCard key={m} loading />)
        : data?.map((kpi) => <KpiCard key={kpi.metric} data={kpi} />)}
    </Stack>
  );
}
