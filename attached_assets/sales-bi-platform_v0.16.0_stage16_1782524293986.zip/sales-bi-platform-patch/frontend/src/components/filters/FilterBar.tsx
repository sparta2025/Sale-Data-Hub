// VERSION: 1.4.0
// Path: frontend/src/components/filters/FilterBar.tsx
// CHANGES v1.0.0:
//   - Этап 7: панель фильтров — мультивыбор значений по видимым измерениям
//     датасета (Autocomplete + useDistinctValues), привязана к FiltersContext
// CHANGES v1.1.0:
//   - Этап 8: максимум видимых тегов читается из VITE_FILTER_MAX_VISIBLE_TAGS (.env)
// CHANGES v1.2.0:
//   - Патч: контрастные chips
// CHANGES v1.3.0:
//   - Этап 11: полный i18n
// CHANGES v1.4.0:
//   - Этап 16: AgentBus.emit при изменении фильтров (hookId=dashboards.filter_change)
//   - Этап 11: полный i18n через useTranslation().t.filters
//   - Патч: контрастные chip-теги выбранных значений — синий фон (#2563eb),
//     белый текст, белая крестик-иконка. Chip «+N» — тёмно-синий фон.
//     Hover-состояние опций в dropdown — контрастный синий фон.
//     Выбранная опция в списке отмечена галочкой + синий цвет текста.
import { useMemo } from "react";
import {
  Box, Paper, Autocomplete, TextField, Chip, Stack, Typography, Button, CircularProgress,
  Checkbox,
} from "@mui/material";
import ClearAllIcon from "@mui/icons-material/ClearAll";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import { useFilters } from "@/context/FiltersContext";
import { useTranslation } from "@/context/I18nContext";
import { AgentBus } from "@/modules/agents/AgentBus";
import { useMetadataOverview } from "@/hooks/useMetadata";
import { useDistinctValues } from "@/hooks/useQueryEngine";
import type { DimensionOut, InFilter } from "@/types";

const PRIMARY = "#2563eb";
const PRIMARY_DARK = "#1d4ed8";
const PRIMARY_LIGHT = "#dbeafe";

function DimensionFilter({ dimension }: { dimension: DimensionOut }) {
  const { datasetId, filters, setFilter, removeFilter } = useFilters();
  const { data: values, isLoading } = useDistinctValues(datasetId ?? undefined, dimension.column_name);

  const currentFilter = filters[dimension.column_name];
  const selectedValues = useMemo<string[]>(() => {
    if (!currentFilter) return [];
    if (currentFilter.type === "in") return currentFilter.values.map(String);
    if (currentFilter.type === "eq") return [String(currentFilter.value)];
    return [];
  }, [currentFilter]);

  const options = useMemo(() => (values ?? []).map(String), [values]);

  const maxVisible = Number(import.meta.env.VITE_FILTER_MAX_VISIBLE_TAGS ?? 2);

  return (
    <Autocomplete
      multiple
      disableCloseOnSelect
      size="small"
      options={options}
      value={selectedValues}
      loading={isLoading}
      sx={{
        minWidth: 220,
        "& .MuiAutocomplete-listbox .MuiAutocomplete-option": {
          "&:hover": {
            backgroundColor: PRIMARY_LIGHT,
          },
          "&.Mui-focused": {
            backgroundColor: PRIMARY_LIGHT,
          },
          '&[aria-selected="true"]': {
            backgroundColor: `${PRIMARY}18`,
            color: PRIMARY_DARK,
            fontWeight: 600,
          },
          '&[aria-selected="true"]:hover': {
            backgroundColor: `${PRIMARY}28`,
          },
        },
      }}
      onChange={(_event, newValues) => {
        if (newValues.length === 0) {
          removeFilter(dimension.column_name);
          AgentBus.emit("dashboards.filter_change", "dashboards", {
            dimension: dimension.column_name, values: [],
          });
          return;
        }
        const filter: InFilter = { type: "in", values: newValues };
        setFilter(dimension.column_name, filter);
        AgentBus.emit("dashboards.filter_change", "dashboards", {
          dimension: dimension.column_name, values: newValues,
        });
      }}
      renderOption={(props, option, { selected }) => (
        <li {...props}>
          <Checkbox
            icon={<CheckBoxOutlineBlankIcon fontSize="small" />}
            checkedIcon={<CheckBoxIcon fontSize="small" />}
            style={{ marginRight: 6, padding: 2, color: selected ? PRIMARY : undefined }}
            checked={selected}
          />
          <Typography
            variant="body2"
            sx={{ color: selected ? PRIMARY_DARK : "inherit", fontWeight: selected ? 600 : 400 }}
          >
            {option}
          </Typography>
        </li>
      )}
      renderInput={(params) => (
        <TextField
          {...params}
          label={dimension.display_name}
          placeholder={selectedValues.length === 0 ? t.filters.all : undefined}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {isLoading ? <CircularProgress color="inherit" size={16} /> : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
          sx={{
            "& .MuiOutlinedInput-root": {
              ...(selectedValues.length > 0 && {
                "& fieldset": { borderColor: PRIMARY, borderWidth: 2 },
                "&:hover fieldset": { borderColor: PRIMARY_DARK },
              }),
            },
            "& .MuiInputLabel-root": {
              ...(selectedValues.length > 0 && { color: PRIMARY }),
            },
          }}
        />
      )}
      renderTags={(tagValues, getTagProps) => {
        const visible = tagValues.slice(0, maxVisible).map((val, index) => (
          <Chip
            {...getTagProps({ index })}
            key={val}
            label={val}
            size="small"
            sx={{
              backgroundColor: PRIMARY,
              color: "#fff",
              fontWeight: 600,
              fontSize: "0.72rem",
              "& .MuiChip-deleteIcon": {
                color: "rgba(255,255,255,0.8)",
                "&:hover": { color: "#fff" },
              },
            }}
          />
        ));
        const overflowChip =
          tagValues.length > maxVisible
            ? [
                <Chip
                  key="more"
                  size="small"
                  label={`+${tagValues.length - maxVisible}`}
                  sx={{
                    backgroundColor: PRIMARY_DARK,
                    color: "#fff",
                    fontWeight: 700,
                    fontSize: "0.72rem",
                    cursor: "pointer",
                  }}
                />,
              ]
            : [];
        return [...visible, ...overflowChip];
      }}
    />
  );
}

export function FilterBar() {
  const { t } = useTranslation();
  const { datasetId, activeFilterCount, clearFilters } = useFilters();
  const { data: overview, isLoading } = useMetadataOverview(datasetId ?? undefined);

  if (!datasetId) {
    return (
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="body2" color="text.secondary">
          Выберите датасет, чтобы настроить фильтры.
        </Typography>
      </Paper>
    );
  }

  const visibleDimensions = (overview?.dimensions ?? []).filter((d) => d.is_visible);

  return (
    <Paper
      variant="outlined"
      sx={{
        p: 2,
        mb: 2,
        ...(activeFilterCount > 0 && {
          borderColor: PRIMARY,
          borderWidth: 1.5,
        }),
      }}
    >
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1.5}>
        <Typography variant="subtitle2" color="text.secondary">
          Фильтры{" "}
          {activeFilterCount > 0 && (
            <Box
              component="span"
              sx={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                ml: 0.5,
                px: 0.8,
                py: 0.1,
                borderRadius: "10px",
                backgroundColor: PRIMARY,
                color: "#fff",
                fontSize: "0.7rem",
                fontWeight: 700,
                lineHeight: 1.6,
                minWidth: 20,
              }}
            >
              {activeFilterCount}
            </Box>
          )}
        </Typography>
        {activeFilterCount > 0 && (
          <Button
            size="small"
            startIcon={<ClearAllIcon />}
            onClick={clearFilters}
            sx={{ color: PRIMARY, "&:hover": { backgroundColor: PRIMARY_LIGHT } }}
          >
            Очистить всё
          </Button>
        )}
      </Stack>

      {isLoading ? (
        <Typography variant="body2" color="text.secondary">Загрузка измерений…</Typography>
      ) : (
        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1.5 }}>
          {visibleDimensions.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              У этого датасета нет видимых измерений для фильтрации.
            </Typography>
          )}
          {visibleDimensions.map((dim) => (
            <DimensionFilter key={dim.id} dimension={dim} />
          ))}
        </Box>
      )}
    </Paper>
  );
}
