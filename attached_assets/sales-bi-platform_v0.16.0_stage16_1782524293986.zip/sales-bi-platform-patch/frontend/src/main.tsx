// VERSION: 1.0.0
// Path: frontend/src/main.tsx
// CHANGES v1.0.0:
//   - Этап 1: точка входа React (ReactDOM.createRoot)
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
