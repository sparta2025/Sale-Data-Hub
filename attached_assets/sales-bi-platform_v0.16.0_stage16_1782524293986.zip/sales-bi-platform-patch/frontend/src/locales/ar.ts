// VERSION: 1.0.0 — العربية (RTL)
export const ar = {
  nav: { datasets: "مجموعات البيانات", dashboard: "لوحة التحكم", savedDashboards: "اللوحات المحفوظة", selectDatasetFirst: "الرجاء اختيار مجموعة بيانات أولاً" },
  filters: { title: "الفلاتر", clearAll: "مسح الكل", all: "الكل", loading: "جار تحميل الأبعاد…", noVisibleDimensions: "لا توجد أبعاد مرئية", noDataset: "اختر مجموعة بيانات" },
  kpi: { sum: "مجموع", avg: "متوسط", count: "عدد" },
  charts: { contextMenu: { scale: "المقياس", fullWidth: "توسيع لعرض الصفحة", fullScreen: "ملء الشاشة", default: "الافتراضي", resizeCorner: "تغيير الحجم" }, noData: "لا توجد بيانات", loading: "جار التحميل…", error: "خطأ في التحميل" },
  dashboard: { title: "لوحة التحكم", metricForCharts: "المقياس للرسوم البيانية", noVisibleMetrics: "لا توجد مقاييس مرئية.", availableCharts: "الرسوم البيانية المتاحة", showChart: "إظهار", hideChart: "إخفاء", dragHint: "اسحب الرسم البياني إلى الموضع المطلوب" },
  datasets: { title: "مجموعات البيانات", noDatasets: "لا توجد مجموعات بيانات", current: "الحالي", upload: "رفع مجموعة بيانات" },
  savedDashboards: { title: "اللوحات المحفوظة", save: "حفظ اللوحة", noSaved: "لا توجد لوحات محفوظة", delete: "حذف", open: "فتح" },
  settings: { theme: "المظهر", language: "اللغة", themeLight: "فاتح", themeDark: "داكن", themeNeutral: "محايد" },
  map: { clickHint: "انقر للتحديد. انقر مرتين للتحليل.", dblClickHint: "نقر مزدوج — مجموعات المنتجات", allCountries: "جميع الدول", categories: "مجموعات المنتجات", products: "المنتجات", showProducts: "عرض المنتجات ←", total: "المجموع", back: "رجوع", reset: "إعادة تعيين", groups: "مجموعات", items: "منتجات", noData: "لا توجد بيانات", ctrlClickHint: "Ctrl+نقر — تحديد متعدد", branches: "فروع" },
  table: { rowsPerPage: "صفوف في الصفحة", exportCsv: "تصدير CSV" },
  common: { save: "حفظ", cancel: "إلغاء", delete: "حذف", confirm: "تأكيد", search: "بحث", selectAll: "تحديد الكل", clearSelection: "إلغاء التحديد", close: "إغلاق" },


  modules: {
    dashboards: { name: "لوحات التحكم", description: "لوحات BI تفاعلية: 15 نوعاً من الرسوم البيانية" },
    kpi:        { name: "تحليل KPI", description: "تحليل KPI: بطاقة الأداء، مقارنة الفترات، الاتجاهات" },
    agents:     { name: "وكلاء الذكاء الاصطناعي", description: "تكامل وكلاء الذكاء الاصطناعي" },
  },
  pages: {
    datasets: {
      title: "مجموعات البيانات", uploadHint: "ارفع ملف CSV أو XLSX لبدء التحليل",
      noDatasets: "لا توجد مجموعات بيانات بعد — ارفع ملفاً أعلاه.",
      deleteTitle: "حذف مجموعة البيانات؟",
      deleteText: "لا يمكن التراجع عن هذا الإجراء.",
      deleteBtn: "حذف", cancelBtn: "إلغاء",
    },
    datasetDetail: {
      previewTab: "معاينة البيانات", metadataTab: "البيانات الوصفية",
      openDashboard: "فتح لوحة التحكم", rows: "صفوف", columns: "أعمدة",
      refreshMeta: "تحديث البيانات الوصفية",
    },
    savedDashboards: {
      title: "اللوحات المحفوظة", newDashboard: "لوحة جديدة", nameLabel: "اسم اللوحة",
      createBtn: "إنشاء", noSaved: "لا توجد لوحات محفوظة بعد.",
      updated: "تم التحديث",
    },
  },
  chartNames: { line: "خطي (بمرور الوقت)", bar: "شريطي", pie: "دائري", treemap: "خريطة شجرية", heatmap: "خريطة حرارية", waterfall: "شلالي", map: "خريطة الفروع", table: "جدول محوري", scatter: "مبعثر", histogram: "رسم بياني للتوزيع" },
};
