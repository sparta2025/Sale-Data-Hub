// VERSION: 1.0.0 — 한국어
export const ko = {
  nav: { datasets: "데이터셋", dashboard: "대시보드", savedDashboards: "저장된 대시보드", selectDatasetFirst: "먼저 데이터셋을 선택하세요" },
  filters: { title: "필터", clearAll: "모두 지우기", all: "전체", loading: "차원 로딩 중…", noVisibleDimensions: "표시 가능한 차원 없음", noDataset: "데이터셋 선택" },
  kpi: { sum: "합계", avg: "평균", count: "개수" },
  charts: { contextMenu: { scale: "크기 조정", fullWidth: "페이지 너비로 확장", fullScreen: "전체 화면", default: "기본값", resizeCorner: "크기 조정 (모서리)" }, noData: "데이터 없음", loading: "로딩 중…", error: "로드 오류" },
  dashboard: { title: "대시보드", metricForCharts: "차트 지표", noVisibleMetrics: "표시 가능한 지표 없음.", availableCharts: "사용 가능한 차트", showChart: "표시", hideChart: "숨기기", dragHint: "차트를 원하는 위치로 드래그하세요" },
  datasets: { title: "데이터셋", noDatasets: "데이터셋 없음", current: "현재", upload: "데이터셋 업로드" },
  savedDashboards: { title: "저장된 대시보드", save: "대시보드 저장", noSaved: "저장된 대시보드 없음", delete: "삭제", open: "열기" },
  settings: { theme: "테마", language: "언어", themeLight: "라이트", themeDark: "다크", themeNeutral: "중립" },
  map: { clickHint: "클릭으로 선택. 더블클릭으로 제품 분석.", dblClickHint: "더블클릭 — 제품 그룹", allCountries: "모든 국가", categories: "제품 그룹", products: "제품", showProducts: "제품 보기 →", total: "합계", back: "뒤로", reset: "초기화", groups: "그룹", items: "제품", noData: "데이터 없음", ctrlClickHint: "Ctrl+클릭 — 다중 선택", branches: "지점" },
  table: { rowsPerPage: "페이지당 행", exportCsv: "CSV 내보내기" },
  common: { save: "저장", cancel: "취소", delete: "삭제", confirm: "확인", search: "검색", selectAll: "모두 선택", clearSelection: "선택 해제", close: "닫기" },


  modules: {
    dashboards: { name: "대시보드", description: "인터랙티브 BI 대시보드: 15가지 차트 유형" },
    kpi:        { name: "KPI 분석", description: "KPI 분석: 스코어카드, 기간 비교, 트렌드" },
    agents:     { name: "AI 에이전트", description: "AI 에이전트 통합: 인사이트, 이상 감지" },
  },
  pages: {
    datasets: {
      title: "데이터셋", uploadHint: "분석을 시작하려면 CSV 또는 XLSX 파일을 업로드하세요",
      noDatasets: "데이터셋이 없습니다 — 위에서 파일을 업로드하세요.",
      deleteTitle: "데이터셋 삭제?",
      deleteText: "이 작업은 취소할 수 없습니다.",
      deleteBtn: "삭제", cancelBtn: "취소",
    },
    datasetDetail: {
      previewTab: "데이터 미리보기", metadataTab: "메타데이터",
      openDashboard: "대시보드 열기", rows: "행", columns: "열",
      refreshMeta: "메타데이터 새로고침",
    },
    savedDashboards: {
      title: "저장된 대시보드", newDashboard: "새 대시보드", nameLabel: "대시보드 이름",
      createBtn: "만들기", noSaved: "저장된 대시보드가 없습니다.",
      updated: "업데이트됨",
    },
  },
  chartNames: { line: "꺾은선형 (시계열)", bar: "막대형", pie: "원형", treemap: "트리맵", heatmap: "히트맵", waterfall: "폭포형", map: "지점 지도", table: "피벗 테이블", scatter: "산점도", histogram: "히스토그램" },
};
