// VERSION: 1.0.0 — Deutsch
export const de = {
  nav: { datasets: "Datensätze", dashboard: "Dashboard", savedDashboards: "Gespeicherte Dashboards", selectDatasetFirst: "Bitte zuerst Datensatz auswählen" },
  filters: { title: "Filter", clearAll: "Alle löschen", all: "Alle", loading: "Dimensionen laden…", noVisibleDimensions: "Keine sichtbaren Dimensionen", noDataset: "Datensatz auswählen" },
  kpi: { sum: "Summe", avg: "Mittel", count: "Anzahl" },
  charts: { contextMenu: { scale: "Maßstab", fullWidth: "Seitenbreite", fullScreen: "Vollbild", default: "Standard", resizeCorner: "Größe ändern" }, noData: "Keine Daten", loading: "Laden…", error: "Ladefehler" },
  dashboard: { title: "Dashboard", metricForCharts: "Metrik für Diagramme", noVisibleMetrics: "Keine sichtbaren Metriken.", availableCharts: "Verfügbare Diagramme", showChart: "Anzeigen", hideChart: "Ausblenden", dragHint: "Diagramm ziehen" },
  datasets: { title: "Datensätze", noDatasets: "Keine Datensätze", current: "Aktuell", upload: "Datensatz hochladen" },
  savedDashboards: { title: "Gespeicherte Dashboards", save: "Dashboard speichern", noSaved: "Keine gespeicherten Dashboards", delete: "Löschen", open: "Öffnen" },
  settings: { theme: "Thema", language: "Sprache", themeLight: "Hell", themeDark: "Dunkel", themeNeutral: "Neutral" },
  map: { clickHint: "Klick = auswählen. Doppelklick = Produktanalyse.", dblClickHint: "Doppelklick — Produktgruppen", allCountries: "Alle Länder", categories: "Produktgruppen", products: "Produkte", showProducts: "Produkte anzeigen →", total: "Gesamt", back: "Zurück", reset: "Zurücksetzen", groups: "Gruppen", items: "Artikel", noData: "Keine Daten", ctrlClickHint: "Strg+Klick — Mehrfachauswahl", branches: "Filialen" },
  table: { rowsPerPage: "Zeilen pro Seite", exportCsv: "CSV exportieren" },
  common: { save: "Speichern", cancel: "Abbrechen", delete: "Löschen", confirm: "Bestätigen", search: "Suchen", selectAll: "Alle auswählen", clearSelection: "Auswahl aufheben", close: "Schließen" },


  modules: {
    dashboards: { name: "Dashboards", description: "Interaktive BI-Dashboards: 15 Diagrammtypen, Drag-and-Drop, Drill-Down" },
    kpi:        { name: "KPI Analyse", description: "KPI-Analyse: Scorecard, Periodenvergleich, Trends" },
    agents:     { name: "KI-Agenten", description: "KI-Agentenintegration: Erkenntnisse, Anomalien, Prognosen" },
  },
  pages: {
    datasets: {
      title: "Datensätze", uploadHint: "CSV- oder XLSX-Datei hochladen",
      noDatasets: "Noch keine Datensätze — laden Sie eine CSV- oder XLSX-Datei hoch.",
      deleteTitle: "Datensatz löschen?",
      deleteText: "Diese Aktion kann nicht rückgängig gemacht werden.",
      deleteBtn: "Löschen", cancelBtn: "Abbrechen",
    },
    datasetDetail: {
      previewTab: "Datenvorschau", metadataTab: "Metadaten",
      openDashboard: "Dashboard öffnen", rows: "Zeilen", columns: "Spalten",
      refreshMeta: "Metadaten aktualisieren",
    },
    savedDashboards: {
      title: "Gespeicherte Dashboards", newDashboard: "Neues Dashboard", nameLabel: "Dashboard-Name",
      createBtn: "Erstellen", noSaved: "Keine gespeicherten Dashboards.",
      updated: "Aktualisiert",
    },
  },
  chartNames: { line: "Liniendiagramm", bar: "Balkendiagramm", pie: "Kreisdiagramm", treemap: "Treemap", heatmap: "Heatmap", waterfall: "Wasserfall", map: "Filialkarte", table: "Pivot-Tabelle", scatter: "Streudiagramm", histogram: "Histogramm" },
};
