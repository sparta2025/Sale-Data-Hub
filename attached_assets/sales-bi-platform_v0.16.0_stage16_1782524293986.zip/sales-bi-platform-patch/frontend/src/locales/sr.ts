// VERSION: 1.0.0 — Српски
export const sr = {
  nav: { datasets: "Скупови података", dashboard: "Контролна табла", savedDashboards: "Сачуване контролне табле", selectDatasetFirst: "Прво изаберите скуп података" },
  filters: { title: "Филтери", clearAll: "Очисти све", all: "Све", loading: "Учитавање димензија…", noVisibleDimensions: "Нема видљивих димензија", noDataset: "Изаберите скуп података" },
  kpi: { sum: "збир", avg: "просек", count: "број" },
  charts: { contextMenu: { scale: "Размера", fullWidth: "Прошири на ширину странице", fullScreen: "Цео екран", default: "Подразумевано", resizeCorner: "Промени величину" }, noData: "Нема података", loading: "Учитавање…", error: "Грешка при учитавању" },
  dashboard: { title: "Контролна табла", metricForCharts: "Метрика за графиконе", noVisibleMetrics: "Нема видљивих метрика.", availableCharts: "Доступни графикони", showChart: "Прикажи", hideChart: "Сакриј", dragHint: "Превуците графикон на жељену позицију" },
  datasets: { title: "Скупови података", noDatasets: "Нема учитаних скупова", current: "Тренутни", upload: "Учитај скуп података" },
  savedDashboards: { title: "Сачуване контролне табле", save: "Сачувај контролну таблу", noSaved: "Нема сачуваних табли", delete: "Избриши", open: "Отвори" },
  settings: { theme: "Тема", language: "Језик", themeLight: "Светла", themeDark: "Тамна", themeNeutral: "Неутрална" },
  map: { clickHint: "Клик за избор. Двоструки клик за анализу.", dblClickHint: "Двоструки клик — групе производа", allCountries: "Све земље", categories: "Групе производа", products: "Производи", showProducts: "Прикажи производе →", total: "Укупно", back: "Назад", reset: "Ресетуј", groups: "група", items: "производа", noData: "Нема података", ctrlClickHint: "Ctrl+клик — вишеструки избор", branches: "филијала" },
  table: { rowsPerPage: "Редова по страници", exportCsv: "Извоз CSV" },
  common: { save: "Сачувај", cancel: "Откажи", delete: "Избриши", confirm: "Потврди", search: "Претрага", selectAll: "Изабери све", clearSelection: "Поништи избор", close: "Затвори" },


  modules: {
    dashboards: { name: "Контролне табле", description: "Интерактивне BI контролне табле: 15 врста графикона" },
    kpi:        { name: "KPI Анализа", description: "KPI анализа: скоркарта, поређење периода, трендови" },
    agents:     { name: "ВИ Агенти", description: "Интеграција ВИ агената: увиди, аномалије" },
  },
  pages: {
    datasets: {
      title: "Скупови података", uploadHint: "Учитајте CSV или XLSX датотеку за анализу",
      noDatasets: "Нема скупова података — учитајте датотеку горе.",
      deleteTitle: "Избриши скуп података?",
      deleteText: "Ова радња се не може поништити.",
      deleteBtn: "Избриши", cancelBtn: "Откажи",
    },
    datasetDetail: {
      previewTab: "Преглед података", metadataTab: "Метаподаци",
      openDashboard: "Отвори контролну таблу", rows: "редова", columns: "колона",
      refreshMeta: "Освежи метаподатке",
    },
    savedDashboards: {
      title: "Сачуване контролне табле", newDashboard: "Нова контролна табла", nameLabel: "Назив",
      createBtn: "Направи", noSaved: "Нема сачуваних контролних табли.",
      updated: "Ажурирано",
    },
  },
  chartNames: { line: "Линијски (временски)", bar: "Стубичасти", pie: "Кружни", treemap: "Стабло", heatmap: "Топлотна карта", waterfall: "Водопад", map: "Карта филијала", table: "Збирна табела", scatter: "Тачкасти", histogram: "Хистограм" },
};
