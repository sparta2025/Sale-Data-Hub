// VERSION: 1.0.0 — 中文
export const zh = {
  nav: { datasets: "数据集", dashboard: "仪表板", savedDashboards: "已保存仪表板", selectDatasetFirst: "请先选择数据集" },
  filters: { title: "筛选器", clearAll: "全部清除", all: "全部", loading: "加载维度…", noVisibleDimensions: "没有可见维度", noDataset: "选择数据集" },
  kpi: { sum: "合计", avg: "平均", count: "数量" },
  charts: { contextMenu: { scale: "缩放", fullWidth: "页面宽度", fullScreen: "全屏", default: "默认", resizeCorner: "调整大小" }, noData: "暂无数据", loading: "加载中…", error: "加载错误" },
  dashboard: { title: "仪表板", metricForCharts: "图表指标", noVisibleMetrics: "没有可见指标。", availableCharts: "可用图表", showChart: "显示", hideChart: "隐藏", dragHint: "拖动图表到所需位置" },
  datasets: { title: "数据集", noDatasets: "无数据集", current: "当前", upload: "上传数据集" },
  savedDashboards: { title: "已保存仪表板", save: "保存仪表板", noSaved: "无已保存仪表板", delete: "删除", open: "打开" },
  settings: { theme: "主题", language: "语言", themeLight: "浅色", themeDark: "深色", themeNeutral: "中性" },
  map: { clickHint: "单击国家选择，双击标记分析产品。", dblClickHint: "双击 — 产品组", allCountries: "所有国家", categories: "产品组", products: "产品", showProducts: "显示产品 →", total: "合计", back: "返回", reset: "重置", groups: "组", items: "项目", noData: "暂无数据", ctrlClickHint: "Ctrl+点击 — 多选", branches: "分支" },
  table: { rowsPerPage: "每页行数", exportCsv: "导出CSV" },
  common: { save: "保存", cancel: "取消", delete: "删除", confirm: "确认", search: "搜索", selectAll: "全选", clearSelection: "清除选择", close: "关闭" },


  modules: {
    dashboards: { name: "仪表板", description: "交互式BI仪表板：15种图表类型，拖放，下钻" },
    kpi:        { name: "KPI分析", description: "KPI分析：计分卡，周期比较，趋势" },
    agents:     { name: "AI代理", description: "AI代理集成：洞察，异常，预测" },
  },
  pages: {
    datasets: {
      title: "数据集", uploadHint: "上传CSV或XLSX文件开始分析",
      noDatasets: "暂无数据集 — 请上传CSV或XLSX文件。",
      deleteTitle: "删除数据集？",
      deleteText: "此操作无法撤销。所有相关仪表板也将被删除。",
      deleteBtn: "删除", cancelBtn: "取消",
    },
    datasetDetail: {
      previewTab: "数据预览", metadataTab: "元数据",
      openDashboard: "打开仪表板", rows: "行", columns: "列",
      refreshMeta: "刷新元数据",
    },
    savedDashboards: {
      title: "已保存仪表板", newDashboard: "新建仪表板", nameLabel: "仪表板名称",
      createBtn: "创建", noSaved: "暂无已保存仪表板。",
      updated: "更新于",
    },
  },
  chartNames: { line: "折线图", bar: "柱状图", pie: "饼图", treemap: "树形图", heatmap: "热力图", waterfall: "瀑布图", map: "分支地图", table: "数据透视表", scatter: "散点图", histogram: "直方图" },
};
