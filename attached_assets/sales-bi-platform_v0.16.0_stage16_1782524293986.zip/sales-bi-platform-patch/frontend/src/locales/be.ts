// VERSION: 1.0.0 — Беларуская
export const be = {
  nav: { datasets: "Датасеты", dashboard: "Дашборд", savedDashboards: "Захаваныя дашборды", selectDatasetFirst: "Спачатку выберыце датасет" },
  filters: { title: "Фільтры", clearAll: "Ачысціць усё", all: "Усе", loading: "Загрузка вымярэнняў…", noVisibleDimensions: "Няма бачных вымярэнняў", noDataset: "Выберыце датасет" },
  kpi: { sum: "сума", avg: "сярэдняе", count: "колькасць" },
  charts: { contextMenu: { scale: "Маштаб", fullWidth: "Шырыня старонкі", fullScreen: "Поўны экран", default: "Па змаўчанні", resizeCorner: "Памер (вугал)" }, noData: "Няма дадзеных", loading: "Загрузка…", error: "Памылка загрузкі" },
  dashboard: { title: "Дашборд", metricForCharts: "Метрыка для графікаў", noVisibleMetrics: "Няма бачных метрык.", availableCharts: "Даступныя дыяграмы", showChart: "Паказаць", hideChart: "Схаваць", dragHint: "Перацягніце дыяграму" },
  datasets: { title: "Датасеты", noDatasets: "Няма датасетаў", current: "Бягучы", upload: "Загрузіць датасет" },
  savedDashboards: { title: "Захаваныя дашборды", save: "Захаваць дашборд", noSaved: "Няма захаваных", delete: "Выдаліць", open: "Адкрыць" },
  settings: { theme: "Тэма", language: "Мова", themeLight: "Светлая", themeDark: "Цёмная", themeNeutral: "Нейтральная" },
  map: { clickHint: "Клік — выдзяленне. 2× клік — аналіз тавараў.", dblClickHint: "2× клік — тавар. групы", allCountries: "Усе краіны", categories: "Тавар. групы", products: "Тавары", showProducts: "Паказаць тавары →", total: "Разам", back: "Назад", reset: "Скід", groups: "груп", items: "тавараў", noData: "Няма дадзеных", ctrlClickHint: "Ctrl+клік — мультывыбар", branches: "філіялаў" },
  table: { rowsPerPage: "Радкоў на старонцы", exportCsv: "Экспарт CSV" },
  common: { save: "Захаваць", cancel: "Адмена", delete: "Выдаліць", confirm: "Пацвердзіць", search: "Пошук", selectAll: "Выбраць усё", clearSelection: "Зняць выдзяленне", close: "Зачыніць" },


  modules: {
    dashboards: { name: "Дашборды", description: "Інтэрактыўныя BI-дашборды: 15 тыпаў дыяграм" },
    kpi:        { name: "Аналіз KPI", description: "Аналіз KPI: скоркарта метрык, параўнанне перыядаў" },
    agents:     { name: "ІІ-агенты", description: "Інтэграцыя ІІ-агентаў: інсайты, ананамаліі" },
  },
  pages: {
    datasets: {
      title: "Датасеты", uploadHint: "Загрузіце файл CSV або XLSX для аналізу",
      noDatasets: "Пакуль няма датасетаў — загрузіце файл вышэй.",
      deleteTitle: "Выдаліць датасет?",
      deleteText: "Гэтае дзеянне нельга адмяніць.",
      deleteBtn: "Выдаліць", cancelBtn: "Адмена",
    },
    datasetDetail: {
      previewTab: "Прэв'ю даных", metadataTab: "Метаданыя",
      openDashboard: "Адкрыць дашборд", rows: "радкоў", columns: "калонак",
      refreshMeta: "Абнавіць метаданыя",
    },
    savedDashboards: {
      title: "Захаваныя дашборды", newDashboard: "Новы дашборд", nameLabel: "Назва дашборда",
      createBtn: "Стварыць", noSaved: "Захаваных дашбордаў пакуль няма.",
      updated: "Абноўлены",
    },
  },
  chartNames: { line: "Лінейны (па часе)", bar: "Слупковы", pie: "Кругавая", treemap: "Іерархія", heatmap: "Цеплавая карта", waterfall: "Вадаспад", map: "Карта філіялаў", table: "Зводная табліца", scatter: "Кропкавая", histogram: "Гістаграма" },
};
