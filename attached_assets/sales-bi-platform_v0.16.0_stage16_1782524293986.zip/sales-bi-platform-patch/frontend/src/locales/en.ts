// VERSION: 1.0.0 — English
export const en = {
  nav: {
    datasets: "Datasets", dashboard: "Dashboard", savedDashboards: "Saved Dashboards",
    selectDatasetFirst: "Please select a dataset first",
  },
  filters: {
    title: "Filters", clearAll: "Clear All", all: "All", loading: "Loading dimensions…",
    noVisibleDimensions: "No visible dimensions available for filtering", noDataset: "Select a dataset",
  },
  kpi: { sum: "sum", avg: "avg", count: "count" },
  charts: {
    contextMenu: {
      scale: "Scale", fullWidth: "Expand to page width",
      fullScreen: "Full screen", default: "Default", resizeCorner: "Resize (corner)",
    },
    noData: "No data", loading: "Loading…", error: "Load error",
  },
  dashboard: {
    title: "Dashboard", metricForCharts: "Metric for charts",
    noVisibleMetrics: "No visible metrics. Enable them in dataset settings.",
    availableCharts: "Available charts", showChart: "Show", hideChart: "Hide",
    dragHint: "Drag the chart to desired position",
  },
  datasets: { title: "Datasets", noDatasets: "No datasets loaded", current: "Current", upload: "Upload dataset" },
  savedDashboards: { title: "Saved Dashboards", save: "Save Dashboard", noSaved: "No saved dashboards", delete: "Delete", open: "Open" },
  settings: { theme: "Theme", language: "Language", themeLight: "Light", themeDark: "Dark", themeNeutral: "Neutral" },
  map: {
    clickHint: "Click country to select. Double-click marker for product analysis.",
    dblClickHint: "Double-click — product groups", allCountries: "All Countries",
    categories: "Product Groups", products: "Products",
    showProducts: "Show Products →", total: "Total", back: "Back", reset: "Reset",
    groups: "groups", items: "items", noData: "No data", ctrlClickHint: "Ctrl+click — multi-select",
    branches: "branches",
  },
  table: { rowsPerPage: "Rows per page", exportCsv: "Export CSV" },
  common: { save: "Save", cancel: "Cancel", delete: "Delete", confirm: "Confirm", search: "Search", selectAll: "Select All", clearSelection: "Clear selection", close: "Close" },


  modules: {
    dashboards: { name: "Dashboards", description: "Interactive BI dashboards: 15 chart types, drag-and-drop, drill-down" },
    kpi:        { name: "KPI Analysis", description: "KPI analysis: scorecard, period comparison, trends" },
    agents:     { name: "AI Agents", description: "AI agent integration: insights, anomalies, forecasts" },
  },
  pages: {
    datasets: {
      title: "Datasets", uploadHint: "Upload a CSV or XLSX file to start analysis",
      noDatasets: "No datasets yet — upload a CSV or XLSX file above.",
      deleteTitle: "Delete dataset?",
      deleteText: "This action cannot be undone. All related dashboards will also be deleted.",
      deleteBtn: "Delete", cancelBtn: "Cancel",
    },
    datasetDetail: {
      previewTab: "Data Preview", metadataTab: "Metadata",
      openDashboard: "Open Dashboard", rows: "rows", columns: "columns",
      refreshMeta: "Refresh Metadata",
    },
    savedDashboards: {
      title: "Saved Dashboards", newDashboard: "New Dashboard", nameLabel: "Dashboard name",
      createBtn: "Create", noSaved: "No saved dashboards yet. Create one from the dashboard panel.",
      updated: "Updated",
    },
  },
  chartNames: {
    line: "Line (over time)", bar: "Bar chart", pie: "Pie chart",
    treemap: "Hierarchy (Treemap)", heatmap: "Heatmap", waterfall: "Waterfall",
    map: "Branch map", table: "Pivot table", scatter: "Scatter plot",
    boxplot: "Box Plot",
    radar: "Radar Chart",
    funnel: "Sales Funnel",
    statsummary: "Statistical Summary",
    gauge: "Gauge (KPI)",
    histogram: "Distribution histogram",
  },
};
