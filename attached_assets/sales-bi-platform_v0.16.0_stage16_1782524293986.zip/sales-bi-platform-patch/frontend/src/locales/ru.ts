// VERSION: 1.2.0 — русский (базовый, все ключи)
export const ru = {
  nav: {
    datasets: "Датасеты", dashboard: "Дашборд", savedDashboards: "Сохранённые дашборды",
    selectDatasetFirst: "Сначала выберите датасет",
  },
  filters: {
    title: "Фильтры", clearAll: "Очистить всё", all: "Все", loading: "Загрузка измерений…",
    noVisibleDimensions: "Нет видимых измерений для фильтрации", noDataset: "Выберите датасет",
  },
  kpi: { sum: "сумма", avg: "среднее", count: "кол-во" },
  charts: {
    contextMenu: {
      scale: "Масштаб", fullWidth: "Расширить на ширину страницы",
      fullScreen: "Во весь экран", default: "По умолчанию", resizeCorner: "Растянуть (угол)",
    },
    noData: "Нет данных", loading: "Загрузка…", error: "Ошибка загрузки",
  },
  dashboard: {
    title: "Дашборд", metricForCharts: "Метрика для графиков",
    noVisibleMetrics: "Нет видимых метрик. Включите их в настройках датасета.",
    availableCharts: "Доступные диаграммы", showChart: "Показать", hideChart: "Скрыть",
    dragHint: "Перетащите диаграмму на нужную позицию",
  },
  datasets: {
    title: "Датасеты", noDatasets: "Нет загруженных датасетов", current: "Текущий",
    upload: "Загрузить датасет",
  },
  savedDashboards: {
    title: "Сохранённые дашборды", save: "Сохранить дашборд", noSaved: "Нет сохранённых дашбордов",
    delete: "Удалить", open: "Открыть",
  },
  settings: {
    theme: "Тема", language: "Язык",
    themeLight: "Светлая", themeDark: "Тёмная", themeNeutral: "Нейтральная",
  },
  map: {
    clickHint: "Клик на страну — выделение. 2× клик на маркер — анализ товаров.",
    dblClickHint: "2× клик — товарные группы", allCountries: "Все страны",
    categories: "Товарные группы", products: "Товары",
    showProducts: "Показать товары →", total: "Итого", back: "Назад", reset: "Сброс",
    groups: "групп", items: "товаров", noData: "Нет данных", ctrlClickHint: "Ctrl+клик — мультивыбор",
    branches: "филиалов",
  },
  table: { rowsPerPage: "Строк на странице", exportCsv: "Экспорт CSV" },
  common: {
    save: "Сохранить", cancel: "Отмена", delete: "Удалить", confirm: "Подтвердить",
    search: "Поиск", selectAll: "Выбрать все", clearSelection: "Снять выделение", close: "Закрыть",
  },


  modules: {
    dashboards: { name: "Dashboards", description: "Интерактивные BI-дашборды: 15 типов диаграмм, drag-and-drop, drill-down" },
    kpi:        { name: "KPI Analysis", description: "Анализ KPI: скоркарта метрик, сравнение периодов, тренды" },
    agents:     { name: "AI Agents", description: "Подключение ИИ-агентов: инсайты, аномалии, прогнозы" },
  },
  pages: {
    datasets: {
      title: "Датасеты",
      uploadHint: "Загрузите CSV или XLSX-файл, чтобы начать анализ",
      noDatasets: "Пока нет ни одного датасета — загрузите CSV или XLSX-файл выше.",
      deleteTitle: "Удалить датасет?",
      deleteText: "Это действие нельзя отменить. Все связанные дашборды также будут удалены.",
      deleteBtn: "Удалить",
      cancelBtn: "Отмена",
    },
    datasetDetail: {
      previewTab: "Превью данных",
      metadataTab: "Метаданные",
      openDashboard: "Открыть дашборд",
      rows: "строк",
      columns: "колонок",
      refreshMeta: "Обновить метаданные",
    },
    savedDashboards: {
      title: "Сохранённые дашборды",
      newDashboard: "Новый дашборд",
      nameLabel: "Название дашборда",
      createBtn: "Создать",
      noSaved: "Сохранённых дашбордов пока нет. Создайте первый из панели дашборда.",
      updated: "Обновлён",
    },
  },
  chartNames: {
    line: "Линейный (по времени)", bar: "Столбчатый", pie: "Круговая диаграмма",
    treemap: "Иерархия (Treemap)", heatmap: "Тепловая карта", waterfall: "Водопад",
    map: "Карта филиалов", table: "Сводная таблица", scatter: "Точечная диаграмма",
    histogram: "Гистограмма распределения",
    boxplot: "Ящик с усами (Box Plot)",
    radar: "Радарная диаграмма",
    funnel: "Воронка продаж",
    statsummary: "Статистическая сводка",
    gauge: "Спидометр (Gauge KPI)",
  },
};
export type Translation = typeof ru;
