// VERSION: 1.0.0 — Қазақша
export const kk = {
  nav: { datasets: "Деректер жиыны", dashboard: "Бақылау тақтасы", savedDashboards: "Сақталған тақталар", selectDatasetFirst: "Алдымен деректер жиынын таңдаңыз" },
  filters: { title: "Сүзгілер", clearAll: "Барлығын тазарту", all: "Барлығы", loading: "Өлшемдер жүктелуде…", noVisibleDimensions: "Көрінетін өлшемдер жоқ", noDataset: "Деректер жиынын таңдаңыз" },
  kpi: { sum: "сома", avg: "орташа", count: "саны" },
  charts: { contextMenu: { scale: "Масштаб", fullWidth: "Бет еніне кеңейту", fullScreen: "Толық экран", default: "Әдепкі", resizeCorner: "Өлшемін өзгерту" }, noData: "Деректер жоқ", loading: "Жүктелуде…", error: "Жүктеу қатесі" },
  dashboard: { title: "Бақылау тақтасы", metricForCharts: "Диаграммалар үшін метрика", noVisibleMetrics: "Көрінетін метрикалар жоқ.", availableCharts: "Қолжетімді диаграммалар", showChart: "Көрсету", hideChart: "Жасыру", dragHint: "Диаграмманы орнына сүйреңіз" },
  datasets: { title: "Деректер жиыны", noDatasets: "Деректер жиыны жоқ", current: "Ағымдағы", upload: "Жүктеп салу" },
  savedDashboards: { title: "Сақталған тақталар", save: "Тақтаны сақтау", noSaved: "Сақталған тақталар жоқ", delete: "Жою", open: "Ашу" },
  settings: { theme: "Тақырып", language: "Тіл", themeLight: "Жарық", themeDark: "Қараңғы", themeNeutral: "Бейтарап" },
  map: { clickHint: "Басу — бөлектеу. 2× басу — тауар талдауы.", dblClickHint: "2× басу — тауар топтары", allCountries: "Барлық елдер", categories: "Тауар топтары", products: "Тауарлар", showProducts: "Тауарларды көрсету →", total: "Барлығы", back: "Артқа", reset: "Қалпына келтіру", groups: "топ", items: "тауар", noData: "Деректер жоқ", ctrlClickHint: "Ctrl+басу — бірнешеуін таңдау", branches: "филиал" },
  table: { rowsPerPage: "Беттегі жолдар", exportCsv: "CSV экспорт" },
  common: { save: "Сақтау", cancel: "Бас тарту", delete: "Жою", confirm: "Растау", search: "Іздеу", selectAll: "Барлығын таңдау", clearSelection: "Таңдауды алып тастау", close: "Жабу" },


  modules: {
    dashboards: { name: "Бақылау тақталары", description: "Интерактивті BI тақталары: 15 диаграмма түрі" },
    kpi:        { name: "KPI Талдауы", description: "KPI талдауы: бал картасы, кезеңдерді салыстыру" },
    agents:     { name: "ЖИ агенттері", description: "ЖИ агенттерін интеграциялау" },
  },
  pages: {
    datasets: {
      title: "Деректер жиыны", uploadHint: "Талдау үшін CSV немесе XLSX файлын жүктеңіз",
      noDatasets: "Деректер жиыны жоқ — жоғарыдан файл жүктеңіз.",
      deleteTitle: "Деректер жиынын жою?",
      deleteText: "Бұл әрекетті кері қайтару мүмкін емес.",
      deleteBtn: "Жою", cancelBtn: "Бас тарту",
    },
    datasetDetail: {
      previewTab: "Деректерді алдын ала қарау", metadataTab: "Метадеректер",
      openDashboard: "Бақылау тақтасын ашу", rows: "жол", columns: "баған",
      refreshMeta: "Метадеректерді жаңарту",
    },
    savedDashboards: {
      title: "Сақталған тақталар", newDashboard: "Жаңа тақта", nameLabel: "Тақта атауы",
      createBtn: "Жасау", noSaved: "Сақталған тақталар жоқ.",
      updated: "Жаңартылды",
    },
  },
  chartNames: { line: "Сызықтық", bar: "Бағандық", pie: "Дөңгелек", treemap: "Иерархия", heatmap: "Жылу картасы", waterfall: "Сарқырама", map: "Филиал картасы", table: "Жиынтық кесте", scatter: "Нүктелік", histogram: "Гистограмма" },
};
