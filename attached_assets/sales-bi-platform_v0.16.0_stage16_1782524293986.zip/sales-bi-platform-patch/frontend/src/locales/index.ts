// VERSION: 1.0.0
// Path: frontend/src/locales/index.ts
// CHANGES v1.0.0:
//   - Реестр всех локалей. Добавление нового языка: создать файл XX.ts,
//     импортировать здесь и добавить запись в LOCALES и LOCALE_LABELS.
import { ru } from "./ru";
import { en } from "./en";
import { de } from "./de";
import { zh } from "./zh";
import { be } from "./be";
import { kk } from "./kk";
import { ar } from "./ar";
import { sr } from "./sr";
import { ko } from "./ko";
export type { Translation } from "./ru";

export type LocaleCode = "ru" | "en" | "de" | "zh" | "be" | "kk" | "ar" | "sr" | "ko";

/** Все переводы. Ключ = код языка ISO 639-1. */
export const LOCALES: Record<LocaleCode, typeof ru> = { ru, en, de, zh, be, kk, ar, sr, ko };

/** Человекочитаемые названия языков (на родном языке). */
export const LOCALE_LABELS: Record<LocaleCode, string> = {
  ru: "Русский",
  en: "English",
  de: "Deutsch",
  zh: "中文",
  be: "Беларуская",
  kk: "Қазақша",
  ar: "العربية",
  sr: "Српски",
  ko: "한국어",
};

/** Языки с направлением текста справа налево. */
export const RTL_LOCALES: Set<LocaleCode> = new Set(["ar"]);
