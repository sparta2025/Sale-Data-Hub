// VERSION: 1.0.0
// Path: frontend/src/modules/types.ts
// CHANGES v1.0.0:
//   - Этап 13: типы модульной системы Sales BI Platform.
//     Каждый модуль (инструмент) описывается ManifestModule и регистрируется
//     в ModuleRegistry. Подписка управляет доступом. AgentHook — точки
//     интеграции ИИ-агентов (сейчас заглушки, активируются при подключении).

export type SubscriptionTier = "free" | "pro" | "enterprise";
export type ModuleStatus = "active" | "trial" | "locked" | "coming_soon";

/**
 * Точка интеграции AI-агента в модуль.
 * hookId — уникальный идентификатор хука, агент подписывается на него.
 * description — что агент может делать в этой точке.
 */
export interface AgentHook {
  hookId: string;
  event: "on_filter_change" | "on_metric_select" | "on_drilldown" | "on_save" | "on_load";
  description: string;
}

/** Элемент навигации, который модуль добавляет в сайдбар */
export interface ModuleNavItem {
  label: string;                 // i18n key или строка
  path: string;                  // роут относительно корня приложения
  icon: string;                  // имя MUI-иконки
  requiresDataset?: boolean;     // показывать только при выбранном датасете
}

/** Манифест модуля — единственный источник правды о возможностях инструмента */
export interface ModuleManifest {
  id: string;                    // уникальный идентификатор: "dashboards", "kpi", etc.
  name: string;                  // человекочитаемое название
  nameKey: string;               // ключ перевода в locales
  version: string;               // semver
  description: string;
  descriptionKey: string;
  icon: string;                  // MUI иконка
  color: string;                 // акцентный цвет (#hex)
  tier: SubscriptionTier;        // минимальная подписка
  routePrefix: string;           // префикс роутов: "/dashboards", "/kpi"
  navItems: ModuleNavItem[];
  tags: string[];                // "analytics", "reporting", "kpi"
  agentHooks: AgentHook[];       // точки интеграции агентов
  /** Метаданные для Tools Board */
  toolsBoard: {
    featured: boolean;
    category: "analytics" | "reporting" | "automation" | "ai";
    screenshots: string[];        // URL превью (опционально)
    whatsnew?: string;
  };
}

/** Состояние подписки пользователя */
export interface UserSubscription {
  tier: SubscriptionTier;
  activeModuleIds: string[];     // явно активированные модули
  trialModuleIds: string[];      // модули в trial-режиме
  expiresAt?: string;            // ISO date
  isStandaloneMode: boolean;     // true = отдельное приложение без SaaS
}
