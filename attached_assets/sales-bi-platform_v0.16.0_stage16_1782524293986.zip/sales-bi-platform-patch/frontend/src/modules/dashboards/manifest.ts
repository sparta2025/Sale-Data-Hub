// VERSION: 1.0.0
// Path: frontend/src/modules/dashboards/manifest.ts
import type { ModuleManifest } from "@/modules/types";

export const DashboardsModule: ModuleManifest = {
  id: "dashboards",
  name: "Dashboards",
  nameKey: "modules.dashboards.name",
  version: "0.12.0",
  description: "Интерактивные BI-дашборды: 15 типов диаграмм, drag-and-drop, drill-down, экспорт",
  descriptionKey: "modules.dashboards.description",
  icon: "Dashboard",
  color: "#2563eb",
  tier: "free",
  routePrefix: "/datasets",
  navItems: [
    { label: "Датасеты",           path: "/datasets",              icon: "FolderOpen" },
    { label: "Дашборд",            path: "/datasets/:id/overview", icon: "Dashboard",       requiresDataset: true },
    { label: "Сохранённые",        path: "/datasets/:id/dashboards", icon: "SpaceDashboard", requiresDataset: true },
  ],
  tags: ["analytics", "visualization", "reporting", "bi"],
  agentHooks: [
    { hookId: "dashboards.filter_change",  event: "on_filter_change",  description: "Агент получает новые значения фильтров и может предложить инсайты" },
    { hookId: "dashboards.metric_select",  event: "on_metric_select",  description: "Агент объясняет метрику и связанные KPI" },
    { hookId: "dashboards.drilldown",      event: "on_drilldown",      description: "Агент интерпретирует drill-down результат" },
    { hookId: "dashboards.save",           event: "on_save",           description: "Агент создаёт автоматический отчёт по сохранённому дашборду" },
  ],
  toolsBoard: {
    featured: true,
    category: "analytics",
    screenshots: [],
    whatsnew: "v0.12.0: 15 диаграмм, react-grid-layout, 9 языков, 3 темы, backend статистика",
  },
};
