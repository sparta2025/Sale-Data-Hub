// VERSION: 1.0.0
// Path: frontend/src/modules/registry.ts
// CHANGES v1.0.0:
//   - Этап 13: реестр всех модулей платформы.
//     Добавить новый модуль: 1) создать manifest.ts, 2) добавить сюда.
//     VITE_ENABLED_MODULES (через запятую) ограничивает набор модулей
//     для standalone-развёртывания без полного SaaS.
import type { ModuleManifest } from "@/modules/types";
import { DashboardsModule } from "./dashboards/manifest";
import { KpiModule }        from "./kpi/manifest";
import { AgentsModule }     from "./agents/manifest";

/** Все зарегистрированные модули платформы */
export const ALL_MODULES: ModuleManifest[] = [
  DashboardsModule,
  KpiModule,
  AgentsModule,
];

/** Env-фильтр: VITE_ENABLED_MODULES="dashboards,kpi" → только эти два */
const ENABLED_IDS = import.meta.env.VITE_ENABLED_MODULES
  ? new Set((import.meta.env.VITE_ENABLED_MODULES as string).split(",").map((s) => s.trim()))
  : null; // null = все модули разрешены

/** Модули, доступные в текущем развёртывании */
export const ENABLED_MODULES: ModuleManifest[] = ENABLED_IDS
  ? ALL_MODULES.filter((m) => ENABLED_IDS.has(m.id))
  : ALL_MODULES;

/** Найти манифест по ID */
export function getModule(id: string): ModuleManifest | undefined {
  return ALL_MODULES.find((m) => m.id === id);
}

/** Standalone mode: модуль разрешён env-переменной */
export function isModuleEnabled(id: string): boolean {
  return ENABLED_IDS ? ENABLED_IDS.has(id) : true;
}
