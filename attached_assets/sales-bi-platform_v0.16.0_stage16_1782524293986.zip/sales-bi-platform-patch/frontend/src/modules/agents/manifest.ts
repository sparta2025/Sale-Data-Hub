// VERSION: 1.0.0
// Path: frontend/src/modules/agents/manifest.ts
// Заглушка — модуль агентов (AI integration), coming soon
import type { ModuleManifest } from "@/modules/types";

export const AgentsModule: ModuleManifest = {
  id: "agents",
  name: "AI Agents",
  nameKey: "modules.agents.name",
  version: "0.0.1",
  description: "Подключение ИИ-агентов: автоматические инсайты, аномалии, прогнозы, объяснения",
  descriptionKey: "modules.agents.description",
  icon: "SmartToy",
  color: "#059669",
  tier: "enterprise",
  routePrefix: "/agents",
  navItems: [],
  tags: ["ai", "agents", "automation", "llm"],
  agentHooks: [],
  toolsBoard: {
    featured: false,
    category: "ai",
    screenshots: [],
    whatsnew: "Интеграция LLM-агентов через MCP/LangGraph. Скоро.",
  },
};
