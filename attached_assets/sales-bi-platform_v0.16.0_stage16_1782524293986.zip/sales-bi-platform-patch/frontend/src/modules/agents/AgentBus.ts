// VERSION: 1.0.0
// Path: frontend/src/modules/agents/AgentBus.ts
// CHANGES v1.0.0:
//   - Этап 14: шина событий для интеграции AI-агентов.
//     Модули платформы вызывают AgentBus.emit() в точках AgentHook.
//     Внешние агенты (LangGraph, MCP, etc.) подписываются через subscribe().
//     AgentBus.log() — список последних N событий для отладки.
//     В production агенты подключаются через WebSocket или SSE поверх этой шины.

export interface AgentEvent {
  hookId: string;
  moduleId: string;
  timestamp: string;   // ISO
  payload: Record<string, unknown>;
}

type AgentHandler = (event: AgentEvent) => void;

const MAX_LOG = 100;

class AgentEventBus {
  private handlers = new Map<string, Set<AgentHandler>>();
  private catchAll  = new Set<AgentHandler>();
  private eventLog: AgentEvent[] = [];

  /** Отправить событие — вызывается из компонентов в точках AgentHook */
  emit(hookId: string, moduleId: string, payload: Record<string, unknown> = {}): void {
    const event: AgentEvent = {
      hookId, moduleId,
      timestamp: new Date().toISOString(),
      payload,
    };
    this.eventLog.unshift(event);
    if (this.eventLog.length > MAX_LOG) this.eventLog.pop();

    // Подписчики на конкретный hookId
    this.handlers.get(hookId)?.forEach((h) => h(event));
    // Подписчики на все события
    this.catchAll.forEach((h) => h(event));

    if (import.meta.env.DEV) {
      console.debug(`[AgentBus] ${moduleId}::${hookId}`, payload);
    }
  }

  /** Подписаться на конкретный hookId. Возвращает функцию отписки. */
  subscribe(hookId: string, handler: AgentHandler): () => void {
    if (!this.handlers.has(hookId)) this.handlers.set(hookId, new Set());
    this.handlers.get(hookId)!.add(handler);
    return () => this.handlers.get(hookId)?.delete(handler);
  }

  /** Подписаться на все события. Возвращает функцию отписки. */
  subscribeAll(handler: AgentHandler): () => void {
    this.catchAll.add(handler);
    return () => this.catchAll.delete(handler);
  }

  /** Последние N событий (для отладки / агентского контекста) */
  getLog(n = 20): AgentEvent[] {
    return this.eventLog.slice(0, n);
  }

  /** Сбросить лог (для тестов) */
  clearLog(): void {
    this.eventLog = [];
  }
}

/** Глобальный синглтон — единая шина для всей платформы */
export const AgentBus = new AgentEventBus();
