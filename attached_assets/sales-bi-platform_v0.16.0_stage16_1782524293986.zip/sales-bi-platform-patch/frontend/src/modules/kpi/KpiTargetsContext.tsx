// VERSION: 1.0.0
// Path: frontend/src/modules/kpi/KpiTargetsContext.tsx
// CHANGES v1.0.0:
//   - Этап 15: контекст KPI-целей.
//     Пользователь устанавливает плановые значения для метрик (по датасету).
//     Цели хранятся в localStorage. Используются на KpiAnalysisPage и GaugeCard.
//     setTarget(datasetId, metricCol, value) — установить цель.
//     getTarget(datasetId, metricCol) → number | null.
import {
  createContext, useContext, useState, useCallback, type ReactNode,
} from "react";

interface TargetsMap {
  [datasetId: string]: {
    [metricCol: string]: number;
  };
}

const LS_KEY = "bi_kpi_targets";

function load(): TargetsMap {
  try { return JSON.parse(localStorage.getItem(LS_KEY) ?? "{}"); }
  catch { return {}; }
}

function save(data: TargetsMap) {
  localStorage.setItem(LS_KEY, JSON.stringify(data));
}

interface KpiTargetsCtxValue {
  getTarget: (datasetId: string, metricCol: string) => number | null;
  setTarget: (datasetId: string, metricCol: string, value: number | null) => void;
  getAllTargets: (datasetId: string) => Record<string, number>;
  clearTargets: (datasetId: string) => void;
}

const Ctx = createContext<KpiTargetsCtxValue | null>(null);

export function KpiTargetsProvider({ children }: { children: ReactNode }) {
  const [targets, setTargets] = useState<TargetsMap>(load);

  const getTarget = useCallback((dsId: string, col: string): number | null => {
    return targets[dsId]?.[col] ?? null;
  }, [targets]);

  const setTarget = useCallback((dsId: string, col: string, value: number | null) => {
    setTargets((prev) => {
      const next = { ...prev, [dsId]: { ...(prev[dsId] ?? {}) } };
      if (value === null) { delete next[dsId][col]; }
      else { next[dsId][col] = value; }
      save(next);
      return next;
    });
  }, []);

  const getAllTargets = useCallback((dsId: string) => {
    return targets[dsId] ?? {};
  }, [targets]);

  const clearTargets = useCallback((dsId: string) => {
    setTargets((prev) => {
      const next = { ...prev };
      delete next[dsId];
      save(next);
      return next;
    });
  }, []);

  return (
    <Ctx.Provider value={{ getTarget, setTarget, getAllTargets, clearTargets }}>
      {children}
    </Ctx.Provider>
  );
}

export function useKpiTargets() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useKpiTargets must be within KpiTargetsProvider");
  return ctx;
}
