// VERSION: 1.0.0
// Path: frontend/src/modules/kpi/components/KpiTargetSetter.tsx
// CHANGES v1.0.0:
//   - Этап 15: компонент установки KPI-целей.
//     Таблица метрик с полем ввода числового значения-цели.
//     Сохраняет в KpiTargetsContext (localStorage). Используется на KpiAnalysisPage.
import { useState } from "react";
import {
  Box, Typography, Table, TableBody, TableCell, TableHead,
  TableRow, TextField, IconButton, Chip, Paper, Stack,
} from "@mui/material";
import CheckIcon       from "@mui/icons-material/Check";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { useKpiTargets } from "@/modules/kpi/KpiTargetsContext";
import { formatValue }   from "@/utils/formatValue";
import type { MetricOut } from "@/types";

interface KpiTargetSetterProps {
  datasetId: string;
  metrics: MetricOut[];
}

export function KpiTargetSetter({ datasetId, metrics }: KpiTargetSetterProps) {
  const { getTarget, setTarget } = useKpiTargets();
  const [inputs, setInputs] = useState<Record<string, string>>({});

  const handleSave = (col: string, fmt: string) => {
    const raw = inputs[col];
    if (!raw) return;
    const val = parseFloat(raw.replace(/\s/g, "").replace(",", "."));
    if (!isNaN(val)) {
      setTarget(datasetId, col, val);
      setInputs((p) => ({ ...p, [col]: "" }));
    }
  };

  return (
    <Paper variant="outlined" sx={{ p: 0, overflow: "hidden" }}>
      <Box sx={{ px: 2, py: 1.25, backgroundColor: "action.hover", borderBottom: "1px solid", borderColor: "divider" }}>
        <Typography variant="subtitle2" fontWeight={700}>🎯 KPI Цели</Typography>
        <Typography variant="caption" color="text.secondary">
          Задайте плановые значения — используются как 100% на диаграммах Gauge
        </Typography>
      </Box>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell sx={{ fontWeight: 700 }}>Метрика</TableCell>
            <TableCell sx={{ fontWeight: 700 }}>Текущая цель</TableCell>
            <TableCell sx={{ fontWeight: 700 }}>Новое значение</TableCell>
            <TableCell />
          </TableRow>
        </TableHead>
        <TableBody>
          {metrics.map((m) => {
            const current = getTarget(datasetId, m.column_name);
            return (
              <TableRow key={m.column_name} hover>
                <TableCell>
                  <Typography variant="body2" noWrap>{m.display_name}</Typography>
                </TableCell>
                <TableCell>
                  {current !== null
                    ? (
                      <Stack direction="row" alignItems="center" gap={0.5}>
                        <Chip
                          label={formatValue(current, m.display_format)}
                          size="small"
                          sx={{ backgroundColor: "#22c55e22", color: "#16a34a", fontWeight: 700, fontSize: "0.72rem" }}
                        />
                        <IconButton size="small" onClick={() => setTarget(datasetId, m.column_name, null)}>
                          <DeleteOutlineIcon sx={{ fontSize: 14, color: "#ef4444" }} />
                        </IconButton>
                      </Stack>
                    )
                    : <Typography variant="caption" color="text.disabled">Не задана</Typography>}
                </TableCell>
                <TableCell>
                  <TextField
                    size="small"
                    placeholder="Напр. 1000000"
                    value={inputs[m.column_name] ?? ""}
                    onChange={(e) => setInputs((p) => ({ ...p, [m.column_name]: e.target.value }))}
                    onKeyDown={(e) => e.key === "Enter" && handleSave(m.column_name, m.display_format)}
                    sx={{ width: 140 }}
                    InputProps={{ sx: { fontSize: "0.8rem" } }}
                  />
                </TableCell>
                <TableCell>
                  <IconButton
                    size="small"
                    disabled={!inputs[m.column_name]}
                    onClick={() => handleSave(m.column_name, m.display_format)}
                    sx={{ color: "#22c55e" }}
                  >
                    <CheckIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </Paper>
  );
}
