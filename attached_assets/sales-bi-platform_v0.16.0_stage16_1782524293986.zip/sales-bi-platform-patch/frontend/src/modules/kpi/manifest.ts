// VERSION: 1.0.0
// Path: frontend/src/modules/kpi/manifest.ts
import type { ModuleManifest } from "@/modules/types";

export const KpiModule: ModuleManifest = {
  id: "kpi",
  name: "KPI Analysis",
  nameKey: "modules.kpi.name",
  version: "1.0.0",
  description: "Анализ KPI: скоркарта метрик, сравнение периодов, тренды, топ-исполнители",
  descriptionKey: "modules.kpi.description",
  icon: "TrendingUp",
  color: "#7c3aed",
  tier: "pro",
  routePrefix: "/kpi",
  navItems: [
    { label: "KPI Анализ",    path: "/kpi",                    icon: "TrendingUp" },
    { label: "Скоркарта",     path: "/kpi/scorecard",          icon: "AssessmentOutlined",  requiresDataset: true },
    { label: "Сравнение",     path: "/kpi/compare",            icon: "CompareArrows",       requiresDataset: true },
    { label: "Тренды",        path: "/kpi/trends",             icon: "ShowChart",           requiresDataset: true },
  ],
  tags: ["kpi", "analytics", "performance", "comparison"],
  agentHooks: [
    { hookId: "kpi.anomaly_detect",   event: "on_metric_select", description: "Агент обнаруживает аномалии в KPI и предупреждает" },
    { hookId: "kpi.forecast",         event: "on_filter_change", description: "Агент строит прогноз на следующий период" },
    { hookId: "kpi.explain_delta",    event: "on_drilldown",     description: "Агент объясняет причину изменения KPI между периодами" },
  ],
  toolsBoard: {
    featured: true,
    category: "analytics",
    screenshots: [],
    whatsnew: "v1.0.0: KPI Скоркарта, период-в-период сравнение, топ-исполнители, тренды",
  },
};
