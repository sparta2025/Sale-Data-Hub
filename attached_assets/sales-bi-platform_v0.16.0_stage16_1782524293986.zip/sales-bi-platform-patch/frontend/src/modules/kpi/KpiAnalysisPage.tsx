// VERSION: 2.1.0
// Path: frontend/src/modules/kpi/KpiAnalysisPage.tsx
// CHANGES v1.0.0:
//   - Этап 13: основная страница (frontend-only запросы)
// CHANGES v2.0.0:
//   - Этап 14: использует backend /api/kpi/scorecard и /api/kpi/compare
//     (один SQL-проход вместо двух отдельных запросов);
//     ModuleGuard — блокирует доступ при locked подписке;
//     AgentBus.emit() в ключевых точках для будущей интеграции агентов;
//     KpiCompareChart — ECharts grouped bar chart для side-by-side сравнения.
import { useState, useMemo, useEffect } from "react";
import {
  Box, Typography, Stack, Breadcrumbs, Link as MuiLink,
  FormControl, InputLabel, Select, MenuItem, Divider,
  CircularProgress, Grid, Paper, Chip, Alert,
} from "@mui/material";
import TrendingUpIcon    from "@mui/icons-material/TrendingUp";
import TrendingDownIcon  from "@mui/icons-material/TrendingDown";
import TrendingFlatIcon  from "@mui/icons-material/TrendingFlat";
import { useNavigate, useParams } from "react-router-dom";
import { useDataset }          from "@/hooks/useDatasets";
import { useMetadataOverview } from "@/hooks/useMetadata";
import { useFilters }          from "@/context/FiltersContext";
import { useTranslation }      from "@/context/I18nContext";
import { useRunQuery }         from "@/hooks/useQueryEngine";
import { FilterBar }           from "@/components/filters/FilterBar";
import { StatSummaryCard, RadarChartCard } from "@/components/charts";
import { EChartWrapper }       from "@/components/charts/EChartWrapper";
import { useChartTheme }       from "@/hooks/useChartTheme";
import { formatValue }         from "@/utils/formatValue";
import { CHART_COLORS }        from "@/components/charts/chartTheme";
import { ModuleGuard }         from "@/components/common/ModuleGuard";
import { AgentBus }            from "@/modules/agents/AgentBus";
import { useKpiScorecard }     from "./hooks/useKpiScorecard";
import { KpiTargetSetter }     from "./components/KpiTargetSetter";
import { useKpiCompare }       from "./hooks/useKpiCompare";
import type { MetricOut, DimensionOut } from "@/types";
import type { EChartsOption }  from "echarts";

const KPI_COLOR = "#7c3aed";

// ---- KPI Scorecard Card ----
function KpiMetricCard({ m }: { m: { display_name: string; display_format: string; value_a: number; value_b: number; delta_pct: number } }) {
  const isUp   = m.delta_pct >  0.5;
  const isDown = m.delta_pct < -0.5;
  const color  = isUp ? "#22c55e" : isDown ? "#ef4444" : "#94a3b8";
  return (
    <Paper variant="outlined" sx={{ p: 2, flex: 1, minWidth: 180, position: "relative", overflow: "hidden" }}>
      <Box sx={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, backgroundColor: KPI_COLOR }} />
      <Typography variant="body2" color="text.secondary" noWrap mb={0.5} title={m.display_name}>
        {m.display_name}
      </Typography>
      <Typography variant="h5" fontWeight={700}>
        {formatValue(m.value_a, m.display_format)}
      </Typography>
      <Stack direction="row" alignItems="center" gap={0.5} mt={0.5}>
        {isUp   && <TrendingUpIcon sx={{ fontSize: 16, color }} />}
        {isDown && <TrendingDownIcon sx={{ fontSize: 16, color }} />}
        {!isUp && !isDown && <TrendingFlatIcon sx={{ fontSize: 16, color }} />}
        <Typography variant="caption" sx={{ color, fontWeight: 700 }}>
          {m.delta_pct > 0 ? "+" : ""}{m.delta_pct.toFixed(1)}%
        </Typography>
        <Typography variant="caption" color="text.disabled">vs предыдущий</Typography>
      </Stack>
      <Typography variant="caption" color="text.disabled" display="block" mt={0.25}>
        Пред: {formatValue(m.value_b, m.display_format)}
      </Typography>
    </Paper>
  );
}

// ---- KPI Compare Chart (grouped bar) ----
function KpiCompareChart({
  labels, valuesA, valuesB, periodA, periodB, metricDisplay, valueFormat, height,
}: {
  labels: string[]; valuesA: number[]; valuesB: number[];
  periodA: string; periodB: string; metricDisplay: string;
  valueFormat: string; height?: number;
}) {
  const ct = useChartTheme();
  const option: EChartsOption = {
    grid: { left: 80, right: 24, top: 40, bottom: 60 },
    tooltip: {
      trigger: "axis",
      axisPointer: { type: "shadow" },
      formatter: (params: Array<{ seriesName: string; value: number; name: string }>) =>
        `<strong>${params[0]?.name}</strong><br/>` +
        params.map((p) => `${p.seriesName}: <strong>${formatValue(p.value, valueFormat)}</strong>`).join("<br/>"),
    },
    legend: { bottom: 0, textStyle: { color: ct.axisColor } },
    xAxis: {
      type: "category",
      data: labels,
      axisLabel: { rotate: labels.length > 5 ? 30 : 0, color: ct.axisColor, fontSize: 11 },
      axisLine: { lineStyle: { color: ct.axisLineColor } },
    },
    yAxis: {
      type: "value",
      name: metricDisplay,
      nameTextStyle: { color: ct.axisColor, fontSize: 10 },
      axisLabel: { color: ct.axisColor, formatter: (v: number) => formatValue(v, "{:,.0f}") },
      splitLine: { lineStyle: { color: ct.splitLineColor } },
    },
    series: [
      {
        name: periodA, type: "bar", data: valuesA, barMaxWidth: 40,
        itemStyle: { color: CHART_COLORS[0], borderRadius: [3, 3, 0, 0] },
        label: { show: labels.length <= 8, position: "top", formatter: (p: {value: number}) => formatValue(p.value, "{:,.0f}"), fontSize: 10, color: ct.labelColor },
      },
      {
        name: periodB, type: "bar", data: valuesB, barMaxWidth: 40,
        itemStyle: { color: CHART_COLORS[4], borderRadius: [3, 3, 0, 0] },
      },
    ],
  };
  return (
    <EChartWrapper title={`${metricDisplay}: ${periodA} vs ${periodB}`}
      option={option} height={height ?? 340} isEmpty={labels.length === 0} />
  );
}

// ---- Main Page ----
function KpiAnalysisContent() {
  const { datasetId } = useParams<{ datasetId: string }>();
  const navigate = useNavigate();
  const { t }    = useTranslation();
  const { filters } = useFilters();

  const { data: dataset }  = useDataset(datasetId);
  const { data: metadata, isLoading: metaLoading } = useMetadataOverview(datasetId);

  const visibleMetrics = useMemo<MetricOut[]>(
    () => (metadata?.metrics ?? []).filter((m) => m.is_visible), [metadata]);
  const visibleDimensions = useMemo<DimensionOut[]>(
    () => (metadata?.dimensions ?? []).filter((d) => d.is_visible), [metadata]);

  const timeDims = useMemo(
    () => visibleDimensions
      .filter((d) => d.hierarchy_group === "time")
      .sort((a, b) => a.hierarchy_level - b.hierarchy_level),
    [visibleDimensions]);

  const yearDim = timeDims[0];
  const catDim  = useMemo(
    () => visibleDimensions.find((d) => d.hierarchy_group !== "time" && d.hierarchy_level === 0),
    [visibleDimensions]);

  const [primaryMetric, setPrimaryMetric] = useState("");
  const [periodA, setPeriodA] = useState("");
  const [periodB, setPeriodB] = useState("");

  const effectiveMetric = primaryMetric || visibleMetrics[0]?.column_name || "";
  const metricMeta = visibleMetrics.find((m) => m.column_name === effectiveMetric);
  const fmt = metricMeta?.display_format ?? "{:,.2f}";

  // Список доступных периодов
  const { data: periodsData } = useRunQuery(
    datasetId,
    { dimensions: yearDim ? [yearDim.column_name] : [], metrics: [], filters, limit: 50 },
    Boolean(yearDim),
  );
  const periods = useMemo(
    () => (periodsData?.rows ?? []).map((r) => String(r[yearDim?.column_name ?? ""] ?? "")).sort().reverse(),
    [periodsData, yearDim]);

  const effA = periodA || periods[0] || "";
  const effB = periodB || periods[1] || "";

  // KPI Scorecard — backend endpoint
  const { data: scorecard, isLoading: scorecardLoading } = useKpiScorecard(
    datasetId, yearDim?.column_name ?? "", effA, effB,
  );

  // KPI Compare — backend endpoint
  const { data: compareData, isLoading: compareLoading } = useKpiCompare(
    datasetId,
    {
      dimension: catDim?.column_name ?? "",
      metric: effectiveMetric,
      period_col: yearDim?.column_name ?? "",
      period_a: effA,
      period_b: effB,
      limit: 15,
    },
    Boolean(catDim && effectiveMetric && yearDim),
  );

  // AgentBus — emit при смене метрики/периода
  useEffect(() => {
    if (!effectiveMetric || !effA) return;
    AgentBus.emit("kpi.metric_select", "kpi", {
      datasetId, metric: effectiveMetric, period_a: effA, period_b: effB,
    });
  }, [effectiveMetric, effA, effB, datasetId]);

  return (
    <Box>
      <Breadcrumbs sx={{ mb: 1 }}>
        <MuiLink component="button" underline="hover" onClick={() => navigate("/datasets")}>
          {t.nav.datasets}
        </MuiLink>
        <MuiLink component="button" underline="hover" onClick={() => navigate(`/datasets/${datasetId}/overview`)}>
          {dataset?.name ?? "…"}
        </MuiLink>
        <Typography color="text.primary">KPI Analysis</Typography>
      </Breadcrumbs>

      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2} flexWrap="wrap" gap={2}>
        <Stack direction="row" alignItems="center" gap={1.5}>
          <Box sx={{ width: 40, height: 40, borderRadius: 2, backgroundColor: `${KPI_COLOR}18`,
            display: "flex", alignItems: "center", justifyContent: "center" }}>
            <TrendingUpIcon sx={{ color: KPI_COLOR }} />
          </Box>
          <Box>
            <Typography variant="h5" fontWeight={700}>KPI Analysis</Typography>
            <Typography variant="body2" color="text.secondary">{dataset?.name}</Typography>
          </Box>
        </Stack>

        <Stack direction="row" gap={1.5} flexWrap="wrap">
          {visibleMetrics.length > 0 && (
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel>Метрика</InputLabel>
              <Select value={effectiveMetric} label="Метрика" onChange={(e) => setPrimaryMetric(e.target.value)}>
                {visibleMetrics.map((m) => <MenuItem key={m.column_name} value={m.column_name}>{m.display_name}</MenuItem>)}
              </Select>
            </FormControl>
          )}
          {periods.length > 1 && (
            <>
              <FormControl size="small" sx={{ minWidth: 110 }}>
                <InputLabel>Период A</InputLabel>
                <Select value={effA} label="Период A" onChange={(e) => setPeriodA(e.target.value)}>
                  {periods.map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
                </Select>
              </FormControl>
              <FormControl size="small" sx={{ minWidth: 110 }}>
                <InputLabel>Период B</InputLabel>
                <Select value={effB} label="Период B" onChange={(e) => setPeriodB(e.target.value)}>
                  {periods.map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
                </Select>
              </FormControl>
            </>
          )}
        </Stack>
      </Stack>

      <FilterBar />

      {/* 1. KPI Scorecard */}
      <Box mb={3}>
        <Stack direction="row" alignItems="center" gap={1} mb={1.5}>
          <Typography variant="subtitle1" fontWeight={700}>📊 KPI Скоркарта</Typography>
          {effA && effB && (
            <Chip label={`${effA} vs ${effB}`} size="small"
              sx={{ backgroundColor: `${KPI_COLOR}18`, color: KPI_COLOR, fontWeight: 700 }} />
          )}
        </Stack>
        {scorecardLoading && <CircularProgress size={24} />}
        {!scorecardLoading && scorecard?.metrics && (
          <Stack direction="row" flexWrap="wrap" gap={1.5}>
            {scorecard.metrics.map((m) => <KpiMetricCard key={m.column_name} m={m} />)}
          </Stack>
        )}
        {!scorecardLoading && !effA && (
          <Alert severity="info">Выберите периоды A и B для отображения скоркарты.</Alert>
        )}
      </Box>

      <Divider sx={{ my: 2 }} />

      {/* 2. Grouped Bar — сравнение */}
      {catDim && (
        <Box mb={3}>
          <Typography variant="subtitle1" fontWeight={700} mb={1.5}>
            📈 Сравнение по {catDim.display_name}: {effA} vs {effB}
          </Typography>
          {compareLoading && <CircularProgress size={24} />}
          {!compareLoading && compareData && compareData.items.length > 0 && (
            <KpiCompareChart
              labels={compareData.items.map((i) => i.label)}
              valuesA={compareData.items.map((i) => i.value_a)}
              valuesB={compareData.items.map((i) => i.value_b)}
              periodA={effA} periodB={effB}
              metricDisplay={compareData.metric_display}
              valueFormat={fmt}
              height={360}
            />
          )}
        </Box>
      )}

      <Divider sx={{ my: 2 }} />

      {/* 3. Radar */}
      {catDim && visibleMetrics.length >= 2 && (
        <Box mb={3}>
          <Typography variant="subtitle1" fontWeight={700} mb={1.5}>
            🕸 Многомерный анализ: {catDim.display_name}
          </Typography>
          <RadarChartCard
            title={`Сравнение по всем метрикам`}
            dimension={catDim.column_name}
            metrics={visibleMetrics.slice(0, 5).map((m) => m.column_name)}
            metricLabels={visibleMetrics.slice(0, 5).map((m) => m.display_name)}
            height={400} topN={6}
          />
        </Box>
      )}

      <Divider sx={{ my: 2 }} />

      {/* 4. Статсводка */}
      <Box mb={3}>
        <Typography variant="subtitle1" fontWeight={700} mb={1.5}>🔢 Статистическая сводка</Typography>
        <StatSummaryCard valueFormat={fmt} />
      </Box>

      <Divider sx={{ my: 2 }} />

      {/* 5. KPI Цели */}
      {datasetId && visibleMetrics.length > 0 && (
        <Box mb={3}>
          <KpiTargetSetter datasetId={datasetId} metrics={visibleMetrics} />
        </Box>
      )}
    </Box>
  );
}

export default function KpiAnalysisPage() {
  return (
    <ModuleGuard moduleId="kpi">
      <KpiAnalysisContent />
    </ModuleGuard>
  );
}
