// VERSION: 1.0.0
import { useQuery } from "@tanstack/react-query";
import { kpiApi } from "@/api/kpi";

export function useKpiCompare(
  datasetId: string | null | undefined,
  params: { dimension: string; metric: string; period_col: string; period_a: string; period_b: string; limit?: number },
  enabled = true,
) {
  return useQuery({
    queryKey: ["kpi", "compare", datasetId, params],
    queryFn: () => kpiApi.compare(datasetId as string, params),
    enabled: Boolean(datasetId && params.dimension && params.metric && params.period_a && params.period_b && enabled),
    staleTime: 2 * 60 * 1000,
  });
}
