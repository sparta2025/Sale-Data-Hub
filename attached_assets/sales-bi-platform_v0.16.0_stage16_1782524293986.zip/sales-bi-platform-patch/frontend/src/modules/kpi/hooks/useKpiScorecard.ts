// VERSION: 1.0.0
import { useQuery } from "@tanstack/react-query";
import { kpiApi } from "@/api/kpi";

export function useKpiScorecard(
  datasetId: string | null | undefined,
  periodCol: string, periodA: string, periodB: string,
) {
  return useQuery({
    queryKey: ["kpi", "scorecard", datasetId, periodCol, periodA, periodB],
    queryFn: () => kpiApi.scorecard(datasetId as string, { period_col: periodCol, period_a: periodA, period_b: periodB }),
    enabled: Boolean(datasetId && periodCol && periodA && periodB),
    staleTime: 2 * 60 * 1000,
  });
}
