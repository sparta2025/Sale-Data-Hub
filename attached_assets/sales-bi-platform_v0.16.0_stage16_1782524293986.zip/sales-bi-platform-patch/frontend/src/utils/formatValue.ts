// VERSION: 1.0.0
// Path: frontend/src/utils/formatValue.ts
// CHANGES v1.0.0:
//   - Этап 8: парсер/форматтер Python-style format-строк из metrics.display_format
//     (см. backend/app/modules/metadata/detector.py: "{:,.2f}", "€ {:,.2f}",
//     "{:.1%}", "{:,.0f}") — применяется к числам в KPI-карточках, тултипах
//     и подписях осей графиков
/**
 * Разбирает Python format spec вида "{:[,][.N][f|%]}" с произвольным
 * префиксом/суффиксом текста снаружи фигурных скобок:
 *   "{:.2f}"      -> decimals=2, grouping=false, percent=false
 *   "€ {:,.2f}"   -> prefix="€ ", decimals=2, grouping=true
 *   "{:.1%}"      -> decimals=1, percent=true (значение умножается на 100)
 *   "{:,.0f}"     -> decimals=0, grouping=true
 */
const FORMAT_SPEC_RE = /^(.*)\{:(,)?(?:\.(\d+))?([f%d])?\}(.*)$/;

interface ParsedFormat {
  prefix: string;
  suffix: string;
  grouping: boolean;
  decimals: number;
  isPercent: boolean;
}

function parseFormatSpec(formatStr: string): ParsedFormat | null {
  const match = formatStr.match(FORMAT_SPEC_RE);
  if (!match) return null;
  const [, prefix, comma, digits, type] = match;
  const isPercent = type === "%";
  return {
    prefix,
    suffix: match[5] ?? "",
    grouping: Boolean(comma),
    decimals: digits !== undefined ? parseInt(digits, 10) : isPercent ? 0 : 2,
    isPercent,
  };
}

/**
 * Форматирует число согласно display_format метрики. null/undefined -> "—".
 * Локаль 'ru-RU' (пробел как разделитель разрядов, запятая как десятичный знак) —
 * единообразно с серверным CSV/PDF-экспортом (Этап 6).
 */
export function formatValue(value: number | null | undefined, formatStr: string): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";

  const parsed = parseFormatSpec(formatStr);
  if (!parsed) return String(value);

  const { prefix, suffix, grouping, decimals, isPercent } = parsed;
  const numericValue = isPercent ? value * 100 : value;

  const formatted = new Intl.NumberFormat("ru-RU", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
    useGrouping: grouping,
  }).format(numericValue);

  return `${prefix}${formatted}${isPercent ? "%" : ""}${suffix}`;
}

/** Компактная запись для подписей осей графиков: 1 200 000 -> "1.2М", 45 000 -> "45 тыс.". */
export function formatCompact(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return new Intl.NumberFormat("ru-RU", {
    notation: "compact",
    compactDisplay: "short",
    maximumFractionDigits: 1,
  }).format(value);
}
