// VERSION: 1.0.0
// Path: frontend/src/utils/branchCoordinates.ts
// CHANGES v1.0.0:
//   - Этап 9: lookup-таблица координат для городов из датасета (Берлин, Варшава
//     и т.д.) — в исходном XLSX нет колонок lat/lng, используем справочник.
//     Для расширения: добавьте новые города в BRANCH_COORDINATES.
//     Ключи регистронезависимы при поиске (toLowerCase).

export interface GeoCoord {
  lat: number;
  lng: number;
  country: string;
}

/**
 * Справочник координат городов из датасета sales_report_2015_2026Q1.
 * Ключ — русское название города (как в колонке "Филиал").
 */
export const BRANCH_COORDINATES: Record<string, GeoCoord> = {
  берлин:   { lat: 52.5200, lng: 13.4050, country: "Германия" },
  гамбург:  { lat: 53.5511, lng:  9.9937, country: "Германия" },
  мюнхен:   { lat: 48.1351, lng: 11.5820, country: "Германия" },
  варшава:  { lat: 52.2297, lng: 21.0122, country: "Польша" },
  гданьск:  { lat: 54.3520, lng: 18.6466, country: "Польша" },
  краков:   { lat: 50.0647, lng: 19.9450, country: "Польша" },
  познань:  { lat: 52.4064, lng: 16.9252, country: "Польша" },
  париж:    { lat: 48.8566, lng:  2.3522, country: "Франция" },
  лион:     { lat: 45.7640, lng:  4.8357, country: "Франция" },
};

/** Ищет координаты города по имени (регистронезависимо). */
export function findCoord(cityName: string): GeoCoord | undefined {
  return BRANCH_COORDINATES[cityName.toLowerCase()];
}
