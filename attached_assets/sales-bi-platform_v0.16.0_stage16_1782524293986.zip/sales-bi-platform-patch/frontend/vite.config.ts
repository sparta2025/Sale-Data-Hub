// VERSION: 1.0.0
// Path: frontend/vite.config.ts
// CHANGES v1.0.0:
//   - Этап 1: dev-сервер + прокси /api -> backend, alias '@' -> src
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Прокси /api -> backend, чтобы в dev-режиме не возиться с CORS вручную
// и чтобы frontend-код всегда обращался к одному и тому же относительному пути.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    proxy: {
      "/api": {
        target: process.env.VITE_API_PROXY_TARGET || "http://localhost:8000",
        changeOrigin: true,
      },
    },
  },
  resolve: {
    alias: {
      "@": "/src",
    },
  },
});
