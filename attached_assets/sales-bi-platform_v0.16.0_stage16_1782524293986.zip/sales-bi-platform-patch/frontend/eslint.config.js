// VERSION: 1.0.0
// Path: frontend/eslint.config.js
// CHANGES v1.0.0:
//   - Этап 7: flat-конфиг ESLint v9 (TypeScript + React Hooks + Fast Refresh) —
//     отсутствовал с Этапа 1, из-за чего `npm run lint` падал с ошибкой
import js from "@eslint/js";
import tseslint from "@typescript-eslint/eslint-plugin";
import tsParser from "@typescript-eslint/parser";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";

export default [
  { ignores: ["dist", "node_modules"] },
  js.configs.recommended,
  {
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      parser: tsParser,
      parserOptions: {
        ecmaVersion: "latest",
        sourceType: "module",
        ecmaFeatures: { jsx: true },
      },
      globals: {
        window: "readonly",
        document: "readonly",
        console: "readonly",
        FormData: "readonly",
        DragEvent: "readonly",
        HTMLInputElement: "readonly",
        HTMLDivElement: "readonly",
        File: "readonly",
        URLSearchParams: "readonly",
        setInterval: "readonly",
        clearInterval: "readonly",
      },
    },
    plugins: {
      "@typescript-eslint": tseslint,
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      ...tseslint.configs.recommended.rules,
      ...reactHooks.configs.recommended.rules,
      "react-refresh/only-export-components": [
        "warn",
        { allowConstantExport: true },
      ],
      "@typescript-eslint/no-unused-vars": [
        "warn",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
      "no-unused-vars": "off", // делегируем правилу @typescript-eslint выше
      "no-undef": "off", // TypeScript сам проверяет неопределённые имена через tsc
    },
  },
];
