-- VERSION: 1.0.0
-- Path: scripts/init_postgres.sql
-- CHANGES v1.0.0:
--   - Этап 2: SQL-эквивалент setup_postgres.sh для ручного/однократного запуска
--
-- Чистый SQL-вариант создания роли и БД — для случаев, когда вы подключаетесь
-- к уже существующему серверу PostgreSQL (managed-сервис в облаке, отдельный
-- сервер и т.п.) и предпочитаете выполнить SQL сами, а не запускать bash-скрипт.
--
-- Запуск (от имени суперпользователя, обычно 'postgres'):
--   psql -U postgres -h <host> -p <port> -f scripts/init_postgres.sql
--
-- В отличие от setup_postgres.sh, этот файл НЕ идемпотентен: если роль или
-- база уже существуют, CREATE USER/CREATE DATABASE завершится ошибкой
-- "already exists" — в этом случае просто пропустите соответствующую команду.

CREATE USER bi_user WITH PASSWORD 'bi_password';
CREATE DATABASE bi_metadata OWNER bi_user;
GRANT ALL PRIVILEGES ON DATABASE bi_metadata TO bi_user;

-- Опционально: отдельная БД для тестов (см. backend/tests/conftest.py —
-- тесты создают её автоматически через psycopg2, но если автоматическое
-- создание недоступно в вашей среде, создайте её здесь явно).
CREATE DATABASE bi_metadata_test OWNER bi_user;
