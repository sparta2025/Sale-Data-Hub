"""
VERSION: 1.0.0
Path: scripts/init_duckdb.py
CHANGES v1.0.0:
  - Этап 2: явная инициализация файла DuckDB (директория, служебная таблица _meta)

Явная инициализация файла DuckDB.

ВАЖНО: в отличие от PostgreSQL, DuckDB — встраиваемая (embedded) БД без
отдельного сервера/демона. "База данных" — это просто файл на диске, который
сам движок DuckDB создаёт автоматически при первом подключении (это уже
происходит лениво в app/db/duckdb_conn.py при старте FastAPI). Поэтому
формально этот скрипт НЕ ОБЯЗАТЕЛЕН для работы приложения.

Зачем он тогда нужен:
  - явное провижининг в CI/деплое — заранее проверить права на запись
    в директорию данных, до того как приложение попытается это сделать;
  - создать служебную таблицу _meta с версией схемы — задел на будущее,
    если в Этапе 4+ понадобится отслеживать миграции самой DuckDB-схемы
    (DuckDB не имеет инструмента миграций уровня Alembic "из коробки").

Использование:
  python3 scripts/init_duckdb.py [путь_к_файлу.duckdb]
  (по умолчанию — data/duckdb/analytics.duckdb относительно корня репозитория)
"""
import sys
from pathlib import Path

import duckdb

DEFAULT_RELATIVE_PATH = "data/duckdb/analytics.duckdb"


def init_duckdb(db_path: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = duckdb.connect(str(db_path))
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS _meta (
                key VARCHAR PRIMARY KEY,
                value VARCHAR
            )
            """
        )
        conn.execute(
            "INSERT INTO _meta (key, value) VALUES ('schema_version', '1') "
            "ON CONFLICT (key) DO NOTHING"
        )
        version = conn.execute("SELECT value FROM _meta WHERE key = 'schema_version'").fetchone()[0]
        tables = conn.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'main'"
        ).fetchall()
    finally:
        conn.close()

    print(f"DuckDB готов: {db_path.resolve()}")
    print(f"  schema_version = {version}")
    print(f"  таблиц в файле: {len(tables)} ({', '.join(t[0] for t in tables)})")


if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else project_root / DEFAULT_RELATIVE_PATH
    init_duckdb(target)
