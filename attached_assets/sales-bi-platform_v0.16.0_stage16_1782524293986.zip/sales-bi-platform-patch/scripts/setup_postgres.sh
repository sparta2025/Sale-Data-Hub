#!/usr/bin/env bash
# VERSION: 1.0.0
# Path: scripts/setup_postgres.sh
# CHANGES v1.0.0:
#   - Этап 2: идемпотентное создание роли+БД PostgreSQL для локальной разработки
#
# Назначение: создаёт пользователя и базу PostgreSQL, описанные в .env
# (или в дефолтах .env.example), если их ещё нет. Безопасно запускать повторно.
#
# ВНИМАНИЕ: это скрипт для ЛОКАЛЬНОЙ разработки без Docker. Если вы запускаете
# проект через `docker compose up`, этот скрипт НЕ НУЖЕН — официальный образ
# postgres сам создаёт пользователя/БД из переменных окружения при первом
# старте контейнера (см. docker-compose.yml, секция services.postgres).
#
# Использование:
#   bash scripts/setup_postgres.sh
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="$PROJECT_ROOT/.env"

if [[ -f "$ENV_FILE" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi

POSTGRES_USER="${POSTGRES_USER:-bi_user}"
POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-bi_password}"
POSTGRES_DB="${POSTGRES_DB:-bi_metadata}"
POSTGRES_HOST="${POSTGRES_HOST:-localhost}"
POSTGRES_PORT="${POSTGRES_PORT:-5432}"

echo "==> PostgreSQL setup: user=${POSTGRES_USER} db=${POSTGRES_DB} host=${POSTGRES_HOST}:${POSTGRES_PORT}"

# --- 1. Убеждаемся, что psql/сервер установлены ---
if ! command -v psql >/dev/null 2>&1; then
  echo "psql не найден в PATH."
  if command -v apt-get >/dev/null 2>&1; then
    echo "==> Устанавливаю postgresql через apt-get (нужны права root)..."
    apt-get update -qq
    apt-get install -y -qq postgresql postgresql-contrib
  elif command -v brew >/dev/null 2>&1; then
    echo "Установите PostgreSQL вручную: brew install postgresql@16 && brew services start postgresql@16"
    exit 1
  else
    echo "Установите PostgreSQL для вашей ОС вручную и запустите скрипт снова." >&2
    exit 1
  fi
fi

# --- 2. Запускаем сервис, если он не запущен ---
if command -v pg_isready >/dev/null 2>&1 && pg_isready -q; then
  echo "==> PostgreSQL уже запущен"
else
  echo "==> Запускаю PostgreSQL..."
  if command -v service >/dev/null 2>&1; then
    service postgresql start || true
  elif command -v pg_ctlcluster >/dev/null 2>&1; then
    PG_VERSION="$(ls /etc/postgresql/ 2>/dev/null | head -1)"
    pg_ctlcluster "${PG_VERSION:-16}" main start || true
  elif command -v brew >/dev/null 2>&1; then
    brew services start postgresql@16 || true
  fi
  for _ in $(seq 1 10); do
    pg_isready -q && break
    sleep 1
  done
fi

# --- 3. Создаём роль и БД (идемпотентно) ---
run_as_postgres() {
  if command -v su >/dev/null 2>&1 && id postgres >/dev/null 2>&1; then
    su - postgres -c "psql -tAc \"$1\""
  else
    psql -U postgres -tAc "$1"
  fi
}

ROLE_EXISTS=$(run_as_postgres "SELECT 1 FROM pg_roles WHERE rolname='${POSTGRES_USER}'" || echo "")
if [[ "$ROLE_EXISTS" != "1" ]]; then
  echo "==> Создаю роль ${POSTGRES_USER}"
  run_as_postgres "CREATE USER ${POSTGRES_USER} WITH PASSWORD '${POSTGRES_PASSWORD}' SUPERUSER;" >/dev/null
else
  echo "==> Роль ${POSTGRES_USER} уже существует — пропускаю"
fi

DB_EXISTS=$(run_as_postgres "SELECT 1 FROM pg_database WHERE datname='${POSTGRES_DB}'" || echo "")
if [[ "$DB_EXISTS" != "1" ]]; then
  echo "==> Создаю базу ${POSTGRES_DB}"
  run_as_postgres "CREATE DATABASE ${POSTGRES_DB} OWNER ${POSTGRES_USER};" >/dev/null
else
  echo "==> База ${POSTGRES_DB} уже существует — пропускаю"
fi

# --- 4. Проверка подключения от имени приложения ---
echo "==> Проверка подключения как ${POSTGRES_USER}:"
PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" \
  -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "SELECT version();"

echo "==> Готово. Дальше: cd backend && alembic upgrade head"
