# VERSION: 1.1.0
# Path: scripts/init_schema.sql
# CHANGES v1.1.0:
#   - Этап 5: добавлена таблица dashboards с COMMENT-ами; обновлена версия alembic
-- =============================================================================
-- Sales BI Platform — полная схема PostgreSQL
-- Версия: v1.3.0 (Этапы 1–4)
-- Применять: psql -U bi_user -d bi_metadata -f init_schema.sql
--
-- Архитектура хранения данных:
--   • PostgreSQL (этот файл) — хранит ТОЛЬКО МЕТАДАННЫЕ загруженных
--     датасетов: структуру колонок, типы, правила агрегации и отображения.
--     Самих строк данных здесь нет.
--   • DuckDB — хранит ФАКТИЧЕСКИЕ ДАННЫЕ (миллионы строк из CSV/XLSX).
--     Для каждого датасета создаётся отдельная таблица с именем
--     'dataset_<32hex>'. Postgres знает только схему этой таблицы
--     (через dimensions/metrics), но не её содержимое.
-- =============================================================================

-- CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =============================================================================
-- alembic_version
-- =============================================================================
CREATE TABLE IF NOT EXISTS alembic_version (
    version_num VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);
COMMENT ON TABLE alembic_version IS
    'Служебная таблица Alembic. Хранит одну строку — хеш последней применённой миграции.';
COMMENT ON COLUMN alembic_version.version_num IS
    'Хеш (идентификатор) ревизии Alembic, например «68f0e9eb15c8».';

-- =============================================================================
-- datasets
-- =============================================================================
CREATE TABLE IF NOT EXISTS datasets (
    id                UUID                     NOT NULL DEFAULT gen_random_uuid(),
    name              VARCHAR(255)             NOT NULL,
    original_filename VARCHAR(512)             NOT NULL,
    source_format     VARCHAR(16)              NOT NULL,
    duckdb_table      VARCHAR(128)             NOT NULL,
    row_count         INTEGER                  NOT NULL DEFAULT 0,
    column_count      INTEGER                  NOT NULL DEFAULT 0,
    status            VARCHAR(32)              NOT NULL DEFAULT 'ready',
    warnings          JSON                     NOT NULL DEFAULT '[]',
    column_profile    JSON                     NOT NULL DEFAULT '[]',
    created_at        TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    CONSTRAINT datasets_pkey PRIMARY KEY (id),
    CONSTRAINT datasets_duckdb_table_key UNIQUE (duckdb_table)
);
COMMENT ON TABLE datasets IS
    'Реестр загруженных датасетов. Одна строка = один файл (CSV или XLSX). '
    'Хранятся только метаданные; фактические данные в DuckDB (поле duckdb_table).';
COMMENT ON COLUMN datasets.id IS 'UUID датасета, генерируется автоматически.';
COMMENT ON COLUMN datasets.name IS 'Отображаемое имя в UI. По умолчанию = имя файла без расширения.';
COMMENT ON COLUMN datasets.original_filename IS 'Исходное имя файла (например «Продажи_Q1_2026.xlsx»).';
COMMENT ON COLUMN datasets.source_format IS 'Формат файла: «csv» или «xlsx».';
COMMENT ON COLUMN datasets.duckdb_table IS
    'Имя таблицы в DuckDB. Формат: «dataset_<32hex>». '
    'Единственная связь между метаданными Postgres и данными DuckDB.';
COMMENT ON COLUMN datasets.row_count IS 'Строк, успешно загруженных в DuckDB.';
COMMENT ON COLUMN datasets.column_count IS 'Колонок в исходном файле.';
COMMENT ON COLUMN datasets.status IS '«ready» — импорт успешен; «failed» — провалился.';
COMMENT ON COLUMN datasets.warnings IS
    'JSON-массив предупреждений парсинга. '
    'Пример: ["Колонка ''Дата'' содержит 3 пустых значения"].';
COMMENT ON COLUMN datasets.column_profile IS
    'JSON-снимок технического профиля колонок на момент импорта. '
    'Используется для повторного анализа; для отчётов — dimensions/metrics.';
COMMENT ON COLUMN datasets.created_at IS 'Дата и время загрузки (UTC).';

-- =============================================================================
-- dimensions
-- =============================================================================
CREATE TABLE IF NOT EXISTS dimensions (
    id               UUID                     NOT NULL DEFAULT gen_random_uuid(),
    dataset_id       UUID                     NOT NULL,
    column_name      VARCHAR(255)             NOT NULL,
    display_name     VARCHAR(255)             NOT NULL,
    data_type        VARCHAR(32)              NOT NULL,
    hierarchy_group  VARCHAR(64),
    hierarchy_level  INTEGER                  NOT NULL DEFAULT 0,
    sample_values    JSON                     NOT NULL DEFAULT '[]',
    distinct_count   INTEGER                  NOT NULL DEFAULT 0,
    is_visible       BOOLEAN                  NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    CONSTRAINT dimensions_pkey PRIMARY KEY (id),
    CONSTRAINT dimensions_dataset_id_fkey
        FOREIGN KEY (dataset_id) REFERENCES datasets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_dimensions_dataset_id ON dimensions (dataset_id);

COMMENT ON TABLE dimensions IS
    'Измерения датасета — колонки для GROUP BY и фильтров. '
    'Примеры: «Регион», «Год», «Месяц». Заполняется при импорте; '
    'пользователь может изменить display_name, is_visible, иерархию.';
COMMENT ON COLUMN dimensions.dataset_id IS 'FK → datasets.id. CASCADE DELETE.';
COMMENT ON COLUMN dimensions.column_name IS 'Физическое имя колонки в DuckDB. Используется в SQL.';
COMMENT ON COLUMN dimensions.display_name IS 'Отображаемое имя в UI. Редактируется пользователем.';
COMMENT ON COLUMN dimensions.data_type IS '«text» | «year» | «month».';
COMMENT ON COLUMN dimensions.hierarchy_group IS
    'Группа иерархии для drill-down: «time», «geography», «product». NULL = нет иерархии.';
COMMENT ON COLUMN dimensions.hierarchy_level IS
    '0 = верхний уровень иерархии. Год=0, Месяц=1 при group=«time».';
COMMENT ON COLUMN dimensions.sample_values IS
    'JSON-массив примеров значений для предпросмотра в UI. Пример: ["Москва","Берлин"].';
COMMENT ON COLUMN dimensions.distinct_count IS 'Кол-во уникальных значений на момент импорта.';
COMMENT ON COLUMN dimensions.is_visible IS 'FALSE — скрыть из UI построителя отчётов.';
COMMENT ON INDEX ix_dimensions_dataset_id IS
    'Ускоряет выборку всех измерений датасета (основной паттерн доступа).';

-- =============================================================================
-- metrics
-- =============================================================================
CREATE TABLE IF NOT EXISTS metrics (
    id             UUID                     NOT NULL DEFAULT gen_random_uuid(),
    dataset_id     UUID                     NOT NULL,
    column_name    VARCHAR(255)             NOT NULL,
    display_name   VARCHAR(255)             NOT NULL,
    data_type      VARCHAR(32)              NOT NULL,
    aggregation    VARCHAR(16)              NOT NULL DEFAULT 'sum',
    display_format VARCHAR(64)              NOT NULL DEFAULT '{:.2f}',
    is_visible     BOOLEAN                  NOT NULL DEFAULT TRUE,
    created_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    CONSTRAINT metrics_pkey PRIMARY KEY (id),
    CONSTRAINT metrics_dataset_id_fkey
        FOREIGN KEY (dataset_id) REFERENCES datasets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_metrics_dataset_id ON metrics (dataset_id);

COMMENT ON TABLE metrics IS
    'Метрики датасета — числовые колонки для агрегации. '
    'Примеры: «Выручка», «Количество», «Маржа %». '
    'Хранит функцию агрегации по умолчанию и шаблон форматирования числа.';
COMMENT ON COLUMN metrics.dataset_id IS 'FK → datasets.id. CASCADE DELETE.';
COMMENT ON COLUMN metrics.column_name IS 'Физическое имя колонки в DuckDB. Используется в SQL.';
COMMENT ON COLUMN metrics.display_name IS 'Отображаемое имя в UI. Редактируется пользователем.';
COMMENT ON COLUMN metrics.data_type IS '«integer» | «float» | «currency» | «percentage».';
COMMENT ON COLUMN metrics.aggregation IS
    'Агрегация по умолчанию: «sum», «avg», «count», «min», «max». '
    'currency/integer → sum; percentage → avg.';
COMMENT ON COLUMN metrics.display_format IS
    'Python-шаблон форматирования: «€ {:,.2f}», «{:.1f}%», «{:,.0f}».';
COMMENT ON COLUMN metrics.is_visible IS 'FALSE — скрыть из UI построителя отчётов.';
COMMENT ON INDEX ix_metrics_dataset_id IS
    'Ускоряет выборку всех метрик датасета (основной паттерн доступа).';

-- =============================================================================
-- Версия схемы
-- =============================================================================
INSERT INTO alembic_version (version_num)
VALUES ('68f0e9eb15c8')
ON CONFLICT DO NOTHING;

-- =============================================================================
-- Проверка:
--   SELECT table_name FROM information_schema.tables
--     WHERE table_schema = 'public' ORDER BY table_name;
--   SELECT version_num FROM alembic_version;
-- =============================================================================

-- =============================================================================
-- dashboards  (добавлено в Этапе 5)
-- =============================================================================
CREATE TABLE IF NOT EXISTS dashboards (
    id          UUID                     NOT NULL DEFAULT gen_random_uuid(),
    dataset_id  UUID                     NOT NULL,
    name        VARCHAR(255)             NOT NULL,
    description VARCHAR(1024),
    config      JSON                     NOT NULL DEFAULT '{}',
    created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),

    CONSTRAINT dashboards_pkey PRIMARY KEY (id),
    CONSTRAINT dashboards_dataset_id_fkey
        FOREIGN KEY (dataset_id) REFERENCES datasets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_dashboards_dataset_id ON dashboards (dataset_id);

COMMENT ON TABLE dashboards IS
    'Сохранённые конфигурации дашбордов пользователя. '
    'Одна строка = один дашборд, привязанный к датасету. '
    'config (JSON) хранит: kpi_metrics, default_filters, список charts '
    '(type: timeseries|bar|pie|treemap|heatmap|table, dimensions, metrics, group_by).';
COMMENT ON COLUMN dashboards.dataset_id IS 'FK → datasets.id. CASCADE DELETE.';
COMMENT ON COLUMN dashboards.name IS 'Отображаемое имя дашборда в UI.';
COMMENT ON COLUMN dashboards.description IS 'Опциональное описание/заметка к дашборду.';
COMMENT ON COLUMN dashboards.config IS
    'Полная конфигурация дашборда в JSON. Структура: '
    '{ kpi_metrics: [...], default_filters: {...}, '
    'charts: [{id, type, title, dimensions, metrics, group_by, limit}] }';
COMMENT ON COLUMN dashboards.updated_at IS 'Время последнего обновления (UTC).';
COMMENT ON INDEX ix_dashboards_dataset_id IS
    'Ускоряет выборку всех дашбордов датасета.';

-- Обновляем версию схемы (последняя миграция Этапа 5)
DELETE FROM alembic_version;
INSERT INTO alembic_version (version_num) VALUES ('de5cb779847d');
