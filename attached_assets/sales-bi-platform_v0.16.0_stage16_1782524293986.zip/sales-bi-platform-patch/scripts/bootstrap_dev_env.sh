#!/usr/bin/env bash
# VERSION: 1.0.0
# Path: scripts/bootstrap_dev_env.sh
# CHANGES v1.0.0:
#   - Этап 2: единая точка входа для локальной инициализации сред (Postgres + Alembic + DuckDB)
#
# Полная инициализация локальной среды разработки одной командой (вне Docker
# Compose — внутри него всё происходит автоматически при `docker compose up`).
#
# Делает по порядку:
#   1) создаёт роль+БД PostgreSQL (scripts/setup_postgres.sh);
#   2) применяет Alembic-миграции (создаёт таблицы метаданных, напр. datasets);
#   3) инициализирует файл DuckDB (scripts/init_duckdb.py).
#
# Использование:
#   bash scripts/bootstrap_dev_env.sh
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "########## 1/3 PostgreSQL ##########"
bash "$PROJECT_ROOT/scripts/setup_postgres.sh"

echo
echo "########## 2/3 Alembic migrations ##########"
cd "$PROJECT_ROOT/backend"
alembic upgrade head

echo
echo "########## 3/3 DuckDB ##########"
python3 "$PROJECT_ROOT/scripts/init_duckdb.py"

echo
echo "==> Среда готова. Запуск backend: cd backend && uvicorn app.main:app --reload"
