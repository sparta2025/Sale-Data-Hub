"""Утилита разового запуска: проставляет заголовки VERSION/Path/CHANGES.

ВАЖНО: каждый список STAGE<N>_* применяется к проекту РОВНО ОДИН РАЗ — в
момент завершения соответствующего этапа. Списки прошлых этапов оставлены
в файле как читаемая история (что и с какой версии было проставлено), но
не передаются в apply() повторно — иначе заголовки задублируются. Если файл
полностью перезаписывается в новом этапе (теряя старый заголовок), для него
заводится новая запись с тем же путём в списке актуального этапа — так было,
например, с app/models/__init__.py при добавлении в него реального кода.

Не входит в сам продукт — служебный скрипт, не копируется в финальный zip.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# ============================================================================
# ЭТАП 1 — ИСТОРИЯ (уже применено, см. чекпойнт v1.0.0; НЕ запускать повторно)
# ============================================================================
STAGE1_HASH_ENTRIES = [
    ("backend/requirements.txt", "1.0.0", ["..."]),
    ("backend/requirements-dev.txt", "1.0.0", ["..."]),
    ("backend/pytest.ini", "1.0.0", ["..."]),
    ("backend/alembic.ini", "1.0.0", ["..."]),
    ("backend/Dockerfile", "1.0.0", ["..."]),
    ("frontend/Dockerfile", "1.0.0", ["..."]),
    (".gitignore", "1.0.0", ["..."]),
    ("docker-compose.yml", "1.0.0", ["..."]),
    (".env.example", "1.0.0", ["..."]),
    ("backend/app/__init__.py", "1.0.0", ["..."]),
    ("backend/app/core/__init__.py", "1.0.0", ["..."]),
    ("backend/app/db/__init__.py", "1.0.0", ["..."]),
    ("backend/app/models/__init__.py", "1.0.0", ["заглушка — позже перезаписана в Этапе 2"]),
    ("backend/app/schemas/__init__.py", "1.0.0", ["заглушка — позже перезаписана в Этапе 2"]),
    ("backend/app/api/__init__.py", "1.0.0", ["..."]),
    ("backend/app/modules/__init__.py", "1.0.0", ["..."]),
    ("backend/app/modules/data_import/__init__.py", "1.0.0", ["..."]),
    ("backend/app/modules/metadata/__init__.py", "1.0.0", ["..."]),
    ("backend/app/modules/query_engine/__init__.py", "1.0.0", ["..."]),
    ("backend/app/modules/dashboard_engine/__init__.py", "1.0.0", ["..."]),
    ("backend/app/modules/export/__init__.py", "1.0.0", ["..."]),
    ("backend/tests/__init__.py", "1.0.0", ["..."]),
]
STAGE1_PY_ENTRIES = [
    ("backend/app/core/config.py", "1.0.0", ["..."]),
    ("backend/app/db/postgres.py", "1.0.0", ["..."]),
    ("backend/app/db/duckdb_conn.py", "1.0.0", ["..."]),
    ("backend/app/interfaces/data_provider.py", "1.0.0", ["..."]),
    ("backend/app/interfaces/dashboard_provider.py", "1.0.0", ["..."]),
    ("backend/app/interfaces/chart_provider.py", "1.0.0", ["..."]),
    ("backend/app/interfaces/metric_provider.py", "1.0.0", ["..."]),
    ("backend/app/interfaces/data_exporter.py", "1.0.0", ["..."]),
    ("backend/app/interfaces/__init__.py", "1.0.0", ["..."]),
    ("backend/app/api/router.py", "1.0.0", ["заголовок v1.0.0 — позже дополнен в Этапе 2 правкой вручную"]),
    ("backend/app/main.py", "1.0.0", ["..."]),
    ("backend/migrations/env.py", "1.0.0", ["заголовок v1.0.0 — бампнут до v1.1.0 в Этапе 2 правкой вручную"]),
    ("backend/tests/conftest.py", "1.0.0", ["..."]),
    ("backend/tests/test_health.py", "1.0.0", ["..."]),
    ("backend/tests/test_config.py", "1.0.0", ["..."]),
    ("backend/tests/test_duckdb_conn.py", "1.0.0", ["..."]),
    ("backend/tests/test_interfaces.py", "1.0.0", ["..."]),
]
STAGE1_TS_ENTRIES = [
    ("frontend/vite.config.ts", "1.0.0", ["..."]),
    ("frontend/src/theme/index.ts", "1.0.0", ["..."]),
    ("frontend/src/api/client.ts", "1.0.0", ["..."]),
    ("frontend/src/pages/StatusPage.tsx", "1.0.0", ["..."]),
    ("frontend/src/App.tsx", "1.0.0", ["..."]),
    ("frontend/src/main.tsx", "1.0.0", ["..."]),
    ("frontend/src/vite-env.d.ts", "1.0.0", ["..."]),
]
STAGE1_HTML_ENTRIES = [("frontend/index.html", "1.0.0", ["..."])]
STAGE1_MD_ENTRIES = [
    ("README.md", "1.0.0", ["..."]),
    ("docs/PROGRESS.md", "1.0.0", ["..."]),
]

# ============================================================================
# ЭТАП 2 — применяется ЭТИМ запуском (новые файлы; не пересекается с Этапом 1)
# ============================================================================
STAGE2_HASH_ENTRIES = [
    ("backend/app/models/dataset.py", "1.0.0", [
        "Этап 2: ORM-модель Dataset — реестр загруженных датасетов в Postgres",
    ]),
    ("backend/app/models/__init__.py", "1.0.0", [
        "Этап 2: регистрация Dataset на Base.metadata (файл переписан целиком,"
        "|старый заголовок-заглушка Этапа 1 утрачен вместе с пустым содержимым)",
    ]),
    ("backend/app/schemas/dataset.py", "1.0.0", [
        "Этап 2: Pydantic-схемы ColumnProfile/DatasetOut/ImportResponse/PreviewResponse",
    ]),
    ("backend/app/schemas/__init__.py", "1.0.0", [
        "Этап 2: точка импорта схем датасета (файл переписан целиком, см. models/__init__.py)",
    ]),
    ("backend/app/modules/data_import/structure_detector.py", "1.1.0", [
        "Этап 2: автоопределение роли/типа колонки (текст/число/%/валюта/год/месяц)"
        "|v1.1.0: добавлено «спасение» числовых колонок, ставших object из-за"
        "|пары «грязных» значений (иначе падали при сортировке смешанных типов в sample_values)",
    ]),
    ("backend/app/modules/data_import/file_reader.py", "1.0.0", [
        "Этап 2: чтение CSV (автоопределение кодировки/разделителя) и XLSX"
        "|(выбор листа с данными среди нескольких листов)",
    ]),
    ("backend/app/modules/data_import/cleaner.py", "1.0.0", [
        "Этап 2: очистка данных и обработка пропусков (текст -> плейсхолдер,"
        "|числа -> NULL, а не 0, чтобы не искажать агрегаты)",
    ]),
    ("backend/app/modules/data_import/duckdb_writer.py", "1.0.0", [
        "Этап 2: запись DataFrame в DuckDB как физическую таблицу датасета"
        "|(register + CREATE TABLE AS SELECT, без поэлементных INSERT)",
    ]),
    ("backend/migrations/versions/e4b51d19ff29_create_datasets_table.py", "1.0.0", [
        "Этап 2: первая миграция — таблица datasets (автогенерация Alembic,"
        "|применена к реальному PostgreSQL в песочнице)",
    ]),
    # ПРИМЕЧАНИЕ: scripts/setup_postgres.sh, scripts/init_postgres.sql,
    # scripts/init_duckdb.py и scripts/bootstrap_dev_env.sh заголовок получили
    # вручную, прямо при создании файла (он встроен в сам file_text) — здесь
    # их специально НЕТ, чтобы повторный запуск скрипта не продублировал его.
]


def _bullet_lines(changes: list[str], dash: str, cont: str) -> list[str]:
    out = []
    for change in changes:
        parts = change.split("|")
        out.append(f"{dash}{parts[0]}")
        out.extend(f"{cont}{p}" for p in parts[1:])
    return out


def header_hash(path: str, version: str, changes: list[str]) -> str:
    lines = [f"# VERSION: {version}", f"# Path: {path}", f"# CHANGES v{version}:"]
    lines += _bullet_lines(changes, "#   - ", "#     ")
    return "\n".join(lines) + "\n"


def header_slash(path: str, version: str, changes: list[str]) -> str:
    lines = [f"// VERSION: {version}", f"// Path: {path}", f"// CHANGES v{version}:"]
    lines += _bullet_lines(changes, "//   - ", "//     ")
    return "\n".join(lines) + "\n"


def header_html(path: str, version: str, changes: list[str]) -> str:
    lines = [f"VERSION: {version}", f"Path: {path}", f"CHANGES v{version}:"]
    lines += _bullet_lines(changes, "  - ", "    ")
    return "<!--\n" + "\n".join(lines) + "\n-->\n"


def apply(entries, header_fn):
    for rel_path, version, changes in entries:
        full = ROOT / rel_path
        original = full.read_text(encoding="utf-8")
        header = header_fn(rel_path, version, changes)
        full.write_text(header + original, encoding="utf-8")
        print(f"OK  {rel_path}")


if __name__ == "__main__":
    # Только Этап 2 — Этап 1 уже применён ранее и не повторяется.
    apply(STAGE2_HASH_ENTRIES, header_hash)
    print("Готово (Этап 2).")
