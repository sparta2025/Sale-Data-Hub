<!--
VERSION: 2.0.0
Path: README.md
CHANGES v2.0.0:
  - Этап 16: полная переработка — архитектура, модульная система,
    инструкции деплоя (full / standalone), переменные окружения.
-->

# Sales BI Platform

**Модульная BI-платформа** для анализа продаж: 15 типов диаграмм, KPI Analysis,
drag-and-drop дашборды, 9 языков, 3 темы, AI-агенты (AgentBus).

---

## Быстрый старт

```bash
git clone <repo>
cd sales-bi-platform
docker compose up --build
```

Открыть: **http://localhost:5173**

---

## Стек

| Слой      | Технологии                                             |
|-----------|--------------------------------------------------------|
| Frontend  | React 18, TypeScript, Vite, MUI v6, ECharts, Leaflet  |
| Backend   | FastAPI, Python 3.12, DuckDB (аналитика), SQLAlchemy   |
| DB        | PostgreSQL 16 (метаданные), DuckDB (данные/OLAP)       |
| Deploy    | Docker Compose (profiles: full / dashboards / kpi)    |

---

## Структура репозитория

```
sales-bi-platform/
├── backend/
│   ├── app/
│   │   ├── modules/
│   │   │   ├── data_import/       Загрузка CSV/XLSX → DuckDB
│   │   │   ├── metadata/          Метаданные колонок (dimensions/metrics)
│   │   │   ├── query_engine/      SQL-builder, агрегации, фильтры
│   │   │   ├── dashboard_engine/  CRUD дашбордов
│   │   │   ├── export/            CSV/XLSX/PDF/PNG экспорт
│   │   │   ├── analytics/         Статистика: describe (min/max/median/Q1/Q3)
│   │   │   ├── kpi/               KPI Scorecard и Period Comparison
│   │   │   └── platform_registry/ GET /api/platform/info|modules
│   │   ├── schemas/               Pydantic-схемы
│   │   ├── models/                SQLAlchemy ORM
│   │   ├── db/                    PostgreSQL + DuckDB соединения
│   │   └── api/router.py          Сборка всех роутеров
│   ├── migrations/                Alembic (PostgreSQL)
│   └── tests/                     pytest (>15 файлов)
│
├── frontend/
│   └── src/
│       ├── modules/               Модульная система
│       │   ├── types.ts           ModuleManifest, AgentHook, SubscriptionTier
│       │   ├── registry.ts        ALL_MODULES + VITE_ENABLED_MODULES фильтр
│       │   ├── dashboards/        manifest.ts
│       │   ├── kpi/               manifest + KpiAnalysisPage + hooks + KpiTargets
│       │   └── agents/            manifest + AgentBus (event bus)
│       ├── components/
│       │   ├── charts/            15 типов ECharts-диаграмм
│       │   ├── common/            ModuleGuard, ScalableChartWrapper, AgentConsole
│       │   ├── filters/           FilterBar с мульти-выбором и Ctrl+клик
│       │   └── layout/            AppLayout, Sidebar (accordion)
│       ├── context/               FiltersCtx, ThemeCtx, I18nCtx, ModulesCtx, DashboardLayoutCtx
│       ├── pages/                 Datasets, Detail, Dashboard, KPI, ToolsBoard, ...
│       ├── locales/               9 языков (ru/en/de/zh/be/kk/ar/sr/ko)
│       └── hooks/                 useDatasets, useMetadata, useQueryEngine, useKPI, ...
│
├── docs/
│   ├── PROGRESS.md                Журнал этапов разработки
│   └── ARCHITECTURE.md            Гайд по добавлению нового модуля
│
├── docker-compose.yml             Full (все модули)
└── docker-compose.standalone.yml  Standalone (выбранные модули)
```

---

## Диаграммы (15 типов)

| Тип               | Описание                                   |
|-------------------|--------------------------------------------|
| line              | Динамика по времени, группировка           |
| bar               | Столбчатый, drill-down                     |
| pie               | Круговой, drill-down                       |
| treemap           | Иерархия двух уровней                      |
| heatmap           | Год × месяц                                |
| waterfall         | Вклад категорий в итог                     |
| scatter           | Зависимость двух метрик, линия тренда      |
| histogram         | Распределение, N бинов                     |
| boxplot           | Ящик с усами, квартили                     |
| radar             | Многомерное сравнение (≥2 метрики)         |
| gauge             | Спидометр KPI, цели из KpiTargetsContext   |
| funnel            | Воронка Top-N категорий                    |
| statsummary       | Статистическая таблица (Q1/Q3/std/CV/null%)|
| map               | Карта филиалов, drill-down → товары        |
| table             | DataGrid с сортировкой и экспортом         |

---

## Модули платформы

| ID           | Название      | Tier       | Роуты                        |
|--------------|---------------|------------|------------------------------|
| dashboards   | Dashboards    | free       | /datasets, /metadata, /query |
| kpi          | KPI Analysis  | pro        | /kpi                         |
| analytics    | Analytics     | free       | /analytics                   |
| agents       | AI Agents     | enterprise | (coming soon)                |

### Добавить новый модуль

1. `frontend/src/modules/[name]/manifest.ts` — `ModuleManifest`
2. Зарегистрировать в `modules/registry.ts`
3. Создать страницу с `<ModuleGuard moduleId="[name]">`
4. Добавить роут в `routes/AppRoutes.tsx`
5. Backend: `app/modules/[name]/router.py` → подключить в `api/router.py`
6. Подробнее: **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**

---

## Docker Compose

### Full (все модули)

```bash
docker compose up --build
```

### Standalone — только Dashboards

```bash
docker compose -f docker-compose.standalone.yml up --build
```

### Standalone — Dashboards + KPI

```bash
MODULES=dashboards,kpi docker compose -f docker-compose.standalone.yml up --build
```

### docker-compose profiles

```bash
docker compose --profile dashboards up   # только Dashboards
docker compose --profile kpi up          # Dashboards + KPI
```

---

## Переменные окружения

### Backend (.env)

| Переменная        | Default      | Описание                          |
|-------------------|--------------|-----------------------------------|
| POSTGRES_USER     | bi_user      | Пользователь PostgreSQL           |
| POSTGRES_PASSWORD | bi_password  | Пароль                            |
| POSTGRES_DB       | bi_metadata  | Имя базы данных                   |
| DUCKDB_PATH       | /data/...    | Путь к DuckDB файлу               |
| UPLOAD_DIR        | /data/...    | Директория загрузок               |
| ENABLED_MODULES   | (пусто=все)  | Разрешённые модули через запятую  |
| STANDALONE_MODE   | false        | true = standalone (enterprise)    |
| DEBUG             | true         | Подробные логи                    |

### Frontend (.env или docker-compose env)

| Переменная             | Default     | Описание                            |
|------------------------|-------------|-------------------------------------|
| VITE_ENABLED_MODULES   | (пусто=все) | Модули через запятую                |
| VITE_STANDALONE_MODE   | false       | true = enterprise без ограничений   |
| VITE_AGENT_CONSOLE     | false       | true = AgentConsole в production    |

---

## Разработка

```bash
# Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
alembic upgrade head
uvicorn app.main:app --reload

# Frontend
cd frontend
npm install
npm run dev

# Тесты backend
cd backend && pytest
```

---

## API Документация

После запуска: **http://localhost:8000/docs** (Swagger UI)

Основные эндпоинты:

```
GET  /api/health                         Проверка соединения
GET  /api/platform/info                  Версия платформы и модули
GET  /api/datasets                       Список датасетов
POST /api/datasets/upload                Загрузка CSV/XLSX
GET  /api/metadata/{id}                  Метаданные датасета
POST /api/query/{id}/run                 Выполнить запрос
GET  /api/analytics/{id}/describe        Статистика метрик
GET  /api/kpi/{id}/scorecard             KPI период-vs-период
GET  /api/kpi/{id}/compare               Сравнение двух периодов
GET  /api/export/{id}/{format}           Экспорт (csv/xlsx/pdf/png)
```

---

## AgentBus — Интеграция AI-агентов

```typescript
import { AgentBus } from "@/modules/agents/AgentBus";

// Подписка на все события платформы
const unsubscribe = AgentBus.subscribeAll((event) => {
  console.log(event.hookId, event.moduleId, event.payload);
  // → передать агенту через WebSocket/SSE
});

// Получить последние события для контекста
const context = AgentBus.getLog(20);
```

Визуализация: иконка 🤖 в левом нижнем углу (AgentConsole).

---

## Версия: v0.16.0 | Этапов: 16 | Диаграмм: 15 | Языков: 9 | Тем: 3
