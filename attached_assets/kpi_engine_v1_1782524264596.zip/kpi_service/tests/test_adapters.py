# Path: kpi_service/tests/test_adapters.py
"""Тесты: адаптеры данных — Mock и Excel (без реального файла)."""
import asyncio
import pytest
import pandas as pd

from kpi_service.adapters.mock import MockAdapter
from sales_kpi import COL


@pytest.fixture
def mock():
    return MockAdapter(n=100, seed=1)


class TestMockAdapter:
    @pytest.mark.asyncio
    async def test_load_all(self, mock):
        df = await mock.load_transactions({})
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 100

    @pytest.mark.asyncio
    async def test_load_with_filter(self, mock):
        df = await mock.load_transactions({COL["country"]: "Германия"})
        assert (df[COL["country"]] == "Германия").all()

    @pytest.mark.asyncio
    async def test_load_unknown_filter_ignored(self, mock):
        df = await mock.load_transactions({"NonExistentColumn": "val"})
        assert len(df) == 100  # фильтр игнорируется, все строки

    @pytest.mark.asyncio
    async def test_health_ok(self, mock):
        h = await mock.health()
        assert h["status"] == "ok"
        assert h["row_count"] == 100

    @pytest.mark.asyncio
    async def test_row_count(self, mock):
        n = await mock.row_count()
        assert n == 100

    def test_name(self, mock):
        assert mock.name() == "mock"

    @pytest.mark.asyncio
    async def test_required_columns_present(self, mock):
        df = await mock.load_transactions({})
        required = [COL["country"], COL["year"], COL["rev_net"],
                    COL["gp"], COL["ebit"], COL["ebitda"]]
        for col in required:
            assert col in df.columns, f"Колонка {col} отсутствует"

    @pytest.mark.asyncio
    async def test_deterministic_seed(self):
        m1 = MockAdapter(n=50, seed=42)
        m2 = MockAdapter(n=50, seed=42)
        df1 = await m1.load_transactions({})
        df2 = await m2.load_transactions({})
        assert df1[COL["rev_net"]].sum() == df2[COL["rev_net"]].sum()

    @pytest.mark.asyncio
    async def test_filter_year(self, mock):
        df = await mock.load_transactions({COL["year"]: 2023})
        if len(df) > 0:
            assert (df[COL["year"]] == 2023).all()


class TestExcelAdapterNoFile:
    """Тесты Excel адаптера без реального файла — проверяем только error handling."""

    @pytest.mark.asyncio
    async def test_health_error_when_no_file(self):
        from kpi_service.adapters.excel import ExcelAdapter
        adapter = ExcelAdapter("/nonexistent/path/file.xlsx")
        h = await adapter.health()
        assert h["status"] == "error"
        assert "not found" in h["error"].lower() or "File not found" in h["error"]

    @pytest.mark.asyncio
    async def test_load_raises_when_no_file(self):
        from kpi_service.adapters.excel import ExcelAdapter, DataAdapterError
        adapter = ExcelAdapter("/nonexistent/path/file.xlsx")
        with pytest.raises(DataAdapterError):
            await adapter.load_transactions({})

    def test_name(self):
        from kpi_service.adapters.excel import ExcelAdapter
        adapter = ExcelAdapter("any.xlsx")
        assert adapter.name() == "excel"
