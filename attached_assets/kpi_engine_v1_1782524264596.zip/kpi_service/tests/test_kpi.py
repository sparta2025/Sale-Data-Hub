# Path: kpi_service/tests/test_kpi.py
"""Тесты: /api/kpi/* — агрегированные KPI-метрики."""
import pytest


class TestKPISummary:
    def test_status_200(self, client, kpi_summary_payload):
        r = client.post("/api/kpi/summary", json=kpi_summary_payload)
        assert r.status_code == 200

    def test_response_structure(self, client, kpi_summary_payload):
        data = client.post("/api/kpi/summary", json=kpi_summary_payload).json()
        assert "rows"       in data
        assert "total"      in data
        assert "row_count"  in data
        assert "group_by"   in data
        assert "source"     in data

    def test_group_by_reflected(self, client, kpi_summary_payload):
        data = client.post("/api/kpi/summary", json=kpi_summary_payload).json()
        assert data["group_by"] == kpi_summary_payload["group_by"]

    def test_rows_not_empty(self, client, kpi_summary_payload):
        data = client.post("/api/kpi/summary", json=kpi_summary_payload).json()
        assert data["row_count"] > 0
        assert len(data["rows"]) == data["row_count"]

    def test_row_has_dimensions(self, client, kpi_summary_payload):
        data = client.post("/api/kpi/summary", json=kpi_summary_payload).json()
        row = data["rows"][0]
        assert "dimensions" in row
        assert "metrics"    in row
        # Измерения = group_by колонки
        for g in kpi_summary_payload["group_by"]:
            assert g in row["dimensions"]

    def test_total_sum_matches_rows(self, client, kpi_summary_payload):
        data = client.post("/api/kpi/summary", json=kpi_summary_payload).json()
        # Сумма выручки по строкам ≈ итоговой строке
        rev_key = "Выручка нетто (EUR)"
        if rev_key in data["total"]:
            row_sum = sum(
                r["metrics"].get(rev_key, 0) or 0
                for r in data["rows"]
            )
            assert abs(row_sum - data["total"][rev_key]) < 1.0

    def test_group_by_single_dimension(self, client):
        payload = {"group_by": ["Страна"], "filters": {}}
        data = client.post("/api/kpi/summary", json=payload).json()
        assert data["row_count"] <= 3  # максимум 3 страны в mock

    def test_group_by_category(self, client):
        payload = {"group_by": ["Товарная группа"], "filters": {}}
        data = client.post("/api/kpi/summary", json=payload).json()
        assert data["row_count"] <= 3  # 3 категории в mock

    def test_filter_by_country(self, client):
        payload = {
            "group_by": ["Год"],
            "filters": {"country": "Германия"}
        }
        data = client.post("/api/kpi/summary", json=payload).json()
        assert data["row_count"] > 0

    def test_cached_flag_false_first_call(self, client):
        import uuid
        # Уникальная группировка чтобы гарантировать cache miss
        payload = {"group_by": ["Страна", "Год"], "filters": {"year": 2023}}
        data = client.post("/api/kpi/summary", json=payload).json()
        assert data["cached"] is False

    def test_source_field_is_string(self, client, kpi_summary_payload):
        data = client.post("/api/kpi/summary", json=kpi_summary_payload).json()
        assert isinstance(data["source"], str)
        assert data["source"] in ("duckdb", "excel", "mock")

    def test_metrics_are_numeric_or_null(self, client, kpi_summary_payload):
        data = client.post("/api/kpi/summary", json=kpi_summary_payload).json()
        for row in data["rows"]:
            for key, val in row["metrics"].items():
                assert val is None or isinstance(val, (int, float)), \
                    f"Метрика {key} = {val} не является числом"

    def test_invalid_group_by_returns_422(self, client):
        # group_by не список → 422
        r = client.post("/api/kpi/summary", json={"group_by": "Страна"})
        assert r.status_code == 422

    def test_empty_group_by_returns_422(self, client):
        r = client.post("/api/kpi/summary", json={"group_by": []})
        assert r.status_code in (200, 422)  # зависит от валидации

    def test_invalid_filter_key_ignored(self, client):
        # Несуществующий фильтр — не ломает запрос
        payload = {"group_by": ["Страна"], "filters": {"nonexistent": "value"}}
        r = client.post("/api/kpi/summary", json=payload)
        assert r.status_code in (200, 404)
