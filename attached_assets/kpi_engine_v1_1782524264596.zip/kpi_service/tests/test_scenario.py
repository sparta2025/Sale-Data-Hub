# Path: kpi_service/tests/test_scenario.py
"""Тесты: /api/scenario/* — сценарный анализ."""
import pytest


class TestScenarioRun:
    def test_status_200(self, client, scenario_payload):
        r = client.post("/api/scenario/run", json=scenario_payload)
        assert r.status_code == 200

    def test_response_structure(self, client, scenario_payload):
        data = client.post("/api/scenario/run", json=scenario_payload).json()
        assert "scenario_name" in data
        assert "base"          in data
        assert "result"        in data
        assert "deltas"        in data
        assert "group_by"      in data

    def test_scenario_name_reflected(self, client, scenario_payload):
        data = client.post("/api/scenario/run", json=scenario_payload).json()
        assert data["scenario_name"] == scenario_payload["name"]

    def test_price_increase_raises_revenue(self, client):
        base  = client.post("/api/scenario/run", json={
            "name": "base", "price_change": 0.0, "group_by": ["Страна"]
        }).json()
        up    = client.post("/api/scenario/run", json={
            "name": "up", "price_change": 0.10, "group_by": ["Страна"]
        }).json()

        rev_key = "Выручка нетто (EUR)"
        if rev_key in base["result"] and rev_key in up["result"]:
            assert up["result"][rev_key] > base["result"][rev_key]

    def test_price_decrease_lowers_revenue(self, client):
        base = client.post("/api/scenario/run", json={
            "name": "base", "price_change": 0.0, "group_by": ["Страна"]
        }).json()
        down = client.post("/api/scenario/run", json={
            "name": "down", "price_change": -0.10, "group_by": ["Страна"]
        }).json()
        rev_key = "Выручка нетто (EUR)"
        if rev_key in base["result"] and rev_key in down["result"]:
            assert down["result"][rev_key] < base["result"][rev_key]

    def test_cogs_decrease_raises_gp(self, client):
        base   = client.post("/api/scenario/run", json={
            "name": "base", "cogs_change": 0.0, "group_by": ["Страна"]
        }).json()
        cheaper = client.post("/api/scenario/run", json={
            "name": "cheaper", "cogs_change": -0.10, "group_by": ["Страна"]
        }).json()
        gp_key = "Валовая прибыль (EUR)"
        if gp_key in base["result"] and gp_key in cheaper["result"]:
            assert cheaper["result"][gp_key] > base["result"][gp_key]

    def test_deltas_structure(self, client, scenario_payload):
        data   = client.post("/api/scenario/run", json=scenario_payload).json()
        deltas = data["deltas"]
        assert isinstance(deltas, list)
        if deltas:
            d = deltas[0]
            assert "kpi"            in d
            assert "base_value"     in d
            assert "scenario_value" in d
            assert "delta_abs"      in d
            assert "delta_pct"      in d

    def test_baseline_delta_is_zero(self, client):
        data   = client.post("/api/scenario/run", json={
            "name": "base", "price_change": 0.0, "group_by": ["Страна"]
        }).json()
        for d in data["deltas"]:
            assert abs(d["delta_abs"]) < 1.0, f"Baseline delta non-zero for {d['kpi']}"

    def test_price_change_out_of_range(self, client):
        r = client.post("/api/scenario/run", json={
            "price_change": 2.0,  # > 0.5 → 422
            "group_by": ["Страна"],
        })
        assert r.status_code == 422

    def test_filter_by_country(self, client):
        r = client.post("/api/scenario/run", json={
            "name": "de", "filters": {"country": "Германия"},
            "group_by": ["Год"]
        })
        assert r.status_code == 200


class TestScenarioCompare:
    def test_status_200(self, client, compare_payload):
        r = client.post("/api/scenario/compare", json=compare_payload)
        assert r.status_code == 200

    def test_response_structure(self, client, compare_payload):
        data = client.post("/api/scenario/compare", json=compare_payload).json()
        assert "scenarios"      in data
        assert "kpis"           in data
        assert "comparison"     in data
        assert "best_scenario"  in data
        assert "worst_scenario" in data

    def test_all_scenarios_present(self, client, compare_payload):
        data   = client.post("/api/scenario/compare", json=compare_payload).json()
        names  = {r["scenario"] for r in data["comparison"]}
        expected = {s["name"] for s in compare_payload["scenarios"]}
        assert names == expected

    def test_best_worst_are_valid_scenarios(self, client, compare_payload):
        data = client.post("/api/scenario/compare", json=compare_payload).json()
        valid = {s["name"] for s in compare_payload["scenarios"]}
        assert data["best_scenario"]  in valid
        assert data["worst_scenario"] in valid

    def test_optimistic_better_than_stress(self, client, compare_payload):
        data = client.post("/api/scenario/compare", json=compare_payload).json()
        rev_key = "Выручка нетто (EUR)"
        by_name = {r["scenario"]: r for r in data["comparison"]}
        opt    = by_name.get("Оптим.", {}).get(rev_key)
        stress = by_name.get("Стресс", {}).get(rev_key)
        if opt is not None and stress is not None:
            assert opt > stress

    def test_single_scenario_rejected(self, client):
        r = client.post("/api/scenario/compare", json={
            "scenarios": [{"name": "only_one"}],
            "group_by": ["Страна"],
        })
        assert r.status_code == 422

    def test_too_many_scenarios_rejected(self, client):
        r = client.post("/api/scenario/compare", json={
            "scenarios": [{"name": f"s{i}"} for i in range(11)],
            "group_by": ["Страна"],
        })
        assert r.status_code == 422


class TestSensitivity:
    def test_status_200(self, client, sensitivity_payload):
        r = client.post("/api/scenario/sensitivity", json=sensitivity_payload)
        assert r.status_code == 200

    def test_response_structure(self, client, sensitivity_payload):
        data = client.post("/api/scenario/sensitivity", json=sensitivity_payload).json()
        assert "param_name"  in data
        assert "target_kpi"  in data
        assert "rows"        in data
        assert "elasticity"  in data

    def test_row_count_matches_values(self, client, sensitivity_payload):
        data = client.post("/api/scenario/sensitivity", json=sensitivity_payload).json()
        assert len(data["rows"]) == len(sensitivity_payload["values"])

    def test_rows_structure(self, client, sensitivity_payload):
        data = client.post("/api/scenario/sensitivity", json=sensitivity_payload).json()
        for row in data["rows"]:
            assert "param_value" in row
            assert "kpi_value"   in row
            assert "delta"       in row
            assert "delta_pct"   in row

    def test_monotonic_kpi_with_price(self, client, sensitivity_payload):
        data   = client.post("/api/scenario/sensitivity", json=sensitivity_payload).json()
        values = [r["kpi_value"] for r in data["rows"] if r["kpi_value"] is not None]
        # Цена растёт → EBITDA растёт (монотонно)
        for i in range(1, len(values)):
            assert values[i] >= values[i-1] - 1.0

    def test_elasticity_is_numeric(self, client, sensitivity_payload):
        data = client.post("/api/scenario/sensitivity", json=sensitivity_payload).json()
        assert isinstance(data["elasticity"], float)
