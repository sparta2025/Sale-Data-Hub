# Path: kpi_service/tests/conftest.py
"""
Pytest конфигурация для тестов KPI Engine.

Все тесты работают без реальных DuckDB/Excel файлов —
используется MockAdapter через dependency override.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx import ASGITransport, AsyncClient

# Добавляем корень проекта в sys.path
ROOT = Path(__file__).parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Устанавливаем переменные окружения ДО импорта app
import os
os.environ.setdefault("DUCKDB_PATH", "")       # пустой → MockAdapter
os.environ.setdefault("EXCEL_PATH", "")        # пустой → MockAdapter
os.environ.setdefault("CACHE_TTL", "60")
os.environ.setdefault("LOG_LEVEL", "WARNING")


@pytest.fixture(scope="session")
def app():
    """Создать FastAPI приложение один раз для всей сессии."""
    from kpi_service.adapters.mock import MockAdapter
    from kpi_service.cache import init_cache
    from kpi_service.deps import get_adapter, get_cache, reset_adapter
    from kpi_service.main import app as _app

    # Инициализируем кэш
    cache = init_cache(default_ttl=60, max_size=100)

    # Сбрасываем глобальный адаптер и форсируем MockAdapter
    reset_adapter()
    mock = MockAdapter(n=300, seed=0)

    _app.dependency_overrides[get_adapter] = lambda: mock
    _app.dependency_overrides[get_cache]   = lambda: cache

    yield _app

    _app.dependency_overrides.clear()


@pytest.fixture(scope="session")
def client(app):
    """Синхронный TestClient для простых тестов."""
    with TestClient(app, raise_server_exceptions=True) as c:
        yield c


@pytest.fixture
async def async_client(app):
    """Асинхронный клиент для async тестов."""
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as ac:
        yield ac


# ─── Общие тест-данные ────────────────────────────────────────────────────────

@pytest.fixture
def kpi_summary_payload():
    return {
        "group_by": ["Страна", "Год"],
        "filters":  {}
    }


@pytest.fixture
def scenario_payload():
    return {
        "name":           "Тест цена+5%",
        "price_change":   0.05,
        "volume_change":  -0.03,
        "cogs_change":    0.0,
        "group_by":       ["Страна"],
        "filters":        {}
    }


@pytest.fixture
def compare_payload():
    return {
        "scenarios": [
            {"name": "Базовый", "price_change": 0.0},
            {"name": "Оптим.",  "price_change": 0.05,  "volume_change":  0.03},
            {"name": "Стресс",  "price_change": -0.15, "volume_change": -0.10},
        ],
        "kpis":     ["Выручка нетто (EUR)", "Валовая прибыль (EUR)", "EBITDA (EUR)"],
        "group_by": ["Страна"],
    }


@pytest.fixture
def sensitivity_payload():
    return {
        "base_scenario": {"name": "base", "price_change": 0.0},
        "param_name":    "price_change",
        "values":        [-0.10, -0.05, 0.0, 0.05, 0.10],
        "target_kpi":    "EBITDA (EUR)",
        "group_by":      ["Страна"],
    }


@pytest.fixture
def forecast_payload():
    return {
        "horizon":   6,
        "method":    "trend_seasonal",
        "group_col": "Страна",
        "macro_adj": 1.0,
        "filters":   {}
    }


@pytest.fixture
def bcg_payload():
    return {}


@pytest.fixture
def eva_payload():
    return {
        "group_by": ["Страна", "Год"],
        "filters":  {}
    }
