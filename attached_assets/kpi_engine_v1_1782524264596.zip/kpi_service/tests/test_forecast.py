# Path: kpi_service/tests/test_forecast.py
"""Тесты: /api/forecast/* — прогнозирование."""
import pytest
from datetime import datetime


class TestForecastRun:
    def test_status_200(self, client, forecast_payload):
        r = client.post("/api/forecast/run", json=forecast_payload)
        assert r.status_code == 200

    def test_response_structure(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        assert "method"       in data
        assert "horizon"      in data
        assert "history"      in data
        assert "forecast"     in data
        assert "seasonality"  in data

    def test_method_reflected(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        assert data["method"] == forecast_payload["method"]

    def test_horizon_reflected(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        assert data["horizon"] == forecast_payload["horizon"]

    def test_forecast_length_matches_horizon(self, client, forecast_payload):
        data    = client.post("/api/forecast/run", json=forecast_payload).json()
        horizon = forecast_payload["horizon"]
        n_groups = 3  # Германия, Польша, Франция
        # Количество прогнозных точек = horizon × n_groups
        assert len(data["forecast"]) == horizon * n_groups

    def test_history_not_empty(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        assert len(data["history"]) > 0

    def test_forecast_points_in_future(self, client, forecast_payload):
        data     = client.post("/api/forecast/run", json=forecast_payload).json()
        hist_max = max(p["date"] for p in data["history"])
        fc_min   = min(p["date"] for p in data["forecast"])
        assert fc_min > hist_max

    def test_forecast_values_positive(self, client, forecast_payload):
        data   = client.post("/api/forecast/run", json=forecast_payload).json()
        values = [p["value"] for p in data["forecast"] if p["value"] is not None]
        assert all(v >= 0 for v in values)

    def test_forecast_is_forecast_flag(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        for pt in data["forecast"]:
            assert pt["is_history"] is False

    def test_history_is_history_flag(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        for pt in data["history"]:
            assert pt["is_history"] is True

    def test_seasonality_12_months(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        assert len(data["seasonality"]) == 12
        for s in data["seasonality"]:
            assert "month" in s
            assert "index" in s
            assert 1 <= s["month"] <= 12

    def test_macro_adj_scales_forecast(self, client):
        base = client.post("/api/forecast/run", json={
            "horizon": 6, "method": "naive", "group_col": "Страна", "macro_adj": 1.0
        }).json()
        adj  = client.post("/api/forecast/run", json={
            "horizon": 6, "method": "naive", "group_col": "Страна", "macro_adj": 0.90
        }).json()
        base_total = sum(p["value"] for p in base["forecast"] if p["value"])
        adj_total  = sum(p["value"] for p in adj["forecast"]  if p["value"])
        if base_total > 0:
            ratio = adj_total / base_total
            assert abs(ratio - 0.90) < 0.05

    def test_method_naive(self, client):
        r = client.post("/api/forecast/run", json={
            "horizon": 3, "method": "naive", "group_col": "Страна"
        })
        assert r.status_code == 200

    def test_method_ma_seasonal(self, client):
        r = client.post("/api/forecast/run", json={
            "horizon": 3, "method": "ma_seasonal", "group_col": "Страна"
        })
        assert r.status_code == 200

    def test_invalid_method_rejected(self, client):
        r = client.post("/api/forecast/run", json={
            "horizon": 3, "method": "invalid_method"
        })
        assert r.status_code == 422

    def test_horizon_too_large_rejected(self, client):
        r = client.post("/api/forecast/run", json={"horizon": 100})
        assert r.status_code == 422

    def test_horizon_zero_rejected(self, client):
        r = client.post("/api/forecast/run", json={"horizon": 0})
        assert r.status_code == 422

    def test_no_group_col(self, client):
        r = client.post("/api/forecast/run", json={
            "horizon": 3, "method": "naive", "group_col": None
        })
        assert r.status_code == 200

    def test_forecast_date_format(self, client, forecast_payload):
        data = client.post("/api/forecast/run", json=forecast_payload).json()
        for pt in data["forecast"]:
            # Дата должна быть в формате YYYY-MM-DD
            datetime.strptime(pt["date"][:10], "%Y-%m-%d")

    def test_group_reflected_in_points(self, client, forecast_payload):
        data   = client.post("/api/forecast/run", json=forecast_payload).json()
        groups = {pt["group"] for pt in data["forecast"] if pt["group"]}
        assert len(groups) > 0
        assert "Германия" in groups or "Польша" in groups or "Франция" in groups


class TestCascadeForecast:
    def test_status_200(self, client):
        r = client.post("/api/forecast/cascade", json={
            "horizon": 3, "method": "naive",
            "hierarchy": ["Артикул", "Страна"]
        })
        assert r.status_code == 200

    def test_response_has_reconciled(self, client):
        data = client.post("/api/forecast/cascade", json={
            "horizon": 3, "method": "naive",
            "hierarchy": ["Артикул", "Страна"]
        }).json()
        assert "rows" in data
        assert "total_reconciled" in data
        if data["rows"]:
            assert "Выручка нетто (EUR)_reconciled" in data["rows"][0] or \
                   any("reconciled" in k for k in data["rows"][0].keys())

    def test_reconciled_positive(self, client):
        data = client.post("/api/forecast/cascade", json={
            "horizon": 3, "method": "naive",
            "hierarchy": ["Артикул"]
        }).json()
        assert data["total_reconciled"] > 0
