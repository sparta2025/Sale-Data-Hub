# Path: kpi_service/tests/test_health.py
"""Тесты: /health endpoint и базовая работоспособность сервиса."""
import pytest


class TestHealth:
    def test_health_ok(self, client):
        r = client.get("/health")
        assert r.status_code == 200

    def test_health_structure(self, client):
        data = client.get("/health").json()
        assert "status"         in data
        assert "duckdb"         in data
        assert "duckdb_rows"    in data
        assert "cache_entries"  in data
        assert "version"        in data
        assert "uptime_seconds" in data

    def test_health_status_ok_or_degraded(self, client):
        data = client.get("/health").json()
        assert data["status"] in ("ok", "degraded")

    def test_health_version_format(self, client):
        data = client.get("/health").json()
        parts = data["version"].split(".")
        assert len(parts) == 3

    def test_root_redirect(self, client):
        r = client.get("/")
        assert r.status_code == 200
        data = r.json()
        assert "service" in data
        assert data["service"] == "KPI Engine"

    def test_openapi_available(self, client):
        r = client.get("/openapi.json")
        assert r.status_code == 200
        schema = r.json()
        assert "paths" in schema
        assert "components" in schema

    def test_docs_available(self, client):
        r = client.get("/docs")
        assert r.status_code == 200

    def test_cors_header_present(self, client):
        r = client.get("/health", headers={"Origin": "http://localhost:5173"})
        assert r.status_code == 200
