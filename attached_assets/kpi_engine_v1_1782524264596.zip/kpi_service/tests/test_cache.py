# Path: kpi_service/tests/test_cache.py
"""Тесты: Cache — TTL, hits/misses, make_key."""
import asyncio
import pytest
from kpi_service.cache import Cache


@pytest.fixture
def cache():
    return Cache(default_ttl=1, max_size=5)


class TestCache:
    @pytest.mark.asyncio
    async def test_get_miss(self, cache):
        result = await cache.get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_set_get(self, cache):
        await cache.set("key1", {"value": 42})
        result = await cache.get("key1")
        assert result == {"value": 42}

    @pytest.mark.asyncio
    async def test_ttl_expiry(self, cache):
        await cache.set("expiring", "data", ttl=1)
        assert await cache.get("expiring") == "data"
        await asyncio.sleep(1.1)
        assert await cache.get("expiring") is None

    @pytest.mark.asyncio
    async def test_delete(self, cache):
        await cache.set("key2", "val")
        await cache.delete("key2")
        assert await cache.get("key2") is None

    @pytest.mark.asyncio
    async def test_clear(self, cache):
        await cache.set("a", 1)
        await cache.set("b", 2)
        await cache.clear()
        assert await cache.get("a") is None
        assert await cache.get("b") is None

    @pytest.mark.asyncio
    async def test_size(self, cache):
        await cache.set("x", 1)
        await cache.set("y", 2)
        size = await cache.size()
        assert size == 2

    @pytest.mark.asyncio
    async def test_max_size_eviction(self, cache):
        # max_size=5, добавим 6 ключей
        for i in range(6):
            await cache.set(f"key{i}", i)
        size = await cache.size()
        assert size <= 5

    @pytest.mark.asyncio
    async def test_stats(self, cache):
        await cache.set("s", "v")
        await cache.get("s")          # hit
        await cache.get("missing")    # miss
        stats = cache.stats
        assert stats["hits"]   >= 1
        assert stats["misses"] >= 1

    def test_make_key_deterministic(self):
        k1 = Cache.make_key("group", ["Страна", "Год"], {"year": 2023})
        k2 = Cache.make_key("group", ["Страна", "Год"], {"year": 2023})
        assert k1 == k2

    def test_make_key_different_inputs(self):
        k1 = Cache.make_key("a", [1, 2])
        k2 = Cache.make_key("a", [1, 3])
        assert k1 != k2

    def test_make_key_order_insensitive_dict(self):
        k1 = Cache.make_key({"b": 2, "a": 1})
        k2 = Cache.make_key({"a": 1, "b": 2})
        assert k1 == k2

    @pytest.mark.asyncio
    async def test_overwrite_existing(self, cache):
        await cache.set("ow", "old")
        await cache.set("ow", "new")
        assert await cache.get("ow") == "new"
