# Path: kpi_service/tests/test_portfolio.py
"""Тесты: /api/portfolio/* — BCG, EVA, Payback."""
import pytest


class TestBCG:
    def test_status_200(self, client, bcg_payload):
        r = client.post("/api/portfolio/bcg", json=bcg_payload)
        assert r.status_code == 200

    def test_response_structure(self, client, bcg_payload):
        data = client.post("/api/portfolio/bcg", json=bcg_payload).json()
        assert "current_year"     in data
        assert "prev_year"        in data
        assert "items"            in data
        assert "quadrant_counts"  in data
        assert "quadrant_rev"     in data

    def test_items_not_empty(self, client, bcg_payload):
        data = client.post("/api/portfolio/bcg", json=bcg_payload).json()
        assert len(data["items"]) > 0

    def test_item_structure(self, client, bcg_payload):
        data = client.post("/api/portfolio/bcg", json=bcg_payload).json()
        item = data["items"][0]
        assert "sku"           in item
        assert "category"      in item
        assert "rev_current"   in item
        assert "market_share"  in item
        assert "bcg_quadrant"  in item

    def test_all_four_quadrants_present(self, client, bcg_payload):
        data      = client.post("/api/portfolio/bcg", json=bcg_payload).json()
        quadrants = {item["bcg_quadrant"] for item in data["items"]}
        assert quadrants == {"Star", "Cash Cow", "Question Mark", "Dog"}

    def test_market_share_per_category_sums_to_100(self, client, bcg_payload):
        from collections import defaultdict
        data = client.post("/api/portfolio/bcg", json=bcg_payload).json()
        cat_sums = defaultdict(float)
        for item in data["items"]:
            cat_sums[item["category"]] += item["market_share"]
        for cat, total in cat_sums.items():
            assert abs(total - 100.0) < 0.5, f"Сумма долей {cat} = {total:.2f}"

    def test_quadrant_counts_match_items(self, client, bcg_payload):
        data    = client.post("/api/portfolio/bcg", json=bcg_payload).json()
        from collections import Counter
        counts  = Counter(item["bcg_quadrant"] for item in data["items"])
        for q, cnt in data["quadrant_counts"].items():
            assert counts.get(q, 0) == cnt

    def test_current_year_in_data(self, client, bcg_payload):
        data = client.post("/api/portfolio/bcg", json=bcg_payload).json()
        assert isinstance(data["current_year"], int)
        assert 2010 < data["current_year"] <= 2030

    def test_filter_by_category(self, client):
        r = client.post("/api/portfolio/bcg", json={"category": "Электроника"})
        assert r.status_code == 200

    def test_explicit_year(self, client):
        r = client.post("/api/portfolio/bcg", json={"current_year": 2024, "prev_year": 2023})
        assert r.status_code == 200


class TestEVA:
    def test_status_200(self, client, eva_payload):
        r = client.post("/api/portfolio/eva", json=eva_payload)
        assert r.status_code == 200

    def test_response_structure(self, client, eva_payload):
        data = client.post("/api/portfolio/eva", json=eva_payload).json()
        assert "group_by"         in data
        assert "rows"             in data
        assert "total_eva"        in data
        assert "total_nopat"      in data
        assert "value_creators"   in data
        assert "value_destroyers" in data

    def test_rows_not_empty(self, client, eva_payload):
        data = client.post("/api/portfolio/eva", json=eva_payload).json()
        assert len(data["rows"]) > 0

    def test_row_structure(self, client, eva_payload):
        data = client.post("/api/portfolio/eva", json=eva_payload).json()
        row  = data["rows"][0]
        assert "dimensions"   in row
        assert "ebit"         in row
        assert "ic"           in row
        assert "nopat"        in row
        assert "eva"          in row
        assert "eva_positive" in row

    def test_nopat_less_than_ebit(self, client, eva_payload):
        data = client.post("/api/portfolio/eva", json=eva_payload).json()
        for row in data["rows"]:
            if row["ebit"] > 0:
                assert row["nopat"] <= row["ebit"] + 0.01

    def test_creators_plus_destroyers_equals_total(self, client, eva_payload):
        data = client.post("/api/portfolio/eva", json=eva_payload).json()
        assert data["value_creators"] + data["value_destroyers"] == len(data["rows"])

    def test_eva_positive_flag_matches_value(self, client, eva_payload):
        data = client.post("/api/portfolio/eva", json=eva_payload).json()
        for row in data["rows"]:
            if row["eva"] > 0:
                assert row["eva_positive"] is True
            else:
                assert row["eva_positive"] is False

    def test_group_by_country_only(self, client):
        r = client.post("/api/portfolio/eva", json={
            "group_by": ["Страна"], "filters": {}
        })
        assert r.status_code == 200
        data = r.json()
        assert len(data["rows"]) <= 3


class TestPayback:
    def test_status_200(self, client):
        r = client.get("/api/portfolio/payback")
        assert r.status_code == 200

    def test_response_structure(self, client):
        data = client.get("/api/portfolio/payback").json()
        assert "rows"          in data
        assert "avg_payback"   in data
        assert "under_3_years" in data
        assert "over_5_years"  in data

    def test_rows_not_empty(self, client):
        data = client.get("/api/portfolio/payback").json()
        assert len(data["rows"]) > 0

    def test_row_structure(self, client):
        data = client.get("/api/portfolio/payback").json()
        row  = data["rows"][0]
        assert "sku"           in row
        assert "gp_annual"     in row
        assert "ic"            in row
        assert "payback_years" in row

    def test_payback_positive_or_null(self, client):
        data = client.get("/api/portfolio/payback").json()
        for row in data["rows"]:
            pb = row["payback_years"]
            assert pb is None or pb > 0

    def test_avg_payback_positive(self, client):
        data = client.get("/api/portfolio/payback").json()
        assert data["avg_payback"] > 0

    def test_counters_consistent(self, client):
        data  = client.get("/api/portfolio/payback").json()
        valid = [r["payback_years"] for r in data["rows"] if r["payback_years"] is not None]
        u3 = sum(1 for v in valid if v < 3)
        o5 = sum(1 for v in valid if v > 5)
        assert data["under_3_years"] == u3
        assert data["over_5_years"]  == o5
