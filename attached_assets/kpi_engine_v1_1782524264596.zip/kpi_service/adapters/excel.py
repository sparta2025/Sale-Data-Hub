# VERSION: 1.0.0
# Path: kpi_service/adapters/excel.py
"""
Excel адаптер для KPI Engine.
Fallback для dev/test среды без DuckDB.
Читает файл один раз и кэширует DataFrame в памяти.
"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, Optional

import pandas as pd

from .base import BaseDataAdapter, DataAdapterError

logger = logging.getLogger(__name__)


class ExcelAdapter(BaseDataAdapter):
    """
    Адаптер для чтения данных из Excel-файла.
    Первая загрузка — синхронная (блокирующая), последующие — из памяти.

    Parameters
    ----------
    file_path : str
        Путь к .xlsx файлу.
    sheet_name : str
        Имя листа с данными.
    """

    def __init__(
        self,
        file_path: str,
        sheet_name: str = "01_Данные_KPI",
    ) -> None:
        self._file_path  = Path(file_path)
        self._sheet_name = sheet_name
        self._df: Optional[pd.DataFrame] = None
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    async def load_transactions(self, filters: dict[str, Any]) -> pd.DataFrame:
        df = await self._get_df()
        return self._apply_filters(df, filters)

    async def health(self) -> dict[str, Any]:
        if not self._file_path.exists():
            return {"status": "error", "error": f"File not found: {self._file_path}"}
        try:
            df = await self._get_df()
            return {
                "status":    "ok",
                "file_path": str(self._file_path),
                "sheet":     self._sheet_name,
                "row_count": len(df),
                "columns":   list(df.columns[:10]),
            }
        except Exception as exc:
            return {"status": "error", "error": str(exc)}

    async def row_count(self) -> int:
        df = await self._get_df()
        return len(df)

    def name(self) -> str:
        return "excel"

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _get_df(self) -> pd.DataFrame:
        """Lazy-load: читаем файл один раз, потом из памяти."""
        if self._df is not None:
            return self._df
        async with self._lock:
            if self._df is not None:
                return self._df
            if not self._file_path.exists():
                raise DataAdapterError(f"Excel file not found: {self._file_path}")
            logger.info("ExcelAdapter: loading %s [%s]…", self._file_path, self._sheet_name)
            # Читаем в executor чтобы не блокировать event loop
            loop = asyncio.get_event_loop()
            self._df = await loop.run_in_executor(
                None,
                lambda: pd.read_excel(str(self._file_path), sheet_name=self._sheet_name)
            )
            logger.info("ExcelAdapter: loaded %d rows, %d cols", len(self._df), len(self._df.columns))
            return self._df

    @staticmethod
    def _apply_filters(df: pd.DataFrame, filters: dict[str, Any]) -> pd.DataFrame:
        """Pandas фильтрация по словарю {колонка: значение}."""
        result = df
        for col, value in filters.items():
            if col not in result.columns:
                logger.warning("ExcelAdapter: column '%s' not found, skip filter", col)
                continue
            if isinstance(value, list):
                result = result[result[col].isin(value)]
            elif value is not None:
                result = result[result[col] == value]
        return result.reset_index(drop=True)
