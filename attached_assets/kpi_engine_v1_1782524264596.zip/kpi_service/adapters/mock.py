# VERSION: 1.0.0
# Path: kpi_service/adapters/mock.py
"""Mock адаптер для тестов и dev без реального источника данных."""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from sales_kpi import COL
from .base import BaseDataAdapter


class MockAdapter(BaseDataAdapter):
    """Генерирует синтетические данные для тестирования."""

    def __init__(self, n: int = 500, seed: int = 42) -> None:
        self._n    = n
        self._seed = seed

    async def load_transactions(self, filters: dict[str, Any]) -> pd.DataFrame:
        rng = np.random.default_rng(self._seed)
        n = self._n
        df = pd.DataFrame({
            COL["country"]:  rng.choice(["Германия", "Польша", "Франция"], n),
            COL["branch"]:   rng.choice(["Берлин", "Варшава", "Париж"], n),
            COL["year"]:     rng.choice(range(2020, 2026), n),
            COL["month"]:    rng.choice(range(1, 13), n),
            COL["category"]: rng.choice(["Электроника", "Одежда", "Косметика"], n),
            COL["sku"]:      [f"SKU-{i:03d}" for i in rng.integers(1, 30, n)],
            COL["qty"]:      rng.integers(1, 100, n).astype(float),
            COL["price"]:    rng.uniform(50, 500, n),
            COL["cost"]:     rng.uniform(30, 350, n),
            COL["rev_net"]:  rng.uniform(5000, 80000, n),
            COL["cogs"]:     rng.uniform(3000, 55000, n),
            COL["gp"]:       rng.uniform(1000, 25000, n),
            COL["ebit"]:     rng.uniform(500, 15000, n),
            COL["ebitda"]:   rng.uniform(800, 18000, n),
            COL["mc"]:       rng.uniform(1000, 22000, n),
            COL["marketing"]:rng.uniform(100, 3000, n),
            COL["capex"]:    rng.uniform(50, 1500, n),
            COL["overhead"]: rng.uniform(200, 5000, n),
            COL["ic"]:       rng.uniform(2000, 40000, n),
            COL["inventory"]:rng.uniform(1000, 20000, n),
            COL["provision"]:rng.uniform(10, 1000, n),
        })
        # Применяем фильтры
        for col, val in filters.items():
            if col in df.columns and val is not None:
                df = df[df[col] == val]
        return df.reset_index(drop=True)

    async def health(self) -> dict[str, Any]:
        return {"status": "ok", "source": "mock", "row_count": self._n}

    async def row_count(self) -> int:
        return self._n

    def name(self) -> str:
        return "mock"
