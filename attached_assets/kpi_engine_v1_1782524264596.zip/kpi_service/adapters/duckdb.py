# VERSION: 1.0.0
# Path: kpi_service/adapters/duckdb.py
"""
DuckDB адаптер для KPI Engine.

Подключается к shared DuckDB файлу (read-only) из sales-bi-platform.
Путь задаётся через DUCKDB_PATH в .env.

Особенности:
  - Shared volume с bi-platform: kpi-engine монтирует файл read-only
  - Каждый вызов открывает соединение и закрывает его (thread-safe для async)
  - SQL-фильтрация на уровне DuckDB — не грузим весь датасет в память
  - Fallback: если DuckDB недоступен — кидает DataAdapterError
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any

import pandas as pd

from .base import BaseDataAdapter, DataAdapterError

logger = logging.getLogger(__name__)


class DuckDBAdapter(BaseDataAdapter):
    """
    Адаптер для чтения данных из DuckDB (sales-bi-platform датасет).

    Parameters
    ----------
    db_path : str
        Путь к .duckdb файлу. Из переменной окружения DUCKDB_PATH.
    table_name : str
        Имя таблицы с транзакциями. По умолчанию "sales_transactions".
    read_only : bool
        True = read-only режим (для shared доступа с bi-platform).
    """

    # Маппинг русских имён колонок → имена в DuckDB таблице
    # Если в DuckDB таблица имеет русские имена — маппинг идентичный
    COLUMN_MAPPING: dict[str, str] = {
        "Страна":            "country",
        "Филиал":            "branch",
        "Год":               "year",
        "Месяц":             "month",
        "Товарная группа":   "category",
        "Артикул":           "sku",
    }

    def __init__(
        self,
        db_path: str,
        table_name: str = "sales_transactions",
        read_only:  bool = True,
    ) -> None:
        self._db_path   = db_path
        self._table     = table_name
        self._read_only = read_only
        self._col_map   = self.COLUMN_MAPPING

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    async def load_transactions(self, filters: dict[str, Any]) -> pd.DataFrame:
        """
        Загрузить транзакции из DuckDB с SQL-фильтрацией.
        Возвращает pd.DataFrame с оригинальными именами колонок.
        """
        try:
            import duckdb
        except ImportError:
            raise DataAdapterError(
                "duckdb не установлен. pip install duckdb"
            )

        where_clauses, params = self._build_where(filters)
        where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        sql = f"SELECT * FROM {self._table} {where_sql}"
        logger.debug("DuckDB query: %s | params: %s", sql, params)

        try:
            con = duckdb.connect(self._db_path, read_only=self._read_only)
            df  = con.execute(sql, params).df()
            con.close()
        except Exception as exc:
            raise DataAdapterError(f"DuckDB query failed: {exc}") from exc

        # Переименовываем колонки обратно в русские если нужно
        reverse_map = {v: k for k, v in self._col_map.items()}
        df = df.rename(columns=reverse_map)

        logger.info("DuckDB: loaded %d rows (filters=%s)", len(df), filters)
        return df

    async def health(self) -> dict[str, Any]:
        try:
            import duckdb
            con    = duckdb.connect(self._db_path, read_only=self._read_only)
            count  = con.execute(f"SELECT COUNT(*) FROM {self._table}").fetchone()[0]
            tables = [r[0] for r in con.execute("SHOW TABLES").fetchall()]
            con.close()
            return {
                "status":     "ok",
                "db_path":    self._db_path,
                "table":      self._table,
                "row_count":  count,
                "tables":     tables,
            }
        except Exception as exc:
            return {"status": "error", "error": str(exc), "db_path": self._db_path}

    async def row_count(self) -> int:
        try:
            import duckdb
            con   = duckdb.connect(self._db_path, read_only=self._read_only)
            count = con.execute(f"SELECT COUNT(*) FROM {self._table}").fetchone()[0]
            con.close()
            return int(count)
        except Exception:
            return 0

    def name(self) -> str:
        return "duckdb"

    # ------------------------------------------------------------------
    # SQL helpers
    # ------------------------------------------------------------------

    def _build_where(
        self, filters: dict[str, Any]
    ) -> tuple[list[str], list[Any]]:
        """Построить WHERE-условия из словаря фильтров."""
        clauses: list[str] = []
        params:  list[Any] = []

        for ru_col, value in filters.items():
            db_col = self._col_map.get(ru_col, ru_col)  # fallback = как есть
            if isinstance(value, list):
                placeholders = ", ".join(["?" for _ in value])
                clauses.append(f"{db_col} IN ({placeholders})")
                params.extend(value)
            elif value is not None:
                clauses.append(f"{db_col} = ?")
                params.append(value)

        return clauses, params
