# VERSION: 1.0.0
# Path: kpi_service/adapters/base.py
"""
Абстрактный адаптер источника данных.
Позволяет переключаться между DuckDB, Excel и mock без изменения бизнес-логики.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd


class DataAdapterError(Exception):
    """Ошибка адаптера данных."""


class BaseDataAdapter(ABC):
    """Интерфейс для всех адаптеров данных KPI Engine."""

    @abstractmethod
    async def load_transactions(self, filters: dict[str, Any]) -> pd.DataFrame:
        """
        Загрузить транзакции с применением фильтров.

        Parameters
        ----------
        filters : dict
            Словарь {имя_колонки: значение} для фильтрации.
            Пустой dict = все данные.

        Returns
        -------
        pd.DataFrame
            Датафрейм транзакций с колонками из исходного датасета.
        """

    @abstractmethod
    async def health(self) -> dict[str, Any]:
        """Вернуть статус подключения и метрики источника."""

    @abstractmethod
    async def row_count(self) -> int:
        """Вернуть общее количество строк в источнике."""

    def name(self) -> str:
        return self.__class__.__name__.replace("Adapter", "").lower()
