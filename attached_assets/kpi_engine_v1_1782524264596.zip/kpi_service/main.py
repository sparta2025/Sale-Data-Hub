# VERSION: 1.0.0
# Path: kpi_service/main.py
"""
KPI Engine — FastAPI приложение.

Запуск:
    uvicorn kpi_service.main:app --host 0.0.0.0 --port 8100 --reload

Переменные окружения (.env):
    DUCKDB_PATH   = /data/duckdb/analytics.duckdb   # путь к shared DuckDB
    EXCEL_PATH    = /data/demo/sales_analytics_2015_2026.xlsx  # fallback
    EXCEL_SHEET   = 01_Данные_KPI
    DUCKDB_TABLE  = sales_transactions
    CACHE_TTL     = 300
    CACHE_MAX     = 1000
    LOG_LEVEL     = INFO
    CORS_ORIGINS  = http://localhost:5173,http://localhost:8000
"""
from __future__ import annotations

import logging
import os
import time
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

load_dotenv()

# ─── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, os.getenv("LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ─── Startup / Shutdown ──────────────────────────────────────────────────────
_start_time = time.monotonic()


@asynccontextmanager
async def lifespan(app: FastAPI):
    from .cache import init_cache
    from .deps import get_adapter

    ttl = int(os.getenv("CACHE_TTL", "300"))
    max_size = int(os.getenv("CACHE_MAX", "1000"))
    init_cache(default_ttl=ttl, max_size=max_size)
    logger.info("Cache initialised: TTL=%ds, max=%d", ttl, max_size)

    adapter = get_adapter()
    health  = await adapter.health()
    logger.info("Data adapter: %s | health: %s", adapter.name(), health.get("status"))

    yield

    logger.info("KPI Engine shutting down.")


# ─── App ─────────────────────────────────────────────────────────────────────
app = FastAPI(
    title       = "KPI Engine",
    description = (
        "REST API для расчёта бизнес-KPI, сценарного анализа, прогнозирования "
        "и портфельного анализа (BCG, EVA, Payback).\n\n"
        "Часть Tools-Board: интегрируется с sales-bi-platform и MultiAgents."
    ),
    version     = "1.0.0",
    lifespan    = lifespan,
    docs_url    = "/docs",
    redoc_url   = "/redoc",
    openapi_url = "/openapi.json",
)

# ─── CORS ────────────────────────────────────────────────────────────────────
_origins_raw = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:8000")
origins = [o.strip() for o in _origins_raw.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins     = origins,
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ─── Routers ─────────────────────────────────────────────────────────────────
from .routers import forecast, kpi, portfolio, scenario  # noqa: E402

app.include_router(kpi.router,       prefix="/api")
app.include_router(scenario.router,  prefix="/api")
app.include_router(forecast.router,  prefix="/api")
app.include_router(portfolio.router, prefix="/api")


# ─── Health ──────────────────────────────────────────────────────────────────
@app.get("/health", tags=["System"], summary="Статус сервиса")
async def health():
    from .cache import get_cache
    from .deps import get_adapter
    from .schemas import HealthResponse

    adapter      = get_adapter()
    adapter_info = await adapter.health()
    cache        = get_cache()
    cache_stats  = cache.stats

    return HealthResponse(
        status         = "ok" if adapter_info.get("status") == "ok" else "degraded",
        duckdb         = adapter_info.get("status", "unknown"),
        duckdb_rows    = adapter_info.get("row_count", 0),
        cache_entries  = cache_stats.get("size", 0),
        version        = "1.0.0",
        uptime_seconds = round(time.monotonic() - _start_time, 1),
    )


@app.get("/", tags=["System"], include_in_schema=False)
async def root():
    return JSONResponse({"service": "KPI Engine", "docs": "/docs", "health": "/health"})
