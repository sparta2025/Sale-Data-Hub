# VERSION: 1.0.0
# Path: kpi_service/deps.py
"""
FastAPI Depends — dependency injection для адаптера и кэша.
Выбор адаптера: DuckDB (если DUCKDB_PATH задан и файл существует) → Excel → Mock.
"""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Annotated

from fastapi import Depends

from .adapters.base import BaseDataAdapter
from .cache import Cache, get_cache as _get_cache

logger = logging.getLogger(__name__)

_adapter_instance: BaseDataAdapter | None = None


def _build_adapter() -> BaseDataAdapter:
    """Создать адаптер на основе переменных окружения."""
    duckdb_path = os.getenv("DUCKDB_PATH", "")
    excel_path  = os.getenv("EXCEL_PATH", "")

    # Приоритет: DuckDB → Excel → Mock
    if duckdb_path and Path(duckdb_path).exists():
        try:
            from .adapters.duckdb import DuckDBAdapter
            table = os.getenv("DUCKDB_TABLE", "sales_transactions")
            adapter = DuckDBAdapter(db_path=duckdb_path, table_name=table, read_only=True)
            logger.info("Using DuckDB adapter: %s / %s", duckdb_path, table)
            return adapter
        except ImportError:
            logger.warning("duckdb not installed, trying Excel fallback")

    if excel_path and Path(excel_path).exists():
        from .adapters.excel import ExcelAdapter
        sheet = os.getenv("EXCEL_SHEET", "01_Данные_KPI")
        adapter = ExcelAdapter(file_path=excel_path, sheet_name=sheet)
        logger.info("Using Excel adapter: %s / %s", excel_path, sheet)
        return adapter

    # Mock адаптер для тестов
    logger.warning("No data source configured. Using mock adapter (empty data).")
    from .adapters.mock import MockAdapter
    return MockAdapter()


def get_adapter() -> BaseDataAdapter:
    global _adapter_instance
    if _adapter_instance is None:
        _adapter_instance = _build_adapter()
    return _adapter_instance


def reset_adapter() -> None:
    """Сбросить кэшированный адаптер (для тестов)."""
    global _adapter_instance
    _adapter_instance = None


def get_cache() -> Cache:
    return _get_cache()
