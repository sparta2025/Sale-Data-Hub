# VERSION: 1.0.0
# Path: kpi_service/schemas.py
"""
Pydantic-схемы для KPI Engine REST API.

Все схемы экспортируются в OpenAPI /docs автоматически.
Служат контрактом для bi-platform и MultiAgents.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


# ─────────────────────────────────────────────────────────────────────────────
# Enums
# ─────────────────────────────────────────────────────────────────────────────

class ForecastMethod(str, Enum):
    naive           = "naive"
    trend_seasonal  = "trend_seasonal"
    ma_seasonal     = "ma_seasonal"
    prophet         = "prophet"


class BCGQuadrant(str, Enum):
    star            = "Star"
    cash_cow        = "Cash Cow"
    question_mark   = "Question Mark"
    dog             = "Dog"


# ─────────────────────────────────────────────────────────────────────────────
# Shared
# ─────────────────────────────────────────────────────────────────────────────

class FilterDict(BaseModel):
    """Фильтры по измерениям датасета."""
    country:  Optional[str]       = Field(None, alias="Страна",          description="Фильтр по стране")
    branch:   Optional[str]       = Field(None, alias="Филиал",          description="Фильтр по филиалу")
    year:     Optional[int]       = Field(None, alias="Год",             description="Фильтр по году")
    month:    Optional[int]       = Field(None, alias="Месяц",           description="Фильтр по месяцу (1–12)")
    category: Optional[str]       = Field(None, alias="Товарная группа", description="Фильтр по категории")
    sku:      Optional[str]       = Field(None, alias="Артикул",         description="Фильтр по артикулу")

    model_config = {"populate_by_name": True}

    def to_dict(self) -> dict[str, Any]:
        """Вернуть непустые фильтры с русскими именами полей."""
        mapping = {
            "country":  "Страна",
            "branch":   "Филиал",
            "year":     "Год",
            "month":    "Месяц",
            "category": "Товарная группа",
            "sku":      "Артикул",
        }
        return {
            mapping[k]: v
            for k, v in self.model_dump().items()
            if v is not None and k in mapping
        }


# ─────────────────────────────────────────────────────────────────────────────
# KPI Summary
# ─────────────────────────────────────────────────────────────────────────────

class KPISummaryRequest(BaseModel):
    group_by: list[str] = Field(
        default=["Страна", "Год"],
        description="Список измерений для группировки (русские названия колонок)",
        examples=[["Страна", "Год"], ["Товарная группа", "Год"], ["Филиал"]],
        min_length=1,
    )
    filters: FilterDict = Field(
        default_factory=FilterDict,
        description="Необязательные фильтры по измерениям",
    )
    include_embeddings: bool = Field(
        default=False,
        description="Включить embedding-модели (только для model manager)",
    )


class KPIRow(BaseModel):
    """Одна строка агрегированного KPI-ответа."""
    dimensions: dict[str, Any] = Field(description="Значения измерений группировки")
    metrics:    dict[str, Any] = Field(description="Значения KPI-метрик")


class KPISummaryResponse(BaseModel):
    group_by:   list[str]   = Field(description="Использованная группировка")
    rows:       list[KPIRow]
    total:      dict[str, Any] = Field(description="Итоговые значения по всем строкам")
    row_count:  int
    cached:     bool        = False
    source:     str         = Field(description="duckdb | excel | mock")


# ─────────────────────────────────────────────────────────────────────────────
# Scenario
# ─────────────────────────────────────────────────────────────────────────────

class ScenarioRequest(BaseModel):
    name:               str   = Field(default="Сценарий", description="Название сценария")
    price_change:       float = Field(default=0.0, ge=-0.5, le=0.5,  description="Изменение цены, доля: 0.05 = +5%")
    volume_change:      float = Field(default=0.0, ge=-0.5, le=0.5,  description="Изменение объёма")
    cogs_change:        float = Field(default=0.0, ge=-0.5, le=0.5,  description="Изменение COGS")
    marketing_change:   float = Field(default=0.0, ge=-1.0, le=2.0,  description="Изменение маркетинга")
    overhead_change:    float = Field(default=0.0, ge=-0.5, le=0.5,  description="Изменение накладных")
    dso_change_days:    float = Field(default=0.0, ge=-60,  le=60,   description="Изменение DSO в днях")
    new_sku_rev:        float = Field(default=0.0, ge=0,              description="Доп. выручка от новых SKU, EUR")
    wacc_delta:         float = Field(default=0.0, ge=-0.05, le=0.05, description="Сдвиг WACC, п.п.")
    filters:            FilterDict = Field(default_factory=FilterDict)
    group_by:           list[str] = Field(default=["Страна"])


class ScenarioCompareRequest(BaseModel):
    scenarios: list[ScenarioRequest] = Field(
        description="Список сценариев для сравнения. Первый считается базовым.",
        min_length=2,
        max_length=10,
    )
    kpis: list[str] = Field(
        default=["Выручка нетто (EUR)", "Валовая прибыль (EUR)", "EBITDA (EUR)", "Операционная прибыль (EUR)"],
        description="KPI для сравнения",
    )
    group_by: list[str] = Field(default=["Страна"])


class SensitivityRequest(BaseModel):
    base_scenario:  ScenarioRequest
    param_name:     str   = Field(description="Параметр для вариации: price_change, volume_change, …")
    values:         list[float] = Field(description="Список значений параметра")
    target_kpi:     str   = Field(default="EBITDA (EUR)", description="KPI для анализа")
    group_by:       list[str] = Field(default=["Страна"])


class ScenarioDelta(BaseModel):
    kpi:            str
    base_value:     float
    scenario_value: float
    delta_abs:      float
    delta_pct:      float


class ScenarioRunResponse(BaseModel):
    scenario_name:  str
    group_by:       list[str]
    base:           dict[str, Any]
    result:         dict[str, Any]
    deltas:         list[ScenarioDelta]


class ScenarioCompareResponse(BaseModel):
    scenarios:      list[str]
    kpis:           list[str]
    comparison:     list[dict[str, Any]]   # строки = сценарии
    best_scenario:  str                    # по первому KPI
    worst_scenario: str


class SensitivityResponse(BaseModel):
    param_name:     str
    target_kpi:     str
    rows:           list[dict[str, Any]]   # [{param_value, kpi_value, delta, delta_pct}]
    elasticity:     float                  # Δ% KPI / Δ% param (средняя)


# ─────────────────────────────────────────────────────────────────────────────
# Forecast
# ─────────────────────────────────────────────────────────────────────────────

class ForecastRequest(BaseModel):
    horizon:    int             = Field(default=12, ge=1, le=36,  description="Горизонт прогноза в месяцах")
    method:     ForecastMethod  = Field(default=ForecastMethod.trend_seasonal)
    group_col:  Optional[str]   = Field(default="Страна", description="Колонка группировки (одна)")
    macro_adj:  float           = Field(default=1.0, ge=0.5, le=1.5, description="Макрокорректировка: 0.97 = −3% ВВП-прокси")
    filters:    FilterDict      = Field(default_factory=FilterDict)


class CascadeForecastRequest(BaseModel):
    horizon:    int             = Field(default=12, ge=1, le=36)
    method:     ForecastMethod  = Field(default=ForecastMethod.trend_seasonal)
    hierarchy:  list[str]       = Field(
        default=["Артикул", "Товарная группа", "Филиал", "Страна"],
        description="Иерархия от нижнего к верхнему уровню",
    )
    macro_adj:  float           = Field(default=1.0, ge=0.5, le=1.5)


class ForecastPoint(BaseModel):
    date:       str
    year:       int
    month:      int
    value:      float
    group:      Optional[str]   = None
    is_history: bool            = False
    lower_ci:   Optional[float] = None
    upper_ci:   Optional[float] = None


class ForecastResponse(BaseModel):
    method:         str
    horizon:        int
    group_col:      Optional[str]
    macro_adj:      float
    history:        list[ForecastPoint]
    forecast:       list[ForecastPoint]
    seasonality:    list[dict[str, Any]]   # [{month, index}]
    trend_yoy_pct:  Optional[float]        # средний YoY тренд


# ─────────────────────────────────────────────────────────────────────────────
# Portfolio
# ─────────────────────────────────────────────────────────────────────────────

class BCGRequest(BaseModel):
    current_year:   Optional[int] = Field(default=None, description="Год анализа (по умолчанию — последний)")
    prev_year:      Optional[int] = Field(default=None, description="Год для сравнения роста")
    category:       Optional[str] = Field(default=None, description="Фильтр по категории")


class BCGItem(BaseModel):
    sku:            str
    category:       str
    rev_current:    float
    rev_prev:       Optional[float]
    growth_yoy:     Optional[float]
    market_share:   float
    bcg_quadrant:   BCGQuadrant


class BCGResponse(BaseModel):
    current_year:   int
    prev_year:      int
    items:          list[BCGItem]
    quadrant_counts: dict[str, int]
    quadrant_rev:   dict[str, float]


class EVARequest(BaseModel):
    group_by: list[str] = Field(default=["Страна", "Год"])
    filters:  FilterDict = Field(default_factory=FilterDict)


class EVARow(BaseModel):
    dimensions: dict[str, Any]
    ebit:       float
    ic:         float
    nopat:      float
    wacc:       float
    wacc_ic:    float
    eva:        float
    eva_positive: bool


class EVAResponse(BaseModel):
    group_by:       list[str]
    rows:           list[EVARow]
    total_eva:      float
    total_nopat:    float
    value_creators: int   # строк с EVA > 0
    value_destroyers: int


class PaybackRow(BaseModel):
    sku:            str
    gp_annual:      float
    ic:             float
    payback_years:  Optional[float]
    bcg_quadrant:   Optional[str]


class PaybackResponse(BaseModel):
    rows:           list[PaybackRow]
    avg_payback:    float
    under_3_years:  int
    over_5_years:   int


# ─────────────────────────────────────────────────────────────────────────────
# Health
# ─────────────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status:         str   = "ok"
    duckdb:         str   = "unknown"
    duckdb_rows:    int   = 0
    cache_entries:  int   = 0
    version:        str   = "1.0.0"
    uptime_seconds: float = 0.0
