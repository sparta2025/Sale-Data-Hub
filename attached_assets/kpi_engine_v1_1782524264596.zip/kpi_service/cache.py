# VERSION: 1.0.0
# Path: kpi_service/cache.py
"""
TTL in-memory кэш для KPI Engine.
Redis-ready: реализует тот же интерфейс что и Redis-клиент.
Для переключения на Redis достаточно заменить Cache на RedisCache.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)


class _Entry:
    __slots__ = ("value", "expires_at")

    def __init__(self, value: Any, ttl: int) -> None:
        self.value      = value
        self.expires_at = time.monotonic() + ttl

    @property
    def valid(self) -> bool:
        return time.monotonic() < self.expires_at


class Cache:
    """
    Асинхронный TTL in-memory кэш.

    Использование:
        cache = Cache(default_ttl=300)
        await cache.set("key", value)
        value = await cache.get("key")   # None если просрочен
    """

    def __init__(self, default_ttl: int = 300, max_size: int = 1000) -> None:
        self._store:    dict[str, _Entry] = {}
        self._default_ttl = default_ttl
        self._max_size    = max_size
        self._lock        = asyncio.Lock()
        self._hits        = 0
        self._misses      = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def get(self, key: str) -> Optional[Any]:
        async with self._lock:
            entry = self._store.get(key)
            if entry and entry.valid:
                self._hits += 1
                return entry.value
            if entry:
                del self._store[key]
            self._misses += 1
            return None

    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        async with self._lock:
            if len(self._store) >= self._max_size:
                self._evict_expired()
                if len(self._store) >= self._max_size:
                    # Удаляем самый старый
                    oldest = next(iter(self._store))
                    del self._store[oldest]
            self._store[key] = _Entry(value, ttl or self._default_ttl)

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._store.pop(key, None)

    async def clear(self) -> None:
        async with self._lock:
            self._store.clear()

    async def size(self) -> int:
        async with self._lock:
            self._evict_expired()
            return len(self._store)

    @property
    def stats(self) -> dict[str, int]:
        return {"hits": self._hits, "misses": self._misses, "size": len(self._store)}

    # ------------------------------------------------------------------
    # Key helpers
    # ------------------------------------------------------------------

    @staticmethod
    def make_key(*parts: Any) -> str:
        """Детерминированный ключ из любого набора аргументов."""
        raw = json.dumps(parts, sort_keys=True, default=str, ensure_ascii=False)
        return hashlib.md5(raw.encode()).hexdigest()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _evict_expired(self) -> None:
        expired = [k for k, v in self._store.items() if not v.valid]
        for k in expired:
            del self._store[k]
        if expired:
            logger.debug("Cache: evicted %d expired entries", len(expired))


# Глобальный экземпляр — создаётся при старте приложения
_cache: Optional[Cache] = None


def get_cache() -> Cache:
    global _cache
    if _cache is None:
        _cache = Cache()
    return _cache


def init_cache(default_ttl: int = 300, max_size: int = 1000) -> Cache:
    global _cache
    _cache = Cache(default_ttl=default_ttl, max_size=max_size)
    return _cache
