# VERSION: 1.0.0
# Path: kpi_service/routers/forecast.py
"""
Router: /forecast — прогнозирование по временному ряду.
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from ..cache import Cache, get_cache
from ..deps import get_adapter
from ..routers.kpi import _safe
from ..schemas import (
    CascadeForecastRequest, ForecastPoint,
    ForecastRequest, ForecastResponse,
)
from sales_kpi import COL

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/forecast", tags=["Forecast"])

REV = COL["rev_net"]


@router.post(
    "/run",
    response_model=ForecastResponse,
    summary="Прогноз выручки",
    description=(
        "Строит прогноз на horizon месяцев методами: "
        "naive / trend_seasonal / ma_seasonal / prophet. "
        "Возвращает историю + прогноз + сезонные индексы."
    ),
)
async def run_forecast(
    req:     ForecastRequest,
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> ForecastResponse:
    cache_key = cache.make_key("forecast_run", req.model_dump())
    if cached := await cache.get(cache_key):
        return ForecastResponse(**cached)

    df = await _load(adapter, req.filters.to_dict())

    from sales_kpi import ForecastEngine
    fe = ForecastEngine(df)

    try:
        group_by = [req.group_col] if req.group_col else None
        ts = fe.prepare_timeseries(group_by=group_by, value_col=REV)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    try:
        fc = fe.forecast(
            ts,
            horizon=req.horizon,
            method=req.method.value,
            group_col=req.group_col,
            value_col=REV,
            macro_adj=req.macro_adj,
        )
    except Exception as exc:
        logger.error("Forecast error: %s", exc)
        raise HTTPException(status_code=500, detail=f"Forecast error: {exc}")

    si = fe.calc_seasonality(ts, REV)
    seasonality = [
        {"month": int(r["Месяц"]), "index": round(float(r["seasonality_index"]), 4)}
        for _, r in si.iterrows()
    ]

    # YoY тренд
    try:
        import numpy as np
        yoy_series = ts.groupby(COL["year"])[REV].sum()
        if len(yoy_series) >= 2:
            changes = yoy_series.pct_change().dropna()
            trend_yoy = float(changes.mean() * 100)
        else:
            trend_yoy = None
    except Exception:
        trend_yoy = None

    # История
    history_pts = _ts_to_points(ts, req.group_col, is_history=True)
    forecast_pts = _fc_to_points(fc, req.group_col)

    payload = ForecastResponse(
        method=req.method.value,
        horizon=req.horizon,
        group_col=req.group_col,
        macro_adj=req.macro_adj,
        history=history_pts,
        forecast=forecast_pts,
        seasonality=seasonality,
        trend_yoy_pct=round(trend_yoy, 2) if trend_yoy is not None else None,
    )
    await cache.set(cache_key, payload.model_dump())
    return payload


@router.post(
    "/cascade",
    summary="Каскадный прогноз по иерархии",
    description=(
        "Прогнозирует на нижнем уровне иерархии (SKU), "
        "агрегирует наверх и применяет reconciliation."
    ),
)
async def cascade_forecast(
    req:     CascadeForecastRequest,
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> dict[str, Any]:
    cache_key = cache.make_key("forecast_cascade", req.model_dump())
    if cached := await cache.get(cache_key):
        return cached

    df = await _load(adapter, {})

    from sales_kpi import ForecastEngine
    fe = ForecastEngine(df)

    try:
        result = fe.cascade_forecast(
            df,
            hierarchy=req.hierarchy,
            horizon=req.horizon,
            method=req.method.value,
            value_col=REV,
            macro_adj=req.macro_adj,
        )
    except Exception as exc:
        logger.error("Cascade forecast error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    result["date"] = result["date"].astype(str)
    out = {
        "hierarchy":   req.hierarchy,
        "horizon":     req.horizon,
        "method":      req.method.value,
        "rows":        result.to_dict(orient="records"),
        "total_reconciled": float(result[f"{REV}_reconciled"].sum()),
    }
    await cache.set(cache_key, out)
    return out


# ─────────────────────────────────────────────────────────────────────────────

def _ts_to_points(ts, group_col, is_history: bool) -> list[ForecastPoint]:
    pts = []
    for _, r in ts.iterrows():
        pts.append(ForecastPoint(
            date=str(r["date"])[:10],
            year=int(r[COL["year"]]),
            month=int(r[COL["month"]]),
            value=_safe(r[REV]),
            group=str(r[group_col]) if group_col and group_col in r else None,
            is_history=is_history,
        ))
    return pts


def _fc_to_points(fc, group_col) -> list[ForecastPoint]:
    pts = []
    for _, r in fc.iterrows():
        pts.append(ForecastPoint(
            date=str(r["date"])[:10],
            year=int(r[COL["year"]]) if COL["year"] in r else r["date"].year,
            month=int(r[COL["month"]]) if COL["month"] in r else r["date"].month,
            value=_safe(r[REV]),
            group=str(r[group_col]) if group_col and group_col in r else None,
            is_history=False,
        ))
    return pts


async def _load(adapter, filters):
    try:
        df = await adapter.load_transactions(filters)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    if df.empty:
        raise HTTPException(status_code=404, detail="No data found")
    return df
