# VERSION: 1.0.0
# Path: kpi_service/routers/portfolio.py
"""
Router: /portfolio — BCG, EVA, Payback.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException

from ..cache import Cache, get_cache
from ..deps import get_adapter
from ..routers.kpi import _safe
from ..schemas import (
    BCGItem, BCGQuadrant, BCGRequest, BCGResponse,
    EVARequest, EVAResponse, EVARow,
    PaybackResponse, PaybackRow,
)
from sales_kpi import COL

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/portfolio", tags=["Portfolio"])


@router.post(
    "/bcg",
    response_model=BCGResponse,
    summary="BCG-матрица по SKU",
    description="Классифицирует все SKU по квадрантам BCG на основе доли рынка и роста выручки.",
)
async def bcg_matrix(
    req:     BCGRequest,
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> BCGResponse:
    cache_key = cache.make_key("bcg", req.model_dump())
    if cached := await cache.get(cache_key):
        return BCGResponse(**cached)

    filters = {}
    if req.category:
        filters[COL["category"]] = req.category
    df = await _load(adapter, filters)

    from sales_kpi import bcg_classify
    bcg = bcg_classify(
        df,
        current_year=req.current_year,
        prev_year=req.prev_year,
    )

    items = []
    for _, r in bcg.iterrows():
        items.append(BCGItem(
            sku          = str(r[COL["sku"]]),
            category     = str(r[COL["category"]]),
            rev_current  = _safe(r["rev_current"]) or 0.0,
            rev_prev     = _safe(r.get("rev_prev")),
            growth_yoy   = _safe(r.get("growth_yoy")),
            market_share = _safe(r["market_share"]) or 0.0,
            bcg_quadrant = BCGQuadrant(r["bcg_quadrant"]),
        ))

    years = sorted(df[COL["year"]].unique())
    cur_yr  = req.current_year or (years[-1] if years else 0)
    prev_yr = req.prev_year    or (years[-2] if len(years) >= 2 else cur_yr)

    q_counts = bcg["bcg_quadrant"].value_counts().to_dict()
    q_rev    = bcg.groupby("bcg_quadrant")["rev_current"].sum().to_dict()

    payload = BCGResponse(
        current_year    = int(cur_yr),
        prev_year       = int(prev_yr),
        items           = items,
        quadrant_counts = {k: int(v) for k, v in q_counts.items()},
        quadrant_rev    = {k: float(v) for k, v in q_rev.items()},
    )
    await cache.set(cache_key, payload.model_dump())
    return payload


@router.post(
    "/eva",
    response_model=EVAResponse,
    summary="EVA по группам",
    description="Экономическая добавленная стоимость: NOPAT − WACC × IC. По стране, году или другому срезу.",
)
async def eva_analysis(
    req:     EVARequest,
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> EVAResponse:
    cache_key = cache.make_key("eva", req.model_dump())
    if cached := await cache.get(cache_key):
        return EVAResponse(**cached)

    df = await _load(adapter, req.filters.to_dict())

    from sales_kpi import eva_by_group
    eva_df = eva_by_group(df, req.group_by)

    rows = []
    dim_cols = [c for c in req.group_by if c in eva_df.columns]

    for _, r in eva_df.iterrows():
        rows.append(EVARow(
            dimensions   = {c: _safe(r[c]) for c in dim_cols},
            ebit         = float(r.get(COL["ebit"], 0) or 0),
            ic           = float(r.get(COL["ic"], 0) or 0),
            nopat        = float(r.get("NOPAT", 0) or 0),
            wacc         = float(r.get("_wacc", 0.08) if "_wacc" in r.index else 0.08),
            wacc_ic      = float((r.get("NOPAT", 0) or 0) - (r.get("EVA", 0) or 0)),
            eva          = float(r.get("EVA", 0) or 0),
            eva_positive = float(r.get("EVA", 0) or 0) > 0,
        ))

    total_eva   = sum(r.eva   for r in rows)
    total_nopat = sum(r.nopat for r in rows)

    payload = EVAResponse(
        group_by         = req.group_by,
        rows             = rows,
        total_eva        = total_eva,
        total_nopat      = total_nopat,
        value_creators   = sum(1 for r in rows if r.eva_positive),
        value_destroyers = sum(1 for r in rows if not r.eva_positive),
    )
    await cache.set(cache_key, payload.model_dump())
    return payload


@router.get(
    "/payback",
    response_model=PaybackResponse,
    summary="Срок окупаемости по SKU",
    description="Payback = IC / Annual_GP. Полезен для принятия решений о выводе продуктов.",
)
async def payback(
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> PaybackResponse:
    cache_key = cache.make_key("payback")
    if cached := await cache.get(cache_key):
        return PaybackResponse(**cached)

    df = await _load(adapter, {})

    from sales_kpi import payback_period, bcg_classify
    pb_df  = payback_period(df)
    bcg_df = bcg_classify(df)

    # Присоединяем BCG квадрант
    bcg_map = bcg_df.set_index(COL["sku"])["bcg_quadrant"].to_dict()

    rows = []
    for _, r in pb_df.iterrows():
        sku = str(r[COL["sku"]])
        rows.append(PaybackRow(
            sku            = sku,
            gp_annual      = float(r.get(COL["gp"], 0) or 0),
            ic             = float(r.get(COL["ic"], 0) or 0),
            payback_years  = _safe(r.get("payback_years")),
            bcg_quadrant   = bcg_map.get(sku),
        ))

    valid_pb = [r.payback_years for r in rows if r.payback_years is not None]
    avg_pb   = sum(valid_pb) / len(valid_pb) if valid_pb else 0.0

    payload = PaybackResponse(
        rows          = rows,
        avg_payback   = round(avg_pb, 2),
        under_3_years = sum(1 for v in valid_pb if v < 3),
        over_5_years  = sum(1 for v in valid_pb if v > 5),
    )
    await cache.set(cache_key, payload.model_dump())
    return payload


async def _load(adapter, filters):
    try:
        df = await adapter.load_transactions(filters)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    if df.empty:
        raise HTTPException(status_code=404, detail="No data found")
    return df
