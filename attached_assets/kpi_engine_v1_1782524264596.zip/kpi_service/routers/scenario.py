# VERSION: 1.0.0
# Path: kpi_service/routers/scenario.py
"""
Router: /scenario — сценарный анализ и гипотезы.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException

from ..cache import Cache, get_cache
from ..deps import get_adapter
from ..routers.kpi import _safe
from ..schemas import (
    ScenarioCompareRequest, ScenarioCompareResponse,
    ScenarioDelta, ScenarioRequest, ScenarioRunResponse,
    SensitivityRequest, SensitivityResponse,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/scenario", tags=["Scenario"])


def _req_to_params(req: ScenarioRequest):
    from sales_kpi import ScenarioParams
    return ScenarioParams(
        name             = req.name,
        price_change     = req.price_change,
        volume_change    = req.volume_change,
        cogs_change      = req.cogs_change,
        marketing_change = req.marketing_change,
        overhead_change  = req.overhead_change,
        dso_change_days  = req.dso_change_days,
        new_sku_rev      = req.new_sku_rev,
        wacc_delta       = req.wacc_delta,
        filters          = req.filters.to_dict(),
    )


@router.post(
    "/run",
    response_model=ScenarioRunResponse,
    summary="Запустить один сценарий",
    description="Применяет параметры сценария к данным и возвращает P&L с дельтами к базовому.",
)
async def run_scenario(
    req:     ScenarioRequest,
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> ScenarioRunResponse:
    cache_key = cache.make_key("scenario_run", req.model_dump())
    if cached := await cache.get(cache_key):
        return ScenarioRunResponse(**cached)

    df = await _load(adapter, req.filters.to_dict())

    from sales_kpi import ScenarioEngine, ScenarioParams
    engine  = ScenarioEngine(df)
    base_p  = ScenarioParams(name="Базовый")
    scen_p  = _req_to_params(req)

    base_df = engine.run(base_p, group_by=req.group_by)
    scen_df = engine.run(scen_p, group_by=req.group_by)

    kpi_cols = [c for c in base_df.columns
                if base_df[c].dtype in ("float64", "int64")
                and not c.startswith("_")]

    base_totals = {c: _safe(base_df[c].sum()) for c in kpi_cols}
    scen_totals = {c: _safe(scen_df[c].sum()) for c in kpi_cols}

    deltas = []
    for kpi in kpi_cols:
        bv = base_totals.get(kpi) or 0.0
        sv = scen_totals.get(kpi) or 0.0
        denom = bv if bv != 0 else None
        deltas.append(ScenarioDelta(
            kpi=kpi, base_value=bv, scenario_value=sv,
            delta_abs=sv - bv,
            delta_pct=(sv - bv) / denom * 100 if denom else 0.0,
        ))

    payload = ScenarioRunResponse(
        scenario_name=req.name,
        group_by=req.group_by,
        base=base_totals,
        result=scen_totals,
        deltas=deltas,
    )
    await cache.set(cache_key, payload.model_dump())
    return payload


@router.post(
    "/compare",
    response_model=ScenarioCompareResponse,
    summary="Сравнить несколько сценариев",
    description="Первый сценарий = базовый. Возвращает таблицу с дельтами и определяет лучший/худший.",
)
async def compare_scenarios(
    req:     ScenarioCompareRequest,
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> ScenarioCompareResponse:
    cache_key = cache.make_key("scenario_compare", req.model_dump())
    if cached := await cache.get(cache_key):
        return ScenarioCompareResponse(**cached)

    # Фильтры берём из первого (базового) сценария
    df = await _load(adapter, req.scenarios[0].filters.to_dict())

    from sales_kpi import ScenarioEngine
    engine = ScenarioEngine(df)
    params = [_req_to_params(s) for s in req.scenarios]
    comp   = engine.compare(params, group_by=req.group_by, kpis=req.kpis)

    rows = []
    for scenario_name, row in comp.iterrows():
        rows.append({"scenario": scenario_name, **{k: _safe(v) for k, v in row.items()}})

    # Лучший/худший по первому KPI
    first_kpi = req.kpis[0] if req.kpis else None
    best, worst = rows[0]["scenario"], rows[0]["scenario"]
    if first_kpi:
        vals = [(r["scenario"], r.get(first_kpi, 0) or 0) for r in rows]
        best  = max(vals, key=lambda x: x[1])[0]
        worst = min(vals, key=lambda x: x[1])[0]

    payload = ScenarioCompareResponse(
        scenarios=[s.name for s in req.scenarios],
        kpis=req.kpis,
        comparison=rows,
        best_scenario=best,
        worst_scenario=worst,
    )
    await cache.set(cache_key, payload.model_dump())
    return payload


@router.post(
    "/sensitivity",
    response_model=SensitivityResponse,
    summary="Анализ чувствительности",
    description="Варьирует один параметр сценария и показывает влияние на целевой KPI.",
)
async def sensitivity(
    req:     SensitivityRequest,
    cache:   Cache = Depends(get_cache),
    adapter        = Depends(get_adapter),
) -> SensitivityResponse:
    cache_key = cache.make_key("sensitivity", req.model_dump())
    if cached := await cache.get(cache_key):
        return SensitivityResponse(**cached)

    df = await _load(adapter, req.base_scenario.filters.to_dict())

    from sales_kpi import ScenarioEngine
    engine  = ScenarioEngine(df)
    base_p  = _req_to_params(req.base_scenario)
    sens_df = engine.sensitivity(
        base_p,
        param_name  = req.param_name,
        values      = req.values,
        target_kpi  = req.target_kpi,
        group_by    = req.group_by,
    )

    rows = [
        {
            "param_value": _safe(r["Значение параметра"]),
            "kpi_value":   _safe(r.get(req.target_kpi)),
            "delta":       _safe(r.get(f"Δ {req.target_kpi}")),
            "delta_pct":   _safe(r.get(f"Δ% {req.target_kpi}")),
        }
        for _, r in sens_df.iterrows()
    ]

    # Средняя эластичность
    try:
        import numpy as np
        param_vals = [r["param_value"] for r in rows if r["param_value"] != 0]
        kpi_vals   = [r["kpi_value"]   for r in rows if r["param_value"] != 0]
        if len(param_vals) >= 2:
            delta_kpi   = (kpi_vals[-1]   - kpi_vals[0])   / (kpi_vals[0]   or 1)
            delta_param = (param_vals[-1] - param_vals[0]) / (param_vals[0] or 1)
            elasticity  = delta_kpi / delta_param if delta_param != 0 else 0.0
        else:
            elasticity = 0.0
    except Exception:
        elasticity = 0.0

    payload = SensitivityResponse(
        param_name=req.param_name,
        target_kpi=req.target_kpi,
        rows=rows,
        elasticity=round(elasticity, 4),
    )
    await cache.set(cache_key, payload.model_dump())
    return payload


async def _load(adapter, filters: dict):
    try:
        df = await adapter.load_transactions(filters)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Data source error: {exc}")
    if df.empty:
        raise HTTPException(status_code=404, detail="No data found for given filters")
    return df
