# VERSION: 1.0.0
# Path: kpi_service/routers/kpi.py
"""
Router: /kpi — агрегированные KPI-метрики.
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from ..cache import Cache, get_cache
from ..deps import get_adapter
from ..schemas import KPIRow, KPISummaryRequest, KPISummaryResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/kpi", tags=["KPI"])


@router.post(
    "/summary",
    response_model=KPISummaryResponse,
    summary="Агрегированные KPI по срезу",
    description=(
        "Возвращает KPI-метрики (выручка, маржа, EBITDA, ROI, EVA…) "
        "агрегированные по переданным измерениям с применением фильтров."
    ),
)
async def kpi_summary(
    req:     KPISummaryRequest,
    cache:   Cache  = Depends(get_cache),
    adapter         = Depends(get_adapter),
) -> KPISummaryResponse:
    cache_key = cache.make_key("kpi_summary", req.model_dump())
    cached    = await cache.get(cache_key)
    if cached:
        cached["cached"] = True
        return KPISummaryResponse(**cached)

    filters = req.filters.to_dict()
    try:
        df = await adapter.load_transactions(filters)
    except Exception as exc:
        logger.error("kpi_summary adapter error: %s", exc)
        raise HTTPException(status_code=503, detail=f"Data source error: {exc}")

    if df.empty:
        raise HTTPException(status_code=404, detail="No data found for given filters")

    from sales_kpi import KPICalculator
    calc    = KPICalculator(df)
    summary = calc.summary(req.group_by)

    rows: list[KPIRow] = []
    dim_cols = [c for c in req.group_by if c in summary.columns]
    met_cols = [c for c in summary.columns if c not in dim_cols]

    for _, row in summary.iterrows():
        rows.append(KPIRow(
            dimensions={c: _safe(row[c]) for c in dim_cols},
            metrics={c: _safe(row[c]) for c in met_cols},
        ))

    # Итоговая строка
    total: dict[str, Any] = {}
    for col in met_cols:
        if summary[col].dtype in ("float64", "int64"):
            total[col] = float(summary[col].sum())

    payload = {
        "group_by":  req.group_by,
        "rows":      [r.model_dump() for r in rows],
        "total":     total,
        "row_count": len(rows),
        "cached":    False,
        "source":    adapter.name(),
    }
    await cache.set(cache_key, payload)
    return KPISummaryResponse(**payload)


def _safe(value: Any) -> Any:
    """Конвертировать numpy типы в Python-примитивы для JSON-сериализации."""
    import math
    import numpy as np
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        v = float(value)
        return None if math.isnan(v) or math.isinf(v) else v
    if isinstance(value, np.ndarray):
        return value.tolist()
    return value
