"""
sales_kpi.py
============
Ядро расчёта KPI для данных о продажах 2015–2026.

Структура:
  - KPICalculator   — расчёт 39 KPI на уровне транзакции / агрегата
  - PLBuilder       — построение P&L по любому срезу
  - ScenarioEngine  — сценарный анализ и гипотезы
  - ForecastEngine  — прогнозирование по временному ряду

Использование:
  from sales_kpi import KPICalculator, PLBuilder, ScenarioEngine, ForecastEngine
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ─────────────────────────────────────────────────────────────────────────────
# КОНСТАНТЫ
# ─────────────────────────────────────────────────────────────────────────────

# Налоговые ставки по странам (%)
TAX_RATES: dict[str, float] = {
    "Германия": 0.15,
    "Польша":   0.19,
    "Франция":  0.25,
    "Румыния":  0.16,
    "Австрия":  0.25,
}

# WACC по странам (%)
WACC_BY_COUNTRY: dict[str, float] = {
    "Германия": 0.08,
    "Польша":   0.10,
    "Франция":  0.09,
    "Румыния":  0.12,
    "Австрия":  0.085,
}

# CPI-индексы (2015 = 1.0) — примерные значения для дефлятора
CPI_INDEX: dict[int, dict[str, float]] = {
    2015: {"Германия": 1.000, "Польша": 1.000, "Франция": 1.000},
    2016: {"Германия": 1.005, "Польша": 0.997, "Франция": 1.002},
    2017: {"Германия": 1.022, "Польша": 1.020, "Франция": 1.012},
    2018: {"Германия": 1.042, "Польша": 1.038, "Франция": 1.024},
    2019: {"Германия": 1.056, "Польша": 1.055, "Франция": 1.033},
    2020: {"Германия": 1.055, "Польша": 1.088, "Франция": 1.033},
    2021: {"Германия": 1.088, "Польша": 1.138, "Франция": 1.052},
    2022: {"Германия": 1.185, "Польша": 1.267, "Франция": 1.107},
    2023: {"Германия": 1.245, "Польша": 1.399, "Франция": 1.152},
    2024: {"Германия": 1.270, "Польша": 1.452, "Франция": 1.175},
    2025: {"Германия": 1.290, "Польша": 1.490, "Франция": 1.195},
    2026: {"Германия": 1.305, "Польша": 1.515, "Франция": 1.210},
}

# Колонки исходного датасета
COL = {
    "country":      "Страна",
    "branch":       "Филиал",
    "year":         "Год",
    "month":        "Месяц",
    "category":     "Товарная группа",
    "product":      "Наименование товара",
    "sku":          "Артикул",
    "unit":         "Ед. изм.",
    "qty":          "Количество",
    "price":        "Продажная цена (EUR)",
    "excise":       "Акциз (EUR)",
    "vat":          "НДС (EUR)",
    "sum_gross":    "Сумма с налогами (EUR)",
    "cost":         "Закупочная цена (EUR)",
    "overhead":     "Накладные расходы (EUR)",
    "logistics":    "Логистические затраты (EUR)",
    "customs":      "Таможенные платежи (EUR)",
    "rev_net":      "Выручка нетто (EUR)",
    "cogs":         "Себестоимость продаж (EUR)",
    "gp":           "Валовая прибыль (EUR)",
    "gpm":          "Маржа валовой прибыли (%)",
    "tc":           "Полные затраты (EUR)",
    "ebit":         "Операционная прибыль (EUR)",
    "om":           "Операц. маржа (%)",
    "excise_sum":   "Акциз итого (EUR)",
    "vat_sum":      "НДС итого (EUR)",
    "markup":       "Наценка (%)",
    "profit_unit":  "Прибыль на единицу (EUR)",
    "marketing":    "Маркетинговые затраты (EUR)",
    "capex":        "CAPEX аллокация (EUR)",
    "inventory":    "Запасы на складе (EUR)",
    "provision":    "Резерв по сомн. долгам (EUR)",
    "ebitda":       "EBITDA (EUR)",
    "ebitda_m":     "EBITDA маржа (%)",
    "ic":           "Инвестированный капитал (EUR)",
    "roi":          "ROI (%)",
    "roce":         "ROCE (%)",
    "mroi":         "Marketing ROI",
    "mc":           "Маржинальный вклад (EUR)",
    "mcr":          "Маржинальный вклад (%)",
    "bep":          "Точка безубыточности (ед.)",
    "safety":       "Запас прочности (%)",
    "price_index":  "Ценовой индекс (к ср. по кат.)",
    "inv_turns":    "Оборачиваемость запасов (раз/год)",
    "dso":          "DSO (дней)",
    "rev_real":     "Реальная выручка (EUR 2015)",
    "rev_per_fte":  "Выручка на сотрудника (EUR)",
    "cac":          "CAC (EUR)",
    "ltv":          "LTV (EUR)",
    "ltv_cac":      "LTV/CAC",
}


# ─────────────────────────────────────────────────────────────────────────────
# KPI CALCULATOR
# ─────────────────────────────────────────────────────────────────────────────

class KPICalculator:
    """
    Расчёт всех KPI для переданного DataFrame.

    Параметры
    ---------
    df : pd.DataFrame
        Сырые данные из листа 01_Данные_KPI.
    verify : bool
        Если True — сравнивает расчётные значения с предрассчитанными в файле.
    """

    def __init__(self, df: pd.DataFrame, verify: bool = False):
        self.df = df.copy()
        self._verify = verify
        self._enrich()

    # ------------------------------------------------------------------
    # Публичные методы
    # ------------------------------------------------------------------

    def get(self) -> pd.DataFrame:
        """Вернуть датафрейм со всеми рассчитанными KPI."""
        return self.df

    def summary(self, group_by: list[str]) -> pd.DataFrame:
        """
        Агрегировать KPI по переданным измерениям.

        Пример:
            calc.summary(['Страна', 'Год'])
            calc.summary(['Товарная группа', 'Год', 'Месяц'])
        """
        agg_rules = {
            COL["rev_net"]:  "sum",
            COL["cogs"]:     "sum",
            COL["gp"]:       "sum",
            COL["ebit"]:     "sum",
            COL["ebitda"]:   "sum",
            COL["mc"]:       "sum",
            COL["marketing"]:"sum",
            COL["ic"]:       "sum",
            COL["qty"]:      "sum",
            COL["inventory"]:"sum",
            COL["provision"]:"sum",
        }
        # Оставляем только колонки, которые есть в df
        valid = {k: v for k, v in agg_rules.items() if k in self.df.columns}
        agg = self.df.groupby(group_by).agg(valid).reset_index()

        # Пересчитываем процентные KPI после агрегации
        rev = COL["rev_net"]
        if rev in agg.columns:
            if COL["gp"] in agg.columns:
                agg[COL["gpm"]]     = agg[COL["gp"]] / agg[rev].replace(0, np.nan) * 100
            if COL["ebit"] in agg.columns:
                agg[COL["om"]]      = agg[COL["ebit"]] / agg[rev].replace(0, np.nan) * 100
            if COL["ebitda"] in agg.columns:
                agg[COL["ebitda_m"]]= agg[COL["ebitda"]] / agg[rev].replace(0, np.nan) * 100
            if COL["mc"] in agg.columns:
                agg[COL["mcr"]]     = agg[COL["mc"]] / agg[rev].replace(0, np.nan) * 100
            if COL["ic"] in agg.columns:
                agg[COL["roi"]]     = agg[COL["ebit"]] / agg[COL["ic"]].replace(0, np.nan) * 100
            if COL["inventory"] in agg.columns:
                agg[COL["inv_turns"]] = agg[COL["cogs"]] / agg[COL["inventory"]].replace(0, np.nan)
            if COL["provision"] in agg.columns:
                agg[COL["dso"]] = agg[COL["provision"]] / agg[rev].replace(0, np.nan) * 365

        return agg

    # ------------------------------------------------------------------
    # Внутренние расчёты
    # ------------------------------------------------------------------

    def _enrich(self):
        """Добавить/пересчитать все KPI-колонки."""
        d = self.df
        q   = d.get(COL["qty"],      pd.Series(0, index=d.index))
        p   = d.get(COL["price"],    pd.Series(0, index=d.index))
        rev = d.get(COL["rev_net"],  pd.Series(np.nan, index=d.index))
        cogs = d.get(COL["cogs"],    pd.Series(np.nan, index=d.index))
        gp   = d.get(COL["gp"],      pd.Series(np.nan, index=d.index))
        tc   = d.get(COL["tc"],      pd.Series(np.nan, index=d.index))
        mkt  = d.get(COL["marketing"], pd.Series(0, index=d.index))
        ic   = d.get(COL["ic"],      pd.Series(np.nan, index=d.index))
        inv  = d.get(COL["inventory"], pd.Series(np.nan, index=d.index))
        prov = d.get(COL["provision"],  pd.Series(0, index=d.index))

        # ── Базовые маржи (если не предрассчитаны) ──
        if COL["gpm"] not in d.columns:
            d[COL["gpm"]] = gp / rev.replace(0, np.nan) * 100

        if COL["om"] not in d.columns:
            ebit = d.get(COL["ebit"], gp - tc + cogs)
            d[COL["om"]] = ebit / rev.replace(0, np.nan) * 100

        if COL["ebitda_m"] not in d.columns and COL["ebitda"] in d.columns:
            d[COL["ebitda_m"]] = d[COL["ebitda"]] / rev.replace(0, np.nan) * 100

        if COL["mcr"] not in d.columns and COL["mc"] in d.columns:
            d[COL["mcr"]] = d[COL["mc"]] / rev.replace(0, np.nan) * 100

        # ── Оборачиваемость запасов ──
        if COL["inv_turns"] not in d.columns:
            d[COL["inv_turns"]] = cogs / inv.replace(0, np.nan)

        # ── DSO ──
        if COL["dso"] not in d.columns:
            d[COL["dso"]] = prov / rev.replace(0, np.nan) * 365

        # ── MROI ──
        if COL["mroi"] not in d.columns:
            d[COL["mroi"]] = (gp - mkt) / mkt.replace(0, np.nan)

        # ── Реальная выручка ──
        if COL["rev_real"] not in d.columns and COL["year"] in d.columns:
            cpi_col = d[COL["year"]].map(
                lambda y: CPI_INDEX.get(y, {}).get("Германия", 1.0)  # дефолт DE
            )
            if COL["country"] in d.columns:
                cpi_col = d.apply(
                    lambda r: CPI_INDEX.get(r[COL["year"]], {}).get(r[COL["country"]], 1.0),
                    axis=1
                )
            d[COL["rev_real"]] = rev / cpi_col

        # ── Наценка ──
        if COL["markup"] not in d.columns:
            cost = d.get(COL["cost"], pd.Series(np.nan, index=d.index))
            d[COL["markup"]] = (p - cost) / cost.replace(0, np.nan)

        # ── EVA (добавляем, если нет) ──
        if "EVA (EUR)" not in d.columns and COL["ebit"] in d.columns:
            country_col = d.get(COL["country"], pd.Series("Германия", index=d.index))
            tax = country_col.map(TAX_RATES).fillna(0.15)
            wacc = country_col.map(WACC_BY_COUNTRY).fillna(0.08)
            ebit = d[COL["ebit"]]
            d["EVA (EUR)"] = ebit * (1 - tax) - wacc * ic.fillna(0)

        if self._verify:
            self._run_verification()

    def _run_verification(self):
        """Сравнить расчётные KPI с предрассчитанными в исходном файле."""
        checks = [
            (COL["gpm"],     COL["gp"],   COL["rev_net"]),
            (COL["om"],      COL["ebit"], COL["rev_net"]),
            (COL["ebitda_m"],COL["ebitda"],COL["rev_net"]),
        ]
        for ratio_col, num_col, den_col in checks:
            if all(c in self.df.columns for c in [ratio_col, num_col, den_col]):
                calc = self.df[num_col] / self.df[den_col].replace(0, np.nan) * 100
                orig = self.df[ratio_col]
                diff = (calc - orig).abs()
                bad  = diff[diff > 0.01].count()
                if bad > 0:
                    print(f"[WARN] {ratio_col}: {bad} строк расхождение > 0.01%")
                else:
                    print(f"[OK]   {ratio_col}: верифицировано")


# ─────────────────────────────────────────────────────────────────────────────
# P&L BUILDER
# ─────────────────────────────────────────────────────────────────────────────

class PLBuilder:
    """
    Строит P&L по любому срезу данных.

    Пример:
        pl = PLBuilder(df)
        pl.build(group_by=['Страна', 'Год'])
        pl.build(group_by=['Страна', 'Товарная группа', 'Год'])
    """

    PL_ROWS = [
        ("Выручка нетто",        COL["rev_net"],  True),
        ("(-) COGS",             COL["cogs"],     False),
        ("Валовая прибыль",      COL["gp"],       True),
        ("Маржа ВП %",           None,            None),   # пересчёт
        ("(-) Маркетинг",        COL["marketing"],False),
        ("(-) CAPEX аллокация",  COL["capex"],    False),
        ("(-) Накладные",        COL["overhead"], False),
        ("EBITDA",               COL["ebitda"],   True),
        ("EBITDA маржа %",       None,            None),
        ("Операционная прибыль", COL["ebit"],     True),
        ("Операц. маржа %",      None,            None),
        ("(-) WACC × IC",        None,            None),   # рассчитывается
        ("EBT",                  None,            None),
        ("(-) Налог",            None,            None),
        ("Чистая прибыль",       None,            None),
        ("EVA",                  "EVA (EUR)",     True),
        ("ROI %",                COL["roi"],      None),
    ]

    def __init__(self, df: pd.DataFrame):
        self.df = df

    def build(
        self,
        group_by: list[str],
        country_col: str = COL["country"],
        year_col: str    = COL["year"],
    ) -> pd.DataFrame:
        """Вернуть P&L DataFrame с иерархией строк."""
        agg: dict[str, str] = {}
        for _, col, _ in self.PL_ROWS:
            if col and col in self.df.columns:
                agg[col] = "sum"

        grouped = self.df.groupby(group_by).agg(agg).reset_index()

        # Пересчёт WACC × IC и производных
        if country_col in grouped.columns:
            grouped["_wacc"] = grouped[country_col].map(WACC_BY_COUNTRY).fillna(0.08)
            grouped["_tax"]  = grouped[country_col].map(TAX_RATES).fillna(0.15)
        else:
            grouped["_wacc"] = 0.08
            grouped["_tax"]  = 0.15

        ic_col   = COL["ic"]
        ebit_col = COL["ebit"]
        rev_col  = COL["rev_net"]
        gp_col   = COL["gp"]
        ebitda_col = COL["ebitda"]

        if ic_col in grouped.columns and ebit_col in grouped.columns:
            grouped["_wacc_ic"]   = grouped["_wacc"] * grouped[ic_col]
            grouped["_ebt"]       = grouped[ebit_col] - grouped["_wacc_ic"]
            grouped["_tax_amt"]   = grouped["_ebt"] * grouped["_tax"]
            grouped["_net_profit"]= grouped["_ebt"] - grouped["_tax_amt"]

        if rev_col in grouped.columns:
            if gp_col in grouped.columns:
                grouped["_gpm"] = grouped[gp_col] / grouped[rev_col].replace(0, np.nan) * 100
            if ebitda_col in grouped.columns:
                grouped["_ebitda_m"] = grouped[ebitda_col] / grouped[rev_col].replace(0, np.nan) * 100
            if ebit_col in grouped.columns:
                grouped["_om"] = grouped[ebit_col] / grouped[rev_col].replace(0, np.nan) * 100

        return grouped


# ─────────────────────────────────────────────────────────────────────────────
# SCENARIO ENGINE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ScenarioParams:
    """Параметры одного сценария."""
    name:               str   = "Базовый"
    price_change:       float = 0.0    # доля: 0.05 = +5%
    volume_change:      float = 0.0    # доля: -0.03 = −3%
    cogs_change:        float = 0.0    # доля изменения COGS
    marketing_change:   float = 0.0    # доля изменения маркетинговых затрат
    overhead_change:    float = 0.0    # доля изменения накладных
    dso_change_days:    float = 0.0    # изменение DSO в днях (−10 = улучшение)
    discount_rate:      float = 0.0    # разовая скидка (0.1 = 10%) для стресс-теста
    new_sku_rev:        float = 0.0    # дополнительная выручка от новых SKU
    wacc_delta:         float = 0.0    # изменение WACC (0.01 = +1 п.п.)
    filters:            dict  = field(default_factory=dict)  # {'Страна': 'Германия'}


class ScenarioEngine:
    """
    Сценарный анализ: применяет изменения к агрегированному P&L.

    Пример:
        engine = ScenarioEngine(df)

        # Гипотеза: цена +5%, объём −3%
        s = ScenarioParams(name='Price+5/Vol-3', price_change=0.05, volume_change=-0.03)
        result = engine.run(s)

        # Сравнение нескольких сценариев
        comparison = engine.compare([base, optimistic, pessimistic])
    """

    def __init__(self, df: pd.DataFrame, calc: Optional[KPICalculator] = None):
        self.df = df
        self._calc = calc or KPICalculator(df)

    def run(
        self,
        params: ScenarioParams,
        group_by: Optional[list[str]] = None,
    ) -> pd.DataFrame:
        """Применить сценарий и вернуть изменённый P&L."""
        group_by = group_by or [COL["country"], COL["year"]]

        # Фильтрация датасета
        df_s = self.df.copy()
        for col, val in params.filters.items():
            if col in df_s.columns:
                df_s = df_s[df_s[col] == val]

        # Применяем изменения на уровне строк
        rev_col  = COL["rev_net"]
        cogs_col = COL["cogs"]
        gp_col   = COL["gp"]
        mkt_col  = COL["marketing"]
        oh_col   = COL["overhead"]
        ebit_col = COL["ebit"]
        ic_col   = COL["ic"]
        prov_col = COL["provision"]

        df_s = df_s.copy()

        # Цена и объём → выручка
        price_vol_factor = (1 + params.price_change) * (1 + params.volume_change)
        if rev_col in df_s.columns:
            df_s[rev_col] = df_s[rev_col] * price_vol_factor

        # Объём → COGS (только переменная часть: 80% COGS считаем переменной)
        if cogs_col in df_s.columns:
            variable_share  = 0.80
            fixed_share     = 1 - variable_share
            cogs_variable   = df_s[cogs_col] * variable_share * (1 + params.volume_change) * (1 + params.cogs_change)
            cogs_fixed      = df_s[cogs_col] * fixed_share * (1 + params.cogs_change)
            df_s[cogs_col]  = cogs_variable + cogs_fixed

        # GP
        if rev_col in df_s.columns and cogs_col in df_s.columns:
            df_s[gp_col] = df_s[rev_col] - df_s[cogs_col]

        # Маркетинг
        if mkt_col in df_s.columns and params.marketing_change != 0:
            df_s[mkt_col] = df_s[mkt_col] * (1 + params.marketing_change)

        # Накладные
        if oh_col in df_s.columns and params.overhead_change != 0:
            df_s[oh_col] = df_s[oh_col] * (1 + params.overhead_change)

        # EBIT пересчёт
        capex_col = COL.get("capex", "CAPEX аллокация (EUR)")
        if all(c in df_s.columns for c in [gp_col, mkt_col, oh_col]):
            capex = df_s.get(capex_col, pd.Series(0, index=df_s.index))
            df_s[ebit_col] = df_s[gp_col] - df_s[mkt_col] - df_s[oh_col] - capex

        # EBITDA пересчёт (EBIT + D&A; D&A ≈ CAPEX аллокация как прокси)
        ebitda_col = COL["ebitda"]
        if ebit_col in df_s.columns:
            da = df_s.get(capex_col, pd.Series(0, index=df_s.index))
            df_s[ebitda_col] = df_s[ebit_col] + da

        # DSO → изменение дебиторки (IC)
        if ic_col in df_s.columns and params.dso_change_days != 0:
            daily_rev = df_s[rev_col] / 365
            ar_delta  = daily_rev * params.dso_change_days
            df_s[ic_col] = (df_s[ic_col] + ar_delta).clip(lower=0)

        # WACC сдвиг
        scenario_wacc = {k: v + params.wacc_delta for k, v in WACC_BY_COUNTRY.items()}

        # Новые SKU
        if params.new_sku_rev > 0 and rev_col in df_s.columns:
            # Распределяем пропорционально выручке
            total = df_s[rev_col].sum()
            if total > 0:
                df_s[rev_col] = df_s[rev_col] + df_s[rev_col] / total * params.new_sku_rev

        # Строим P&L
        pl = PLBuilder(df_s)
        result = pl.build(group_by)
        result["_scenario"] = params.name
        return result

    def compare(
        self,
        scenarios: list[ScenarioParams],
        group_by: Optional[list[str]] = None,
        kpis: Optional[list[str]] = None,
    ) -> pd.DataFrame:
        """
        Сравнить несколько сценариев.

        Возвращает DataFrame: строки = сценарии, колонки = KPI.
        """
        group_by = group_by or [COL["country"]]
        kpis = kpis or [
            COL["rev_net"], COL["gp"], COL["ebitda"], COL["ebit"], "EVA (EUR)"
        ]
        frames = []
        for s in scenarios:
            r = self.run(s, group_by)
            totals = {col: r[col].sum() if col in r.columns else np.nan for col in kpis}
            totals["Сценарий"] = s.name
            frames.append(totals)

        comparison = pd.DataFrame(frames).set_index("Сценарий")

        # Дельта vs первый сценарий (базовый)
        base_row = comparison.iloc[0]
        for col in comparison.columns:
            if pd.api.types.is_numeric_dtype(comparison[col]):
                comparison[f"Δ {col}"]    = comparison[col] - base_row[col]
                base_val = float(base_row[col]); denom = base_val if base_val != 0 else np.nan; comparison[f"Δ% {col}"] = (comparison[col] - base_row[col]) / denom * 100

        return comparison

    def sensitivity(
        self,
        base_params: ScenarioParams,
        param_name: str,
        values: list[float],
        target_kpi: str = COL["ebitda"],
        group_by: Optional[list[str]] = None,
    ) -> pd.DataFrame:
        """
        Анализ чувствительности: изменяем один параметр, смотрим на KPI.

        Пример:
            engine.sensitivity(base, 'price_change', [-0.1, -0.05, 0, 0.05, 0.1])
        """
        group_by = group_by or [COL["country"]]
        rows = []
        for v in values:
            p = ScenarioParams(**{**base_params.__dict__, param_name: v,
                                  "name": f"{param_name}={v:+.1%}"})
            r = self.run(p, group_by)
            kpi_val = r[target_kpi].sum() if target_kpi in r.columns else np.nan
            rows.append({"Значение параметра": v, target_kpi: kpi_val})

        sens = pd.DataFrame(rows)
        base_val = sens[target_kpi].iloc[len(values) // 2]
        sens[f"Δ {target_kpi}"]  = sens[target_kpi] - base_val
        sens[f"Δ% {target_kpi}"] = (sens[target_kpi] - base_val) / (base_val or np.nan) * 100
        return sens


# ─────────────────────────────────────────────────────────────────────────────
# FORECAST ENGINE
# ─────────────────────────────────────────────────────────────────────────────

class ForecastEngine:
    """
    Прогнозирование выручки по временному ряду.

    Поддерживает:
    - Наивный (последний год)
    - Скользящая средняя с трендом и сезонностью
    - Линейная регрессия с трендом
    - (Prophet, если установлен)

    Пример:
        fe = ForecastEngine(df)
        ts = fe.prepare_timeseries(group_by=['Страна', 'Товарная группа'])
        forecast = fe.forecast(ts, horizon=12, method='trend_seasonal')
        fe.apply_scenario(forecast, price_change=0.05)
    """

    def __init__(self, df: pd.DataFrame):
        self.df = df

    def prepare_timeseries(
        self,
        group_by: Optional[list[str]] = None,
        value_col: str = COL["rev_net"],
        freq: str = "month",
    ) -> pd.DataFrame:
        """
        Собрать временной ряд: агрегация по (group_by + год + месяц).

        Возвращает DataFrame с колонками:
          group_by... | Год | Месяц | value_col | date
        """
        time_cols = [COL["year"], COL["month"]]
        all_cols  = (group_by or []) + time_cols

        if not all(c in self.df.columns for c in all_cols + [value_col]):
            missing = [c for c in all_cols + [value_col] if c not in self.df.columns]
            raise ValueError(f"Колонки отсутствуют: {missing}")

        ts = self.df.groupby(all_cols)[value_col].sum().reset_index()
        ts["date"] = pd.to_datetime(
            ts[COL["year"]].astype(str) + "-" + ts[COL["month"]].astype(str).str.zfill(2) + "-01"
        )
        ts = ts.sort_values(["date"] + (group_by or []))
        return ts

    def calc_seasonality(
        self, ts: pd.DataFrame, value_col: str = COL["rev_net"]
    ) -> pd.DataFrame:
        """
        Рассчитать сезонный индекс по месяцам (1–12).
        SI_m = Avg(Rev в месяц m) / Avg(Rev все месяцы)
        """
        si = (
            ts.groupby(COL["month"])[value_col]
            .mean()
        )
        si_df = (si / si.mean()).reset_index()
        si_df.columns = [COL["month"], "seasonality_index"]
        return si_df

    def forecast(
        self,
        ts: pd.DataFrame,
        horizon: int = 12,
        method: str = "trend_seasonal",
        group_col: Optional[str] = None,
        value_col: str = COL["rev_net"],
        macro_adj: float = 1.0,
    ) -> pd.DataFrame:
        """
        Прогноз на *horizon* месяцев.

        method:
            'naive'           — последний месяц × SI
            'trend_seasonal'  — линейный тренд + сезонность
            'ma_seasonal'     — MA-12 + сезонность
            'prophet'         — Meta Prophet (требует pip install prophet)

        macro_adj : float
            Макро-корректировка (напр. 0.98 при ожидании падения ВВП на 2%).
        """
        if method == "prophet":
            return self._forecast_prophet(ts, horizon, group_col, value_col, macro_adj)

        # Общий случай: группируем если нужно
        if group_col and group_col in ts.columns:
            groups = ts[group_col].unique()
            parts  = []
            for g in groups:
                sub = ts[ts[group_col] == g].copy()
                fcast = self._forecast_single(sub, horizon, method, value_col, macro_adj)
                fcast[group_col] = g
                parts.append(fcast)
            return pd.concat(parts, ignore_index=True)

        return self._forecast_single(ts, horizon, method, value_col, macro_adj)

    def _forecast_single(
        self, ts: pd.DataFrame, horizon: int, method: str, value_col: str, macro_adj: float
    ) -> pd.DataFrame:
        ts = ts.sort_values("date").copy()
        si = self.calc_seasonality(ts, value_col)

        last_date = ts["date"].max()
        future_dates = pd.date_range(
            start=last_date + pd.DateOffset(months=1),
            periods=horizon,
            freq="MS",
        )

        if method == "naive":
            base = ts[value_col].iloc[-12:].mean()
            preds = []
            for d in future_dates:
                m = d.month
                si_m = si[si[COL["month"]] == m]["seasonality_index"].values
                s = float(si_m[0]) if len(si_m) else 1.0
                preds.append(base * s * macro_adj)

        elif method == "ma_seasonal":
            ma12 = ts[value_col].rolling(12, min_periods=1).mean().iloc[-1]
            yoy  = ts[value_col].pct_change(12).dropna().mean()
            preds = []
            for i, d in enumerate(future_dates):
                m = d.month
                si_m = si[si[COL["month"]] == m]["seasonality_index"].values
                s = float(si_m[0]) if len(si_m) else 1.0
                month_factor = (1 + yoy) ** (i / 12)
                preds.append(ma12 * month_factor * s * macro_adj)

        else:  # trend_seasonal (default)
            ts["_t"] = np.arange(len(ts))
            ts_clean = ts[[value_col, "_t"]].dropna()
            if len(ts_clean) < 2:
                preds = [ts[value_col].mean() * macro_adj] * horizon
            else:
                X = np.column_stack([np.ones(len(ts_clean)), ts_clean["_t"].values])
                y = ts_clean[value_col].values
                try:
                    beta = np.linalg.lstsq(X, y, rcond=None)[0]
                except Exception:
                    beta = [y.mean(), 0]
                start_t = len(ts)
                preds = []
                for i, d in enumerate(future_dates):
                    m = d.month
                    trend = beta[0] + beta[1] * (start_t + i)
                    si_m  = si[si[COL["month"]] == m]["seasonality_index"].values
                    s = float(si_m[0]) if len(si_m) else 1.0
                    preds.append(max(0, trend * s * macro_adj))

        return pd.DataFrame({
            "date":     future_dates,
            COL["year"]:  future_dates.year,
            COL["month"]: future_dates.month,
            value_col:    preds,
            "method":     method,
            "is_forecast": True,
        })

    def _forecast_prophet(
        self, ts: pd.DataFrame, horizon: int, group_col: Optional[str],
        value_col: str, macro_adj: float
    ) -> pd.DataFrame:
        try:
            from prophet import Prophet  # type: ignore
        except ImportError:
            raise ImportError("pip install prophet")

        if group_col and group_col in ts.columns:
            parts = []
            for g in ts[group_col].unique():
                sub = ts[ts[group_col] == g][["date", value_col]].rename(
                    columns={"date": "ds", value_col: "y"}
                )
                m = Prophet(yearly_seasonality=True, weekly_seasonality=False)
                m.fit(sub)
                future = m.make_future_dataframe(periods=horizon, freq="MS")
                fc = m.predict(future).tail(horizon)[["ds", "yhat"]]
                fc.columns = ["date", value_col]
                fc[value_col] *= macro_adj
                fc[group_col] = g
                fc["method"] = "prophet"
                fc["is_forecast"] = True
                parts.append(fc)
            return pd.concat(parts, ignore_index=True)

        sub = ts[["date", value_col]].rename(columns={"date": "ds", value_col: "y"})
        m = Prophet(yearly_seasonality=True, weekly_seasonality=False)
        m.fit(sub)
        future = m.make_future_dataframe(periods=horizon, freq="MS")
        fc = m.predict(future).tail(horizon)[["ds", "yhat"]]
        fc.columns = ["date", value_col]
        fc[value_col] = (fc[value_col] * macro_adj).clip(lower=0)
        fc["method"] = "prophet"
        fc["is_forecast"] = True
        return fc

    def apply_scenario(
        self,
        forecast: pd.DataFrame,
        value_col: str = COL["rev_net"],
        **kwargs,
    ) -> pd.DataFrame:
        """
        Наложить сценарные изменения на прогноз.

        kwargs: те же, что у ScenarioParams
          price_change=0.05, volume_change=-0.03, ...
        """
        fc = forecast.copy()
        factor = (1 + kwargs.get("price_change", 0)) * (1 + kwargs.get("volume_change", 0))
        if value_col in fc.columns:
            fc[f"{value_col}_scenario"] = fc[value_col] * factor
        return fc

    def cascade_forecast(
        self,
        df: pd.DataFrame,
        hierarchy: list[str],
        horizon: int = 12,
        method: str = "trend_seasonal",
        value_col: str = COL["rev_net"],
        macro_adj: float = 1.0,
    ) -> pd.DataFrame:
        """
        Иерархический (каскадный) прогноз снизу вверх.

        hierarchy: список от нижнего к верхнему,
            напр. ['Артикул', 'Товарная группа', 'Филиал', 'Страна']

        Алгоритм:
          1. Прогноз на уровне SKU (нижний уровень)
          2. Агрегация снизу вверх
          3. Reconciliation: корректировка прогноза нижнего уровня
             так чтобы сумма = прогнозу верхнего уровня.
        """
        bottom = hierarchy[0]
        ts_bottom = self.prepare_timeseries(
            group_by=[bottom], value_col=value_col
        )
        fcast_bottom = self.forecast(
            ts_bottom, horizon=horizon, method=method,
            group_col=bottom, value_col=value_col, macro_adj=macro_adj
        )

        # Агрегируем для верхнего уровня как top-level прогноз
        ts_top = self.prepare_timeseries(value_col=value_col)
        fcast_top = self.forecast(
            ts_top, horizon=horizon, method=method, value_col=value_col, macro_adj=macro_adj
        )

        # Reconciliation
        top_total = fcast_top.groupby("date")[value_col].sum()
        bottom_total = fcast_bottom.groupby("date")[value_col].sum()
        scale = top_total / bottom_total.replace(0, np.nan)

        fcast_bottom = fcast_bottom.merge(
            scale.rename("_scale").reset_index(), on="date", how="left"
        )
        fcast_bottom[f"{value_col}_reconciled"] = (
            fcast_bottom[value_col] * fcast_bottom["_scale"].fillna(1)
        )
        fcast_bottom.drop(columns=["_scale"], inplace=True)
        return fcast_bottom


# ─────────────────────────────────────────────────────────────────────────────
# УТИЛИТЫ
# ─────────────────────────────────────────────────────────────────────────────

def load_data(path: str, sheet: str = "01_Данные_KPI") -> pd.DataFrame:
    """Загрузить данные из Excel-файла."""
    return pd.read_excel(path, sheet_name=sheet)


def eva_by_group(
    df: pd.DataFrame,
    group_by: list[str],
) -> pd.DataFrame:
    """
    Рассчитать EVA для каждой группы.

    EVA = EBIT × (1 − Tax) − WACC × IC
    """
    agg = df.groupby(group_by).agg({
        COL["ebit"]: "sum",
        COL["ic"]:   "sum",
    }).reset_index()

    country_col = COL["country"]
    if country_col in agg.columns:
        agg["_tax"]  = agg[country_col].map(TAX_RATES).fillna(0.15)
        agg["_wacc"] = agg[country_col].map(WACC_BY_COUNTRY).fillna(0.08)
    else:
        agg["_tax"]  = 0.15
        agg["_wacc"] = 0.08

    agg["NOPAT"] = agg[COL["ebit"]] * (1 - agg["_tax"])
    agg["EVA"]   = agg["NOPAT"] - agg["_wacc"] * agg[COL["ic"]]
    return agg.drop(columns=["_tax", "_wacc"])


def bcg_classify(
    df: pd.DataFrame,
    sku_col: str = COL["sku"],
    rev_col: str = COL["rev_net"],
    category_col: str = COL["category"],
    year_col: str = COL["year"],
    current_year: Optional[int] = None,
    prev_year: Optional[int] = None,
) -> pd.DataFrame:
    """
    Классифицировать SKU по BCG-матрице.

    Returns DataFrame с колонками: sku, category, rev_current, rev_prev,
    growth_yoy, market_share, bcg_quadrant.
    """
    years = sorted(df[year_col].unique())
    if current_year is None:
        current_year = years[-1]
    if prev_year is None:
        prev_year = years[-2] if len(years) >= 2 else current_year

    cur = df[df[year_col] == current_year].groupby([sku_col, category_col])[rev_col].sum().reset_index()
    prv = df[df[year_col] == prev_year].groupby([sku_col, category_col])[rev_col].sum().reset_index()
    prv.columns = [sku_col, category_col, "rev_prev"]

    merged = cur.merge(prv, on=[sku_col, category_col], how="left")
    merged.rename(columns={rev_col: "rev_current"}, inplace=True)
    merged["growth_yoy"] = (merged["rev_current"] - merged["rev_prev"]) / merged["rev_prev"].replace(0, np.nan) * 100

    cat_total = merged.groupby(category_col)["rev_current"].sum().rename("cat_total")
    merged    = merged.merge(cat_total.reset_index(), on=category_col)
    merged["market_share"] = merged["rev_current"] / merged["cat_total"].replace(0, np.nan) * 100

    median_share  = merged["market_share"].median()
    median_growth = merged["growth_yoy"].median()

    def classify(row):
        high_share  = row["market_share"] > median_share
        high_growth = row["growth_yoy"]   > median_growth
        if   high_share and high_growth:  return "Star"
        elif high_share and not high_growth: return "Cash Cow"
        elif not high_share and high_growth: return "Question Mark"
        else: return "Dog"

    merged["bcg_quadrant"] = merged.apply(classify, axis=1)
    return merged


def payback_period(
    df: pd.DataFrame,
    sku_col: str = COL["sku"],
    gp_col:  str = COL["gp"],
    ic_col:  str = COL["ic"],
) -> pd.DataFrame:
    """
    Срок окупаемости по SKU: IC / Annual_GP.
    """
    annual = df.groupby(sku_col).agg({gp_col: "sum", ic_col: "sum"}).reset_index()
    annual["payback_years"] = annual[ic_col] / annual[gp_col].replace(0, np.nan)
    return annual


if __name__ == "__main__":
    # ── Пример использования ──────────────────────────────────────────────
    import sys

    path = sys.argv[1] if len(sys.argv) > 1 else "sales_analytics_2015_2026.xlsx"

    print("Загружаем данные…")
    try:
        df = load_data(path)
        print(f"  Загружено {len(df):,} строк, {len(df.columns)} колонок")
    except Exception as e:
        print(f"  Ошибка загрузки: {e}")
        print("  Создаём тестовые данные…")
        rng = np.random.default_rng(42)
        n = 1000
        df = pd.DataFrame({
            COL["country"]:  rng.choice(["Германия", "Польша", "Франция"], n),
            COL["branch"]:   rng.choice(["Берлин", "Варшава", "Париж"], n),
            COL["year"]:     rng.choice(range(2015, 2027), n),
            COL["month"]:    rng.choice(range(1, 13), n),
            COL["category"]: rng.choice(["Электроника", "Одежда", "Косметика"], n),
            COL["sku"]:      [f"SKU-{i:04d}" for i in rng.integers(1, 50, n)],
            COL["qty"]:      rng.integers(1, 200, n),
            COL["price"]:    rng.uniform(20, 800, n),
            COL["cost"]:     rng.uniform(15, 600, n),
            COL["rev_net"]:  rng.uniform(1000, 100000, n),
            COL["cogs"]:     rng.uniform(500, 70000, n),
            COL["gp"]:       rng.uniform(200, 30000, n),
            COL["ebit"]:     rng.uniform(100, 20000, n),
            COL["ebitda"]:   rng.uniform(150, 25000, n),
            COL["mc"]:       rng.uniform(200, 28000, n),
            COL["marketing"]:rng.uniform(50, 5000, n),
            COL["ic"]:       rng.uniform(1000, 50000, n),
            COL["inventory"]:rng.uniform(500, 20000, n),
            COL["provision"]:rng.uniform(10, 2000, n),
            COL["overhead"]: rng.uniform(100, 8000, n),
        })

    print("\n── KPI Calculator ─────────────────────────────────────────────")
    calc = KPICalculator(df, verify=False)
    summary = calc.summary([COL["country"], COL["year"]])
    print(summary[[COL["country"], COL["year"], COL["rev_net"], COL["gp"]]].head(10).to_string(index=False))

    print("\n── Сценарный анализ ────────────────────────────────────────────")
    engine = ScenarioEngine(df, calc)
    scenarios = [
        ScenarioParams(name="Базовый"),
        ScenarioParams(name="Цена +5%, Объём -3%",    price_change=0.05,  volume_change=-0.03),
        ScenarioParams(name="Цена -10%, Объём +15%",  price_change=-0.10, volume_change=0.15),
        ScenarioParams(name="COGS -8%, DSO -15 дней", cogs_change=-0.08,  dso_change_days=-15),
        ScenarioParams(name="Стресс: цена -15%",      price_change=-0.15),
    ]
    comparison = engine.compare(scenarios, group_by=[COL["country"]])
    print(comparison[[COL["rev_net"], COL["gp"], COL["ebitda"]]].to_string())

    print("\n── Анализ чувствительности: цена → EBITDA ──────────────────────")
    sens = engine.sensitivity(
        ScenarioParams(name="Base"),
        "price_change",
        [-0.15, -0.10, -0.05, 0, 0.05, 0.10, 0.15],
        target_kpi=COL["ebitda"],
        group_by=[COL["country"]],
    )
    print(sens.to_string(index=False))

    print("\n── Прогноз выручки (12 мес., trend_seasonal) ───────────────────")
    fe = ForecastEngine(df)
    try:
        ts = fe.prepare_timeseries(group_by=[COL["country"]])
        fc = fe.forecast(ts, horizon=12, method="trend_seasonal",
                         group_col=COL["country"], macro_adj=0.97)
        print(fc[[COL["country"], "date", COL["rev_net"]]].head(15).to_string(index=False))
    except Exception as e:
        print(f"  Ошибка прогноза: {e}")

    print("\n── BCG классификация ────────────────────────────────────────────")
    try:
        bcg = bcg_classify(df)
        print(bcg["bcg_quadrant"].value_counts().to_string())
    except Exception as e:
        print(f"  {e}")

    print("\n── EVA по стране × году ─────────────────────────────────────────")
    try:
        eva = eva_by_group(df, [COL["country"], COL["year"]])
        print(eva[[COL["country"], COL["year"], "EVA"]].head(10).to_string(index=False))
    except Exception as e:
        print(f"  {e}")

    print("\nГотово.")
