# KPI Engine — Инструкция по тестированию

## Что тестируется

| Файл тестов | Покрытие | Тестов |
|---|---|---|
| `test_health.py` | `/health`, `/`, `/docs`, CORS | 8 |
| `test_kpi.py` | `POST /api/kpi/summary` | 14 |
| `test_scenario.py` | `/run`, `/compare`, `/sensitivity` | 22 |
| `test_forecast.py` | `/run`, `/cascade` | 21 |
| `test_portfolio.py` | `/bcg`, `/eva`, `/payback` | 28 |
| `test_cache.py` | Cache TTL, eviction, make_key | 13 |
| `test_adapters.py` | MockAdapter, ExcelAdapter | 12 |
| **Итого** | | **118** |

Все тесты работают без внешних сервисов — используется MockAdapter (500 синтетических строк).

---

## Быстрый старт

### 1. Установка зависимостей

```bash
# Из корня проекта (там где sales_kpi.py и папка kpi_service/)
pip install -r kpi_service/requirements-dev.txt
```

### 2. Запуск всех тестов

```bash
python -m pytest kpi_service/tests/ -c pytest_kpi.ini
```

Ожидаемый результат:
```
118 passed in ~3s
```

### 3. Запуск с покрытием

```bash
python -m pytest kpi_service/tests/ -c pytest_kpi.ini \
  --cov=kpi_service --cov=sales_kpi \
  --cov-report=term-missing \
  --cov-report=html:htmlcov
# Открыть htmlcov/index.html для детального отчёта
```

### 4. Запуск отдельных групп

```bash
# Только здоровье сервиса
python -m pytest kpi_service/tests/test_health.py -v

# Только сценарный анализ
python -m pytest kpi_service/tests/test_scenario.py -v

# Только прогнозы
python -m pytest kpi_service/tests/test_forecast.py -v

# Только портфельный анализ
python -m pytest kpi_service/tests/test_portfolio.py -v

# Конкретный тест
python -m pytest kpi_service/tests/test_scenario.py::TestScenarioCompare::test_optimistic_better_than_stress -v
```

---

## Тестирование с реальными данными

### Вариант A — Excel файл

```bash
# Установить переменную окружения и запустить сервер
export EXCEL_PATH=data/demo/sales_analytics_2015_2026.xlsx
export EXCEL_SHEET="01_Данные_KPI"
export LOG_LEVEL=INFO

uvicorn kpi_service.main:app --port 8100 --reload
```

Затем открыть в браузере: http://localhost:8100/docs

### Вариант B — DuckDB (из sales-bi-platform)

```bash
export DUCKDB_PATH=data/duckdb/analytics.duckdb
export DUCKDB_TABLE=sales_transactions   # или как называется в вашем DuckDB

uvicorn kpi_service.main:app --port 8100 --reload
```

---

## Ручное тестирование через curl

После запуска сервера:

```bash
# Health check
curl http://localhost:8100/health | python3 -m json.tool

# KPI Summary: выручка и маржа по стране × году
curl -X POST http://localhost:8100/api/kpi/summary \
  -H "Content-Type: application/json" \
  -d '{"group_by": ["Страна", "Год"], "filters": {}}' \
  | python3 -m json.tool

# KPI с фильтром по стране
curl -X POST http://localhost:8100/api/kpi/summary \
  -H "Content-Type: application/json" \
  -d '{"group_by": ["Год", "Товарная группа"], "filters": {"country": "Германия"}}' \
  | python3 -m json.tool

# Сценарий: цена +5%, объём -3%
curl -X POST http://localhost:8100/api/scenario/run \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Цена+5/Объём-3",
    "price_change": 0.05,
    "volume_change": -0.03,
    "group_by": ["Страна"]
  }' | python3 -m json.tool

# Сравнение сценариев
curl -X POST http://localhost:8100/api/scenario/compare \
  -H "Content-Type: application/json" \
  -d '{
    "scenarios": [
      {"name": "Базовый"},
      {"name": "Оптимистичный", "price_change": 0.05, "volume_change": 0.03},
      {"name": "Стресс",        "price_change": -0.15, "volume_change": -0.10}
    ],
    "kpis": ["Выручка нетто (EUR)", "EBITDA (EUR)"],
    "group_by": ["Страна"]
  }' | python3 -m json.tool

# Анализ чувствительности: цена [-15%, +15%] → EBITDA
curl -X POST http://localhost:8100/api/scenario/sensitivity \
  -H "Content-Type: application/json" \
  -d '{
    "base_scenario": {"name": "base"},
    "param_name": "price_change",
    "values": [-0.15, -0.10, -0.05, 0, 0.05, 0.10, 0.15],
    "target_kpi": "EBITDA (EUR)",
    "group_by": ["Страна"]
  }' | python3 -m json.tool

# Прогноз: 12 месяцев по странам
curl -X POST http://localhost:8100/api/forecast/run \
  -H "Content-Type: application/json" \
  -d '{
    "horizon": 12,
    "method": "trend_seasonal",
    "group_col": "Страна",
    "macro_adj": 0.97
  }' | python3 -m json.tool

# BCG-матрица
curl -X POST http://localhost:8100/api/portfolio/bcg \
  -H "Content-Type: application/json" \
  -d '{}' | python3 -m json.tool

# EVA по стране и году
curl -X POST http://localhost:8100/api/portfolio/eva \
  -H "Content-Type: application/json" \
  -d '{"group_by": ["Страна", "Год"]}' | python3 -m json.tool

# Срок окупаемости
curl http://localhost:8100/api/portfolio/payback | python3 -m json.tool
```

---

## Тестирование через Python-скрипт

```python
import httpx

BASE = "http://localhost:8100/api"

with httpx.Client() as c:
    # Health
    print(c.get("http://localhost:8100/health").json())

    # KPI сводка
    r = c.post(f"{BASE}/kpi/summary", json={
        "group_by": ["Страна", "Год"],
        "filters": {}
    })
    data = r.json()
    print(f"Строк: {data['row_count']}, источник: {data['source']}")

    # Сценарий
    r = c.post(f"{BASE}/scenario/run", json={
        "name": "test",
        "price_change": 0.05,
        "group_by": ["Страна"]
    })
    for delta in r.json()["deltas"][:3]:
        print(f"{delta['kpi']}: {delta['delta_pct']:+.1f}%")
```

---

## Docker запуск (полный стек)

```bash
# Из папки tools-board (когда будет создана)
docker compose up kpi-engine

# Или напрямую из корня
docker build -f kpi_service/Dockerfile -t kpi-engine .
docker run -p 8100:8100 \
  -e EXCEL_PATH=/data/sales_analytics_2015_2026.xlsx \
  -v $(pwd)/data:/data \
  kpi-engine
```

---

## Структура тестовых данных (MockAdapter)

MockAdapter генерирует 300 строк (seed=0) с:
- **Страны:** Германия, Польша, Франция
- **Годы:** 2020–2025
- **Месяцы:** 1–12
- **Категории:** Электроника, Одежда, Косметика
- **SKU:** SKU-001 … SKU-029 (29 уникальных)
- **Выручка нетто:** 5 000 – 80 000 EUR / строка
- **Все KPI-колонки** из sales_kpi.COL

Данные детерминированы через seed=0 — тесты воспроизводимы.

---

## Известные предупреждения

```
StarletteDeprecationWarning: Using `httpx` with `starlette.testclient`...
```
Это предупреждение от Starlette — не влияет на работу тестов.
Исчезнет при обновлении до `httpx2` (roadmap FastAPI).
